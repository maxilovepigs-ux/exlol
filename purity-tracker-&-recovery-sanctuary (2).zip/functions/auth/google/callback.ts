// Types
type PagesFunction<Env = any> = (context: { request: Request; env: Env; params: Record<string, string | string[]> }) => Promise<Response> | Response;

interface DBStructure {
  users: Record<string, any>;
  leaderboard: Array<any>;
  chatMessages: Array<any>;
  supportTickets: Array<any>;
}

const DEFAULT_LEADERBOARD = [
  {
    id: "sim-1",
    username: "Marcus_Aurelius_Will",
    avatarUrl: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80",
    currentStreak: 124,
    highestStreak: 124,
    level: 18,
    title: "Ascended Spirit",
    isRealUser: false,
    statusMessage: "The happiness of your life depends upon the quality of your thoughts. Stand firm."
  },
  {
    id: "sim-2",
    username: "Socrates_Mind",
    avatarUrl: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&auto=format&fit=crop&q=80",
    currentStreak: 78,
    highestStreak: 105,
    level: 14,
    title: "Aegis of Integrity",
    isRealUser: false,
    statusMessage: "The secret of change is to focus all of your energy, not on fighting the old, but on building the new."
  },
  {
    id: "sim-3",
    username: "ZenMaster_Kai",
    avatarUrl: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&auto=format&fit=crop&q=80",
    currentStreak: 45,
    highestStreak: 45,
    level: 9,
    title: "Sovereign of Focus",
    isRealUser: false,
    statusMessage: "The urge is like a wave in the ocean. Ride it with mindful breathing. It always subsides."
  }
];

let memoryDb: DBStructure = {
  users: {},
  leaderboard: DEFAULT_LEADERBOARD,
  chatMessages: [],
  supportTickets: []
};

const findKV = (env: any) => {
  if (!env) return null;
  for (const key of Object.keys(env)) {
    const val = env[key];
    if (val && typeof val.get === "function" && typeof val.put === "function") {
      return val;
    }
  }
  return null;
};

async function readDB(env: any): Promise<DBStructure> {
  const kv = findKV(env);
  if (kv) {
    const cached = await kv.get("sanctuary_database");
    if (cached) {
      try {
        const parsed = JSON.parse(cached);
        if (!parsed.users) parsed.users = {};
        if (!parsed.leaderboard) parsed.leaderboard = DEFAULT_LEADERBOARD;
        if (!parsed.chatMessages) parsed.chatMessages = [];
        if (!parsed.supportTickets) parsed.supportTickets = [];
        return parsed;
      } catch (err) {
        console.error("KV parsing failed", err);
      }
    }
  }
  return memoryDb;
}

async function writeDB(db: DBStructure, env: any) {
  const kv = findKV(env);
  if (kv) {
    await kv.put("sanctuary_database", JSON.stringify(db));
  } else {
    memoryDb = db;
  }
}

function calculateLevelAndTitle(xp: number, streakDays: number): { level: number; title: string } {
  const level = Math.floor(xp / 200) + 1;
  let title = "Seed of Will";
  if (streakDays >= 90) title = "Ascended Spirit";
  else if (streakDays >= 60) title = "Aegis of Integrity";
  else if (streakDays >= 30) title = "Sovereign of Focus";
  else if (streakDays >= 15) title = "Defender of Purity";
  else if (streakDays >= 7) title = "Guardian of the Mind";
  else if (streakDays >= 3) title = "Sprout of Discipline";
  return { level, title };
}

function getStreakDays(startDateStr: string | null): number {
  if (!startDateStr) return 0;
  const start = new Date(startDateStr);
  const now = new Date();
  const diffTime = Math.abs(now.getTime() - start.getTime());
  return Math.floor(diffTime / (1000 * 60 * 60 * 24));
}

export const onRequest: PagesFunction<{ GOOGLE_CLIENT_ID?: string; GOOGLE_CLIENT_SECRET?: string }> = async (context) => {
  const { request, env } = context;
  const url = new URL(request.url);
  const code = url.searchParams.get("code");
  const queryEmail = url.searchParams.get("email");
  const queryName = url.searchParams.get("name");

  let email = queryEmail || null;
  let name = queryName || null;

  const referer = request.headers.get("referer");
  const origin = referer ? new URL(referer).origin : url.origin;
  const redirectUri = `${origin}/auth/google/callback`;

  // 1. Exchange real Google OAuth code if Client ID is configured
  const clientId = env.GOOGLE_CLIENT_ID;
  if (clientId && clientId !== "MY_GOOGLE_CLIENT_ID" && code && code !== "sim_code") {
    try {
      const tokenResponse = await fetch("https://oauth2.googleapis.com/token", {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: new URLSearchParams({
          code: String(code),
          client_id: clientId,
          client_secret: env.GOOGLE_CLIENT_SECRET || "",
          redirect_uri: redirectUri,
          grant_type: "authorization_code"
        })
      });

      if (!tokenResponse.ok) {
        throw new Error("Failed to exchange code for Google token");
      }

      const tokenData = await tokenResponse.json() as any;
      const profileResponse = await fetch("https://www.googleapis.com/oauth2/v3/userinfo", {
        headers: { Authorization: `Bearer ${tokenData.access_token}` }
      });

      if (profileResponse.ok) {
        const profile = await profileResponse.json() as any;
        email = profile.email;
        name = profile.name || profile.given_name || email!.split("@")[0];
      }
    } catch (err) {
      console.error("Cloudflare OAuth Callback Error:", err);
      return new Response("<h3>Google Authorization Failed. Please try again.</h3>", {
        status: 500,
        headers: { "Content-Type": "text/html" }
      });
    }
  }

  if (!email) {
    return new Response("<h3>Failed to retrieve Google identity. Please try again.</h3>", {
      status: 400,
      headers: { "Content-Type": "text/html" }
    });
  }

  const db = await readDB(env);
  const lowerEmail = email.toLowerCase();
  let user = Object.values(db.users).find(u => u.email.toLowerCase() === lowerEmail);

  if (!user) {
    const userId = "user_" + Math.random().toString(36).substring(2, 11);
    const now = new Date().toISOString();
    const cleanUsername = (name || email.split("@")[0]).replace(/[^a-zA-Z0-9_]/g, "_");

    user = {
      id: userId,
      username: cleanUsername,
      email: email,
      password: "google_oauth_authorized_" + Math.random().toString(36).substring(2, 11),
      avatarUrl: `https://api.dicebear.com/7.x/bottts/svg?seed=${cleanUsername}`,
      streakStartDate: now,
      highestStreak: 0,
      totalXp: 100,
      level: 1,
      title: "Seed of Will",
      joinedDate: now,
      equippedBadgeId: null,
      logs: [],
      triggers: [],
      statusMessage: "Aligned mind and spirit via Google.",
      streakFreezes: 1,
      lastEarnedFreezeMonth: null,
      role: (lowerEmail === "max@carsonmail.uk" || cleanUsername === "ollymckee101") ? "moderator" : "user"
    };

    db.users[userId] = user;
  } else {
    user.role = (lowerEmail === "max@carsonmail.uk" || user.username === "ollymckee101") ? "moderator" : (user.role || "user");
  }

  const currentStreak = getStreakDays(user.streakStartDate);
  const { level, title } = calculateLevelAndTitle(user.totalXp, currentStreak);
  user.level = level;
  user.title = title;
  if (currentStreak > user.highestStreak) {
    user.highestStreak = currentStreak;
  }

  db.users[user.id] = user;
  await writeDB(db, env);

  const { password: _, ...userSafe } = user;

  const responseHtml = `
    <!DOCTYPE html>
    <html lang="en">
    <head>
      <meta charset="UTF-8">
      <title>Sanctuary Handshake complete</title>
      <style>
        body {
          background-color: #0A0A0B;
          color: #E5E5E5;
          font-family: sans-serif;
          display: flex;
          flex-direction: column;
          align-items: center;
          justify-content: center;
          height: 100vh;
          margin: 0;
          text-align: center;
        }
        .spinner {
          border: 4px solid rgba(245,158,11,0.1);
          border-left-color: #F59E0B;
          border-radius: 50%;
          width: 36px;
          height: 36px;
          animation: spin 1s linear infinite;
          margin-bottom: 20px;
        }
        @keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }
      </style>
    </head>
    <body>
      <div class="spinner"></div>
      <h3>Handshake Complete</h3>
      <p style="color: #888888; font-size: 13px;">Sanctuary is syncing your profile. This window will close automatically.</p>
      
      <script>
        try {
          if (window.opener) {
            window.opener.postMessage({ 
              type: 'OAUTH_AUTH_SUCCESS', 
              user: ${JSON.stringify(userSafe)} 
            }, '*');
            window.close();
          } else {
            window.location.href = '/';
          }
        } catch (err) {
          console.error("PostMessage failed:", err);
          window.location.href = '/';
        }
      </script>
    </body>
    </html>
  `;

  return new Response(responseHtml, {
    headers: { "Content-Type": "text/html" }
  });
};
