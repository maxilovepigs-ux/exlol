import { GoogleGenAI, Type } from "@google/genai";

type PagesFunction<Env = any> = (context: { request: Request; env: Env; params: Record<string, string | string[]> }) => Promise<Response> | Response;

interface DBStructure {
  users: Record<string, any>;
  leaderboard: Array<{
    id: string;
    username: string;
    avatarUrl: string;
    currentStreak: number;
    highestStreak: number;
    level: number;
    title: string;
    isRealUser: boolean;
    statusMessage: string;
  }>;
  chatMessages: Array<{
    id: string;
    userId: string;
    username: string;
    avatarUrl: string;
    text: string;
    timestamp: string;
    level: number;
    title: string;
  }>;
  supportTickets: Array<{
    id: string;
    userId: string;
    username: string;
    avatarUrl: string;
    title: string;
    status: "open" | "resolved";
    type: "ai" | "real";
    messages: Array<{
      id: string;
      sender: "user" | "ai" | "mod";
      senderName: string;
      text: string;
      createdAt: string;
    }>;
    createdAt: string;
  }>;
  dailyQuote?: {
    date: string;
    quote: string;
    author: string;
    commentary: string;
    school: string;
  };
  securityLogs?: Array<{
    id: string;
    timestamp: string;
    eventType: "FAILED_LOGIN" | "UNUSUAL_ACCESS" | "ROLE_CHANGE" | "ABNORMAL_REQUEST" | "XSS_ATTEMPT";
    description: string;
    userId?: string;
    severity: "low" | "medium" | "high" | "critical";
  }>;
}

const DEFAULT_LEADERBOARD = [
  {
    id: "sim-1",
    username: "Marcus_Aurelius_Will",
    avatarUrl: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80",
    currentStreak: 124,
    highestStreak: 124,
    level: 18,
    title: "Ascended Spirit",
    isRealUser: false,
    statusMessage: "The happiness of your life depends upon the quality of your thoughts. Stand firm."
  },
  {
    id: "sim-2",
    username: "Socrates_Mind",
    avatarUrl: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&auto=format&fit=crop&q=80",
    currentStreak: 78,
    highestStreak: 105,
    level: 14,
    title: "Aegis of Integrity",
    isRealUser: false,
    statusMessage: "The secret of change is to focus all of your energy, not on fighting the old, but on building the new."
  },
  {
    id: "sim-3",
    username: "ZenMaster_Kai",
    avatarUrl: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&auto=format&fit=crop&q=80",
    currentStreak: 45,
    highestStreak: 45,
    level: 9,
    title: "Sovereign of Focus",
    isRealUser: false,
    statusMessage: "The urge is like a wave in the ocean. Ride it with mindful breathing. It always subsides."
  },
  {
    id: "sim-4",
    username: "Purity_Warrior",
    avatarUrl: "https://images.unsplash.com/photo-1519345182560-3f2917c472ef?w=150&auto=format&fit=crop&q=80",
    currentStreak: 24,
    highestStreak: 35,
    level: 6,
    title: "Defender of Purity",
    isRealUser: false,
    statusMessage: "Relapsed at 35 days, but we rise back! Day 24 and feeling stronger than ever."
  },
  {
    id: "sim-5",
    username: "Clarity_Seeker",
    avatarUrl: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=150&auto=format&fit=crop&q=80",
    currentStreak: 12,
    highestStreak: 12,
    level: 4,
    title: "Guardian of the Mind",
    isRealUser: false,
    statusMessage: "Using the Urge SOS Box Breathing helped me crush a massive late-night trigger."
  },
  {
    id: "sim-6",
    username: "Sovereign_Willpower",
    avatarUrl: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=150&auto=format&fit=crop&q=80",
    currentStreak: 5,
    highestStreak: 18,
    level: 2,
    title: "Sprout of Discipline",
    isRealUser: false,
    statusMessage: "Social media clean-up complete. Reducing digital temptation is key!"
  }
];

const FALLBACK_PHILOSOPHY_QUOTES = [
  {
    quote: "The happiness of your life depends upon the quality of your thoughts.",
    author: "Marcus Aurelius",
    school: "Stoicism",
    commentary: "Your mind is your ultimate sanctuary. When urges arise, recognize them as mere chemical signals, and choose to focus your thoughts on your higher goals and inner strength."
  },
  {
    quote: "No man is free who is not master of himself.",
    author: "Epictetus",
    school: "Stoicism",
    commentary: "True liberty is not the license to follow every fleeting physical desire, but the sovereignty to veto impulses that undermine your character and spirit."
  },
  {
    quote: "We suffer more often in imagination than in reality.",
    author: "Seneca",
    school: "Stoicism",
    commentary: "An urge can feel like an unbearable storm in your thoughts, but in reality, it is just a passing sensation. Surf the wave; it has no physical power over you."
  },
  {
    quote: "He who conquers others is strong; he who conquers himself is mighty.",
    author: "Lao Tzu",
    school: "Taoism",
    commentary: "The greatest battle is always internal. Restraining yourself from immediate gratification is a sign of ultimate personal power and mastery."
  },
  {
    quote: "He who has a why to live can bear almost any how.",
    author: "Friedrich Nietzsche",
    school: "Existentialism",
    commentary: "Connect deeply with your purpose—whether it is clear cognitive focus, self-respect, or pure energy. A strong 'why' makes any urge easy to overcome."
  },
  {
    quote: "You have power over your mind - not outside events. Realize this, and you will find strength.",
    author: "Marcus Aurelius",
    school: "Stoicism",
    commentary: "Triggers will always exist in the digital world. You cannot control what appears, but you have absolute power over how you respond. Reclaim your focus."
  }
];

// Memory state persists during active hot lambdas on Cloudflare
let memoryDb: DBStructure = {
  users: {},
  leaderboard: DEFAULT_LEADERBOARD,
  chatMessages: [],
  supportTickets: []
};

// Automatic KV Namespace binding detector
const findKV = (env: any) => {
  if (!env) return null;
  for (const key of Object.keys(env)) {
    const val = env[key];
    if (val && typeof val.get === "function" && typeof val.put === "function") {
      return val;
    }
  }
  return null;
};

async function readDB(env: any): Promise<DBStructure> {
  const kv = findKV(env);
  if (kv) {
    const cached = await kv.get("sanctuary_database");
    if (cached) {
      try {
        const parsed = JSON.parse(cached);
        if (!parsed.users) parsed.users = {};
        if (!parsed.leaderboard) parsed.leaderboard = DEFAULT_LEADERBOARD;
        if (!parsed.chatMessages) parsed.chatMessages = [];
        if (!parsed.supportTickets) parsed.supportTickets = [];
        return parsed;
      } catch (err) {
        console.error("KV parsing failed", err);
      }
    }
  }
  return memoryDb;
}

async function writeDB(db: DBStructure, env: any) {
  const kv = findKV(env);
  if (kv) {
    await kv.put("sanctuary_database", JSON.stringify(db));
  } else {
    memoryDb = db;
  }
}

// Level and Title Calculators
function calculateLevelAndTitle(xp: number, streakDays: number): { level: number; title: string } {
  const level = Math.floor(xp / 200) + 1;
  let title = "Seed of Will";
  if (streakDays >= 90) title = "Ascended Spirit";
  else if (streakDays >= 60) title = "Aegis of Integrity";
  else if (streakDays >= 30) title = "Sovereign of Focus";
  else if (streakDays >= 15) title = "Defender of Purity";
  else if (streakDays >= 7) title = "Guardian of the Mind";
  else if (streakDays >= 3) title = "Sprout of Discipline";
  return { level, title };
}

function getStreakDays(startDateStr: string | null): number {
  if (!startDateStr) return 0;
  const start = new Date(startDateStr);
  const now = new Date();
  const diffTime = Math.abs(now.getTime() - start.getTime());
  return Math.floor(diffTime / (1000 * 60 * 60 * 24));
}

function syncUserStreakAndFreezes(user: any) {
  if (user.streakFreezes === undefined) user.streakFreezes = 1;
  if (user.lastEarnedFreezeMonth === undefined) user.lastEarnedFreezeMonth = null;

  const currentStreak = getStreakDays(user.streakStartDate);

  // Earn freeze on hitting 30 days
  if (currentStreak >= 30) {
    const currentMonth = new Date().toISOString().slice(0, 7);
    if (user.lastEarnedFreezeMonth !== currentMonth) {
      user.streakFreezes += 1;
      user.lastEarnedFreezeMonth = currentMonth;
      
      user.logs = user.logs || [];
      user.logs.push({
        id: "earned_freeze_" + Math.random().toString(36).substring(2, 11),
        userId: user.id,
        date: new Date().toISOString().split("T")[0],
        note: "🎉 Earned a Streak Freeze for sustaining an elite 30+ day milestone this month!",
        mood: "resilient",
        checkInCompleted: true,
        cleanDay: true,
        isMilestoneFreeze: true
      });
    }
  }

  // Handle missed days and freezes
  if (user.streakStartDate) {
    try {
      const todayStr = new Date().toISOString().split("T")[0];
      const streakStartStr = user.streakStartDate.split("T")[0];
      
      const y = new Date();
      y.setUTCDate(y.getUTCDate() - 1);
      const yesterdayStr = y.toISOString().split("T")[0];

      if (streakStartStr < yesterdayStr) {
        let currentDate = new Date(user.streakStartDate);
        currentDate.setUTCDate(currentDate.getUTCDate() + 1);
        
        let safetyCount = 0;
        while (safetyCount < 100) {
          safetyCount++;
          const checkStr = currentDate.toISOString().split("T")[0];
          if (checkStr >= todayStr) break;

          user.logs = user.logs || [];
          const checkedInOnDay = user.logs.some(
            (l: any) => l.date === checkStr && (l.cleanDay || l.isFreeze)
          );

          if (!checkedInOnDay) {
            if (user.streakFreezes > 0) {
              user.streakFreezes -= 1;
              user.logs.push({
                id: "freeze_" + Math.random().toString(36).substring(2, 11),
                userId: user.id,
                date: checkStr,
                note: `❄️ Streak Freeze auto-applied to protect your streak on ${checkStr}!`,
                mood: "resilient",
                checkInCompleted: true,
                cleanDay: true,
                isFreeze: true
              });
            } else {
              user.streakStartDate = new Date(currentDate).toISOString();
              user.logs.push({
                id: "break_" + Math.random().toString(36).substring(2, 11),
                userId: user.id,
                date: checkStr,
                note: `⚠️ Streak reset because daily checklist was missed on ${checkStr} and no Streak Freezes were available.`,
                mood: "restless",
                checkInCompleted: true,
                cleanDay: false
              });
              break;
            }
          }
          currentDate.setUTCDate(currentDate.getUTCDate() + 1);
        }
      }
    } catch (e) {
      console.error(e);
    }
  }
}

// Memory map for simple rate limiting
const rateLimitMap = new Map<string, Array<number>>();

function isModeratorUser(user: any): boolean {
  if (!user) return false;
  const email = (user.email || "").toLowerCase();
  const username = user.username || "";
  return email === "max@carsonmail.uk" || username === "ollymckee101" || user.role === "moderator" || user.role === "admin";
}

function sanitizeInput(str: string): string {
  if (typeof str !== "string") return str;
  return str
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#x27;")
    .replace(/\//g, "&#x2F;");
}

function logSecurityEvent(
  db: DBStructure,
  eventType: "FAILED_LOGIN" | "UNUSUAL_ACCESS" | "ROLE_CHANGE" | "ABNORMAL_REQUEST" | "XSS_ATTEMPT",
  description: string,
  userId?: string,
  severity: "low" | "medium" | "high" | "critical" = "low"
) {
  db.securityLogs = db.securityLogs || [];
  const logId = "log_" + Math.random().toString(36).substring(2, 11);
  const now = new Date().toISOString();
  
  db.securityLogs.push({
    id: logId,
    timestamp: now,
    eventType,
    description,
    userId,
    severity
  });
  
  // If serious security event (high or critical), notify administrators via a special support ticket
  if (severity === "high" || severity === "critical") {
    db.supportTickets = db.supportTickets || [];
    const ticketId = "sec_ticket_" + Math.random().toString(36).substring(2, 11);
    
    db.supportTickets.push({
      id: ticketId,
      userId: "security_system",
      username: "SYSTEM MONITOR",
      avatarUrl: "https://api.dicebear.com/7.x/bottts/svg?seed=SYSTEM_MONITOR",
      title: `⚠️ SECURITY ALERT: ${eventType} (${severity.toUpperCase()})`,
      status: "open",
      type: "real",
      messages: [
        {
          id: "msg_" + Math.random().toString(36).substring(2, 11),
          sender: "ai",
          senderName: "Sanctuary Security Agent",
          text: `[${now}] SERIOUS SECURITY EVENT DETECTED:
- Type: ${eventType}
- Severity: ${severity.toUpperCase()}
- Description: ${description}
Please review this immediately to maintain system integrity.`,
          createdAt: now
        }
      ],
      createdAt: now
    });
  }
}

function checkForXSS(str: string, db: DBStructure, env: any, ip: string): boolean {
  if (typeof str !== "string") return false;
  const lower = str.toLowerCase();
  if (lower.includes("<script") || lower.includes("javascript:") || lower.includes("onload=") || lower.includes("onerror=")) {
    logSecurityEvent(db, "XSS_ATTEMPT", `Potential XSS vector blocked from IP ${ip.substring(0, 15)}: ${str.substring(0, 50)}`, undefined, "high");
    return true;
  }
  return false;
}

// Universal API Router matching Request & Response specifications
export const onRequest: PagesFunction<{ GEMINI_API_KEY?: string; GOOGLE_CLIENT_ID?: string; GOOGLE_CLIENT_SECRET?: string }> = async (context) => {
  const { request, env } = context;
  const url = new URL(request.url);
  const path = url.pathname;
  const method = request.method;

  const corsHeaders = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Methods": "GET, POST, OPTIONS, DELETE",
    "Access-Control-Allow-Headers": "Content-Type, x-requester-id",
    "Content-Type": "application/json",
    "X-Content-Type-Options": "nosniff",
    "X-Frame-Options": "DENY",
    "X-XSS-Protection": "1; mode=block",
    "Referrer-Policy": "no-referrer"
  };

  if (method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  // Init Gemini SDK inside Pages Function context dynamically
  const apiKey = env.GEMINI_API_KEY || "";
  let ai: GoogleGenAI | null = null;
  if (apiKey && apiKey !== "MY_GEMINI_API_KEY") {
    try {
      ai = new GoogleGenAI({ apiKey });
    } catch (err) {
      console.error("Gemini failed in worker initialization", err);
    }
  }

  const db = await readDB(env);

  // Secure IP Rate Limiter
  const ip = request.headers.get("CF-Connecting-IP") || "127.0.0.1";
  const nowMs = Date.now();
  let timestamps = rateLimitMap.get(ip) || [];
  timestamps = timestamps.filter(ts => nowMs - ts < 60000);
  timestamps.push(nowMs);
  rateLimitMap.set(ip, timestamps);

  if (timestamps.length > 80) {
    logSecurityEvent(db, "ABNORMAL_REQUEST", `IP ${ip.substring(0, 15)} exceeded the request rate limit.`, undefined, "medium");
    await writeDB(db, env);
    return new Response(JSON.stringify({ error: "Rate limit exceeded. Please steady your breath and try again in a minute." }), { status: 429, headers: corsHeaders });
  }

  // Input Validation and XSS Protection
  let bodyJson: any = null;
  if (method === "POST" || method === "PUT") {
    try {
      const clonedReq = request.clone();
      bodyJson = await clonedReq.json();
      if (bodyJson) {
        for (const [key, val] of Object.entries(bodyJson)) {
          if (typeof val === "string") {
            if (checkForXSS(val, db, env, ip)) {
              await writeDB(db, env);
              return new Response(JSON.stringify({ error: "Malicious input script detected and blocked by Sanctuary Mind Shield." }), { status: 400, headers: corsHeaders });
            }
          }
        }
      }
    } catch (e) {
      // Body is not JSON, safe to proceed
    }
  }

  try {
    // 1. REGISTER
    if (path === "/api/auth/register" && method === "POST") {
      const { username, email, password, avatarUrl } = await request.json() as any;
      if (!username || !email || !password) {
        return new Response(JSON.stringify({ error: "Username, email, and password are required." }), { status: 400, headers: corsHeaders });
      }

      const sanitizedUsername = sanitizeInput(username.trim());
      const lowerEmail = email.trim().toLowerCase();
      const emailExists = Object.values(db.users).some(u => u.email.toLowerCase() === lowerEmail);
      const usernameExists = Object.values(db.users).some(u => u.username.toLowerCase() === sanitizedUsername.toLowerCase());

      if (emailExists) return new Response(JSON.stringify({ error: "Email is already registered." }), { status: 400, headers: corsHeaders });
      if (usernameExists) return new Response(JSON.stringify({ error: "Username is already taken." }), { status: 400, headers: corsHeaders });

      const userId = "user_" + Math.random().toString(36).substring(2, 11);
      const now = new Date().toISOString();

      const newUser = {
        id: userId,
        username: sanitizedUsername,
        email: lowerEmail,
        password,
        avatarUrl: avatarUrl || `https://api.dicebear.com/7.x/bottts/svg?seed=${sanitizedUsername}`,
        streakStartDate: now,
        highestStreak: 0,
        totalXp: 100,
        level: 1,
        title: "Seed of Will",
        joinedDate: now,
        equippedBadgeId: null,
        logs: [],
        triggers: [],
        statusMessage: "Committed to mental clarity and discipline.",
        streakFreezes: 1,
        lastEarnedFreezeMonth: null,
        role: (lowerEmail === "max@carsonmail.uk" || sanitizedUsername === "ollymckee101") ? "moderator" : "user"
      };

      db.users[userId] = newUser;
      await writeDB(db, env);

      const { password: _, ...userSafe } = newUser;
      return new Response(JSON.stringify({ user: userSafe }), { status: 201, headers: corsHeaders });
    }

    // 2. LOGIN
    if (path === "/api/auth/login" && method === "POST") {
      const { email, password } = await request.json() as any;
      if (!email || !password) {
        return new Response(JSON.stringify({ error: "Email and password are required." }), { status: 400, headers: corsHeaders });
      }

      const lowerEmail = email.trim().toLowerCase();
      const user = Object.values(db.users).find(u => u.email.toLowerCase() === lowerEmail && u.password === password);

      if (!user) {
        // Log failed login attempt
        const matchedEmailUser = Object.values(db.users).find(u => u.email.toLowerCase() === lowerEmail);
        const anonymizedEmail = lowerEmail.replace(/(.{1,3})@.*/, "$1***@***");
        logSecurityEvent(db, "FAILED_LOGIN", `Failed login attempt for anonymized email: ${anonymizedEmail} from IP: ${ip.substring(0, 15)}`, matchedEmailUser?.id, "medium");
        await writeDB(db, env);
        return new Response(JSON.stringify({ error: "Invalid email or password." }), { status: 401, headers: corsHeaders });
      }

      // Automatically assign moderator role if needed
      user.role = (lowerEmail === "max@carsonmail.uk" || user.username === "ollymckee101") ? "moderator" : (user.role || "user");

      syncUserStreakAndFreezes(user);
      const currentStreak = getStreakDays(user.streakStartDate);
      const { level, title } = calculateLevelAndTitle(user.totalXp, currentStreak);
      user.level = level;
      user.title = title;
      
      if (currentStreak > user.highestStreak) {
        user.highestStreak = currentStreak;
      }
      db.users[user.id] = user;
      await writeDB(db, env);

      const { password: _, ...userSafe } = user;
      return new Response(JSON.stringify({ user: userSafe }), { headers: corsHeaders });
    }

    // 3. GOOGLE AUTH GATEWAY URL
    if (path === "/api/auth/google/url" && method === "GET") {
      const referer = request.headers.get("referer");
      const origin = referer ? new URL(referer).origin : url.origin;
      const redirectUri = `${origin}/auth/google/callback`;

      // Use a Client ID if provided, otherwise simulate
      const clientId = env.GOOGLE_CLIENT_ID;
      if (clientId && clientId !== "MY_GOOGLE_CLIENT_ID") {
        const params = new URLSearchParams({
          client_id: clientId,
          redirect_uri: redirectUri,
          response_type: "code",
          scope: "openid email profile",
          access_type: "offline",
          prompt: "consent"
        });
        return new Response(JSON.stringify({ url: `https://accounts.google.com/o/oauth2/v2/auth?${params.toString()}`, real: true }), { headers: corsHeaders });
      } else {
        return new Response(JSON.stringify({ url: `/api/auth/google/simulate`, real: false }), { headers: corsHeaders });
      }
    }

    // 4. SIMULATE OAUTH POPUP WEB PAGE
    if (path === "/api/auth/google/simulate" && method === "GET") {
      const simulateHtml = `
        <!DOCTYPE html>
        <html lang="en">
        <head>
          <meta charset="UTF-8">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
          <title>Google Identity Gateway - Cloudflare Simulation</title>
          <style>
            body { margin: 0; padding: 0; background-color: #0A0A0B; color: #E5E5E5; font-family: sans-serif; display: flex; align-items: center; justify-content: center; min-height: 100vh; }
            .container { width: 100%; max-width: 400px; padding: 24px; background-color: #0F0F10; border: 1px solid #1A1A1B; border-radius: 12px; text-align: center; }
            .logo { font-size: 20px; font-weight: bold; margin-bottom: 20px; color: #F59E0B; }
            .account-btn { display: flex; align-items: center; width: 100%; padding: 12px; margin-bottom: 8px; background-color: #161618; border: 1px solid #262626; border-radius: 8px; color: #E5E5E5; cursor: pointer; text-align: left; }
            .account-btn:hover { border-color: #F59E0B; background-color: #1A1A1C; }
            .name { font-size: 14px; font-weight: bold; }
            .email { font-size: 11px; color: #888888; margin-top: 2px; }
          </style>
        </head>
        <body>
          <div class="container">
            <div class="logo">Google Sign-In</div>
            <p style="font-size: 13px; color: #888; margin-bottom: 20px;">Authorize Sanctuary access in simulation mode.</p>
            <button class="account-btn" onclick="selectAccount('maxilovepigs@gmail.com', 'Maxi')">
              <div>
                <div class="name">Maxi</div>
                <div class="email">maxilovepigs@gmail.com</div>
              </div>
            </button>
            <button class="account-btn" onclick="selectAccount('seeker.purity@gmail.com', 'Sovereign_Seeker')">
              <div>
                <div class="name">Sovereign Seeker</div>
                <div class="email">seeker.purity@gmail.com</div>
              </div>
            </button>
          </div>
          <script>
            function selectAccount(email, name) {
              window.location.href = '/auth/google/callback?code=sim_code&email=' + encodeURIComponent(email) + '&name=' + encodeURIComponent(name);
            }
          </script>
        </body>
        </html>
      `;
      return new Response(simulateHtml, { headers: { "Content-Type": "text/html" } });
    }

    // 5. FORGOT PASSWORD
    if (path === "/api/auth/forgot-password" && method === "POST") {
      const { email } = await request.json() as any;
      if (!email) {
        return new Response(JSON.stringify({ error: "Email is required." }), { status: 400, headers: corsHeaders });
      }

      const lowerEmail = email.toLowerCase();
      const user = Object.values(db.users).find(u => u.email.toLowerCase() === lowerEmail);

      if (!user) {
        return new Response(JSON.stringify({ error: "This email is not registered." }), { status: 404, headers: corsHeaders });
      }

      const resetCode = Math.floor(100000 + Math.random() * 900000).toString();
      user.resetCode = resetCode;
      user.resetExpiry = new Date(Date.now() + 15 * 60 * 1000).toISOString();

      db.users[user.id] = user;
      await writeDB(db, env);

      return new Response(JSON.stringify({ 
        success: true, 
        code: resetCode, 
        message: "Code generated. For convenience, it is shared here." 
      }), { headers: corsHeaders });
    }

    // 6. RESET PASSWORD
    if (path === "/api/auth/reset-password" && method === "POST") {
      const { email, code, newPassword } = await request.json() as any;
      if (!email || !code || !newPassword) {
        return new Response(JSON.stringify({ error: "All fields are required." }), { status: 400, headers: corsHeaders });
      }

      const lowerEmail = email.toLowerCase();
      const user = Object.values(db.users).find(u => u.email.toLowerCase() === lowerEmail);

      if (!user) return new Response(JSON.stringify({ error: "Not registered." }), { status: 404, headers: corsHeaders });
      if (!user.resetCode || user.resetCode !== code) return new Response(JSON.stringify({ error: "Invalid code." }), { status: 400, headers: corsHeaders });

      user.password = newPassword;
      delete user.resetCode;
      delete user.resetExpiry;

      db.users[user.id] = user;
      await writeDB(db, env);

      return new Response(JSON.stringify({ success: true, message: "Cognitive re-key successful." }), { headers: corsHeaders });
    }

    // 7. GET PROFILE
    const profileMatch = path.match(/^\/api\/user\/([^/]+)$/);
    if (profileMatch && method === "GET") {
      const userId = profileMatch[1];
      const user = db.users[userId];
      if (!user) return new Response(JSON.stringify({ error: "User not found." }), { status: 404, headers: corsHeaders });

      const lowerEmail = (user.email || "").toLowerCase();
      user.role = (lowerEmail === "max@carsonmail.uk" || user.username === "ollymckee101") ? "moderator" : (user.role || "user");

      syncUserStreakAndFreezes(user);
      const currentStreak = getStreakDays(user.streakStartDate);
      const { level, title } = calculateLevelAndTitle(user.totalXp, currentStreak);
      user.level = level;
      user.title = title;
      if (currentStreak > user.highestStreak) {
        user.highestStreak = currentStreak;
      }
      db.users[userId] = user;
      await writeDB(db, env);

      const { password: _, ...userSafe } = user;
      return new Response(JSON.stringify(userSafe), { headers: corsHeaders });
    }

    // 8. STREAK RESET / UPDATE
    const streakMatch = path.match(/^\/api\/user\/([^/]+)\/streak$/);
    if (streakMatch && method === "POST") {
      const userId = streakMatch[1];
      const { action, note, triggerType, relapseMood } = await request.json() as any;
      const user = db.users[userId];
      if (!user) return new Response(JSON.stringify({ error: "User not found" }), { status: 404, headers: corsHeaders });

      syncUserStreakAndFreezes(user);
      const now = new Date().toISOString();

      if (action === "relapse") {
        const completedStreak = getStreakDays(user.streakStartDate);
        const logEntry = {
          id: "journal_" + Math.random().toString(36).substring(2, 11),
          userId,
          date: new Date().toISOString().split("T")[0],
          note: note || `Streak of ${completedStreak} days ended. Reflecting and rebuilding.`,
          mood: relapseMood || "restless",
          checkInCompleted: true,
          cleanDay: false
        };
        user.logs.push(logEntry);

        if (triggerType) {
          user.triggers.push({
            id: "trig_" + Math.random().toString(36).substring(2, 11),
            userId,
            date: now,
            intensity: 8,
            type: triggerType,
            mitigationStrategy: "Reflected in log."
          });
        }
        user.streakStartDate = now;
        user.statusMessage = "Rising stronger. Purity starts again today.";
      } else if (action === "start") {
        user.streakStartDate = now;
        user.statusMessage = "Commencing purity quest.";
      }

      const currentStreak = getStreakDays(user.streakStartDate);
      const { level, title } = calculateLevelAndTitle(user.totalXp, currentStreak);
      user.level = level;
      user.title = title;

      db.users[userId] = user;
      await writeDB(db, env);

      const { password: _, ...userSafe } = user;
      return new Response(JSON.stringify(userSafe), { headers: corsHeaders });
    }

    // 9. CHECK IN
    const checkinMatch = path.match(/^\/api\/user\/([^/]+)\/checkin$/);
    if (checkinMatch && method === "POST") {
      const userId = checkinMatch[1];
      const { note, mood, cleanDay } = await request.json() as any;
      const user = db.users[userId];
      if (!user) return new Response(JSON.stringify({ error: "User not found" }), { status: 404, headers: corsHeaders });

      syncUserStreakAndFreezes(user);
      const dateStr = new Date().toISOString().split("T")[0];
      const alreadyCheckedIn = user.logs.some((l: any) => l.date === dateStr && l.cleanDay === cleanDay);
      
      let xpGained = 0;
      const logEntry = {
        id: "journal_" + Math.random().toString(36).substring(2, 11),
        userId,
        date: dateStr,
        note: note || "Maintained daily purity checklist.",
        mood: mood || "focused",
        checkInCompleted: true,
        cleanDay: cleanDay !== false
      };
      user.logs.push(logEntry);

      if (!alreadyCheckedIn) {
        xpGained = cleanDay ? 50 : 15;
        user.totalXp += xpGained;
      }

      const currentStreak = getStreakDays(user.streakStartDate);
      const { level, title } = calculateLevelAndTitle(user.totalXp, currentStreak);
      user.level = level;
      user.title = title;

      if (currentStreak > user.highestStreak) user.highestStreak = currentStreak;

      db.users[userId] = user;
      await writeDB(db, env);

      const { password: _, ...userSafe } = user;
      return new Response(JSON.stringify({ user: userSafe, xpGained }), { headers: corsHeaders });
    }

    // 10. RECORD TRIGGER
    const triggerRecordMatch = path.match(/^\/api\/user\/([^/]+)\/trigger$/);
    if (triggerRecordMatch && method === "POST") {
      const userId = triggerRecordMatch[1];
      const { intensity, type, mitigationStrategy } = await request.json() as any;
      const user = db.users[userId];
      if (!user) return new Response(JSON.stringify({ error: "User not found" }), { status: 404, headers: corsHeaders });

      const triggerLog = {
        id: "trig_" + Math.random().toString(36).substring(2, 11),
        userId,
        date: new Date().toISOString(),
        intensity: Number(intensity) || 5,
        type: type || "Boredom",
        mitigationStrategy: mitigationStrategy || "Practiced mindful urge surfing."
      };

      user.triggers.push(triggerLog);
      const xpGained = 25;
      user.totalXp += xpGained;

      const currentStreak = getStreakDays(user.streakStartDate);
      const { level, title } = calculateLevelAndTitle(user.totalXp, currentStreak);
      user.level = level;
      user.title = title;

      db.users[userId] = user;
      await writeDB(db, env);

      const { password: _, ...userSafe } = user;
      return new Response(JSON.stringify({ user: userSafe, xpGained }), { headers: corsHeaders });
    }

    // 11. BOX BREATHING COMPLETE
    const urgeSurfMatch = path.match(/^\/api\/user\/([^/]+)\/urgesurfed$/);
    if (urgeSurfMatch && method === "POST") {
      const userId = urgeSurfMatch[1];
      const user = db.users[userId];
      if (!user) return new Response(JSON.stringify({ error: "User not found" }), { status: 404, headers: corsHeaders });

      const xpGained = 50;
      user.totalXp += xpGained;

      const currentStreak = getStreakDays(user.streakStartDate);
      const { level, title } = calculateLevelAndTitle(user.totalXp, currentStreak);
      user.level = level;
      user.title = title;

      db.users[userId] = user;
      await writeDB(db, env);

      const { password: _, ...userSafe } = user;
      return new Response(JSON.stringify({ user: userSafe, xpGained }), { headers: corsHeaders });
    }

    // 12. UPDATE STATUS TEXT
    const statusMatch = path.match(/^\/api\/user\/([^/]+)\/status$/);
    if (statusMatch && method === "POST") {
      const userId = statusMatch[1];
      const { statusMessage } = await request.json() as any;
      const user = db.users[userId];
      if (!user) return new Response(JSON.stringify({ error: "User not found" }), { status: 404, headers: corsHeaders });

      user.statusMessage = statusMessage || "";
      db.users[userId] = user;
      await writeDB(db, env);

      const { password: _, ...userSafe } = user;
      return new Response(JSON.stringify(userSafe), { headers: corsHeaders });
    }

    // 13. EQUIP BADGE
    const badgeMatch = path.match(/^\/api\/user\/([^/]+)\/badge$/);
    if (badgeMatch && method === "POST") {
      const userId = badgeMatch[1];
      const { badgeId } = await request.json() as any;
      const user = db.users[userId];
      if (!user) return new Response(JSON.stringify({ error: "User not found" }), { status: 404, headers: corsHeaders });

      user.equippedBadgeId = badgeId || null;
      db.users[userId] = user;
      await writeDB(db, env);

      const { password: _, ...userSafe } = user;
      return new Response(JSON.stringify(userSafe), { headers: corsHeaders });
    }

    // 14. UPDATE SETTINGS
    const settingsMatch = path.match(/^\/api\/user\/([^/]+)\/settings$/);
    if (settingsMatch && method === "POST") {
      const userId = settingsMatch[1];
      const { username, statusMessage, avatarUrl, bannerColor, customStatus, socialLink } = await request.json() as any;
      const user = db.users[userId];
      if (!user) return new Response(JSON.stringify({ error: "User not found" }), { status: 404, headers: corsHeaders });

      if (username && username !== user.username) {
        const cleanUsername = username.replace(/[^a-zA-Z0-9_]/g, "_");
        if (!cleanUsername) return new Response(JSON.stringify({ error: "Invalid username format" }), { status: 400, headers: corsHeaders });
        const usernameTaken = Object.values(db.users).some(u => u.id !== userId && u.username.toLowerCase() === cleanUsername.toLowerCase());
        if (usernameTaken) return new Response(JSON.stringify({ error: "Username already claimed." }), { status: 400, headers: corsHeaders });
        user.username = cleanUsername;
      }

      if (statusMessage !== undefined) user.statusMessage = statusMessage;
      if (avatarUrl !== undefined) user.avatarUrl = avatarUrl;
      if (bannerColor !== undefined) user.bannerColor = bannerColor;
      if (customStatus !== undefined) user.customStatus = customStatus;
      if (socialLink !== undefined) user.socialLink = socialLink;

      db.users[userId] = user;
      await writeDB(db, env);

      const { password: _, ...userSafe } = user;
      return new Response(JSON.stringify(userSafe), { headers: corsHeaders });
    }

    // 15. CHANGE PASSWORD
    const pwMatch = path.match(/^\/api\/user\/([^/]+)\/change-password$/);
    if (pwMatch && method === "POST") {
      const userId = pwMatch[1];
      const { currentPassword, newPassword } = await request.json() as any;
      const user = db.users[userId];
      if (!user) return new Response(JSON.stringify({ error: "User not found" }), { status: 404, headers: corsHeaders });

      if (user.password && !user.password.startsWith("google_oauth_authorized_") && user.password !== currentPassword) {
        return new Response(JSON.stringify({ error: "Current password does not match." }), { status: 400, headers: corsHeaders });
      }

      user.password = newPassword;
      db.users[userId] = user;
      await writeDB(db, env);

      return new Response(JSON.stringify({ success: true, message: "Password updated." }), { headers: corsHeaders });
    }

    // 16. EXPORT PROFILE DATA
    const exportMatch = path.match(/^\/api\/user\/([^/]+)\/export$/);
    if (exportMatch && method === "GET") {
      const userId = exportMatch[1];
      const user = db.users[userId];
      if (!user) return new Response(JSON.stringify({ error: "User not found" }), { status: 404, headers: corsHeaders });

      const { password: _, ...userSafe } = user;
      return new Response(JSON.stringify({
        exportedAt: new Date().toISOString(),
        user: userSafe,
        schemaVersion: "2.5"
      }), { headers: corsHeaders });
    }

    // 17. DELETE PROFILE
    const deleteMatch = path.match(/^\/api\/user\/([^/]+)\/delete$/);
    if (deleteMatch && method === "DELETE") {
      const userId = deleteMatch[1];
      if (!db.users[userId]) return new Response(JSON.stringify({ error: "User not found" }), { status: 404, headers: corsHeaders });

      delete db.users[userId];
      await writeDB(db, env);

      return new Response(JSON.stringify({ success: true, message: "Account deleted permanently." }), { headers: corsHeaders });
    }

    // 18. LEADERBOARD
    if (path === "/api/leaderboard" && method === "GET") {
      const realUsersList = Object.values(db.users).map(user => {
        syncUserStreakAndFreezes(user);
        const currentStreak = getStreakDays(user.streakStartDate);
        const { level, title } = calculateLevelAndTitle(user.totalXp, currentStreak);
        return {
          id: user.id,
          username: user.username,
          avatarUrl: user.avatarUrl,
          currentStreak,
          highestStreak: Math.max(user.highestStreak || 0, currentStreak),
          level,
          title,
          isRealUser: true,
          equippedBadgeId: user.equippedBadgeId || null,
          statusMessage: user.statusMessage || "On the path of self-mastery."
        };
      });

      await writeDB(db, env);
      const combined = [...realUsersList, ...DEFAULT_LEADERBOARD];

      combined.sort((a, b) => {
        if (b.currentStreak !== a.currentStreak) return b.currentStreak - a.currentStreak;
        return b.level - a.level;
      });

      const ranked = combined.map((entry, idx) => ({ ...entry, rank: idx + 1 }));
      return new Response(JSON.stringify(ranked), { headers: corsHeaders });
    }

    // 19. CHAT ENDPOINTS
    if (path === "/api/chat" && method === "GET") {
      return new Response(JSON.stringify(db.chatMessages || []), { headers: corsHeaders });
    }

    if (path === "/api/chat" && method === "POST") {
      const { userId, username, avatarUrl, text, level, title } = await request.json() as any;
      if (!text || !text.trim()) return new Response(JSON.stringify({ error: "Text is required" }), { status: 400, headers: corsHeaders });

      const newMessage = {
        id: "chat_" + Math.random().toString(36).substring(2, 11),
        userId: userId || "guest",
        username: username || "Guest Warrior",
        avatarUrl: avatarUrl || `https://api.dicebear.com/7.x/bottts/svg?seed=Guest_${Math.random()}`,
        text: text.trim(),
        timestamp: new Date().toISOString(),
        level: level || 1,
        title: title || "Seed of Will"
      };

      db.chatMessages = db.chatMessages || [];
      db.chatMessages.push(newMessage);
      if (db.chatMessages.length > 150) db.chatMessages.shift();

      await writeDB(db, env);
      return new Response(JSON.stringify(newMessage), { status: 201, headers: corsHeaders });
    }

    // 20. AI MENTOR
    if (path === "/api/mentor" && method === "POST") {
      const { messages, userProfile } = await request.json() as any;
      if (!messages || !Array.isArray(messages)) {
        return new Response(JSON.stringify({ error: "Messages is required" }), { status: 400, headers: corsHeaders });
      }

      if (!ai) {
        const lastUserMsg = messages[messages.length - 1]?.text || "";
        let mockReply = "Remember, urges are temporary waves. Breathe deeply. Every choice of purity rewires your prefrontal cortex for power.";
        const lower = lastUserMsg.toLowerCase();
        if (lower.includes("relapse") || lower.includes("failed")) {
          mockReply = "A relapse is an educational data point. Do not judge yourself. Rise back up, splash cold water, and reflect on the trigger.";
        } else if (lower.includes("urge") || lower.includes("tempted")) {
          mockReply = "An urge peaks in 3 minutes. Surrender to box breathing right now. You are stronger than a chemical spark.";
        }
        return new Response(JSON.stringify({ text: mockReply }), { headers: corsHeaders });
      }

      const systemPrompt = `You are the "Purity Mentor," a CBT guide helping the user conquer porn addiction and digital triggers.
Tone: Warm, objective, and expert. Speak under 220 words. No lists, no AI jargon. Focus on neuroplasticity, Urge Surfing, and compassionate recovery.
User Context:
- Username: ${userProfile?.username || "Warrior"}
- Current Streak: ${userProfile?.currentStreak || 0} days
- Level: ${userProfile?.level || 1} (${userProfile?.title || "Seed of Will"})`;

      const contents = messages.map((m: any) => ({
        role: m.sender === "user" ? "user" : "model",
        parts: [{ text: m.text }]
      }));

      const result = await ai.models.generateContent({
        model: "gemini-2.5-flash",
        contents,
        config: {
          systemInstruction: systemPrompt,
          temperature: 0.75,
          maxOutputTokens: 400
        }
      });

      return new Response(JSON.stringify({ text: result.text || "Remain focused on the present breath." }), { headers: corsHeaders });
    }

    // 21. DAILY PHILOSOPHY
    if (path === "/api/philosophy/daily" && method === "GET") {
      const todayStr = new Date().toISOString().split("T")[0];
      const regen = url.searchParams.get("regen") === "true";

      if (db.dailyQuote && db.dailyQuote.date === todayStr && !regen) {
        return new Response(JSON.stringify(db.dailyQuote), { headers: corsHeaders });
      }

      let selectedQuote;
      if (ai) {
        try {
          const prompt = `Generate a profound philosophical quote about discipline or self-control. Provide a CBT commentary under 50 words. Return JSON:
{
  "quote": "text",
  "author": "name",
  "school": "school",
  "commentary": "CBT help"
}`;
          const result = await ai.models.generateContent({
            model: "gemini-2.5-flash",
            contents: prompt,
            config: {
              responseMimeType: "application/json",
              temperature: 0.8,
              responseSchema: {
                type: Type.OBJECT,
                properties: {
                  quote: { type: Type.STRING },
                  author: { type: Type.STRING },
                  school: { type: Type.STRING },
                  commentary: { type: Type.STRING }
                },
                required: ["quote", "author", "school", "commentary"]
              }
            }
          });

          if (result.text) {
            const parsed = JSON.parse(result.text.trim());
            selectedQuote = {
              date: todayStr,
              quote: parsed.quote,
              author: parsed.author,
              school: parsed.school,
              commentary: parsed.commentary
            };
          }
        } catch (e) {
          console.error(e);
        }
      }

      if (!selectedQuote) {
        const rand = Math.floor(Math.random() * FALLBACK_PHILOSOPHY_QUOTES.length);
        selectedQuote = { date: todayStr, ...FALLBACK_PHILOSOPHY_QUOTES[rand] };
      }

      db.dailyQuote = selectedQuote;
      await writeDB(db, env);
      return new Response(JSON.stringify(selectedQuote), { headers: corsHeaders });
    }

    // 22. BUDDY SYSTEM: FOLLOW / UNFOLLOW / FOLLOWING
    const followMatch = path.match(/^\/api\/user\/([^/]+)\/follow$/);
    if (followMatch && method === "POST") {
      const userId = followMatch[1];
      const { targetUsername, targetUserId } = await request.json() as any;
      const user = db.users[userId];
      if (!user) return new Response(JSON.stringify({ error: "User not found" }), { status: 404, headers: corsHeaders });

      let targetUser = null;
      if (targetUserId) {
        targetUser = db.users[targetUserId];
      } else if (targetUsername) {
        targetUser = Object.values(db.users).find(u => u.username.toLowerCase() === targetUsername.trim().toLowerCase());
      }

      if (!targetUser) return new Response(JSON.stringify({ error: "Target warrior not found" }), { status: 404, headers: corsHeaders });
      if (targetUser.id === userId) return new Response(JSON.stringify({ error: "You cannot track yourself" }), { status: 400, headers: corsHeaders });

      user.following = user.following || [];
      if (!user.following.includes(targetUser.id)) user.following.push(targetUser.id);

      db.users[userId] = user;
      await writeDB(db, env);

      const { password: _, ...userSafe } = user;
      return new Response(JSON.stringify(userSafe), { headers: corsHeaders });
    }

    const unfollowMatch = path.match(/^\/api\/user\/([^/]+)\/unfollow$/);
    if (unfollowMatch && method === "POST") {
      const userId = unfollowMatch[1];
      const { targetUserId } = await request.json() as any;
      const user = db.users[userId];
      if (!user) return new Response(JSON.stringify({ error: "User not found" }), { status: 404, headers: corsHeaders });

      user.following = user.following || [];
      user.following = user.following.filter((id: string) => id !== targetUserId);

      db.users[userId] = user;
      await writeDB(db, env);

      const { password: _, ...userSafe } = user;
      return new Response(JSON.stringify(userSafe), { headers: corsHeaders });
    }

    const followingMatch = path.match(/^\/api\/user\/([^/]+)\/following$/);
    if (followingMatch && method === "GET") {
      const userId = followingMatch[1];
      const user = db.users[userId];
      if (!user) return new Response(JSON.stringify({ error: "User not found" }), { status: 404, headers: corsHeaders });

      user.following = user.following || [];
      const profiles = user.following.map((id: string) => {
        const u = db.users[id];
        if (!u) return null;
        const currentStreak = getStreakDays(u.streakStartDate);
        const { level, title } = calculateLevelAndTitle(u.totalXp, currentStreak);
        return {
          id: u.id,
          username: u.username,
          avatarUrl: u.avatarUrl,
          currentStreak,
          highestStreak: Math.max(u.highestStreak || 0, currentStreak),
          level,
          title,
          statusMessage: u.statusMessage || "On the path of self-mastery."
        };
      }).filter(Boolean);

      return new Response(JSON.stringify(profiles), { headers: corsHeaders });
    }

    // 23. SUPPORT TICKETS
    if (path === "/api/support/tickets" && method === "GET") {
      const searchParams = url.searchParams;
      const tUserId = searchParams.get("userId");
      const tUsername = searchParams.get("username");
      const tickets = db.supportTickets || [];

      const requestingUser = tUserId ? db.users[tUserId] : Object.values(db.users).find((u: any) => u.username === tUsername);
      const isMod = isModeratorUser(requestingUser);

      if (isMod) {
        return new Response(JSON.stringify(tickets), { headers: corsHeaders });
      }
      if (!tUserId) return new Response(JSON.stringify([]), { headers: corsHeaders });

      const filtered = tickets.filter((t: any) => t.userId === tUserId);
      return new Response(JSON.stringify(filtered), { headers: corsHeaders });
    }

    if (path === "/api/support/tickets" && method === "POST") {
      const { userId, username, avatarUrl, title, type, initialMessage } = await request.json() as any;
      if (!title || !initialMessage) return new Response(JSON.stringify({ error: "Fields required" }), { status: 400, headers: corsHeaders });

      const ticketId = "ticket_" + Math.random().toString(36).substring(2, 11);
      const now = new Date().toISOString();

      const initialMsgObj = {
        id: "msg_" + Math.random().toString(36).substring(2, 11),
        sender: "user" as "user" | "ai" | "mod",
        senderName: username || "Guest Warrior",
        text: initialMessage.trim(),
        createdAt: now
      };

      const newTicket = {
        id: ticketId,
        userId: userId || "guest",
        username: username || "Guest Warrior",
        avatarUrl: avatarUrl || `https://api.dicebear.com/7.x/bottts/svg?seed=Guest_${Math.random()}`,
        title: title.trim(),
        status: "open" as const,
        type: (type === "ai" ? "ai" : "real") as "ai" | "real",
        messages: [initialMsgObj],
        createdAt: now
      };

      db.supportTickets = db.supportTickets || [];
      db.supportTickets.push(newTicket);

      if (type === "ai") {
        let aiResponseText = "Your support request has been catalogued. How can the Sanctuary Support system serve you today?";
        if (ai) {
          try {
            const prompt = `You are the "Sanctuary App Support Bot". Solve user issue:
Title: "${title}"
Description: "${initialMessage}"
Answer helpfully under 130 words about App mechanics (Clocks, XP levels, Checklist logs, Box breathing SOS). No medical advice.`;
            const result = await ai.models.generateContent({
              model: "gemini-2.5-flash",
              contents: prompt,
              config: { temperature: 0.5, maxOutputTokens: 250 }
            });
            aiResponseText = result.text || aiResponseText;
          } catch (e) {
            console.error(e);
          }
        }
        newTicket.messages.push({
          id: "msg_" + Math.random().toString(36).substring(2, 11),
          sender: "ai" as const,
          senderName: "Sanctuary Support AI",
          text: aiResponseText,
          createdAt: new Date().toISOString()
        });
      }

      await writeDB(db, env);
      return new Response(JSON.stringify(newTicket), { status: 201, headers: corsHeaders });
    }

    const tMessageMatch = path.match(/^\/api\/support\/tickets\/([^/]+)\/messages$/);
    if (tMessageMatch && method === "POST") {
      const ticketId = tMessageMatch[1];
      const { username, text, userId } = await request.json() as any;
      if (!text) return new Response(JSON.stringify({ error: "Text required" }), { status: 400, headers: corsHeaders });

      const ticket = (db.supportTickets || []).find((t: any) => t.id === ticketId);
      if (!ticket) return new Response(JSON.stringify({ error: "Not found" }), { status: 404, headers: corsHeaders });

      const requestingUser = userId ? db.users[userId] : Object.values(db.users).find((u: any) => u.username === username);
      const isMod = isModeratorUser(requestingUser);

      const newMsg = {
        id: "msg_" + Math.random().toString(36).substring(2, 11),
        sender: (isMod ? "mod" : "user") as "user" | "ai" | "mod",
        senderName: isMod ? `${requestingUser?.username || "ollymckee101"} (Moderator)` : (username || "Guest Warrior"),
        text: text.trim(),
        createdAt: new Date().toISOString()
      };

      ticket.messages.push(newMsg);
      ticket.status = isMod ? "resolved" : "open";

      if (ticket.type === "ai" && !isMod) {
        let aiResponseText = "Processing response. I am here to help you navigate your sovereign workspace features.";
        if (ai) {
          try {
            const prompt = `User replied in ticket: "${text}". Offer helpful support answer under 100 words.`;
            const result = await ai.models.generateContent({
              model: "gemini-2.5-flash",
              contents: prompt,
              config: { temperature: 0.5 }
            });
            aiResponseText = result.text || aiResponseText;
          } catch (e) {
            console.error(e);
          }
        }
        ticket.messages.push({
          id: "msg_" + Math.random().toString(36).substring(2, 11),
          sender: "ai" as const,
          senderName: "Sanctuary Support AI",
          text: aiResponseText,
          createdAt: new Date().toISOString()
        });
      }

      await writeDB(db, env);
      return new Response(JSON.stringify(ticket), { headers: corsHeaders });
    }

    const resolveMatch = path.match(/^\/api\/support\/tickets\/([^/]+)\/resolve$/);
    if (resolveMatch && method === "POST") {
      const ticketId = resolveMatch[1];
      const ticket = (db.supportTickets || []).find((t: any) => t.id === ticketId);
      if (!ticket) return new Response(JSON.stringify({ error: "Not found" }), { status: 404, headers: corsHeaders });

      ticket.status = "resolved";
      await writeDB(db, env);
      return new Response(JSON.stringify(ticket), { headers: corsHeaders });
    }

    // 24. GET ALL SECURITY LOGS (ADMIN ONLY)
    if (path === "/api/admin/security-logs" && method === "GET") {
      const requesterId = url.searchParams.get("requesterId");
      const requester = db.users[requesterId || ""];
      if (!isModeratorUser(requester)) {
        return new Response(JSON.stringify({ error: "Unauthorized access." }), { status: 403, headers: corsHeaders });
      }
      return new Response(JSON.stringify(db.securityLogs || []), { headers: corsHeaders });
    }

    // 25. GET ALL USERS AND ROLES (ADMIN ONLY)
    if (path === "/api/admin/roles" && method === "GET") {
      const requesterId = url.searchParams.get("requesterId");
      const requester = db.users[requesterId || ""];
      if (!isModeratorUser(requester)) {
        return new Response(JSON.stringify({ error: "Unauthorized access." }), { status: 403, headers: corsHeaders });
      }
      
      const userList = Object.values(db.users).map((u: any) => ({
        id: u.id,
        username: u.username,
        email: u.email,
        role: u.role || (u.email?.toLowerCase() === "max@carsonmail.uk" || u.username === "ollymckee101" ? "moderator" : "user"),
        level: u.level || 1,
        title: u.title || "Seed of Will",
        joinedDate: u.joinedDate
      }));
      return new Response(JSON.stringify(userList), { headers: corsHeaders });
    }

    // 26. UPDATE USER ROLE (ADMIN ONLY)
    if (path === "/api/admin/roles" && method === "POST") {
      const { requesterId, targetUserId, newRole } = await request.json() as any;
      const requester = db.users[requesterId || ""];
      if (!isModeratorUser(requester)) {
        return new Response(JSON.stringify({ error: "Unauthorized access." }), { status: 403, headers: corsHeaders });
      }
      
      if (!targetUserId || !newRole) {
        return new Response(JSON.stringify({ error: "targetUserId and newRole are required." }), { status: 400, headers: corsHeaders });
      }
      
      const targetUser = db.users[targetUserId];
      if (!targetUser) {
        return new Response(JSON.stringify({ error: "Target user not found." }), { status: 404, headers: corsHeaders });
      }
      
      if (targetUser.email?.toLowerCase() === "max@carsonmail.uk" && newRole !== "moderator") {
        return new Response(JSON.stringify({ error: "Cannot demote the primary moderator account." }), { status: 400, headers: corsHeaders });
      }
      
      targetUser.role = newRole;
      db.users[targetUserId] = targetUser;
      
      logSecurityEvent(db, "ROLE_CHANGE", `User ${requester.username} changed role of ${targetUser.username} to ${newRole}`, requesterId, "high");
      
      await writeDB(db, env);
      return new Response(JSON.stringify({ success: true, user: { id: targetUser.id, username: targetUser.username, role: targetUser.role } }), { headers: corsHeaders });
    }

    return new Response(JSON.stringify({ error: `Not Found: ${method} ${path}` }), { status: 404, headers: corsHeaders });
  } catch (err: any) {
    console.error("Pages Function Handler Error:", err);
    return new Response(JSON.stringify({ error: err.message || "An unexpected serverless error occurred." }), { status: 500, headers: corsHeaders });
  }
};
