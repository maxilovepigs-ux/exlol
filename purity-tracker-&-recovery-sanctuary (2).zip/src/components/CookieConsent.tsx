/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from "react";
import { Shield, Settings, Check, X } from "lucide-react";

export default function CookieConsent() {
  const [isOpen, setIsOpen] = useState(false);
  const [showPreferences, setShowPreferences] = useState(false);
  const [prefAds, setPrefAds] = useState(true);
  const [prefFunctional, setPrefFunctional] = useState(true);

  useEffect(() => {
    const consent = localStorage.getItem("sanctuary_cookie_consent");
    if (!consent) {
      // Trigger slide-in after a short delay for optimal CLS
      const timer = setTimeout(() => setIsOpen(true), 1500);
      return () => clearTimeout(timer);
    }
  }, []);

  const handleAcceptAll = () => {
    localStorage.setItem("sanctuary_cookie_consent", "all");
    localStorage.setItem("sanctuary_cookie_pref_ads", "true");
    localStorage.setItem("sanctuary_cookie_pref_func", "true");
    setIsOpen(false);
    console.log("[CookieConsent] Accepted all cookies.");
  };

  const handleAcceptEssential = () => {
    localStorage.setItem("sanctuary_cookie_consent", "essential");
    localStorage.setItem("sanctuary_cookie_pref_ads", "false");
    localStorage.setItem("sanctuary_cookie_pref_func", "false");
    setIsOpen(false);
    console.log("[CookieConsent] Accepted essential cookies only.");
  };

  const handleSavePreferences = () => {
    localStorage.setItem("sanctuary_cookie_consent", "custom");
    localStorage.setItem("sanctuary_cookie_pref_ads", String(prefAds));
    localStorage.setItem("sanctuary_cookie_pref_func", String(prefFunctional));
    setIsOpen(false);
    console.log(`[CookieConsent] Saved custom preferences: Ads=${prefAds}, Func=${prefFunctional}`);
  };

  if (!isOpen) return null;

  return (
    <div 
      id="cookie-consent-banner" 
      aria-live="polite"
      className="fixed bottom-6 left-6 right-6 md:right-auto md:max-w-md z-45 bg-[#0F0F10] border border-amber-500/20 rounded-2xl shadow-2xl p-5 md:p-6 transition-all duration-300 animate-slide-in-up"
    >
      <div className="absolute top-0 right-0 h-24 w-24 bg-amber-500/5 rounded-full blur-2xl pointer-events-none"></div>
      
      {!showPreferences ? (
        <div className="space-y-4">
          <div className="flex items-start space-x-3">
            <div className="h-9 w-9 rounded-xl bg-amber-500/10 border border-amber-500/20 text-amber-500 flex items-center justify-center shrink-0">
              <Shield className="h-5 w-5" />
            </div>
            <div>
              <h3 className="text-xs font-bold text-neutral-100 uppercase tracking-widest">
                Cookie Consent Shield
              </h3>
              <p className="text-[11px] text-neutral-400 mt-1 leading-relaxed">
                We utilize cookies and browser storage to optimize your focus milestones, save interface preferences, and display non-intrusive personal advertisements powered by Google AdSense.
              </p>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row gap-2 pt-1">
            <button
              onClick={handleAcceptAll}
              className="flex-1 bg-amber-500 hover:bg-amber-400 text-[#0A0A0B] text-[10.5px] font-black uppercase py-2 px-3 rounded-xl transition-all cursor-pointer text-center"
            >
              Accept All
            </button>
            <button
              onClick={handleAcceptEssential}
              className="flex-1 border border-neutral-800 hover:border-neutral-700 bg-transparent text-neutral-400 hover:text-neutral-200 text-[10.5px] font-bold uppercase py-2 px-3 rounded-xl transition-all cursor-pointer text-center"
            >
              Essential Only
            </button>
            <button
              onClick={() => setShowPreferences(true)}
              className="border border-neutral-800 hover:border-neutral-750 p-2 text-neutral-500 hover:text-amber-500 rounded-xl transition-all cursor-pointer flex items-center justify-center shrink-0"
              title="Customize Preferences"
            >
              <Settings className="h-4 w-4" />
            </button>
          </div>
        </div>
      ) : (
        <div className="space-y-4">
          <div className="flex items-center justify-between border-b border-neutral-800 pb-2">
            <h3 className="text-xs font-bold text-neutral-100 uppercase tracking-widest">
              Cookie Preferences
            </h3>
            <button 
              onClick={() => setShowPreferences(false)}
              className="text-neutral-500 hover:text-neutral-300 transition-all cursor-pointer"
            >
              <X className="h-4 w-4" />
            </button>
          </div>

          <div className="space-y-3 py-1">
            {/* Essential */}
            <div className="flex items-start justify-between text-xs">
              <div className="pr-4">
                <h4 className="font-bold text-neutral-300">Strictly Essential</h4>
                <p className="text-[10px] text-neutral-500 leading-relaxed mt-0.5">
                  Used for account login, theme settings, and offline custom habit tracking. Mandatory.
                </p>
              </div>
              <span className="text-[10px] bg-neutral-900 text-neutral-500 px-2 py-0.5 rounded font-mono font-bold">
                Active
              </span>
            </div>

            {/* Functional */}
            <div className="flex items-start justify-between text-xs border-t border-neutral-900 pt-3">
              <div className="pr-4">
                <h4 className="font-bold text-neutral-300">Functional Settings</h4>
                <p className="text-[10px] text-neutral-500 leading-relaxed mt-0.5">
                  Remembers your active tab index and checklist completion states. Highly recommended.
                </p>
              </div>
              <button
                onClick={() => setPrefFunctional(!prefFunctional)}
                className={`h-5.5 w-10 rounded-full border transition-all cursor-pointer p-0.5 relative flex items-center ${
                  prefFunctional 
                    ? "bg-amber-500 border-amber-500 justify-end" 
                    : "bg-neutral-900 border-neutral-800 justify-start"
                }`}
              >
                <span className={`h-4.5 w-4.5 rounded-full bg-white shadow transition-all ${
                  prefFunctional ? "bg-[#0A0A0B]" : ""
                }`} />
              </button>
            </div>

            {/* Advertising */}
            <div className="flex items-start justify-between text-xs border-t border-neutral-900 pt-3">
              <div className="pr-4">
                <h4 className="font-bold text-neutral-300">Targeted Advertising</h4>
                <p className="text-[10px] text-neutral-500 leading-relaxed mt-0.5">
                  Allows Google AdSense to optimize displaying ads aligned with your interest profile.
                </p>
              </div>
              <button
                onClick={() => setPrefAds(!prefAds)}
                className={`h-5.5 w-10 rounded-full border transition-all cursor-pointer p-0.5 relative flex items-center ${
                  prefAds 
                    ? "bg-amber-500 border-amber-500 justify-end" 
                    : "bg-neutral-900 border-neutral-800 justify-start"
                }`}
              >
                <span className={`h-4.5 w-4.5 rounded-full bg-white shadow transition-all ${
                  prefAds ? "bg-[#0A0A0B]" : ""
                }`} />
              </button>
            </div>
          </div>

          <div className="flex gap-2 pt-2">
            <button
              onClick={() => setShowPreferences(false)}
              className="flex-1 border border-neutral-800 hover:border-neutral-700 bg-transparent text-neutral-400 text-[10.5px] font-bold uppercase py-2 rounded-xl transition-all cursor-pointer text-center"
            >
              Back
            </button>
            <button
              onClick={handleSavePreferences}
              className="flex-1 bg-amber-500 hover:bg-amber-400 text-[#0A0A0B] text-[10.5px] font-black uppercase py-2 rounded-xl transition-all cursor-pointer text-center"
            >
              Save Choices
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
