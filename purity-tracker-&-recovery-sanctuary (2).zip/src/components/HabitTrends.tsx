/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from "react";
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  Tooltip, 
  ResponsiveContainer, 
  Cell,
  AreaChart,
  Area
} from "recharts";
import { 
  TrendingUp, 
  Award, 
  Flame, 
  CheckSquare, 
  BrainCircuit,
  Zap
} from "lucide-react";

interface HabitTrendsProps {
  dailyChecklist: Record<string, boolean>;
}

export default function HabitTrends({ dailyChecklist }: HabitTrendsProps) {
  // Generate historical data for past 7 days (including today)
  const getHistoricalData = () => {
    const data = [];
    const daysOfWeek = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
    
    // Default values to seed if not already present in history
    const defaultSeeds = [50, 66, 83, 33, 66, 83]; // past 6 days
    
    const savedHistory = (() => {
      try {
        const saved = localStorage.getItem("sanctuary_checklist_history");
        return saved ? JSON.parse(saved) : {};
      } catch {
        return {};
      }
    })();
    
    const todayDateStr = new Date().toISOString().split("T")[0];
    
    for (let i = 6; i >= 0; i--) {
      const d = new Date();
      d.setDate(d.getDate() - i);
      const dateStr = d.toISOString().split("T")[0];
      const dayName = i === 0 ? "Today" : daysOfWeek[d.getDay()];
      
      let rate = 0;
      if (i === 0) {
        // Calculate live for today based on active dailyChecklist prop
        const completedCount = Object.values(dailyChecklist).filter(Boolean).length;
        rate = Math.round((completedCount / 6) * 100);
        
        // Persist today's value in localStorage history
        savedHistory[todayDateStr] = rate;
        try {
          localStorage.setItem("sanctuary_checklist_history", JSON.stringify(savedHistory));
        } catch (e) {
          console.error(e);
        }
      } else {
        if (savedHistory[dateStr] !== undefined) {
          rate = savedHistory[dateStr];
        } else {
          // Use seeded default values to provide immediate rich telemetry
          rate = defaultSeeds[6 - i] || 0;
          savedHistory[dateStr] = rate;
        }
      }
      
      data.push({
        dateStr,
        name: dayName,
        rate: rate,
        completed: Math.round((rate / 100) * 6),
        total: 6
      });
    }
    
    // Persist seeded history to localstorage
    try {
      localStorage.setItem("sanctuary_checklist_history", JSON.stringify(savedHistory));
    } catch (e) {
      console.error(e);
    }
    
    return data;
  };

  const chartData = getHistoricalData();

  // Generate 30-day history data
  const get30DayHistory = () => {
    const data = [];
    const savedHistory = (() => {
      try {
        const saved = localStorage.getItem("sanctuary_checklist_history");
        return saved ? JSON.parse(saved) : {};
      } catch {
        return {};
      }
    })();

    const defaultSeeds = [
      50, 66, 83, 33, 66, 83, 100, 50, 66, 83, 33, 50, 100, 83,
      66, 50, 83, 100, 33, 66, 50, 83, 66, 100, 50, 83, 33, 66, 83, 100
    ];

    for (let i = 29; i >= 0; i--) {
      const d = new Date();
      d.setDate(d.getDate() - i);
      const dateStr = d.toISOString().split("T")[0];
      
      let rate = 0;
      if (i === 0) {
        const completedCount = Object.values(dailyChecklist).filter(Boolean).length;
        rate = Math.round((completedCount / 6) * 100);
      } else {
        if (savedHistory[dateStr] !== undefined) {
          rate = savedHistory[dateStr];
        } else {
          rate = defaultSeeds[29 - i] || 0;
        }
      }

      data.push({
        dayIndex: 30 - i,
        dateStr,
        rate,
        completed: Math.round((rate / 100) * 6),
        total: 6
      });
    }

    return data;
  };

  const history30Days = get30DayHistory();

  // Stats calculations
  const totalRates = chartData.reduce((acc, curr) => acc + curr.rate, 0);
  const avgCompletionRate = Math.round(totalRates / chartData.length);
  const peakRate = Math.max(...chartData.map(d => d.rate));
  
  // High consistency trigger: if average completion rate >= 65%
  const isHighConsistency = avgCompletionRate >= 65;

  // Custom tooltips matching the modern dark aesthetic
  const CustomTooltip = ({ active, payload }: any) => {
    if (active && payload && payload.length) {
      const data = payload[0].payload;
      return (
        <div className="rounded-xl border border-[#1A1A1B] bg-[#0A0A0B] p-3 shadow-xl space-y-1">
          <p className="text-xs font-bold text-neutral-100">{data.name === "Today" ? "Today" : `Day: ${data.name}`}</p>
          <div className="flex items-center space-x-1.5 text-[11px]">
            <span className="h-2 w-2 rounded-full bg-amber-500"></span>
            <span className="text-neutral-400">Completion:</span>
            <span className="font-bold text-amber-500">{data.rate}%</span>
          </div>
          <p className="text-[10px] text-neutral-500 font-semibold uppercase">
            {data.completed} of {data.total} Habits Checked
          </p>
        </div>
      );
    }
    return null;
  };

  return (
    <div id="habit-trends-section" className="rounded-2xl border border-[#1A1A1B] bg-[#0F0F10] p-6 shadow-sm space-y-6">
      
      {/* Header section with Stats Row */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-[#1A1A1B] pb-5">
        <div className="space-y-1">
          <div className="flex items-center space-x-2">
            <TrendingUp className="h-5 w-5 text-amber-500" />
            <h3 className="font-display font-bold text-neutral-100">7-Day Habit Trends</h3>
          </div>
          <p className="text-xs text-neutral-400">
            Telemetry analysis of your Daily Sovereignty Checklist discipline.
          </p>
        </div>

        {/* Stats metrics */}
        <div className="grid grid-cols-2 sm:flex sm:items-center gap-3.5 shrink-0 self-start md:self-auto">
          {/* Average Completion */}
          <div className="bg-[#0A0A0B] border border-[#1A1A1B] px-3.5 py-2 rounded-xl flex flex-col justify-center min-w-[120px]">
            <span className="text-[10px] text-neutral-550 font-bold uppercase tracking-wider">7-Day Average</span>
            <span className="font-display font-black text-amber-500 text-sm mt-0.5 flex items-center space-x-1">
              <span>{avgCompletionRate}%</span>
              <span className="text-[10px] text-neutral-550 font-normal">/ day</span>
            </span>
          </div>

          {/* Peak discipline */}
          <div className="bg-[#0A0A0B] border border-[#1A1A1B] px-3.5 py-2 rounded-xl flex flex-col justify-center min-w-[120px]">
            <span className="text-[10px] text-neutral-550 font-bold uppercase tracking-wider">Peak Rate</span>
            <span className="font-display font-black text-emerald-400 text-sm mt-0.5 flex items-center space-x-1">
              <Award className="h-3.5 w-3.5 text-emerald-400" />
              <span>{peakRate}%</span>
            </span>
          </div>
        </div>
      </div>

      {/* Main Grid: Chart and Descriptive Insight Column */}
      <div className="grid gap-6 lg:grid-cols-12 items-center">
        
        {/* Recharts Bar Chart - Takes 7 columns */}
        <div className="lg:col-span-7 h-52 w-full bg-[#0A0A0B]/50 border border-[#1A1A1B] p-4 rounded-xl flex flex-col justify-between">
          <div className="text-[10px] text-neutral-500 font-bold uppercase tracking-wider mb-2 flex items-center space-x-1">
            <CheckSquare className="h-3.5 w-3.5 text-amber-500" />
            <span>Habit Completion Percentage</span>
          </div>

          <div className="w-full h-40">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={chartData} margin={{ top: 5, right: 5, left: -25, bottom: 0 }}>
                <XAxis 
                  dataKey="name" 
                  stroke="#555555" 
                  fontSize={10}
                  tickLine={false}
                  axisLine={false}
                  dy={8}
                  fontFamily="monospace"
                />
                <YAxis 
                  stroke="#555555" 
                  fontSize={10} 
                  domain={[0, 100]} 
                  tickCount={5}
                  tickFormatter={(v) => `${v}%`}
                  tickLine={false}
                  axisLine={false}
                  fontFamily="monospace"
                />
                <Tooltip content={<CustomTooltip />} cursor={{ fill: '#1A1A1B', opacity: 0.2 }} />
                <Bar 
                  dataKey="rate" 
                  radius={[6, 6, 0, 0]}
                  maxBarSize={32}
                >
                  {chartData.map((entry, index) => {
                    // Visual feedback: full 100% green, solid primary/accent for high, muted secondary for low
                    let fillColor = "var(--primary, #F59E0B)"; // Default dynamic accent
                    if (entry.rate === 100) fillColor = "#10B981"; // Vibrant Emerald for perfect days
                    else if (entry.rate < 50) fillColor = "var(--primary-light, rgba(245, 158, 11, 0.15))"; // Darker warning accent color
                    
                    // Highlight "Today" slightly more with active border or glow style color
                    if (entry.name === "Today") {
                      fillColor = entry.rate === 100 ? "#34D399" : "var(--primary, #FBBF24)";
                    }

                    return (
                      <Cell 
                        key={`cell-${index}`} 
                        fill={fillColor} 
                        className="transition-all duration-300 hover:opacity-80"
                      />
                    );
                  })}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Cognitive & Neuro-Insight panel - Takes 5 columns */}
        <div className="lg:col-span-5 space-y-4">
          <div className="space-y-2">
            <div className="flex items-center space-x-1.5 text-xs font-bold text-neutral-300">
              <BrainCircuit className="h-4 w-4 text-amber-500" />
              <span>Sovereign Neuro-Telemetry</span>
            </div>
            
            <p className="text-xs text-neutral-400 leading-relaxed">
              Consistently checking off items recruits prefrontal networks. Maintaining above a <strong className="text-amber-500">65% 7-Day Average</strong> forces neurotransmitter re-regulation and structural remodeling of reward circuitry.
            </p>
          </div>

          {/* Reward Status Banner */}
          <div className={`p-3.5 rounded-xl border flex items-start space-x-3 ${
            isHighConsistency 
              ? "bg-emerald-550/5 border-emerald-500/20 text-neutral-200" 
              : "bg-amber-550/5 border-amber-500/20 text-neutral-300"
          }`}>
            <div className={`h-8 w-8 rounded-lg flex items-center justify-center shrink-0 border ${
              isHighConsistency 
                ? "bg-emerald-500/10 border-emerald-500/30 text-emerald-400" 
                : "bg-amber-500/10 border-amber-500/30 text-amber-400"
            }`}>
              {isHighConsistency ? <Flame className="h-4.5 w-4.5" /> : <Zap className="h-4.5 w-4.5" />}
            </div>

            <div className="space-y-1">
              <h4 className="text-xs font-black uppercase tracking-wide">
                {isHighConsistency ? "Discipline Shield Active" : "Shield Offline (Needs 65%+)"}
              </h4>
              <p className="text-[10px] text-neutral-450 leading-relaxed">
                {isHighConsistency 
                  ? "Your 7-day habits indicate active neurobiological rewiring. Executive control is dominant over limbic impulses."
                  : "Raise your 7-day habit average above 65% to lock in optimal executive control and speed up DeltaFosB clearance."
                }
              </p>
            </div>
          </div>
        </div>

      </div>

      {/* ================= 30-DAY HEATMAP & CONSISTENCY GRID ================= */}
      <div className="border-t border-[#1A1A1B] pt-6">
        <div className="space-y-4">
          <div className="flex items-center space-x-2">
            <BrainCircuit className="h-5 w-5 text-purple-400" />
            <h3 className="font-display font-bold text-neutral-100">30-Day Consistency Heatmap</h3>
          </div>
          
          <p className="text-xs text-neutral-400 leading-relaxed">
            A comprehensive overview of your past 30 days of prefrontal regulation. Purity is a marathon of aggregated days.
          </p>

          <div className="grid gap-6 lg:grid-cols-12 items-center">
            {/* Heatmap block grid - Takes 6 columns */}
            <div className="lg:col-span-6 bg-[#0A0A0B]/50 border border-[#1A1A1B] p-5 rounded-xl space-y-4">
              <span className="text-[10px] text-neutral-500 font-mono font-bold uppercase tracking-wider">
                30-Day Calendar Blocks
              </span>
              
              <div className="grid grid-cols-10 gap-2">
                {history30Days.map((day) => {
                  let cellColor = "bg-[#0A0A0B] border-[#1A1A1B]";
                  let textColor = "text-neutral-500";
                  
                  if (day.completed === 6) {
                    cellColor = "bg-emerald-500/80 border-emerald-500/30 hover:bg-emerald-400";
                    textColor = "text-[#0A0A0B] font-bold";
                  } else if (day.completed >= 4) {
                    cellColor = "bg-[var(--primary)] border-[var(--primary)]/30 hover:bg-[var(--primary-hover)]";
                    textColor = "text-[#0A0A0B] font-bold";
                  } else if (day.completed >= 2) {
                    cellColor = "bg-[var(--primary)]/40 border-[var(--primary)]/20 hover:bg-[var(--primary)]/60";
                    textColor = "text-neutral-300";
                  } else if (day.completed >= 1) {
                    cellColor = "bg-[var(--primary-light)] border-[var(--primary)]/10 hover:bg-[var(--primary)]/20";
                    textColor = "text-neutral-400";
                  }

                  return (
                    <div 
                      key={day.dayIndex}
                      title={`Day ${day.dayIndex}: ${day.completed}/6 completed (${day.rate}%) - ${day.dateStr}`}
                      className={`aspect-square rounded flex flex-col items-center justify-center border text-[9.5px] transition-all relative group cursor-help ${cellColor} ${textColor}`}
                    >
                      {day.dayIndex}
                      {/* Tooltip on hover */}
                      <div className="absolute bottom-full left-1/2 transform -translate-x-1/2 mb-2 w-32 bg-[#0A0A0B] border border-[#1A1A1B] p-2 rounded-lg text-[10px] text-neutral-350 opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none z-50 text-center font-sans">
                        <p className="font-bold text-neutral-100">Day {day.dayIndex}</p>
                        <p className="text-amber-500 font-bold">{day.completed}/6 Completed</p>
                        <p className="text-[8px] text-neutral-500 mt-0.5">{day.dateStr}</p>
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Heatmap Legend */}
              <div className="flex flex-wrap items-center gap-2 sm:gap-3.5 text-[10px] text-neutral-500 border-t border-[#1A1A1B]/50 pt-3">
                <span>Legend:</span>
                <div className="flex items-center space-x-1">
                  <div className="h-2.5 w-2.5 rounded bg-[#0A0A0B] border border-[#1A1A1B]"></div>
                  <span>0</span>
                </div>
                <div className="flex items-center space-x-1">
                  <div className="h-2.5 w-2.5 rounded bg-amber-950/20 border border-amber-900/10"></div>
                  <span>1-2</span>
                </div>
                <div className="flex items-center space-x-1">
                  <div className="h-2.5 w-2.5 rounded bg-amber-800/40 border border-amber-700/20"></div>
                  <span>3-4</span>
                </div>
                <div className="flex items-center space-x-1">
                  <div className="h-2.5 w-2.5 rounded bg-amber-500 border border-amber-500/30"></div>
                  <span>5</span>
                </div>
                <div className="flex items-center space-x-1">
                  <div className="h-2.5 w-2.5 rounded bg-emerald-500/80 border border-emerald-500/30"></div>
                  <span>6 (Perfect)</span>
                </div>
              </div>
            </div>

            {/* Recharts Area Chart for 30-Day Trend - Takes 6 columns */}
            <div className="lg:col-span-6 h-52 bg-[#0A0A0B]/50 border border-[#1A1A1B] p-5 rounded-xl flex flex-col justify-between">
              <span className="text-[10px] text-neutral-500 font-mono font-bold uppercase tracking-wider mb-2">
                30-Day Completion Rate Trend Curve
              </span>
              
              <div className="w-full h-36">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={history30Days} margin={{ top: 5, right: 5, left: -25, bottom: 0 }}>
                    <defs>
                      <linearGradient id="colorRate" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#8B5CF6" stopOpacity={0.2}/>
                        <stop offset="95%" stopColor="#8B5CF6" stopOpacity={0}/>
                      </linearGradient>
                    </defs>
                    <XAxis 
                      dataKey="dayIndex" 
                      stroke="#444444" 
                      fontSize={9}
                      tickLine={false}
                      axisLine={false}
                      fontFamily="monospace"
                      tickFormatter={(v) => `D${v}`}
                    />
                    <YAxis 
                      stroke="#444444" 
                      fontSize={9} 
                      domain={[0, 100]} 
                      tickCount={3}
                      tickFormatter={(v) => `${v}%`}
                      tickLine={false}
                      axisLine={false}
                      fontFamily="monospace"
                    />
                    <Tooltip 
                      content={({ active, payload }: any) => {
                        if (active && payload && payload.length) {
                          const data = payload[0].payload;
                          return (
                            <div className="rounded-lg border border-[#1A1A1B] bg-[#0A0A0B] p-2 shadow-xl text-[10px]">
                              <p className="font-bold text-neutral-100">Day {data.dayIndex}</p>
                              <p className="text-purple-400 font-bold">{data.rate}% Completion</p>
                            </div>
                          );
                        }
                        return null;
                      }}
                    />
                    <Area 
                      type="monotone" 
                      dataKey="rate" 
                      stroke="#8B5CF6" 
                      strokeWidth={2}
                      fillOpacity={1} 
                      fill="url(#colorRate)" 
                    />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </div>
          </div>
        </div>
      </div>

    </div>
  );
}
