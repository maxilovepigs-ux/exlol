/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from "react";
import { Wind, Activity, Zap, CheckCircle2, ShieldCheck, HeartPulse, RefreshCw } from "lucide-react";
import { User } from "../types";

interface UrgeSOSProps {
  currentUser: User | null;
  onUpdateUser: (user: User) => void;
}

export default function UrgeSOS({ currentUser, onUpdateUser }: UrgeSOSProps) {
  const [activeSOSMode, setActiveSOSMode] = useState<"breathing" | "grounding" | "physical">("breathing");
  
  // ---------------- Box Breathing States ----------------
  const [breathingPhase, setBreathingPhase] = useState<"Inhale" | "Hold" | "Exhale" | "Hold Empty">("Inhale");
  const [phaseSeconds, setPhaseSeconds] = useState(4);
  const [totalSecondsLeft, setTotalSecondsLeft] = useState(120); // 2 minute challenge
  const [breathingActive, setBreathingActive] = useState(false);
  const [breathingComplete, setBreathingComplete] = useState(false);
  const breathingTimerRef = useRef<NodeJS.Timeout | null>(null);

  // ---------------- Grounding States ----------------
  const [groundingStep, setGroundingStep] = useState(0);
  const [groundingInputs, setGroundingInputs] = useState<string[]>(["", "", "", "", ""]);
  const [groundingComplete, setGroundingComplete] = useState(false);

  // ---------------- Box Breathing Logic ----------------
  useEffect(() => {
    if (breathingActive && totalSecondsLeft > 0) {
      breathingTimerRef.current = setInterval(() => {
        setTotalSecondsLeft((prev) => {
          if (prev <= 1) {
            handleBreathingFinish();
            return 0;
          }
          return prev - 1;
        });

        setPhaseSeconds((prevPhaseSecs) => {
          if (prevPhaseSecs <= 1) {
            // Shift breathing phases
            setBreathingPhase((prevPhase) => {
              switch (prevPhase) {
                case "Inhale": return "Hold";
                case "Hold": return "Exhale";
                case "Exhale": return "Hold Empty";
                case "Hold Empty": return "Inhale";
              }
            });
            return 4;
          }
          return prevPhaseSecs - 1;
        });
      }, 1000);
    } else {
      if (breathingTimerRef.current) clearInterval(breathingTimerRef.current);
    }

    return () => {
      if (breathingTimerRef.current) clearInterval(breathingTimerRef.current);
    };
  }, [breathingActive, totalSecondsLeft]);

  const handleBreathingFinish = async () => {
    setBreathingActive(false);
    setBreathingComplete(true);
    
    if (currentUser) {
      try {
        const res = await fetch(`/api/user/${currentUser.id}/urgesurfed`, { method: "POST" });
        if (res.ok) {
          const data = await res.json();
          onUpdateUser(data.user);
        }
      } catch (err) {
        console.error(err);
      }
    }
  };

  const startBreathing = () => {
    setBreathingActive(true);
    setBreathingComplete(false);
    setTotalSecondsLeft(120);
    setBreathingPhase("Inhale");
    setPhaseSeconds(4);
  };

  const stopBreathing = () => {
    setBreathingActive(false);
    if (breathingTimerRef.current) clearInterval(breathingTimerRef.current);
  };

  // ---------------- Grounding Logic ----------------
  const groundingStepsData = [
    { num: 5, prompt: "List 5 objects you can SEE in your room right now (forces optical scanning and breaks focus loop)" },
    { num: 4, prompt: "List 4 textures or physical sensations you can FEEL (e.g. soles of feet, posture of shoulders)" },
    { num: 3, prompt: "List 3 distinct sounds you can HEAR in the environment" },
    { num: 2, prompt: "List 2 scents you can SMELL" },
    { num: 1, prompt: "List 1 word of gratitude or positive affirmation you can TASTE or say out loud" },
  ];

  const handleGroundingNext = () => {
    if (groundingStep < 4) {
      setGroundingStep((prev) => prev + 1);
    } else {
      handleGroundingFinish();
    }
  };

  const handleGroundingFinish = async () => {
    setGroundingComplete(true);
    if (currentUser) {
      try {
        const res = await fetch(`/api/user/${currentUser.id}/urgesurfed`, { method: "POST" });
        if (res.ok) {
          const data = await res.json();
          onUpdateUser(data.user);
        }
      } catch (err) {
        console.error(err);
      }
    }
  };

  const resetGrounding = () => {
    setGroundingStep(0);
    setGroundingInputs(["", "", "", "", ""]);
    setGroundingComplete(false);
  };

  // Helper to get breathing directions
  const getBreathingInstruction = () => {
    switch (breathingPhase) {
      case "Inhale": return "Breathe in deeply through your nose...";
      case "Hold": return "Hold the air in your lungs, feel your chest expand...";
      case "Exhale": return "Let the air out slowly through your mouth...";
      case "Hold Empty": return "Hold empty. Rest in the quiet space...";
    }
  };

  return (
    <div id="sos-room-container" className="max-w-4xl mx-auto space-y-6 fade-in text-neutral-200">
      
      {/* SOS Header Callout */}
      <div className="rounded-2xl bg-[#0F0F10] border border-[#1A1A1B] p-6 shadow-sm flex items-start space-x-4">
        <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-rose-500/10 text-rose-500 border border-rose-500/20 shrink-0">
          <HeartPulse className="h-6 w-6 animate-pulse" />
        </div>
        <div>
          <h2 className="font-display text-xl font-bold text-rose-400">Emergency Urge Sanctuary</h2>
          <p className="mt-1 text-xs text-neutral-400 leading-relaxed">
            An urge is not a mandate to act. Biologically, an urge is a temporary spike of neurological arousal that peaks within <strong>120 seconds</strong> and then recedes if you do not feed it with imagery or thought. Choose a reset protocol below to let the wave pass harmlessly.
          </p>
        </div>
      </div>

      {/* SOS Protocol Selectors */}
      <div className="grid grid-cols-3 gap-3">
        <button
          onClick={() => setActiveSOSMode("breathing")}
          className={`flex flex-col sm:flex-row items-center justify-center sm:space-x-2.5 rounded-xl border p-3 text-center sm:text-left transition-all ${
            activeSOSMode === "breathing"
              ? "bg-amber-500/10 border-amber-500 text-amber-400 font-bold"
              : "bg-[#0F0F10] border-[#1A1A1B] text-neutral-400 hover:bg-[#161618] hover:text-neutral-200"
          }`}
        >
          <Wind className="h-5 w-5 mb-1 sm:mb-0" />
          <div className="text-[11px] sm:text-xs">
            <div className="font-bold sm:text-sm">Box Breathing</div>
            <div className="hidden sm:block text-[10px] opacity-80">2-Min Lung Anchor</div>
          </div>
        </button>

        <button
          onClick={() => setActiveSOSMode("grounding")}
          className={`flex flex-col sm:flex-row items-center justify-center sm:space-x-2.5 rounded-xl border p-3 text-center sm:text-left transition-all ${
            activeSOSMode === "grounding"
              ? "bg-amber-500/10 border-amber-500 text-amber-400 font-bold"
              : "bg-[#0F0F10] border-[#1A1A1B] text-neutral-400 hover:bg-[#161618] hover:text-neutral-200"
          }`}
        >
          <Activity className="h-5 w-5 mb-1 sm:mb-0" />
          <div className="text-[11px] sm:text-xs">
            <div className="font-bold sm:text-sm">5-4-3-2-1 Grounding</div>
            <div className="hidden sm:block text-[10px] opacity-80">Cognitive Focus Reset</div>
          </div>
        </button>

        <button
          onClick={() => setActiveSOSMode("physical")}
          className={`flex flex-col sm:flex-row items-center justify-center sm:space-x-2.5 rounded-xl border p-3 text-center sm:text-left transition-all ${
            activeSOSMode === "physical"
              ? "bg-amber-500/10 border-amber-500 text-amber-400 font-bold"
              : "bg-[#0F0F10] border-[#1A1A1B] text-neutral-400 hover:bg-[#161618] hover:text-neutral-200"
          }`}
        >
          <Zap className="h-5 w-5 mb-1 sm:mb-0" />
          <div className="text-[11px] sm:text-xs">
            <div className="font-bold sm:text-sm">Neural Shock</div>
            <div className="hidden sm:block text-[10px] opacity-80">Physical redirection</div>
          </div>
        </button>
      </div>

      {/* Protocol Workspace */}
      <div className="rounded-2xl border border-[#1A1A1B] bg-[#0F0F10] p-6 shadow-sm min-h-[380px] flex flex-col justify-between">
        
        {/* ================= MODE: BREATHING ================= */}
        {activeSOSMode === "breathing" && (
          <div className="flex flex-col items-center justify-center flex-1 space-y-6">
            {!breathingActive && !breathingComplete ? (
              <div className="text-center max-w-md space-y-4">
                <h3 className="font-display text-lg font-bold text-neutral-100">Box Breathing Sentry</h3>
                <p className="text-xs text-neutral-400 leading-relaxed">
                  Box Breathing is used by special forces to stabilize heart rates and suppress panic or extreme chemical urges. We will breathe in a 4x4x4x4 rhythm. Survive 2 minutes to reclaim focus and gain <strong>+50 XP</strong>.
                </p>
                <button
                  id="start-breathing-btn"
                  onClick={startBreathing}
                  className="rounded-xl bg-amber-500 hover:bg-amber-400 text-[#0A0A0B] font-bold text-sm px-6 py-3 transition-all"
                >
                  Initiate 2-Minute Resiliency Anchor
                </button>
              </div>
            ) : breathingActive ? (
              <div className="flex flex-col items-center text-center space-y-6">
                
                {/* Breathing Visual Ring */}
                <div className="relative flex h-48 w-48 items-center justify-center">
                  
                  {/* Dynamic outer rhythmic breathing circle */}
                  <div className={`absolute inset-0 rounded-full border-4 border-amber-500/40 ${
                    breathingPhase === "Inhale" 
                      ? "scale-115 bg-amber-500/15 duration-4000 transition-transform" 
                      : breathingPhase === "Exhale" 
                      ? "scale-90 bg-amber-500/5 duration-4000 transition-transform" 
                      : breathingPhase === "Hold" 
                      ? "scale-115 bg-amber-500/25 border-amber-500/70" 
                      : "scale-90 bg-amber-500/10 border-amber-500/30"
                  }`} />

                  {/* Core display */}
                  <div className="z-10 text-center">
                    <span className="text-[10px] font-bold text-amber-500 tracking-wider uppercase">
                      {breathingPhase}
                    </span>
                    <div className="font-display text-3xl font-extrabold text-[#E5E5E5] my-1">
                      {phaseSeconds}s
                    </div>
                    <span className="text-[11px] font-semibold text-neutral-400">
                      {Math.floor(totalSecondsLeft / 60)}:
                      {String(totalSecondsLeft % 60).padStart(2, "0")} left
                    </span>
                  </div>
                </div>

                {/* Live Instruction text */}
                <div className="max-w-sm">
                  <p className="text-sm font-semibold text-neutral-200 animate-pulse">
                    {getBreathingInstruction()}
                  </p>
                </div>

                <button
                  id="stop-breathing-btn"
                  onClick={stopBreathing}
                  className="rounded-lg border border-[#1A1A1B] bg-[#0A0A0B] text-neutral-400 hover:bg-[#161618] px-3.5 py-1.5 text-xs font-medium"
                >
                  Pause Anchor
                </button>
              </div>
            ) : (
              <div className="text-center max-w-sm space-y-4 py-6">
                <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-full bg-emerald-500/10 text-emerald-500 border border-emerald-500/20">
                  <ShieldCheck className="h-8 w-8" />
                </div>
                <h3 className="font-display text-xl font-bold text-neutral-100">Urge Wave Surfed!</h3>
                <p className="text-xs text-neutral-400 leading-relaxed">
                  Congratulations! You did not surrender your sovereign mind. Your dopamine baseline has successfully survived the chemical peak. Your prefrontal cortex is taking charge.
                </p>
                {currentUser && (
                  <div className="inline-block rounded-xl bg-emerald-500/10 border border-emerald-500/20 px-4 py-2 text-xs font-bold text-emerald-400">
                    +50 XP Claimed & Level Updated!
                  </div>
                )}
                <div className="pt-2">
                  <button
                    onClick={startBreathing}
                    className="flex items-center mx-auto space-x-1.5 text-xs font-bold text-amber-500 hover:underline"
                  >
                    <RefreshCw className="h-4 w-4" />
                    <span>Surf again if needed</span>
                  </button>
                </div>
              </div>
            )}
          </div>
        )}

        {/* ================= MODE: GROUNDING ================= */}
        {activeSOSMode === "grounding" && (
          <div className="flex flex-col justify-between flex-1">
            {!groundingComplete ? (
              <div className="space-y-6">
                <div className="border-b border-[#1A1A1B] pb-3">
                  <div className="flex items-center justify-between text-xs font-bold text-neutral-500 uppercase tracking-widest">
                    <span>Sensory Grounding Protocol</span>
                    <span>Step {groundingStep + 1} of 5</span>
                  </div>
                  <h3 className="font-display text-lg font-bold text-neutral-100 mt-1">
                    The 5-4-3-2-1 Cognitive Disruption
                  </h3>
                </div>

                {/* Progress bar */}
                <div className="h-1.5 w-full bg-[#161618] border border-[#262626] rounded-full overflow-hidden">
                  <div 
                    className="h-full bg-amber-500 transition-all duration-300"
                    style={{ width: `${((groundingStep + 1) / 5) * 100}%` }}
                  ></div>
                </div>

                <div className="space-y-4">
                  <div className="rounded-xl bg-[#161618] p-4 border border-[#262626]">
                    <span className="inline-flex h-7 w-7 items-center justify-center rounded-lg bg-amber-500/10 text-amber-500 font-bold text-sm mr-2.5 border border-amber-500/20">
                      {groundingStepsData[groundingStep].num}
                    </span>
                    <span className="text-xs font-semibold text-neutral-300">
                      {groundingStepsData[groundingStep].prompt}
                    </span>
                  </div>

                  {/* Input field to keep fingers typing and conscious thought locked */}
                  <div className="space-y-2">
                    <label className="text-[10px] uppercase font-bold text-neutral-500 tracking-wider">
                      Write them down here to lock focus:
                    </label>
                    <input
                      type="text"
                      placeholder="Type your sensory observations..."
                      value={groundingInputs[groundingStep]}
                      onChange={(e) => {
                        const copy = [...groundingInputs];
                        copy[groundingStep] = e.target.value;
                        setGroundingInputs(copy);
                      }}
                      className="w-full rounded-xl border border-[#1A1A1B] bg-[#0A0A0B] text-neutral-200 px-3.5 py-2.5 text-sm outline-none transition-all focus:border-amber-500"
                    />
                  </div>
                </div>

                {/* Buttons */}
                <div className="flex justify-between items-center pt-4">
                  <button
                    onClick={resetGrounding}
                    className="text-xs font-semibold text-neutral-500 hover:underline"
                  >
                    Reset Steps
                  </button>
                  <button
                    onClick={handleGroundingNext}
                    disabled={!groundingInputs[groundingStep].trim()}
                    className="rounded-xl bg-amber-500 hover:bg-amber-400 disabled:bg-neutral-800 disabled:text-neutral-600 text-[#0A0A0B] font-bold text-xs px-5 py-2.5"
                  >
                    {groundingStep === 4 ? "Complete Grounding" : "Next Step"}
                  </button>
                </div>
              </div>
            ) : (
              <div className="flex flex-col items-center text-center justify-center py-8 space-y-4">
                <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-full bg-emerald-500/10 text-emerald-500 border border-emerald-500/20">
                  <CheckCircle2 className="h-8 w-8" />
                </div>
                <h3 className="font-display text-xl font-bold text-neutral-100">Mind Grounded Successfully</h3>
                <p className="text-xs text-neutral-400 max-w-sm leading-relaxed">
                  Excellent work. By writing down your sensory environment, you bypassed the limbic system's hijack and restored control of your prefrontal cortex. You are back in reality.
                </p>
                {currentUser && (
                  <div className="inline-block rounded-xl bg-emerald-500/10 border border-emerald-500/20 px-4 py-2 text-xs font-bold text-emerald-400">
                    +50 XP Claimed & Level Updated!
                  </div>
                )}
                <div className="pt-2">
                  <button
                    onClick={resetGrounding}
                    className="text-xs font-bold text-amber-500 hover:underline"
                  >
                    Perform again
                  </button>
                </div>
              </div>
            )}
          </div>
        )}

        {/* ================= MODE: PHYSICAL SHOCK ================= */}
        {activeSOSMode === "physical" && (
          <div className="space-y-6">
            <div className="border-b border-[#1A1A1B] pb-3">
              <span className="text-xs font-bold text-neutral-500 uppercase tracking-widest">
                Autonomic Nervous System Hijack Protocol
              </span>
              <h3 className="font-display text-lg font-bold text-neutral-100 mt-1">
                The Autonomic Reset (Biological Interruption)
              </h3>
            </div>

            <p className="text-xs text-neutral-400 leading-relaxed">
              When an urge gets severe, your brain experiences a physical dopamine loop. You must break it by triggering a stark physical change. Pick one or both protocols right now:
            </p>

            <div className="grid gap-4 sm:grid-cols-2">
              
              {/* Cold water splash */}
              <div className="rounded-xl border border-[#1A1A1B] bg-[#161618]/30 p-4 space-y-2.5">
                <div className="flex items-center space-x-2">
                  <span className="flex h-7 w-7 items-center justify-center rounded-lg bg-blue-500/10 text-blue-400 border border-blue-500/20 font-bold text-sm">
                    1
                  </span>
                  <h4 className="text-xs font-bold text-neutral-200 uppercase tracking-wider">
                    The Mammalian Dive Reflex Splash
                  </h4>
                </div>
                <p className="text-[11px] text-neutral-450 leading-relaxed">
                  Go to the bathroom instantly. Fill your cupped hands with <strong>freezing cold water</strong> and plunge your face in it for 10 seconds. 
                </p>
                <div className="text-[10px] font-semibold text-blue-400 bg-blue-500/5 p-2 rounded border border-blue-500/15">
                  <strong>Why it works:</strong> Cold water triggers the ophthalmic nerve, forcing your vagus nerve to slow heart rate immediately and shutdown physical arousal mechanics.
                </div>
              </div>

              {/* Pushup challenge */}
              <div className="rounded-xl border border-[#1A1A1B] bg-[#161618]/30 p-4 space-y-2.5">
                <div className="flex items-center space-x-2">
                  <span className="flex h-7 w-7 items-center justify-center rounded-lg bg-rose-500/10 text-rose-400 border border-rose-500/20 font-bold text-sm">
                    2
                  </span>
                  <h4 className="text-xs font-bold text-neutral-200 uppercase tracking-wider">
                    The 20-Pushup Muscle Recruter
                  </h4>
                </div>
                <p className="text-[11px] text-neutral-450 leading-relaxed">
                  Drop to the floor right now. Do <strong>20 controlled pushups</strong> or <strong>25 air squats</strong>. Focus purely on the burn in your muscles.
                </p>
                <div className="text-[10px] font-semibold text-rose-400 bg-rose-500/5 p-2 rounded border border-rose-500/15">
                  <strong>Why it works:</strong> Floods your large skeletal muscles (chest/legs) with vascular blood flow, pulling energy and circulation directly away from sexual centers.
                </div>
              </div>

            </div>

            <div className="border-t border-[#1A1A1B] pt-4 flex justify-between items-center">
              <span className="text-[11px] font-medium text-neutral-500">
                Did you complete a physical shock reset?
              </span>
              <button
                id="claim-shock-xp-btn"
                onClick={handleGroundingFinish} // awards the 50 XP
                disabled={groundingComplete}
                className="rounded-xl bg-emerald-600 hover:bg-emerald-500 disabled:bg-[#161618] disabled:text-neutral-650 text-white font-bold text-xs px-4 py-2"
              >
                {groundingComplete ? "XP Secured" : "Yes, I Surfed the Urge! (+50 XP)"}
              </button>
            </div>
          </div>
        )}

      </div>

    </div>
  );
}
