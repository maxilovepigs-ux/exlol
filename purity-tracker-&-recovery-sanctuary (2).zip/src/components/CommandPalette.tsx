/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from "react";
import { 
  Search, 
  Terminal, 
  Activity, 
  ShieldAlert, 
  BookOpen, 
  Award, 
  MessageSquare, 
  Brain, 
  Settings, 
  Moon, 
  Sun, 
  Flame, 
  Shield, 
  Gift,
  X,
  Keyboard
} from "lucide-react";

interface CommandItem {
  id: string;
  name: string;
  category: string;
  icon: React.ComponentType<any>;
  shortcut?: string;
  action: () => void;
}

interface CommandPaletteProps {
  isOpen: boolean;
  onClose: () => void;
  setActiveTab: (tab: string) => void;
  isFocusMode: boolean;
  onToggleFocusMode: () => void;
  theme: "dark" | "deep-night" | "light" | "midnight" | "soft-gray" | "glassmorphism" | "amoled" | "glass" | "ocean";
  onToggleTheme: () => void;
  onTriggerSOS: () => void;
  onClaimChest: () => void;
  onTogglePrivacyScreen: () => void;
}

export default function CommandPalette({
  isOpen,
  onClose,
  setActiveTab,
  isFocusMode,
  onToggleFocusMode,
  theme,
  onToggleTheme,
  onTriggerSOS,
  onClaimChest,
  onTogglePrivacyScreen
}: CommandPaletteProps) {
  const [query, setQuery] = useState("");
  const [selectedIndex, setSelectedIndex] = useState(0);
  const inputRef = useRef<HTMLInputElement>(null);
  const listRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (isOpen) {
      setQuery("");
      setSelectedIndex(0);
      // Let animation play first before focusing
      const timer = setTimeout(() => {
        inputRef.current?.focus();
      }, 50);
      return () => clearTimeout(timer);
    }
  }, [isOpen]);

  const commands: CommandItem[] = [
    {
      id: "nav-dashboard",
      name: "Go to Dashboard",
      category: "Navigation",
      icon: Activity,
      shortcut: "G + D",
      action: () => {
        setActiveTab("dashboard");
        onClose();
      }
    },
    {
      id: "nav-sos",
      name: "Go to Urge SOS Room",
      category: "Navigation",
      icon: ShieldAlert,
      shortcut: "G + S",
      action: () => {
        setActiveTab("sos");
        onClose();
      }
    },
    {
      id: "nav-wisdom",
      name: "Go to Wisdom & Science",
      category: "Navigation",
      icon: BookOpen,
      shortcut: "G + W",
      action: () => {
        setActiveTab("wisdom");
        onClose();
      }
    },
    {
      id: "nav-leaderboard",
      name: "Go to Leaderboards",
      category: "Navigation",
      icon: Award,
      shortcut: "G + L",
      action: () => {
        setActiveTab("leaderboard");
        onClose();
      }
    },
    {
      id: "nav-community",
      name: "Go to Community & Chat",
      category: "Navigation",
      icon: MessageSquare,
      shortcut: "G + C",
      action: () => {
        setActiveTab("community");
        onClose();
      }
    },
    {
      id: "nav-mentor",
      name: "Go to AI Purity Mentor",
      category: "Navigation",
      icon: Brain,
      shortcut: "G + M",
      action: () => {
        setActiveTab("mentor");
        onClose();
      }
    },
    {
      id: "nav-settings",
      name: "Go to Sovereign Settings",
      category: "Navigation",
      icon: Settings,
      shortcut: "G + ,",
      action: () => {
        setActiveTab("settings");
        onClose();
      }
    },
    {
      id: "cmd-focus",
      name: isFocusMode ? "Disable Focus Mode" : "Enable Focus Mode",
      category: "Quick Actions",
      icon: Flame,
      shortcut: "F",
      action: () => {
        onToggleFocusMode();
        onClose();
      }
    },
    {
      id: "cmd-theme",
      name: `Cycle Themes (Current: ${
        theme === "deep-night" ? "Pure Deep Night" 
        : theme === "light" ? "Alabaster Light" 
        : theme === "midnight" ? "Midnight Cosmic"
        : theme === "soft-gray" ? "Soft Slate"
        : theme === "glassmorphism" ? "Frosted Glass"
        : theme === "amoled" ? "AMOLED Black"
        : theme === "glass" ? "Liquid Glass"
        : theme === "ocean" ? "Ocean Breeze"
        : "Sophisticated Dark"
      })`,
      category: "Appearance",
      icon: theme === "light" ? Sun : Moon,
      shortcut: "T",
      action: () => {
        onToggleTheme();
      }
    },
    {
      id: "cmd-sos-trigger",
      name: "EMERGENCY: Trigger Rescue Pulse",
      category: "Quick Actions",
      icon: ShieldAlert,
      shortcut: "E",
      action: () => {
        onTriggerSOS();
        onClose();
      }
    },
    {
      id: "cmd-daily-chest",
      name: "Unlock Sovereign Daily Chest",
      category: "Rewards",
      icon: Gift,
      shortcut: "D",
      action: () => {
        onClaimChest();
        onClose();
      }
    },
    {
      id: "cmd-privacy",
      name: "Activate Sanctuary Shield Mask",
      category: "Privacy & Safety",
      icon: Shield,
      shortcut: "P",
      action: () => {
        onTogglePrivacyScreen();
        onClose();
      }
    }
  ];

  const filteredCommands = commands.filter(cmd =>
    cmd.name.toLowerCase().includes(query.toLowerCase()) ||
    cmd.category.toLowerCase().includes(query.toLowerCase())
  );

  useEffect(() => {
    // Keep selection in bounds
    if (selectedIndex >= filteredCommands.length) {
      setSelectedIndex(Math.max(0, filteredCommands.length - 1));
    }
  }, [filteredCommands, selectedIndex]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (!isOpen) return;

      if (e.key === "ArrowDown") {
        e.preventDefault();
        setSelectedIndex(prev => (prev + 1) % filteredCommands.length);
      } else if (e.key === "ArrowUp") {
        e.preventDefault();
        setSelectedIndex(prev => (prev - 1 + filteredCommands.length) % filteredCommands.length);
      } else if (e.key === "Enter") {
        e.preventDefault();
        if (filteredCommands[selectedIndex]) {
          filteredCommands[selectedIndex].action();
        }
      } else if (e.key === "Escape") {
        e.preventDefault();
        onClose();
      }
    };

    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [isOpen, filteredCommands, selectedIndex, onClose]);

  // Handle outside click
  const handleOverlayClick = (e: React.MouseEvent) => {
    if (e.target === e.currentTarget) {
      onClose();
    }
  };

  if (!isOpen) return null;

  return (
    <div 
      id="command-palette-overlay" 
      onClick={handleOverlayClick}
      className="fixed inset-0 z-50 flex items-start justify-center bg-black/60 pt-[10vh] px-4 backdrop-blur-md animate-fade-in"
    >
      <div 
        id="command-palette-content"
        className="w-full max-w-xl rounded-2xl border border-[#1A1A1B] bg-[#0F0F10]/95 shadow-2xl overflow-hidden flex flex-col max-h-[70vh] scale-in"
      >
        {/* Search header bar */}
        <div className="flex items-center space-x-3 border-b border-[#1A1A1B] px-4 py-3.5 bg-[#161618]/30">
          <Search className="h-5 w-5 text-neutral-500 shrink-0" />
          <input
            ref={inputRef}
            type="text"
            placeholder="Type a command or page name to search..."
            value={query}
            onChange={(e) => {
              setQuery(e.target.value);
              setSelectedIndex(0);
            }}
            className="flex-1 bg-transparent text-sm text-neutral-200 outline-none placeholder-neutral-600 focus:ring-0 focus:outline-none"
          />
          <kbd className="hidden sm:inline-flex items-center space-x-1 border border-[#262626] bg-[#0A0A0B] px-2 py-0.5 rounded text-[10px] font-mono text-neutral-500">
            <span>ESC</span>
          </kbd>
          <button 
            onClick={onClose}
            className="text-neutral-500 hover:text-neutral-300 transition-all sm:hidden"
          >
            <X className="h-4.5 w-4.5" />
          </button>
        </div>

        {/* Results view list */}
        <div ref={listRef} className="flex-1 overflow-y-auto p-2.5 max-h-[50vh] space-y-1 scrollbar-none">
          {filteredCommands.length > 0 ? (
            filteredCommands.map((cmd, idx) => {
              const Icon = cmd.icon;
              const isSelected = idx === selectedIndex;
              return (
                <button
                  key={cmd.id}
                  onClick={() => cmd.action()}
                  onMouseEnter={() => setSelectedIndex(idx)}
                  className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl transition-all text-left ${
                    isSelected 
                      ? "bg-amber-500/10 border border-amber-500/20 text-amber-400" 
                      : "border border-transparent text-neutral-400 hover:text-neutral-300"
                  }`}
                >
                  <div className="flex items-center space-x-3 min-w-0">
                    <div className={`h-8 w-8 rounded-lg flex items-center justify-center border transition-all shrink-0 ${
                      isSelected 
                        ? "bg-amber-500/15 border-amber-500/30 text-amber-400" 
                        : "bg-[#0A0A0B] border-[#1A1A1B] text-neutral-500"
                    }`}>
                      <Icon className="h-4.5 w-4.5" />
                    </div>
                    <div className="min-w-0">
                      <p className="text-xs font-bold truncate">{cmd.name}</p>
                      <p className="text-[9px] text-neutral-550 uppercase font-mono tracking-wider">{cmd.category}</p>
                    </div>
                  </div>

                  {cmd.shortcut && (
                    <kbd className={`hidden sm:inline-block font-mono text-[9px] px-1.5 py-0.5 rounded border transition-all ${
                      isSelected 
                        ? "border-amber-500/30 bg-amber-500/10 text-amber-500" 
                        : "border-[#1A1A1B] bg-[#0A0A0B] text-neutral-600"
                    }`}>
                      {cmd.shortcut}
                    </kbd>
                  )}
                </button>
              );
            })
          ) : (
            <div className="text-center py-10 text-neutral-500 space-y-2">
              <Keyboard className="h-8 w-8 mx-auto text-neutral-650 animate-pulse" />
              <p className="text-xs font-semibold">No commands found</p>
              <p className="text-[11px] text-neutral-600">Try typing "Navigation" or "Theme" to explore tools.</p>
            </div>
          )}
        </div>

        {/* Dynamic keyboard help footer */}
        <div className="border-t border-[#1A1A1B] bg-[#161618]/30 px-4 py-2.5 flex items-center justify-between text-[10px] text-neutral-550 font-mono font-bold">
          <div className="flex items-center space-x-3">
            <span className="flex items-center"><span className="border border-[#262626] bg-[#0A0A0B] px-1 rounded mr-1">↑↓</span> Move</span>
            <span className="flex items-center"><span className="border border-[#262626] bg-[#0A0A0B] px-1 rounded mr-1">Enter</span> Select</span>
          </div>
          <div className="flex items-center space-x-1.5">
            <Terminal className="h-3 w-3 text-amber-500/60" />
            <span>Sovereign Command Console</span>
          </div>
        </div>
      </div>
    </div>
  );
}
