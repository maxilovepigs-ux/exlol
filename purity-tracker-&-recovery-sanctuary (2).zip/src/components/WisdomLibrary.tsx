/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from "react";
import { 
  BookOpen, 
  Brain, 
  Sparkles, 
  Zap, 
  Flame, 
  ShieldAlert, 
  Compass, 
  Layers, 
  CheckCircle,
  TrendingUp,
  Award,
  Quote,
  RefreshCw
} from "lucide-react";
import { User } from "../types";

interface WisdomLibraryProps {
  currentUser: User | null;
}

export default function WisdomLibrary({ currentUser }: WisdomLibraryProps) {
  const [activeTab, setActiveTab] = useState<"neuroscience" | "transmutation" | "simulator" | "philosophy">("neuroscience");
  const [dailyQuote, setDailyQuote] = useState<any | null>(null);
  const [loadingQuote, setLoadingQuote] = useState<boolean>(false);
  const [quoteError, setQuoteError] = useState<string | null>(null);
  const [pledgeText, setPledgeText] = useState<string>("");
  const [pledgeSuccess, setPledgeSuccess] = useState<boolean>(false);
  const [transmuteTarget, setTransmuteTarget] = useState<string>("");
  const [transmuteInput, setTransmuteInput] = useState<string>("");
  const [plannerOutput, setPlannerOutput] = useState<any | null>(null);

  // Dynamic estimated dopamine recovery percent based on current streak
  const getStreakDays = () => {
    if (!currentUser || !currentUser.streakStartDate) return 0;
    const start = new Date(currentUser.streakStartDate);
    const now = new Date();
    const diff = Math.abs(now.getTime() - start.getTime());
    return Math.floor(diff / (1000 * 60 * 60 * 24));
  };

  const streakDays = getStreakDays();
  // Sigmoid estimation of receptor upregulation: reaches 100% at around 90 days
  const estimateDopaminePercent = (days: number) => {
    const k = 0.05; // Growth constant
    const x0 = 30;  // Midpoint (30 days is peak rewiring)
    const val = 100 / (1 + Math.exp(-k * (days - x0)));
    return Math.min(Math.max(Math.round(val), 10), 100);
  };

  const dopaminePercent = estimateDopaminePercent(streakDays);

  const handleGenerateTransmute = (e: React.FormEvent) => {
    e.preventDefault();
    if (!transmuteTarget) return;

    let strategy = "";
    let actionItem = "";
    let focusQuote = "";

    switch (transmuteTarget) {
      case "athletics":
        strategy = "Hyper-circulate physical energy into compound muscle training. Biological arousal triggers excess adrenaline and glycogen availability.";
        actionItem = "Immediately execute a 15-minute high-intensity workout or do five sets of max-effort pullups/pushups. Use the surge as fuel for skeletal tissue power.";
        focusQuote = "The same energy that creates life is the energy that builds physical armor and grit.";
        break;
      case "creativity":
        strategy = "Sublimate sexual tension into creative visual, musical, or written forms. Tension creates high mental focus and restless desire which can be channeled directly into deep-state writing or design.";
        actionItem = "Open a blank canvas, document, or pick up your instrument. Commit to 25 minutes of continuous creation without self-editing.";
        focusQuote = "Arousal is the ultimate catalyst for emotional art. Channel the raw tension into a finished masterpiece.";
        break;
      case "career":
        strategy = "Direct the drive into cognitive endurance and strategic professional planning. High-speed neural drive can be converted into ruthless planning and high-intensity problem-solving.";
        actionItem = "Draft a step-by-step roadmap for your primary career goal. Work on your most complex code, analysis, or business task for 45 minutes without distraction.";
        focusQuote = "Convert physical urgency into professional dominance. Clear your pending logs and execute.";
        break;
      case "philosophy":
        strategy = "Absorb restless mental energy into stoic literature and critical cognitive self-examination. Channel the physical stress of abstinence into reading challenging metaphysical books.";
        actionItem = "Read 10 pages of Marcus Aurelius or Seneca. Reflect on your sovereignty over animal impulses through a written summary.";
        focusQuote = "No man is free who is not master of himself.";
        break;
      default:
        strategy = "Refocus your physical environment, step outdoors, and practice deep, conscious attention on standard natural structures.";
        actionItem = "Step away from all screens. Walk around the block and notice five complex architectural or natural structures with high focus.";
        focusQuote = "Purity is the deliberate reclamation of the quiet, natural world.";
    }

    setPlannerOutput({
      target: transmuteTarget,
      input: transmuteInput,
      strategy,
      actionItem,
      focusQuote
    });
  };

  const fetchDailyQuote = async (forceRegen = false) => {
    setLoadingQuote(true);
    setQuoteError(null);
    try {
      const url = forceRegen ? "/api/philosophy/daily?regen=true" : "/api/philosophy/daily";
      const res = await fetch(url);
      if (res.ok) {
        const data = await res.json();
        setDailyQuote(data);
      } else {
        throw new Error("Failed to load daily philosophy quote");
      }
    } catch (err: any) {
      console.error(err);
      setQuoteError("Failed to fetch today's quote from Sanctuary archives. Stand firm in your own counsel.");
    } finally {
      setLoadingQuote(false);
    }
  };

  useEffect(() => {
    if (activeTab === "philosophy" && !dailyQuote) {
      fetchDailyQuote();
    }
  }, [activeTab]);

  return (
    <div id="wisdom-library-container" className="max-w-4xl mx-auto space-y-6 fade-in text-neutral-200">
      
      {/* Wisdom Header */}
      <div className="rounded-2xl border border-neutral-800 bg-[#0F0F10] p-6 shadow-sm flex items-start space-x-4">
        <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-amber-500/10 text-amber-500 border border-amber-500/20 shrink-0">
          <BookOpen className="h-6 w-6" />
        </div>
        <div>
          <h2 className="font-display text-xl font-bold text-neutral-100">Wisdom & Neuroscience Sanctuary</h2>
          <p className="mt-1 text-xs text-neutral-400 leading-relaxed">
            Unraveling the deep chemical structures of addiction, rewiring, and the ancient art of <strong>Sexual Transmutation</strong>. Reclaim control of your neural pathways with modern clinical research and stoic wisdom.
          </p>
        </div>
      </div>

      {/* Tabs Selector */}
      <div className="flex border-b border-neutral-800/80 pb-1.5 justify-start space-x-6 overflow-x-auto">
        <button
          onClick={() => setActiveTab("neuroscience")}
          className={`flex items-center space-x-2 pb-2 text-sm font-bold transition-all relative ${
            activeTab === "neuroscience" 
              ? "text-amber-500" 
              : "text-neutral-500 hover:text-neutral-300"
          }`}
        >
          <Brain className="h-4 w-4" />
          <span>The Science of Rewiring</span>
          {activeTab === "neuroscience" && (
            <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-amber-500 rounded-full"></div>
          )}
        </button>

        <button
          onClick={() => setActiveTab("transmutation")}
          className={`flex items-center space-x-2 pb-2 text-sm font-bold transition-all relative ${
            activeTab === "transmutation" 
              ? "text-amber-500" 
              : "text-neutral-500 hover:text-neutral-300"
          }`}
        >
          <Zap className="h-4 w-4" />
          <span>Sexual Transmutation Guide</span>
          {activeTab === "transmutation" && (
            <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-amber-500 rounded-full"></div>
          )}
        </button>

        <button
          onClick={() => setActiveTab("simulator")}
          className={`flex items-center space-x-2 pb-2 text-sm font-bold transition-all relative ${
            activeTab === "simulator" 
              ? "text-amber-500" 
              : "text-neutral-500 hover:text-neutral-300"
          }`}
        >
          <TrendingUp className="h-4 w-4" />
          <span>Dopamine Baseline Simulator</span>
          {activeTab === "simulator" && (
            <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-amber-500 rounded-full"></div>
          )}
        </button>

        <button
          id="philosophy-tab-btn"
          onClick={() => setActiveTab("philosophy")}
          className={`flex items-center space-x-2 pb-2 text-sm font-bold transition-all relative ${
            activeTab === "philosophy" 
              ? "text-amber-500" 
              : "text-neutral-500 hover:text-neutral-300"
          }`}
        >
          <Quote className="h-4 w-4" />
          <span>Daily Philosophy Sanctuary</span>
          {activeTab === "philosophy" && (
            <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-amber-500 rounded-full"></div>
          )}
        </button>
      </div>

      {/* ================= TAB: NEUROSCIENCE ================= */}
      {activeTab === "neuroscience" && (
        <div className="grid gap-6 md:grid-cols-2">
          
          {/* Neuro Card 1 */}
          <div className="rounded-2xl border border-neutral-850 bg-[#0F0F10] p-5 space-y-3.5">
            <div className="flex items-center space-x-2 text-amber-500">
              <Layers className="h-5 w-5" />
              <h3 className="font-display font-bold text-neutral-100">Dopamine DeltaFosB Accumulation</h3>
            </div>
            <p className="text-xs text-neutral-400 leading-relaxed">
              Consuming high-stimulus imagery floods the ventral striatum with dopamine, inducing the accumulation of the transcription factor <strong>DeltaFosB</strong>. DeltaFosB acts as a molecular switch, hyper-sensitizing the brain to sexual cues and driving compulsion.
            </p>
            <div className="rounded-xl bg-[#161618] p-3 text-[11px] text-emerald-400 border border-[#262626]">
              <strong>The Rewire:</strong> DeltaFosB decays gradually when the compulsive loop is starved. After 30–60 days of purity, cravings lose their automatic, chemical grip.
            </div>
          </div>

          {/* Neuro Card 2 */}
          <div className="rounded-2xl border border-neutral-850 bg-[#0F0F10] p-5 space-y-3.5">
            <div className="flex items-center space-x-2 text-amber-500">
              <ShieldAlert className="h-5 w-5" />
              <h3 className="font-display font-bold text-neutral-100">Prefrontal Cortex Decoupling</h3>
            </div>
            <p className="text-xs text-neutral-400 leading-relaxed">
              Under heavy addiction, the connection between the prefrontal cortex (the seat of executive veto power) and the limbic system (impulse engine) is structurally weakened. In a state of trigger, the PFC literally "goes offline", leading to self-sabotage.
            </p>
            <div className="rounded-xl bg-[#161618] p-3 text-[11px] text-emerald-400 border border-[#262626]">
              <strong>The Rewire:</strong> Practicing mindful urge surfing and box breathing forces oxygen into the PFC and activates the vagus nerve, rebuilding the physical structural connection.
            </div>
          </div>

          {/* Neuro Card 3 */}
          <div className="rounded-2xl border border-neutral-850 bg-[#0F0F10] p-5 space-y-3.5">
            <div className="flex items-center space-x-2 text-amber-500">
              <Brain className="h-5 w-5" />
              <h3 className="font-display font-bold text-neutral-100">Hyper-Sensitization & Desensitization</h3>
            </div>
            <p className="text-xs text-neutral-400 leading-relaxed">
              High-intensity artificial stimulation downregulates dopamine D2 receptors. This desensitization bleeds into daily life as <em>Anhedonia</em> (lack of pleasure in regular things like books, sun, normal socialization) and chronic brain fog.
            </p>
            <div className="rounded-xl bg-[#161618] p-3 text-[11px] text-emerald-400 border border-[#262626]">
              <strong>The Rewire:</strong> Starving high-stimulus cues allows D2 receptors to upregulate. In 3 weeks, normal, beautiful aspects of life become intensely vibrant again.
            </div>
          </div>

          {/* Neuro Card 4 */}
          <div className="rounded-2xl border border-neutral-850 bg-[#0F0F10] p-5 space-y-3.5 flex flex-col justify-between">
            <div className="space-y-2.5">
              <div className="flex items-center space-x-2 text-amber-500">
                <Flame className="h-5 w-5 animate-pulse" />
                <h3 className="font-display font-bold text-neutral-100">Androgen Receptor Density</h3>
              </div>
              <p className="text-xs text-neutral-400 leading-relaxed">
                Abstinence and focus prevent androgen receptor saturation, increasing the density of androgen receptors in the brain. This enables more efficient utilization of endogenous testosterone, boosting focus, physical strength, and mental resilience.
              </p>
            </div>
            <div className="rounded-xl bg-amber-500/5 p-3 text-[11px] text-amber-400 border border-amber-500/10 mt-3">
              <strong>Stoic Principle:</strong> Self-control is not deprivation; it is the ultimate optimization of physical and cognitive energy.
            </div>
          </div>

        </div>
      )}

      {/* ================= TAB: TRANSMUTATION ================= */}
      {activeTab === "transmutation" && (
        <div className="space-y-6">
          
          <div className="rounded-2xl border border-neutral-850 bg-[#0F0F10] p-6 space-y-4">
            <h3 className="font-display text-lg font-bold text-neutral-100 flex items-center space-x-2">
              <Zap className="text-amber-500 h-5.5 w-5.5" />
              <span>The Art of Sexual Sublimation</span>
            </h3>
            <p className="text-xs text-neutral-400 leading-relaxed">
              Sexual energy is the strongest biological force in human nature. It is a creative, physical, dynamic current. Attempting to simply "suppress" or "ignore" it builds static tension that inevitably leads to a crash. <strong>Transmutation</strong> is the conscious practice of directing this intense current into secondary productive outlets.
            </p>

            {/* The Transmutation Interactive Planner */}
            <form onSubmit={handleGenerateTransmute} className="space-y-4 rounded-xl bg-[#161618] p-4 border border-[#262626] mt-4">
              <h4 className="text-xs font-bold text-amber-500 uppercase tracking-wider">
                Interactive Transmutation Planner
              </h4>

              <div className="space-y-3">
                <label className="block text-[11px] font-bold text-neutral-400 uppercase">
                  Select your Transmutation Channel:
                </label>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
                  {[
                    { id: "athletics", label: "Athletic Burn" },
                    { id: "creativity", label: "Creative Flow" },
                    { id: "career", label: "Deep Work / Code" },
                    { id: "philosophy", label: "Stoic Study" }
                  ].map((target) => (
                    <button
                      key={target.id}
                      type="button"
                      onClick={() => setTransmuteTarget(target.id)}
                      className={`rounded-lg py-2 text-xs font-semibold text-center border transition-all ${
                        transmuteTarget === target.id
                          ? "bg-amber-500/10 border-amber-500 text-amber-400 font-bold"
                          : "border-neutral-800 text-neutral-500 bg-[#0F0F10] hover:bg-neutral-900"
                      }`}
                    >
                      {target.label}
                    </button>
                  ))}
                </div>
              </div>

              <div className="space-y-2">
                <label className="block text-[11px] font-bold text-neutral-400 uppercase">
                  (Optional) What specific task are you seeking to accomplish?
                </label>
                <input
                  type="text"
                  placeholder="e.g. Code my main landing page, Lift heavy squats, Read Seneca..."
                  value={transmuteInput}
                  onChange={(e) => setTransmuteInput(e.target.value)}
                  className="w-full rounded-xl border border-neutral-800 bg-[#0F0F10] px-3.5 py-2.5 text-xs text-neutral-200 outline-none focus:border-amber-500 transition-all"
                />
              </div>

              <button
                type="submit"
                disabled={!transmuteTarget}
                className="w-full rounded-xl bg-amber-500 text-[#0A0A0B] font-bold text-xs py-2.5 hover:bg-amber-400 disabled:bg-neutral-800 disabled:text-neutral-600 transition-all"
              >
                Formulate Transmutation Protocol
              </button>
            </form>

            {/* Planner Output Box */}
            {plannerOutput && (
              <div className="rounded-xl border border-amber-500/20 bg-amber-500/5 p-5 space-y-4 animate-fade-in mt-4">
                <div className="flex items-center space-x-2 text-amber-500 border-b border-amber-500/10 pb-2">
                  <Sparkles className="h-4.5 w-4.5 animate-pulse" />
                  <span className="text-xs font-bold uppercase tracking-wider">Dynamic Protocol Initiated</span>
                </div>

                <div className="space-y-3">
                  <div>
                    <span className="text-[10px] font-bold text-amber-400/80 uppercase tracking-widest block">Core Sublimation Strategy</span>
                    <p className="text-xs text-neutral-300 leading-relaxed font-medium mt-0.5">{plannerOutput.strategy}</p>
                  </div>

                  <div>
                    <span className="text-[10px] font-bold text-amber-400/80 uppercase tracking-widest block">Immediate Action Item</span>
                    <p className="text-xs text-emerald-400 leading-relaxed font-semibold mt-0.5">{plannerOutput.actionItem}</p>
                  </div>

                  {plannerOutput.input && (
                    <div>
                      <span className="text-[10px] font-bold text-amber-400/80 uppercase tracking-widest block">Personal Target Task</span>
                      <p className="text-xs text-neutral-300 leading-relaxed italic mt-0.5">"{plannerOutput.input}"</p>
                    </div>
                  )}

                  <div className="border-t border-amber-500/10 pt-2.5">
                    <p className="text-[11px] text-neutral-500 italic text-center">
                      "{plannerOutput.focusQuote}"
                    </p>
                  </div>
                </div>
              </div>
            )}

          </div>

        </div>
      )}

      {/* ================= TAB: SIMULATOR ================= */}
      {activeTab === "simulator" && (
        <div className="rounded-2xl border border-neutral-850 bg-[#0F0F10] p-6 space-y-5">
          <div className="border-b border-neutral-800 pb-3 flex justify-between items-center">
            <div>
              <h3 className="font-display text-lg font-bold text-neutral-100 flex items-center space-x-2">
                <TrendingUp className="text-emerald-500 h-5 w-5" />
                <span>Dopamine Receptor Sensitivity Simulator</span>
              </h3>
              <p className="text-xs text-neutral-400 mt-0.5">
                Estimating your physical neural healing trajectory based on your actual timeline.
              </p>
            </div>
            
            <div className="text-right">
              <span className="text-[10px] font-bold text-neutral-400 uppercase tracking-wider block">Your Streak</span>
              <span className="text-lg font-extrabold text-amber-500">{streakDays} Days</span>
            </div>
          </div>

          <div className="grid gap-6 md:grid-cols-3 items-center">
            
            {/* Sensitivity Wheel */}
            <div className="flex flex-col items-center justify-center p-4 border border-neutral-850 bg-[#161618] rounded-xl text-center">
              <span className="text-[10px] font-bold text-neutral-400 uppercase tracking-widest">
                Receptor Density
              </span>
              
              <div className="relative flex h-36 w-36 items-center justify-center my-3.5">
                <svg className="absolute inset-0 h-full w-full rotate-270">
                  <circle
                    cx="72"
                    cy="72"
                    r="58"
                    className="fill-none stroke-neutral-800"
                    strokeWidth="8"
                  />
                  <circle
                    cx="72"
                    cy="72"
                    r="58"
                    className="fill-none stroke-emerald-500 transition-all duration-1000 ease-in-out"
                    strokeWidth="8"
                    strokeDasharray={364}
                    strokeDashoffset={364 - (364 * dopaminePercent) / 100}
                    strokeLinecap="round"
                  />
                </svg>

                <div className="z-10 text-center">
                  <div className="text-2xl font-extrabold text-neutral-100">
                    {dopaminePercent}%
                  </div>
                  <span className="text-[9px] font-bold text-neutral-400 tracking-wider uppercase block">
                    Sensitivity
                  </span>
                </div>
              </div>

              <span className="text-[10px] bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 px-2.5 py-0.5 rounded-full font-bold">
                {dopaminePercent < 30 ? "Downregulated" : dopaminePercent < 70 ? "Upregulating" : "Healed Baseline"}
              </span>
            </div>

            {/* Explanatory trajectory list */}
            <div className="md:col-span-2 space-y-4">
              <h4 className="text-xs font-bold text-neutral-300 uppercase tracking-wider">
                Physical Timeline Milestones:
              </h4>

              <div className="space-y-3">
                {[
                  { range: "Day 0 - 3", desc: "Chemical withdrawal. Brain craves fast feedback. Urge SOS and Box Breathing are crucial anchors.", completed: streakDays >= 3 },
                  { range: "Day 7 - 14", desc: "Androgen receptors adjust. Normal focus starts recovering. Brain fog begins to lift.", completed: streakDays >= 14 },
                  { range: "Day 30", desc: "DeltaFosB declines significantly. Dopamine receptor upregulation reaches midpoint. Pure joy in daily life returns.", completed: streakDays >= 30 },
                  { range: "Day 90+", desc: "Dopamine receptors fully upregulate back to biological baselines. Deep cognitive restructuring is complete. You have ascended.", completed: streakDays >= 90 }
                ].map((m, idx) => (
                  <div 
                    key={idx} 
                    className={`flex items-start space-x-3 p-2.5 rounded-lg border transition-all ${
                      m.completed 
                        ? "bg-emerald-500/5 border-emerald-500/20 text-neutral-200" 
                        : "bg-neutral-900/40 border-neutral-850 text-neutral-500"
                    }`}
                  >
                    <div className="mt-0.5 shrink-0">
                      {m.completed ? (
                        <CheckCircle className="h-4.5 w-4.5 text-emerald-500 fill-emerald-500/10" />
                      ) : (
                        <div className="h-4 w-4 rounded-full border border-neutral-700 flex items-center justify-center text-[8px] font-bold text-neutral-400">
                          {idx + 1}
                        </div>
                      )}
                    </div>
                    <div>
                      <div className="text-[11px] font-bold flex items-center justify-between">
                        <span>{m.range}</span>
                        {m.completed && (
                          <span className="text-[9px] uppercase tracking-wider font-extrabold text-emerald-500 bg-emerald-500/10 px-1.5 py-0.25 rounded">
                            Secured
                          </span>
                        )}
                      </div>
                      <p className="text-[11px] mt-0.5 leading-relaxed">{m.desc}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

          </div>

          <div className="rounded-xl bg-amber-500/5 border border-amber-500/10 p-3.5 text-xs text-amber-400 leading-relaxed flex items-start space-x-2">
            <Award className="h-4.5 w-4.5 text-amber-500 shrink-0 mt-0.5" />
            <span>
              <strong>Scientific Fact:</strong> Brain plasticity is your ally. Neuroplasticity guarantees that every single day you maintain your sovereign stance, your brain physically breaks down the pathways of addiction and builds pathways of strength.
            </span>
          </div>
        </div>
      )}

      {/* ================= TAB: PHILOSOPHY ================= */}
      {activeTab === "philosophy" && (
        <div className="space-y-6 animate-fade-in" id="philosophy-section">
          <div className="rounded-2xl border border-neutral-850 bg-[#0F0F10] p-6 space-y-5 relative overflow-hidden">
            <div className="absolute top-0 right-0 h-40 w-40 bg-amber-500/5 rounded-full blur-3xl -mr-10 -mt-10 pointer-events-none"></div>
            
            <div className="border-b border-neutral-800 pb-4 flex flex-wrap justify-between items-center gap-4">
              <div>
                <h3 className="font-display text-lg font-bold text-neutral-100 flex items-center space-x-2">
                  <Quote className="text-amber-500 h-5 w-5" />
                  <span>The Daily Wisdom Pillar</span>
                </h3>
                <p className="text-xs text-neutral-400 mt-0.5">
                  Profound guidance from history's greatest minds, dynamically analyzed by Gemini AI to help you maintain absolute sovereignty today.
                </p>
              </div>
              
              <button
                onClick={() => fetchDailyQuote(true)}
                disabled={loadingQuote}
                className="rounded-xl border border-[#262626] bg-[#0A0A0B] hover:bg-[#161618] text-xs font-bold text-neutral-400 hover:text-[#E5E5E5] px-3.5 py-2 transition-all flex items-center space-x-2 shrink-0 disabled:opacity-50 cursor-pointer"
              >
                <RefreshCw className={`h-3.5 w-3.5 ${loadingQuote ? 'animate-spin' : ''}`} />
                <span>Request New Insight</span>
              </button>
            </div>

            {loadingQuote ? (
              <div className="py-24 text-center space-y-4">
                <RefreshCw className="h-10 w-10 text-amber-500 mx-auto animate-spin" />
                <div className="space-y-1">
                  <p className="text-sm font-semibold text-neutral-300">Consulting the ancient scrolls...</p>
                  <p className="text-xs text-neutral-500 max-w-xs mx-auto">Gemini is synthesizing a profound, custom philosophical framework for your focus today.</p>
                </div>
              </div>
            ) : quoteError ? (
              <div className="rounded-xl border border-rose-500/20 bg-rose-500/5 p-6 text-center space-y-3">
                <p className="text-xs text-rose-400">{quoteError}</p>
                <button
                  onClick={() => fetchDailyQuote()}
                  className="rounded-lg bg-rose-500/10 border border-rose-500/25 px-4 py-2 text-xs font-bold text-rose-400 hover:bg-rose-500/20 transition-all cursor-pointer"
                >
                  Retry Portal Connection
                </button>
              </div>
            ) : dailyQuote ? (
              <div className="space-y-6">
                
                {/* Large Display Quote */}
                <div className="rounded-xl border border-[#1A1A1B] bg-[#0A0A0B]/60 p-8 space-y-6 flex flex-col justify-center items-center text-center relative">
                  <Quote className="absolute top-4 left-4 h-16 w-16 text-neutral-900 pointer-events-none" />
                  
                  <div className="space-y-4 z-10 max-w-2xl">
                    <span className="inline-block rounded-full bg-amber-500/10 border border-amber-500/25 px-3 py-1 text-[10px] font-bold text-amber-500 tracking-wider uppercase">
                      {dailyQuote.school || "School of Wisdom"}
                    </span>
                    
                    <h4 className="text-lg md:text-xl font-display font-medium text-neutral-100 leading-relaxed italic pr-4">
                      "{dailyQuote.quote}"
                    </h4>
                    
                    <p className="text-sm text-amber-500 font-bold tracking-wider uppercase">
                      — {dailyQuote.author}
                    </p>
                  </div>
                </div>

                {/* AI / CBT Application Commentary */}
                <div className="rounded-xl border border-amber-500/10 bg-amber-500/5 p-5 space-y-3.5 relative overflow-hidden">
                  <div className="absolute top-0 right-0 h-24 w-24 bg-amber-500/5 rounded-full blur-2xl pointer-events-none"></div>
                  
                  <div className="flex items-center space-x-2 text-amber-500">
                    <Sparkles className="h-4.5 w-4.5 animate-pulse" />
                    <h4 className="text-xs font-bold uppercase tracking-wider">CBT Application & Recovery Context</h4>
                  </div>
                  
                  <p className="text-xs text-neutral-300 leading-relaxed font-medium">
                    {dailyQuote.commentary || "No commentary currently available. Let these words settle into your consciousness as you navigate today's triggers."}
                  </p>
                  
                  <div className="border-t border-neutral-800 pt-3 flex justify-between items-center text-[10px] text-neutral-500">
                    <span>Generated fresh on {dailyQuote.date}</span>
                    <span className="italic">Powered by Gemini 3.5 Flash</span>
                  </div>
                </div>

              </div>
            ) : (
              <div className="py-24 text-center">
                <p className="text-xs text-neutral-500">The sanctuary is currently quiet. Click 'Request New Insight' to begin.</p>
              </div>
            )}
          </div>
          
          {/* Quick interactive journaling on the quote */}
          <div className="rounded-2xl border border-neutral-850 bg-[#0F0F10] p-6 space-y-4">
            <div className="flex items-center space-x-2 text-amber-500">
              <Compass className="h-5 w-5" />
              <h3 className="font-display font-bold text-neutral-100">Sovereign Meditation Prompt</h3>
            </div>
            
            <p className="text-xs text-neutral-400 leading-relaxed">
              True learning requires active assimilation. How does today's quote apply to any specific trigger or restless energy you are facing today? Write down a 1-sentence pledge incorporating this insight.
            </p>
            
            <div className="rounded-xl bg-[#161618] p-4 border border-[#262626] space-y-3">
              <textarea
                value={pledgeText}
                onChange={(e) => {
                  setPledgeText(e.target.value);
                  setPledgeSuccess(false);
                }}
                placeholder="e.g., Epictetus' quote reminds me that my urge is not a command. Today, I choose to remain a free master over digital triggers..."
                rows={2}
                className="w-full bg-[#0A0A0B] border border-[#1A1A1B] hover:border-neutral-800 focus:border-amber-500/50 focus:outline-none rounded-xl p-3 text-xs text-neutral-300 placeholder-neutral-700 transition-all resize-none"
              />
              
              {pledgeSuccess && (
                <div className="rounded-lg bg-emerald-500/10 border border-emerald-500/25 p-3 text-xs text-emerald-400">
                  Your Stoic Pledge has been locked into your active memory. Carry this focus throughout the day!
                </div>
              )}

              <button
                onClick={() => {
                  if (pledgeText.trim()) {
                    setPledgeSuccess(true);
                    setPledgeText("");
                  }
                }}
                disabled={!pledgeText.trim()}
                className="w-full bg-amber-500 hover:bg-amber-400 disabled:opacity-50 text-[#0A0A0B] font-bold text-xs py-2 rounded-xl transition-all cursor-pointer"
              >
                Log Stoic Pledge
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
