import React, { useEffect, useRef, useState } from "react";

interface CustomCursorProps {
  enabled: boolean;
  theme: "dark" | "deep-night" | "light" | "midnight" | "soft-gray" | "glassmorphism" | "amoled" | "glass" | "ocean";
  accentColor: "emerald" | "amber" | "indigo" | "rose" | "violet" | "orange";
  reducedMotion: boolean;
}

interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  size: number;
  color: string;
  alpha: number;
  decay: number;
}

const COLOR_MAP: Record<string, string> = {
  emerald: "#10b981",
  amber: "#f59e0b",
  indigo: "#6366f1",
  rose: "#f43f5e",
  violet: "#8b5cf6",
  orange: "#f97316"
};

export default function CustomCursor({ enabled, theme, accentColor, reducedMotion }: CustomCursorProps) {
  const [isVisible, setIsVisible] = useState(false);
  const [isHovered, setIsHovered] = useState(false);
  const [isPressed, setIsPressed] = useState(false);
  const [isTextField, setIsTextField] = useState(false);
  const [ripples, setRipples] = useState<{ id: number; x: number; y: number }[]>([]);

  // Refs for low-overhead coordinates
  const mouseCoords = useRef({ x: -100, y: -100 });
  const ringCoords = useRef({ x: -100, y: -100 });
  const dotCoords = useRef({ x: -100, y: -100 });

  // Refs to track current size and border radius for smooth morphing
  const ringSize = useRef({ w: 28, h: 28 });
  const ringBorderRadius = useRef("50%");

  // Magnetic state references (avoiding state triggers in high-frequency loops)
  const isMagnetic = useRef(false);
  const magneticProgress = useRef(0);
  const hoveredElementRect = useRef<DOMRect | null>(null);
  const hoveredElementBorderRadius = useRef("50%");

  // Premium particle system references
  const particles = useRef<Particle[]>([]);
  const isPremiumHovered = useRef(false);

  // Element Refs
  const dotRef = useRef<HTMLDivElement>(null);
  const ringRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  // Active theme and accent colors for JS drawing
  const currentAccentColorHex = COLOR_MAP[accentColor] || "#f59e0b";
  const isLightTheme = theme === "light" || theme === "soft-gray";

  // Canvas resize handler
  useEffect(() => {
    if (!enabled || reducedMotion) return;

    const handleResize = () => {
      if (canvasRef.current) {
        canvasRef.current.width = window.innerWidth;
        canvasRef.current.height = window.innerHeight;
      }
    };
    
    handleResize();
    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
  }, [enabled, reducedMotion]);

  // Main Event Listeners
  useEffect(() => {
    if (!enabled) {
      document.documentElement.classList.remove("custom-cursor-active");
      return;
    }

    // Hide native cursor on desktop
    document.documentElement.classList.add("custom-cursor-active");

    const onMouseMove = (e: MouseEvent) => {
      mouseCoords.current = { x: e.clientX, y: e.clientY };
      if (!isVisible) setIsVisible(true);
    };

    const onMouseOver = (e: MouseEvent) => {
      const target = e.target as HTMLElement | null;
      if (!target) return;

      // Detect if hovering input fields or textareas for typing state
      const isInput = 
        target.tagName === "INPUT" || 
        target.tagName === "TEXTAREA" || 
        target.isContentEditable ||
        target.closest("input") || 
        target.closest("textarea");

      setIsTextField(!!isInput);

      // Detect premium elements for particle effects
      const isPremium = 
        target.closest(".premium-target") || 
        target.closest(".sobriety-clock") || 
        target.closest(".milestone-card") || 
        target.closest(".premium-hover-target") ||
        target.closest("[data-premium='true']");

      isPremiumHovered.current = !!isPremium;

      // General interactive element check
      const isInteractive = 
        target.closest("a") || 
        target.closest("button") || 
        target.closest("select") || 
        target.closest('[role="button"]') || 
        target.closest(".cursor-pointer") ||
        window.getComputedStyle(target).cursor === "pointer";

      setIsHovered(!!isInteractive);

      // Check if target should have magnetic snapping (buttons, links, nav tabs)
      const shouldBeMagnetic = 
        target.closest("button") || 
        target.closest("a") || 
        target.closest(".magnetic-target");

      if (shouldBeMagnetic && !isInput) {
        const magneticEl = shouldBeMagnetic as HTMLElement;
        const rect = magneticEl.getBoundingClientRect();
        hoveredElementRect.current = rect;
        
        // Grab border radius of the element so the outer ring frames it perfectly
        const computedStyle = window.getComputedStyle(magneticEl);
        hoveredElementBorderRadius.current = computedStyle.borderRadius || "12px";
        isMagnetic.current = true;
      } else {
        isMagnetic.current = false;
        hoveredElementRect.current = null;
      }
    };

    const onMouseDown = (e: MouseEvent) => {
      setIsPressed(true);

      // Create click ripple effect
      if (!reducedMotion) {
        const newRipple = {
          id: Date.now() + Math.random(),
          x: e.clientX,
          y: e.clientY
        };
        setRipples(prev => [...prev.slice(-3), newRipple]);
      }
    };

    const onMouseUp = () => setIsPressed(false);
    const onMouseLeave = () => setIsVisible(false);
    const onMouseEnter = () => setIsVisible(true);

    window.addEventListener("mousemove", onMouseMove);
    window.addEventListener("mouseover", onMouseOver);
    window.addEventListener("mousedown", onMouseDown);
    window.addEventListener("mouseup", onMouseUp);
    document.addEventListener("mouseleave", onMouseLeave);
    document.addEventListener("mouseenter", onMouseEnter);

    return () => {
      document.documentElement.classList.remove("custom-cursor-active");
      window.removeEventListener("mousemove", onMouseMove);
      window.removeEventListener("mouseover", onMouseOver);
      window.removeEventListener("mousedown", onMouseDown);
      window.removeEventListener("mouseup", onMouseUp);
      document.removeEventListener("mouseleave", onMouseLeave);
      document.removeEventListener("mouseenter", onMouseEnter);
    };
  }, [enabled, isVisible, reducedMotion]);

  // 60 FPS RequestAnimationFrame Loop
  useEffect(() => {
    if (!enabled) return;

    let animationFrameId: number;

    const updatePosition = () => {
      // 1. Particle spawning and canvas render if premium target is hovered
      if (canvasRef.current && !reducedMotion) {
        const ctx = canvasRef.current.getContext("2d");
        if (ctx) {
          // Spawn sparkle particles on premium hover
          if (isPremiumHovered.current && Math.random() < 0.35) {
            particles.current.push({
              x: mouseCoords.current.x + (Math.random() - 0.5) * 16,
              y: mouseCoords.current.y + (Math.random() - 0.5) * 16,
              vx: (Math.random() - 0.5) * 1.5,
              vy: -0.6 - Math.random() * 1.5, // Float up
              size: 2.5 + Math.random() * 3,
              color: currentAccentColorHex,
              alpha: 0.9,
              decay: 0.015 + Math.random() * 0.02
            });
          }

          // Render loop for particles
          ctx.clearRect(0, 0, ctx.canvas.width, ctx.canvas.height);
          for (let i = particles.current.length - 1; i >= 0; i--) {
            const p = particles.current[i];
            p.x += p.vx;
            p.y += p.vy;
            p.alpha -= p.decay;
            p.size *= 0.97;

            if (p.alpha <= 0 || p.size <= 0.2) {
              particles.current.splice(i, 1);
              continue;
            }

            ctx.save();
            ctx.globalAlpha = p.alpha;
            ctx.shadowBlur = 6;
            ctx.shadowColor = p.color;
            ctx.beginPath();
            ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
            ctx.fillStyle = p.color;
            ctx.fill();
            ctx.restore();
          }
        }
      }

      // 2. Main Cursor Coordinate Easing
      const targetX = mouseCoords.current.x;
      const targetY = mouseCoords.current.y;

      // Handle Reduced Motion (Zero Lerp Lag)
      if (reducedMotion) {
        ringCoords.current = { x: targetX, y: targetY };
        dotCoords.current = { x: targetX, y: targetY };

        if (ringRef.current) {
          ringRef.current.style.transform = `translate3d(${targetX - 14}px, ${targetY - 14}px, 0)`;
        }
        if (dotRef.current) {
          dotRef.current.style.transform = `translate3d(${targetX - 3}px, ${targetY - 3}px, 0)`;
        }

        animationFrameId = requestAnimationFrame(updatePosition);
        return;
      }

      // Smooth Lerp Rates (hardware-friendly tuning)
      const lerpDot = 0.42; // Fast, instant responsiveness
      let lerpRing = 0.14; // Elegant lag

      dotCoords.current.x += (targetX - dotCoords.current.x) * lerpDot;
      dotCoords.current.y += (targetY - dotCoords.current.y) * lerpDot;

      // Calculate Ring Center and Target Size
      let destRingX = targetX;
      let destRingY = targetY;
      let destWidth = 28;
      let destHeight = 28;
      let destBorderRadius = "50%";

      // Lerp magnetic attraction state
      if (isMagnetic.current && hoveredElementRect.current) {
        magneticProgress.current += (1 - magneticProgress.current) * 0.16;
        lerpRing = 0.22; // Snappier locking when magnetic
      } else {
        magneticProgress.current += (0 - magneticProgress.current) * 0.16;
      }

      // Blend standard position with magnetic snapping location
      if (magneticProgress.current > 0.01 && hoveredElementRect.current) {
        const rect = hoveredElementRect.current;
        const elemCenterX = rect.left + rect.width / 2;
        const elemCenterY = rect.top + rect.height / 2;

        // Apply a subtle rubber-band drag so the ring remains anchored but elastic
        const dragFactor = 0.15;
        const snapX = elemCenterX + (targetX - elemCenterX) * dragFactor;
        const snapY = elemCenterY + (targetY - elemCenterY) * dragFactor;

        destRingX = snapX;
        destRingY = snapY;

        // Scale to wrap the bounding box beautifully
        destWidth = rect.width + 12;
        destHeight = rect.height + 10;
        destBorderRadius = hoveredElementBorderRadius.current;
      } else {
        // Default Hover expansion
        if (isHovered) {
          destWidth = 46;
          destHeight = 46;
        } else if (isPressed) {
          destWidth = 20;
          destHeight = 20;
        } else if (isTextField) {
          destWidth = 0; // Outer ring completely vanishes on text inputs
          destHeight = 0;
        }
      }

      // Interpolate dimensions and coordinates for beautiful fluid transitions
      ringSize.current.w += (destWidth - ringSize.current.w) * 0.18;
      ringSize.current.h += (destHeight - ringSize.current.h) * 0.18;

      ringCoords.current.x += (destRingX - ringCoords.current.x) * lerpRing;
      ringCoords.current.y += (destRingY - ringCoords.current.y) * lerpRing;

      // Apply transforms
      if (ringRef.current) {
        // Position offset centered with dynamic width and height
        const halfW = ringSize.current.w / 2;
        const halfH = ringSize.current.h / 2;
        ringRef.current.style.transform = `translate3d(${ringCoords.current.x - halfW}px, ${ringCoords.current.y - halfH}px, 0)`;
        ringRef.current.style.width = `${ringSize.current.w}px`;
        ringRef.current.style.height = `${ringSize.current.h}px`;
        ringRef.current.style.borderRadius = destBorderRadius;
      }

      if (dotRef.current) {
        // Tiny visual adjustments for typing indicator style
        if (isTextField) {
          // Inner dot morphs to high-precision slender beam or point
          dotRef.current.style.transform = `translate3d(${dotCoords.current.x - 1}px, ${dotCoords.current.y - 7}px, 0) scaleY(2.2)`;
        } else {
          dotRef.current.style.transform = `translate3d(${dotCoords.current.x - 3}px, ${dotCoords.current.y - 3}px, 0) scale(1)`;
        }
      }

      animationFrameId = requestAnimationFrame(updatePosition);
    };

    animationFrameId = requestAnimationFrame(updatePosition);

    return () => {
      cancelAnimationFrame(animationFrameId);
    };
  }, [enabled, isHovered, isPressed, isTextField, reducedMotion, currentAccentColorHex]);

  // Touch device check to prevent mobile interaction conflicts
  const [isTouchDevice, setIsTouchDevice] = useState(false);
  useEffect(() => {
    const checkTouch = () => {
      setIsTouchDevice(
        "ontouchstart" in window || navigator.maxTouchPoints > 0
      );
    };
    checkTouch();
    window.addEventListener("resize", checkTouch);
    return () => window.removeEventListener("resize", checkTouch);
  }, []);

  if (!enabled || isTouchDevice || !isVisible) return null;

  return (
    <div className="fixed inset-0 pointer-events-none z-[999999] overflow-hidden select-none">
      {/* Click Ripple Container */}
      {!reducedMotion && ripples.map(ripple => (
        <span
          key={ripple.id}
          className="absolute rounded-full pointer-events-none border will-change-transform animate-cursor-ripple"
          style={{
            left: ripple.x - 24,
            top: ripple.y - 24,
            width: "48px",
            height: "48px",
            borderColor: isLightTheme ? "rgba(0, 0, 0, 0.45)" : "var(--primary)",
            backgroundColor: isLightTheme ? "rgba(0, 0, 0, 0.05)" : "rgba(var(--primary-rgb), 0.15)",
          }}
          onAnimationEnd={() => {
            setRipples(prev => prev.filter(r => r.id !== ripple.id));
          }}
        />
      ))}

      {/* HTML5 Canvas for Glittering Float Particles */}
      {!reducedMotion && (
        <canvas
          ref={canvasRef}
          className="fixed inset-0 pointer-events-none z-[999998]"
        />
      )}

      {/* Outer Ring Element (Snaps / Morphs dynamically) */}
      <div
        ref={ringRef}
        className={`fixed top-0 left-0 pointer-events-none will-change-transform transition-colors duration-300 ease-out border ${
          isLightTheme 
            ? "border-neutral-800/40 bg-transparent" 
            : "border-primary/45 bg-transparent"
        } ${
          isPressed 
            ? isLightTheme 
              ? "bg-neutral-800/10 border-neutral-800" 
              : "bg-primary/10 border-primary" 
            : isHovered 
            ? isLightTheme 
              ? "bg-neutral-800/5 border-neutral-800" 
              : "bg-primary/5 border-primary" 
            : ""
        }`}
        style={{
          boxShadow: isHovered && !isLightTheme ? "0 0 12px var(--primary)" : "none",
        }}
      />

      {/* Inner Point Element (Provides zero noticeable input delay) */}
      <div
        ref={dotRef}
        className={`fixed top-0 left-0 w-1.5 h-1.5 rounded-full pointer-events-none will-change-transform transition-all duration-200 ${
          isLightTheme ? "bg-neutral-900" : "bg-primary"
        }`}
      />
    </div>
  );
}
