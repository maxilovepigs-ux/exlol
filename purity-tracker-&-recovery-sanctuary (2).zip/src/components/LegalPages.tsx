/**
 * @license
 * SPDX-License-Identifier: Apache-2.5
 */

import React, { useState } from "react";
import { 
  Shield, 
  Info, 
  Mail, 
  FileText, 
  Database, 
  CheckSquare, 
  Send, 
  HelpCircle, 
  Globe, 
  Lock, 
  Compass, 
  MessageSquare, 
  ArrowLeft,
  BookOpen,
  Brain,
  Sparkles,
  Zap,
  RefreshCw
} from "lucide-react";

interface PageProps {
  onBackToDashboard: () => void;
}

// ================= 1. PRIVACY POLICY =================
export function PrivacyPolicy({ onBackToDashboard }: PageProps) {
  return (
    <div className="max-w-4xl mx-auto space-y-8 animate-fade-in text-neutral-200">
      {/* Header */}
      <div className="rounded-2xl border border-neutral-800 bg-[#0F0F10] p-6 sm:p-8 shadow-sm relative overflow-hidden">
        <div className="absolute top-0 right-0 h-40 w-40 bg-primary/5 rounded-full blur-3xl pointer-events-none"></div>
        <button 
          onClick={onBackToDashboard}
          className="inline-flex items-center space-x-1.5 text-xs font-bold text-primary hover:text-primary-hover mb-4 transition-all cursor-pointer"
        >
          <ArrowLeft className="h-4 w-4" />
          <span>Return to Sovereign Dashboard</span>
        </button>
        <div className="flex items-start space-x-4">
          <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-primary/10 text-primary border border-primary/20 shrink-0">
            <Shield className="h-6 w-6" />
          </div>
          <div>
            <h1 className="font-display text-2xl font-bold text-neutral-100">Privacy Policy</h1>
            <p className="mt-1.5 text-xs text-neutral-450 leading-relaxed font-mono">
              Last Updated: July 16, 2026 | Compliant with Google AdSense Policies
            </p>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="rounded-2xl border border-[#1A1A1B] bg-[#0F0F10] p-6 sm:p-8 space-y-6 text-xs sm:text-sm leading-relaxed text-neutral-300">
        <p className="text-neutral-400">
          Sovereign Mind Sanctuary ("we", "our", or "the Sanctuary") is committed to protecting your privacy and security. This Privacy Policy details how we handle information in connection with your use of our application, our commitment to absolute data transparency, and our cooperation with advertising services such as Google AdSense.
        </p>

        {/* Ad Space Placement Placeholder */}
        <div className="rounded-xl border border-dashed border-neutral-800 bg-[#0A0A0B] p-4 text-center my-4">
          <span className="text-[9px] font-mono uppercase tracking-widest text-neutral-600 block mb-1">Sponsored Context Area</span>
          <div className="h-16 flex items-center justify-center text-[10px] text-neutral-500 italic">
            This space is reserved for premium, non-intrusive focus and self-discipline sponsorships.
          </div>
        </div>

        <section className="space-y-3">
          <h2 className="font-display text-base font-bold text-neutral-100 flex items-center space-x-2">
            <Lock className="h-4.5 w-4.5 text-primary" />
            <span>1. Information We Collect</span>
          </h2>
          <p className="text-neutral-450">
            Because we prioritize cognitive sovereignty, we minimize data harvesting. However, to provide a functioning accountability ecosystem, we process the following categories of information:
          </p>
          <ul className="list-disc pl-5 space-y-2 text-neutral-400 text-xs">
            <li>
              <strong>Account Authentication Credentials:</strong> If you register, we store your username, email address, and a hashed version of your password. These are stored on our secure private server solely to manage your leaderboard standing and CBT logs.
            </li>
            <li>
              <strong>CBT Logbook & Sobriety Logs:</strong> Your daily checklists, logged triggers (intensity, type, and coping mechanisms), and private journal notes are maintained securely so that you can trace your recovery trends over time.
            </li>
            <li>
              <strong>Local Preferences:</strong> Interface states, such as enabling <em>Focus Mode</em>, choosing between "Sophisticated Dark" and "deep-night" themes, and cookie consent preferences, are saved directly in your browser's local storage.
            </li>
          </ul>
        </section>

        <section className="space-y-3">
          <h2 className="font-display text-base font-bold text-neutral-100 flex items-center space-x-2">
            <Globe className="h-4.5 w-4.5 text-primary" />
            <span>2. Cookies & Third-Party Advertising (Google AdSense)</span>
          </h2>
          <p className="text-neutral-455">
            We use cookies to enhance user navigation and persist session authentication. In addition, we display advertisements provided by Google AdSense to sustain the operation of the Sanctuary:
          </p>
          <ul className="list-disc pl-5 space-y-2 text-neutral-400 text-xs">
            <li>
              Third-party vendors, including Google, use cookies to serve ads based on a user's prior visits to our website or other websites.
            </li>
            <li>
              Google's use of advertising cookies enables it and its partners to serve ads to our users based on their visit to our sites and/or other sites on the Internet.
            </li>
            <li>
              Users may opt out of personalized advertising by visiting <a href="https://www.google.com/settings/ads" target="_blank" rel="noopener noreferrer" className="text-primary underline hover:text-primary">Google Ad Settings</a>. Alternatively, you can opt out of a third-party vendor's use of cookies for personalized advertising by visiting <a href="https://www.aboutads.info" target="_blank" rel="noopener noreferrer" className="text-primary underline hover:text-primary">www.aboutads.info</a>.
            </li>
          </ul>
        </section>

        <section className="space-y-3">
          <h2 className="font-display text-base font-bold text-neutral-100 flex items-center space-x-2">
            <Database className="h-4.5 w-4.5 text-primary" />
            <span>3. How We Store and Protect Your Data</span>
          </h2>
          <p className="text-neutral-450">
            All database files (including credentials and activity metrics) are kept encrypted on our cloud servers. We do not sell, rent, or trade your personal data under any circumstances. Since we do not employ external tracking beacons, your cognitive recovery records remain yours alone. 
          </p>
        </section>

        <section className="space-y-3">
          <h2 className="font-display text-base font-bold text-neutral-100 flex items-center space-x-2">
            <CheckSquare className="h-4.5 w-4.5 text-primary" />
            <span>4. Your Data and Deletion Rights</span>
          </h2>
          <p className="text-neutral-450">
            You hold sovereign right over your data. You may reset your local application cache or wipe your account details from our database at any time by raising a technical support ticket or choosing the deletion buttons in your profile dashboard.
          </p>
        </section>

        <section className="space-y-3">
          <h2 className="font-display text-base font-bold text-neutral-100 flex items-center space-x-2">
            <HelpCircle className="h-4.5 w-4.5 text-primary" />
            <span>5. Contact Information</span>
          </h2>
          <p className="text-neutral-450">
            For questions about this Privacy Policy, your cognitive metrics, or third-party cookies, please submit an issue on our support page or email our compliance coordinator directly at <span className="text-primary font-semibold">privacy@hopecore-purity.org</span>.
          </p>
        </section>
      </div>
    </div>
  );
}

// ================= 2. TERMS OF SERVICE =================
export function TermsOfService({ onBackToDashboard }: PageProps) {
  return (
    <div className="max-w-4xl mx-auto space-y-8 animate-fade-in text-neutral-200">
      {/* Header */}
      <div className="rounded-2xl border border-neutral-800 bg-[#0F0F10] p-6 sm:p-8 shadow-sm relative overflow-hidden">
        <div className="absolute top-0 right-0 h-40 w-40 bg-primary/5 rounded-full blur-3xl pointer-events-none"></div>
        <button 
          onClick={onBackToDashboard}
          className="inline-flex items-center space-x-1.5 text-xs font-bold text-primary hover:text-primary-hover mb-4 transition-all cursor-pointer"
        >
          <ArrowLeft className="h-4 w-4" />
          <span>Return to Sovereign Dashboard</span>
        </button>
        <div className="flex items-start space-x-4">
          <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-primary/10 text-primary border border-primary/20 shrink-0">
            <FileText className="h-6 w-6" />
          </div>
          <div>
            <h1 className="font-display text-2xl font-bold text-neutral-100">Terms of Service</h1>
            <p className="mt-1.5 text-xs text-neutral-450 leading-relaxed font-mono">
              Last Updated: July 16, 2026 | General User Agreement
            </p>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="rounded-2xl border border-[#1A1A1B] bg-[#0F0F10] p-6 sm:p-8 space-y-6 text-xs sm:text-sm leading-relaxed text-neutral-300">
        <p className="text-neutral-400">
          Welcome to Sovereign Mind Sanctuary. By accessing or using our website, tools, and social channels, you agree to comply with and be bound by the following Terms of Service. Please read them carefully before commencing your purity training.
        </p>

        <section className="space-y-3">
          <h2 className="font-display text-base font-bold text-neutral-100 flex items-center space-x-2">
            <Lock className="h-4.5 w-4.5 text-primary" />
            <span>1. User Conduct and Standing</span>
          </h2>
          <p className="text-neutral-450">
            The Sanctuary is designed to host a high-trust, dedicated community of self-mastery warriors. You agree to utilize the global chat, support boards, and status broadcasts with respect and gravity:
          </p>
          <ul className="list-disc pl-5 space-y-2 text-neutral-400 text-xs">
            <li>
              You will not use vulgar, obscene, highly descriptive sexual language, or trigger-inducing words in your public status broadcasts, chat posts, or usernames.
            </li>
            <li>
              Harassment, spamming, and toxic behavior toward other warriors in the community are strictly prohibited.
            </li>
            <li>
              Violating these guidelines will lead to a permanent suspension of your username and the deletion of your standing from the leaderboards.
            </li>
          </ul>
        </section>

        {/* Ad Space Placement Placeholder */}
        <div className="rounded-xl border border-dashed border-neutral-800 bg-[#0A0A0B] p-4 text-center my-4">
          <span className="text-[9px] font-mono uppercase tracking-widest text-neutral-600 block mb-1">Sponsored Context Area</span>
          <div className="h-16 flex items-center justify-center text-[10px] text-neutral-500 italic">
            This space is reserved for premium, non-intrusive focus and self-discipline sponsorships.
          </div>
        </div>

        <section className="space-y-3">
          <h2 className="font-display text-base font-bold text-neutral-100 flex items-center space-x-2">
            <Brain className="h-4.5 w-4.5 text-primary" />
            <span>2. No Medical Advice Disclaimer</span>
          </h2>
          <p className="text-neutral-450">
            Sovereign Mind Sanctuary provides self-improvement, behavioral logs, and peer-reviewed neuroscience summaries for educational and motivational purposes only. 
          </p>
          <div className="rounded-xl bg-primary/5 border border-primary/10 p-4 font-mono text-[11px] leading-relaxed text-primary" style={{ backgroundColor: "var(--primary-light)", color: "var(--primary)", borderColor: "var(--primary-light)" }}>
            <strong>CRITICAL DISCLOSURE:</strong> The resources, logs, and AI mentor conversations in this app do NOT constitute clinical therapy, professional psychiatry, or medical diagnostics. If you suffer from severe psychiatric conditions, depressive disorders, or chemical dependencies, you should seek guidance from qualified healthcare practitioners.
          </div>
        </section>

        <section className="space-y-3">
          <h2 className="font-display text-base font-bold text-neutral-100 flex items-center space-x-2">
            <Shield className="h-4.5 w-4.5 text-primary" />
            <span>3. Limitation of Liability</span>
          </h2>
          <p className="text-neutral-450">
            Sovereign Mind Sanctuary and its operators shall not be liable for any direct, indirect, incidental, or consequential damages resulting from your use of or inability to use the platform. Your commitment to our sobriety milestones, physical exercise recommendations, and cold showers is taken at your own discretion.
          </p>
        </section>

        <section className="space-y-3">
          <h2 className="font-display text-base font-bold text-neutral-100 flex items-center space-x-2">
            <FileText className="h-4.5 w-4.5 text-primary" />
            <span>4. Changes to Terms</span>
          </h2>
          <p className="text-neutral-455">
            We reserve the right to modify these Terms of Service at any time. Changes will take effect immediately upon being posted on this view. Continued use of the platform following updates establishes your acceptance of the revised terms.
          </p>
        </section>
      </div>
    </div>
  );
}

// ================= 3. COOKIE POLICY =================
export function CookiePolicy({ onBackToDashboard }: PageProps) {
  return (
    <div className="max-w-4xl mx-auto space-y-8 animate-fade-in text-neutral-200">
      {/* Header */}
      <div className="rounded-2xl border border-neutral-800 bg-[#0F0F10] p-6 sm:p-8 shadow-sm relative overflow-hidden">
        <div className="absolute top-0 right-0 h-40 w-40 bg-primary/5 rounded-full blur-3xl pointer-events-none"></div>
        <button 
          onClick={onBackToDashboard}
          className="inline-flex items-center space-x-1.5 text-xs font-bold text-primary hover:text-primary-hover mb-4 transition-all cursor-pointer"
        >
          <ArrowLeft className="h-4 w-4" />
          <span>Return to Sovereign Dashboard</span>
        </button>
        <div className="flex items-start space-x-4">
          <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-primary/10 text-primary border border-primary/20 shrink-0">
            <Database className="h-6 w-6" />
          </div>
          <div>
            <h1 className="font-display text-2xl font-bold text-neutral-100">Cookie Policy</h1>
            <p className="mt-1.5 text-xs text-neutral-450 leading-relaxed font-mono">
              Last Updated: July 16, 2026 | AdSense Cookie Compliance
            </p>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="rounded-2xl border border-[#1A1A1B] bg-[#0F0F10] p-6 sm:p-8 space-y-6 text-xs sm:text-sm leading-relaxed text-neutral-300">
        <p className="text-neutral-400">
          This Cookie Policy explains how Sovereign Mind Sanctuary uses cookies, local storage items, and equivalent browser storage technologies. We seek to maintain absolute transparent communication, so you are aware of what technologies track your interactions.
        </p>

        <section className="space-y-3">
          <h2 className="font-display text-base font-bold text-neutral-100 flex items-center space-x-2">
            <Lock className="h-4.5 w-4.5 text-primary" />
            <span>1. What are Cookies and Local Storage?</span>
          </h2>
          <p className="text-neutral-450">
            Cookies are small text documents stored on your machine when you access a web page. Local Storage is a modern mechanism in HTML5 that operates similarly, allowing websites to preserve high-capacity settings locally in your browser. This application relies extensively on local storage to preserve your data offline if you are browsing without an authenticated profile.
          </p>
        </section>

        {/* Ad Space Placement Placeholder */}
        <div className="rounded-xl border border-dashed border-neutral-800 bg-[#0A0A0B] p-4 text-center my-4">
          <span className="text-[9px] font-mono uppercase tracking-widest text-neutral-600 block mb-1">Sponsored Context Area</span>
          <div className="h-16 flex items-center justify-center text-[10px] text-neutral-500 italic">
            This space is reserved for premium, non-intrusive focus and self-discipline sponsorships.
          </div>
        </div>

        <section className="space-y-3">
          <h2 className="font-display text-base font-bold text-neutral-100 flex items-center space-x-2">
            <CheckSquare className="h-4.5 w-4.5 text-primary" />
            <span>2. Essential Local Storage Variables Used</span>
          </h2>
          <p className="text-neutral-450">
            Below is the precise log of essential identifiers we manage locally in your browser:
          </p>
          <ul className="list-disc pl-5 space-y-2 text-neutral-400 text-xs font-mono">
            <li>
              <strong>sanctuary_theme:</strong> Preserves your aesthetic theme selection ("dark" or "deep-night") across browser reboots.
            </li>
            <li>
              <strong>sanctuary_focus_mode:</strong> Toggles Focus Mode state which narrows visual spacing to exclude extra widgets.
            </li>
            <li>
              <strong>sanctuary_cookie_consent:</strong> Tracks whether you accepted or customized our Cookie Consent policy.
            </li>
            <li>
              <strong>sanctuary_custom_habits:</strong> Holds any custom habits you declare in your dashboard checklist offline.
            </li>
          </ul>
        </section>

        <section className="space-y-3">
          <h2 className="font-display text-base font-bold text-neutral-100 flex items-center space-x-2">
            <Globe className="h-4.5 w-4.5 text-primary" />
            <span>3. Third-Party Advertising and Analytics Cookies</span>
          </h2>
          <p className="text-neutral-450">
            Our site utilizes Google AdSense to serve programmatic ads. Google uses cookies to display ads that align with your interests. It can track your navigation path across multiple sites on the web to deliver personalized ad content. You can revoke this permission by visiting your browser settings or adjusting your choices via our interactive cookie consent banner.
          </p>
        </section>
      </div>
    </div>
  );
}

// ================= 4. ABOUT PAGE =================
export function AboutPage({ onBackToDashboard }: PageProps) {
  return (
    <div className="max-w-4xl mx-auto space-y-8 animate-fade-in text-neutral-200">
      {/* Editorial Header */}
      <div className="rounded-2xl border border-[#1A1A1B] bg-gradient-to-b from-[#161618] to-[#0F0F10] p-8 text-center relative overflow-hidden">
        <div className="absolute top-0 left-1/2 -translate-x-1/2 h-32 w-32 bg-primary/10 rounded-full blur-3xl pointer-events-none animate-pulse"></div>
        <button 
          onClick={onBackToDashboard}
          className="inline-flex items-center space-x-1.5 text-xs font-bold text-primary hover:text-primary-hover mb-6 transition-all cursor-pointer"
        >
          <ArrowLeft className="h-4 w-4" />
          <span>Return to Sovereign Dashboard</span>
        </button>
        
        <h1 className="font-display text-3xl font-black text-neutral-100 tracking-tight leading-tight uppercase">
          Sovereign Mind Sanctuary
        </h1>
        <p className="mt-2 text-xs text-primary font-mono font-bold uppercase tracking-widest">
          A Fortress of Mental Purity & Self-Command
        </p>
        <p className="mt-4 text-xs sm:text-sm text-neutral-400 max-w-2xl mx-auto leading-relaxed">
          The modern digital space has weaponized our dopamine circuits, creating compulsive cravings and eroding prefrontal willpower. Sovereign Mind is a scientifically-backed and stoically-guided digital temple engineered to reverse this damage and restore complete personal focus.
        </p>
      </div>

      {/* Ad Space Placement Placeholder */}
      <div className="rounded-xl border border-dashed border-neutral-800 bg-[#0F0F10] p-4 text-center">
        <span className="text-[9px] font-mono uppercase tracking-widest text-neutral-600 block mb-1">Sponsored Context Area</span>
        <div className="h-14 flex items-center justify-center text-[10px] text-neutral-500 italic">
          We preserve deep focus. Sponsorship ads here remain purely aesthetic and non-obtrusive.
        </div>
      </div>

      {/* Philosophy Columns */}
      <div className="grid gap-6 md:grid-cols-2">
        <div className="rounded-2xl border border-[#1A1A1B] bg-[#0F0F10] p-6 space-y-4">
          <div className="h-10 w-10 flex items-center justify-center rounded-xl bg-primary/10 text-primary border border-primary/20" style={{ backgroundColor: "var(--primary-light)", color: "var(--primary)", borderColor: "var(--primary-light)" }}>
            <Brain className="h-5.5 w-5.5" />
          </div>
          <h2 className="font-display font-bold text-neutral-100 text-sm uppercase tracking-wider">
            Scientific Neuroscience
          </h2>
          <p className="text-xs text-neutral-400 leading-relaxed">
            Repeated hyper-stimulation of sexual centers triggers the overexpression of <strong>DeltaFosB</strong>, a highly stable molecular transcription factor that binds to reward pathways and reduces functional prefrontal connectivity. Restoring control requires standard periods of sensory fasting (dopamine detox) to downregulate these receptors and allow the prefrontal cortex to rebuild its executive command.
          </p>
        </div>

        <div className="rounded-2xl border border-[#1A1A1B] bg-[#0F0F10] p-6 space-y-4">
          <div className="h-10 w-10 flex items-center justify-center rounded-xl bg-purple-500/10 text-purple-400 border border-purple-500/20">
            <BookOpen className="h-5.5 w-5.5" />
          </div>
          <h2 className="font-display font-bold text-neutral-100 text-sm uppercase tracking-wider">
            Stoic Fortress Framework
          </h2>
          <p className="text-xs text-neutral-400 leading-relaxed">
            By adapting classical Stoic logic from Marcus Aurelius, Epictetus, and Seneca, we teach users that external triggers are indifferent events. You have absolute, unconditional power over your prefrontal mind. Our tools, such as the CBT logs and the Stoic Mind Shield, help rewrite toxic cognitive loops into actionable discipline.
          </p>
        </div>
      </div>

      {/* Core Objectives block */}
      <div className="rounded-2xl border border-[#1A1A1B] bg-[#0F0F10] p-6 sm:p-8 space-y-4">
        <h2 className="font-display font-bold text-neutral-100 text-base uppercase tracking-widest text-center">
          Our Five Core Sovereign Missions
        </h2>
        <div className="grid gap-4 sm:grid-cols-5 text-center">
          {[
            { num: "01", title: "Dopamine Detox", desc: "Starve visual triggers to upregulate receptors." },
            { num: "02", title: "CBT Restructuring", desc: "Identify and dispute cognitive errors." },
            { num: "03", title: "Urge Surfing", desc: "Surf chemical cravings without physical action." },
            { num: "04", title: "Sexual Transmutation", desc: "Sublimate restless drive into physical or creative power." },
            { num: "05", title: "Noble Fellowship", desc: "Unite with like-minded warriors in pure focus." }
          ].map((item, idx) => (
            <div key={idx} className="p-3 border border-[#1A1A1B] bg-[#0A0A0B] rounded-xl space-y-1.5">
              <span className="text-xs font-black text-primary font-mono">{item.num}</span>
              <h3 className="text-[11px] font-bold text-neutral-200">{item.title}</h3>
              <p className="text-[9.5px] text-neutral-500 leading-normal">{item.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// ================= 5. CONTACT PAGE =================
export function ContactPage({ onBackToDashboard }: PageProps) {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [category, setCategory] = useState("general");
  const [msg, setMsg] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [success, setSuccess] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !email.trim() || !msg.trim()) return;

    setIsSubmitting(true);
    // Simulate API request
    setTimeout(() => {
      setIsSubmitting(false);
      setSuccess(true);
      // Clean form fields
      setName("");
      setEmail("");
      setMsg("");
    }, 1200);
  };

  return (
    <div className="max-w-3xl mx-auto space-y-8 animate-fade-in text-neutral-200">
      {/* Header */}
      <div className="rounded-2xl border border-[#1A1A1B] bg-[#0F0F10] p-6 shadow-sm">
        <button 
          onClick={onBackToDashboard}
          className="inline-flex items-center space-x-1.5 text-xs font-bold text-primary hover:text-primary-hover mb-4 transition-all cursor-pointer"
        >
          <ArrowLeft className="h-4 w-4" />
          <span>Return to Sovereign Dashboard</span>
        </button>
        <div className="flex items-start space-x-4">
          <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-primary/10 text-primary border border-primary/20 shrink-0">
            <Mail className="h-5.5 w-5.5" />
          </div>
          <div>
            <h1 className="font-display text-xl font-bold text-neutral-100">Contact Sanctuary Liaison</h1>
            <p className="mt-1 text-xs text-neutral-400 leading-relaxed">
              Have inquiries regarding partnerships, AdSense configurations, technical issues, or moderation standards? Securely contact our administrative team below.
            </p>
          </div>
        </div>
      </div>

      {/* Main Grid */}
      <div className="grid gap-6 md:grid-cols-3">
        {/* Info Box */}
        <div className="md:col-span-1 space-y-4">
          <div className="rounded-2xl border border-[#1A1A1B] bg-[#0F0F10] p-5 space-y-4 h-full flex flex-col justify-between">
            <div className="space-y-3.5">
              <span className="text-[10px] font-black uppercase tracking-widest text-primary">Sanctuary Support</span>
              <div className="space-y-1.5">
                <h4 className="text-xs font-bold text-neutral-200">Official Correspondence</h4>
                <p className="text-[11px] text-neutral-550 leading-relaxed font-mono">
                  Sovereign Mind LLC<br />
                  purity@hopecore-purity.org
                </p>
              </div>

              <div className="space-y-1.5 pt-2 border-t border-[#1A1A1B]">
                <h4 className="text-xs font-bold text-neutral-200">Response Speed</h4>
                <p className="text-[11px] text-neutral-500 leading-relaxed">
                  Our administrators and community moderators typically review and resolve messages within 24-48 business hours.
                </p>
              </div>
            </div>

            <a
              href="https://discord.gg/XFusvy4xKP"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex w-full items-center justify-center space-x-1.5 rounded-xl border border-neutral-800 bg-[#0A0A0B] hover:bg-[#161618] text-[11px] font-bold text-neutral-400 hover:text-primary py-2.5 transition-all cursor-pointer"
            >
              <MessageSquare className="h-3.5 w-3.5 text-[#5865F2]" />
              <span>Reach Us on Discord</span>
            </a>
          </div>
        </div>

        {/* Form Box */}
        <div className="md:col-span-2 rounded-2xl border border-[#1A1A1B] bg-[#0F0F10] p-6 shadow-sm">
          {success ? (
            <div className="text-center py-10 space-y-4">
              <div className="h-12 w-12 rounded-full bg-emerald-500/10 text-emerald-500 border border-emerald-500/20 flex items-center justify-center mx-auto">
                <CheckSquare className="h-6 w-6" />
              </div>
              <h3 className="font-display font-semibold text-neutral-200">Transmission Relayed</h3>
              <p className="text-xs text-neutral-500 max-w-xs mx-auto leading-relaxed">
                Thank you. Your inquiry has been securely routed to the Sanctuary administrators. Please check your contact email for a copy of the reference log.
              </p>
              <button
                onClick={() => setSuccess(false)}
                className="rounded-xl border border-[#1A1A1B] bg-[#0A0A0B] hover:bg-[#161618] px-4 py-2 text-xs font-semibold text-neutral-400 transition-all cursor-pointer"
              >
                Send Another Message
              </button>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid gap-4 sm:grid-cols-2">
                <div className="space-y-1.5">
                  <label htmlFor="contact-name" className="text-[10px] font-bold text-neutral-400 uppercase tracking-wider">
                    Full Name
                  </label>
                  <input
                    id="contact-name"
                    required
                    type="text"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="Marcus Aurelius"
                    className="w-full bg-[#0A0A0B] border border-[#1A1A1B] hover:border-neutral-850 focus:border-primary/50 focus:outline-none rounded-xl px-3 py-2 text-xs text-neutral-200 transition-all"
                  />
                </div>
                <div className="space-y-1.5">
                  <label htmlFor="contact-email" className="text-[10px] font-bold text-neutral-400 uppercase tracking-wider">
                    Contact Email Address
                  </label>
                  <input
                    id="contact-email"
                    required
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="marcus@emperor.rome"
                    className="w-full bg-[#0A0A0B] border border-[#1A1A1B] hover:border-neutral-850 focus:border-primary/50 focus:outline-none rounded-xl px-3 py-2 text-xs text-neutral-200 transition-all"
                  />
                </div>
              </div>

              <div className="space-y-1.5">
                <label htmlFor="contact-category" className="text-[10px] font-bold text-neutral-400 uppercase tracking-wider">
                  Inquiry Nature
                </label>
                <select
                  id="contact-category"
                  value={category}
                  onChange={(e) => setCategory(e.target.value)}
                  className="w-full bg-[#0A0A0B] border border-[#1A1A1B] focus:border-primary/50 focus:outline-none rounded-xl px-3 py-2 text-xs text-neutral-200 transition-all cursor-pointer"
                >
                  <option value="general">General Guidance</option>
                  <option value="adsense">AdSense & Partnership Inquiry</option>
                  <option value="technical">Technical Glitch / Bug Report</option>
                  <option value="abuse">User Code of Conduct / Abuse Report</option>
                </select>
              </div>

              <div className="space-y-1.5">
                <label htmlFor="contact-message" className="text-[10px] font-bold text-neutral-400 uppercase tracking-wider">
                  Your Secure Message
                </label>
                <textarea
                  id="contact-message"
                  required
                  rows={4}
                  value={msg}
                  onChange={(e) => setMsg(e.target.value)}
                  placeholder="State your objectives, questions, or details regarding bugs cleanly..."
                  className="w-full bg-[#0A0A0B] border border-[#1A1A1B] hover:border-neutral-850 focus:border-primary/50 focus:outline-none rounded-xl px-3 py-2 text-xs text-neutral-200 transition-all resize-none"
                />
              </div>

              <button
                type="submit"
                disabled={isSubmitting || !name.trim() || !email.trim() || !msg.trim()}
                className="w-full bg-primary hover:bg-primary-hover disabled:opacity-40 text-[#0A0A0B] font-bold text-xs py-2.5 rounded-xl transition-all cursor-pointer flex items-center justify-center space-x-1.5"
              >
                {isSubmitting ? <RefreshCw className="h-3.5 w-3.5 animate-spin" /> : <Send className="h-3.5 w-3.5" />}
                <span>Relay Message Securely</span>
              </button>
            </form>
          )}
        </div>
      </div>
    </div>
  );
}

// ================= 6. 404 NOT FOUND PAGE =================
export function NotFoundPage({ onBackToDashboard }: PageProps) {
  return (
    <div className="max-w-md mx-auto text-center py-16 space-y-6 animate-fade-in text-neutral-200">
      <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-2xl bg-primary/10 text-primary border border-primary/20" style={{ backgroundColor: "var(--primary-light)", color: "var(--primary)", borderColor: "var(--primary-light)" }}>
        <Compass className="h-8 w-8 animate-spin" />
      </div>

      <div className="space-y-2">
        <h1 className="font-display text-3xl font-black text-neutral-100 uppercase tracking-widest font-mono">
          404 - Signal Lost
        </h1>
        <p className="text-xs text-primary font-mono font-bold uppercase tracking-wider">
          You are off the sovereign path
        </p>
        <p className="text-xs text-neutral-400 leading-relaxed max-w-sm mx-auto">
          The coordinates you requested do not point to any recognized sanctuary section. Do not allow your focus to drift into unexplored corridors. Return to safety immediately.
        </p>
      </div>

      <div className="pt-2">
        <button 
          onClick={onBackToDashboard}
          className="rounded-xl bg-primary hover:bg-primary-hover text-[#0A0A0B] font-bold text-xs px-6 py-3 transition-all shadow-lg shadow-primary/10 cursor-pointer"
        >
          Return to Dashboard Sanctuary
        </button>
      </div>

      <p className="text-[10px] font-mono text-neutral-600">
        "Do not stumble on things behind you." — Stoic Maxim
      </p>
    </div>
  );
}

// ================= 7. DISCLAIMER PAGE =================
export function DisclaimerPage({ onBackToDashboard }: PageProps) {
  return (
    <div className="max-w-4xl mx-auto space-y-8 animate-fade-in text-neutral-200">
      <div className="rounded-2xl border border-neutral-800 bg-[#0F0F10] p-6 sm:p-8 shadow-sm relative overflow-hidden">
        <div className="absolute top-0 right-0 h-40 w-40 bg-primary/5 rounded-full blur-3xl pointer-events-none"></div>
        <button 
          onClick={onBackToDashboard}
          className="inline-flex items-center space-x-1.5 text-xs font-bold text-primary hover:text-primary-hover mb-4 transition-all cursor-pointer"
        >
          <ArrowLeft className="h-4 w-4" />
          <span>Return to Sovereign Dashboard</span>
        </button>
        <div className="flex items-start space-x-4">
          <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-red-500/10 text-red-400 border border-red-500/20 shrink-0">
            <Info className="h-6 w-6" />
          </div>
          <div>
            <h1 className="font-display text-2xl font-bold text-neutral-100">Medical & Legal Disclaimer</h1>
            <p className="mt-1.5 text-xs text-neutral-450 leading-relaxed font-mono">
              Essential Disclosures Regarding Cognitive Fasting & Self-Improvement
            </p>
          </div>
        </div>
      </div>

      <div className="rounded-2xl border border-[#1A1A1B] bg-[#0F0F10] p-6 sm:p-8 space-y-6 text-xs sm:text-sm leading-relaxed text-neutral-300">
        <p className="text-neutral-450 font-mono text-xs bg-red-500/5 border border-red-500/10 p-4 rounded-xl leading-relaxed text-red-400">
          <strong>PLEASE READ CAREFULLY:</strong> The materials, tools, tracking utilities, and chatbot guides contained within the Sovereign Mind Sanctuary (and affiliated web presence) do not represent professional clinical psychotherapy, medical directives, psychiatric advice, or drug addiction treatment.
        </p>

        <section className="space-y-3">
          <h2 className="font-display text-base font-bold text-neutral-100 flex items-center space-x-2">
            <Brain className="h-4.5 w-4.5 text-primary" />
            <span>1. Self-Improvement and Behavioral Coaching Only</span>
          </h2>
          <p className="text-neutral-450">
            Sovereign Mind is a serverless, static, cognitive restructuring tool built upon proven behavioral heuristics (such as Cognitive Behavioral Therapy, mindfulness habit logs, and Stoic philosophy). It is designed to assist mentally healthy individuals in maintaining discipline, tracking digital and visual trigger metrics, and building stronger focus.
          </p>
          <p className="text-neutral-450">
            Our automated CBT AI Mentor provides canned or heuristically generated messages that serve purely educational and motivational purposes. These chats are completely local and automated; they are not monitored or responded to by live clinical therapists.
          </p>
        </section>

        {/* Ad Space Placement Placeholder */}
        <div className="rounded-xl border border-dashed border-neutral-800 bg-[#0A0A0B] p-4 text-center my-4">
          <span className="text-[9px] font-mono uppercase tracking-widest text-neutral-600 block mb-1">Sponsored Context Area</span>
          <div className="h-16 flex items-center justify-center text-[10px] text-neutral-500 italic">
            Focus-centered ads here remain purely aesthetic and highly secure.
          </div>
        </div>

        <section className="space-y-3">
          <h2 className="font-display text-base font-bold text-neutral-100 flex items-center space-x-2">
            <Lock className="h-4.5 w-4.5 text-primary" />
            <span>2. No Professional Therapist-Client Relationship</span>
          </h2>
          <p className="text-neutral-450">
            Utilization of this application, reporting triggers, using our breathing timers, logging check-ins, or contacting admin support does not establish a therapist-client relationship. If you are struggling with severe psychological disorders, major clinical depression, compulsive disorders, chemical addiction, or crisis states, you must seek guidance from a licensed, professional medical practitioner immediately.
          </p>
        </section>

        <section className="space-y-3">
          <h2 className="font-display text-base font-bold text-neutral-100 flex items-center space-x-2">
            <Zap className="h-4.5 w-4.5 text-primary" />
            <span>3. Individual Physical Activity and Transmutation</span>
          </h2>
          <p className="text-neutral-450">
            Recommendations on our platform regarding physical workouts, breathing rhythms, meditation sessions, or taking cold hydrotherapy showers are taken entirely at your own risk. Consult your physician before embarking on any physical training, high-intensity breathing, or cold therapy cycles.
          </p>
        </section>
      </div>
    </div>
  );
}

// ================= 8. FAQ PAGE =================
export function FAQPage({ onBackToDashboard }: PageProps) {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  const faqs = [
    {
      q: "What is Sovereign Mind Sanctuary, and how does it help my brain?",
      a: "Sovereign Mind is a structured cognitive habit platform engineered to help you conquer compulsive habits (such as adult content, social media looping, and visual triggers). Modern hyper-stimulants overexpress DeltaFosB in your reward pathway, desensitizing your dopamine receptors. By tracking daily clean days, practicing urge-surfing breathing techniques, and completing CBT restructuring, you gradually downregulate DeltaFosB, rewiring your prefrontal cortex for supreme focus and raw physical drive."
    },
    {
      q: "Is my personal data safe? Who can view my journal logs?",
      a: "Your cognitive sovereignty is our absolute priority. This website is a fully serverless, static application deployed directly onto Cloudflare's secure edge. All credentials, daily journals, trigger logs, and settings are stored locally in your browser's encrypted private cache (localStorage). No backend database or server has access to your private thoughts, which guarantees your absolute privacy."
    },
    {
      q: "What is a 'Streak Freeze', and how do I earn one?",
      a: "A Streak Freeze is an automatic shield that protects your daily streak count in case you miss logging your check-in for a day. Every user is granted 1 welcome Streak Freeze upon registration. You can earn additional freezes by sustaining an active streak of 30 days or longer, limited to one new freeze earned per month to keep accountability high."
    },
    {
      q: "What is 'Urge Surfing', and how does the SOS tool function?",
      a: "Urge Surfing is a clinical mindfulness technique. Chemical cravings and impulses peak in your brain for about 90 seconds to 3 minutes before naturally subsiding, provided you don't feed them. The Urge SOS tab guides you through custom box-breathing rhythms (stretching lung inhalation, retention, and exhalation) while providing a low-frequency brainwave audio trigger. This activates your parasympathetic nervous system, allowing you to ride out the neurochemical wave safely."
    },
    {
      q: "How does the global community chat work?",
      a: "The global community chat allows you to post focus encouragement, milestones, or questions to other warriors in the sanctuary. To ensure the channel is always supportive and responsive, we pre-seed realistic, encouraging responses and employ helpful bots to troubleshoot technical bugs or provide rapid CBT quotes instantly."
    },
    {
      q: "How do Level Up mechanics and Badges work?",
      a: "You earn experience points (XP) by actively participating in your recovery: +50 XP for daily clean check-ins, +15 XP for logging a slip/relapse review, and +25 XP for filing a structured trigger log. As your XP increases, your Level grows, unlocking prestigious titles (from 'Seed of Will' up to 'Ascended Spirit') and unique badges which you can equip in your Settings page."
    }
  ];

  return (
    <div className="max-w-4xl mx-auto space-y-8 animate-fade-in text-neutral-200">
      <div className="rounded-2xl border border-neutral-800 bg-[#0F0F10] p-6 sm:p-8 shadow-sm relative overflow-hidden">
        <div className="absolute top-0 right-0 h-40 w-40 bg-primary/5 rounded-full blur-3xl pointer-events-none"></div>
        <button 
          onClick={onBackToDashboard}
          className="inline-flex items-center space-x-1.5 text-xs font-bold text-primary hover:text-primary-hover mb-4 transition-all cursor-pointer"
        >
          <ArrowLeft className="h-4 w-4" />
          <span>Return to Sovereign Dashboard</span>
        </button>
        <div className="flex items-start space-x-4">
          <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-primary/10 text-primary border border-primary/20 shrink-0">
            <HelpCircle className="h-6 w-6" />
          </div>
          <div>
            <h1 className="font-display text-2xl font-bold text-neutral-100">Frequently Asked Questions</h1>
            <p className="mt-1.5 text-xs text-neutral-450 leading-relaxed font-mono">
              In-Depth Inquiries Regarding Neurological Rewiring & App Logistics
            </p>
          </div>
        </div>
      </div>

      <div className="space-y-4">
        {faqs.map((faq, idx) => {
          const isOpen = openIndex === idx;
          return (
            <div 
              key={idx} 
              className="rounded-2xl border border-[#1A1A1B] bg-[#0F0F10] overflow-hidden transition-all duration-300"
            >
              <button
                onClick={() => setOpenIndex(isOpen ? null : idx)}
                className="w-full flex items-center justify-between p-5 text-left text-xs sm:text-sm font-bold text-neutral-100 hover:bg-[#161618] transition-all cursor-pointer"
              >
                <span>{faq.q}</span>
                <span className={`text-primary text-lg transition-transform duration-300 ${isOpen ? "rotate-45" : ""}`}>
                  +
                </span>
              </button>
              {isOpen && (
                <div className="p-5 pt-0 border-t border-[#161618] text-xs sm:text-sm text-neutral-400 leading-relaxed bg-[#0A0A0B]/30 animate-slide-down">
                  {faq.a}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}

// ================= 9. HELP CENTRE PAGE =================
export function HelpCentrePage({ onBackToDashboard }: PageProps) {
  return (
    <div className="max-w-4xl mx-auto space-y-8 animate-fade-in text-neutral-200">
      <div className="rounded-2xl border border-neutral-800 bg-[#0F0F10] p-6 sm:p-8 shadow-sm relative overflow-hidden">
        <div className="absolute top-0 right-0 h-40 w-40 bg-primary/5 rounded-full blur-3xl pointer-events-none"></div>
        <button 
          onClick={onBackToDashboard}
          className="inline-flex items-center space-x-1.5 text-xs font-bold text-primary hover:text-primary-hover mb-4 transition-all cursor-pointer"
        >
          <ArrowLeft className="h-4 w-4" />
          <span>Return to Sovereign Dashboard</span>
        </button>
        <div className="flex items-start space-x-4">
          <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-primary/10 text-primary border border-primary/20 shrink-0">
            <BookOpen className="h-6 w-6" />
          </div>
          <div>
            <h1 className="font-display text-2xl font-bold text-neutral-100">Help & Knowledge Centre</h1>
            <p className="mt-1.5 text-xs text-neutral-450 leading-relaxed font-mono">
              Operations Manual & Tech Support Guidelines for the Sanctuary
            </p>
          </div>
        </div>
      </div>

      <div className="grid gap-6 md:grid-cols-3">
        <div className="md:col-span-1 space-y-4">
          <div className="rounded-2xl border border-[#1A1A1B] bg-[#0F0F10] p-5 space-y-4">
            <span className="text-[10px] font-black uppercase tracking-widest text-primary">Quick Diagnostics</span>
            <div className="space-y-3.5">
              <div className="space-y-1">
                <h4 className="text-xs font-bold text-neutral-200">Web App Version</h4>
                <p className="text-xs text-neutral-500 font-mono">v2.5.0 (Serverless)</p>
              </div>
              <div className="space-y-1">
                <h4 className="text-xs font-bold text-neutral-200">Database Engine</h4>
                <p className="text-xs text-neutral-500 font-mono">Browser LocalStorage</p>
              </div>
              <div className="space-y-1">
                <h4 className="text-xs font-bold text-neutral-200">Host Infrastructure</h4>
                <p className="text-xs text-neutral-500 font-mono">Cloudflare Pages Edge</p>
              </div>
            </div>
          </div>

          <div className="rounded-2xl border border-[#1A1A1B] bg-[#0F0F10] p-5 space-y-3">
            <span className="text-[10px] font-black uppercase tracking-widest text-primary">Local Actions</span>
            <p className="text-[11px] text-neutral-500 leading-normal">
              Experiencing interface freeze or looking to clear your profile cache? Execute a hard data wipe below.
            </p>
            <button
              onClick={() => {
                if (confirm("Are you absolutely sure you want to clear your local database cache? This will reset all your check-ins, streaks, and journal logs.")) {
                  localStorage.removeItem("sanctuary_mock_db");
                  alert("Local database reset successful. Reloading sanctuary.");
                  window.location.reload();
                }
              }}
              className="w-full text-center text-[10px] font-bold text-red-400 hover:text-red-300 border border-red-500/10 bg-red-500/5 hover:bg-red-500/10 py-2 rounded-xl transition-all cursor-pointer"
            >
              Wipe Local Storage Cache
            </button>
          </div>
        </div>

        <div className="md:col-span-2 space-y-6">
          <div className="rounded-2xl border border-[#1A1A1B] bg-[#0F0F10] p-6 space-y-4">
            <h3 className="text-sm font-bold text-neutral-100 flex items-center space-x-2">
              <span className="h-2 w-2 rounded-full bg-primary"></span>
              <span>1. Complete Guide to Daily Habits</span>
            </h3>
            <p className="text-xs sm:text-sm text-neutral-400 leading-relaxed">
              Every morning, access your <strong>Sovereign Dashboard</strong>. Check off completed items in your checklist (Cold Shower, Physical Exercise, Reading Stoic Wisdom, Deep Breathing). Checking off your daily tasks awards you experience points (+50 XP). Your streak starts automatically and increment daily. If you slip up, log a relapse to review your mental state and resets the count safely to focus on fresh growth.
            </p>
          </div>

          <div className="rounded-2xl border border-[#1A1A1B] bg-[#0F0F10] p-6 space-y-4">
            <h3 className="text-sm font-bold text-neutral-100 flex items-center space-x-2">
              <span className="h-2 w-2 rounded-full bg-primary"></span>
              <span>2. Raising Technical Support Tickets</span>
            </h3>
            <p className="text-xs sm:text-sm text-neutral-400 leading-relaxed">
              If you discover a layout issue, a badge bug, or have ideas for premium features, open the <strong>Support tab</strong>. Create a technical support ticket. To test support ticket resolution and receive automated advice, toggle the ticket category to <em>"AI Support Channel"</em>. The Sanctuary Archon Bot will respond immediately to assist you inside the ticket!
            </p>
          </div>

          <div className="rounded-2xl border border-[#1A1A1B] bg-[#0F0F10] p-6 space-y-4">
            <h3 className="text-sm font-bold text-neutral-100 flex items-center space-x-2">
              <span className="h-2 w-2 rounded-full bg-primary"></span>
              <span>3. Restoring Passwords & Credentials Offline</span>
            </h3>
            <p className="text-xs sm:text-sm text-neutral-400 leading-relaxed">
              Because this application is 100% static, there is no email verification server. If you forget your password, simply click "Forgot Password" on the login modal, input your registered email address, and our emulated gateway will instantly supply you with a 6-digit recovery code. Enter this code to immediately re-key your password and access your offline data records!
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}

// ================= 10. COMMUNITY GUIDELINES PAGE =================
export function CommunityGuidelinesPage({ onBackToDashboard }: PageProps) {
  return (
    <div className="max-w-4xl mx-auto space-y-8 animate-fade-in text-neutral-200">
      <div className="rounded-2xl border border-neutral-800 bg-[#0F0F10] p-6 sm:p-8 shadow-sm relative overflow-hidden">
        <div className="absolute top-0 right-0 h-40 w-40 bg-primary/5 rounded-full blur-3xl pointer-events-none"></div>
        <button 
          onClick={onBackToDashboard}
          className="inline-flex items-center space-x-1.5 text-xs font-bold text-primary hover:text-primary-hover mb-4 transition-all cursor-pointer"
        >
          <ArrowLeft className="h-4 w-4" />
          <span>Return to Sovereign Dashboard</span>
        </button>
        <div className="flex items-start space-x-4">
          <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-primary/10 text-primary border border-primary/20 shrink-0">
            <Shield className="h-6 w-6" />
          </div>
          <div>
            <h1 className="font-display text-2xl font-bold text-neutral-100">Community Guidelines</h1>
            <p className="mt-1.5 text-xs text-neutral-450 leading-relaxed font-mono">
              Noble Codes of Conduct for Global Interactions & Standings
            </p>
          </div>
        </div>
      </div>

      <div className="rounded-2xl border border-[#1A1A1B] bg-[#0F0F10] p-6 sm:p-8 space-y-6 text-xs sm:text-sm leading-relaxed text-neutral-300">
        <p className="text-neutral-400">
          The Sovereign Mind Sanctuary is designed to host a dedicated, high-trust community of warriors pursuing cognitive purity and supreme mental drive. To safeguard this focused space, all members must comply with these guidelines.
        </p>

        <section className="space-y-3">
          <h2 className="font-display text-base font-bold text-neutral-100 flex items-center space-x-2">
            <CheckSquare className="h-4.5 w-4.5 text-primary" />
            <span>1. Keep All Shared Content Clean and Trigger-Free</span>
          </h2>
          <p className="text-neutral-450">
            You are strictly forbidden from posting, referencing, or detailing explicit sexual narratives, provocative references, or links in the global community forum, support tickets, or status updates. Warriors come here to escape stimulation. Do not introduce temptations into this fortress.
          </p>
        </section>

        {/* Ad Space Placement Placeholder */}
        <div className="rounded-xl border border-dashed border-neutral-800 bg-[#0A0A0B] p-4 text-center my-4">
          <span className="text-[9px] font-mono uppercase tracking-widest text-neutral-600 block mb-1">Sponsored Context Area</span>
          <div className="h-16 flex items-center justify-center text-[10px] text-neutral-500 italic">
            Safe, premium focus products may present educational sponsorships here.
          </div>
        </div>

        <section className="space-y-3">
          <h2 className="font-display text-base font-bold text-neutral-100 flex items-center space-x-2">
            <MessageSquare className="h-4.5 w-4.5 text-primary" />
            <span>2. Positive Peer Accountability</span>
          </h2>
          <p className="text-neutral-450">
            Harassment, mocking, trolling, or insulting other members in the community chat will lead to permanent account termination. If a peer reports a slip or relapse, provide encouraging Stoic feedback or suggest workout alternatives. Elevate your fellow warriors.
          </p>
        </section>

        <section className="space-y-3">
          <h2 className="font-display text-base font-bold text-neutral-100 flex items-center space-x-2">
            <Lock className="h-4.5 w-4.5 text-primary" />
            <span>3. No Commercial Spam or Promotion</span>
          </h2>
          <p className="text-neutral-450">
            The community channels must not be utilized for self-promotion, advertising personal services, sharing affiliate links, or soliciting funds. Commercial space is reserved exclusively for validated, non-intrusive AdSense-compliant sponsors.
          </p>
        </section>
      </div>
    </div>
  );
}

// ================= 11. CHANGELOG PAGE =================
export function ChangelogPage({ onBackToDashboard }: PageProps) {
  const logs = [
    {
      version: "v2.5.0 - The Sovereign Edge Update",
      date: "July 16, 2026",
      badge: "Production Ready",
      color: "bg-primary/10 text-primary border border-primary/20",
      changes: [
        "Migrated all backend services and REST APIs to a 100% client-side serverless interceptor, rendering the app entirely static and compatible with Cloudflare Pages.",
        "Created an emulated Google Sign-In identity gateway and verification message listener.",
        "Configured relative asset building configurations (`base: './'`) to resolve file loading or blank screen errors on deployment.",
        "Added six additional highly requested informational pages: Disclaimer, FAQ accordion, Help Centre, Community Guidelines, Changelog, and Accessibility.",
        "Integrated the premium custom interactive cursor with magnetic hover detection.",
        "Designed skeleton transition loaders for tab toggles, reducing perceived loading lag."
      ]
    },
    {
      version: "v2.0.0 - Cognitive Fortress Framework",
      date: "June 20, 2026",
      badge: "Major Release",
      color: "bg-purple-500/10 text-purple-400 border border-purple-500/20",
      changes: [
        "Inaugurated the structured Cognitive Behavioral Therapy (CBT) logging engine for daily habit checklists.",
        "Engineered the Urge SOS panel containing breathing mechanics, box breathing animations, and 5Hz brainwave audio stimulus.",
        "Established the daily Stoic quote generator and commentary analytics panel.",
        "Added local leaderboard stands with real-time XP and title level increments."
      ]
    },
    {
      version: "v1.0.0 - Initial Sanctuary",
      date: "May 10, 2026",
      badge: "Genesis Build",
      color: "bg-neutral-500/10 text-neutral-400 border border-neutral-500/20",
      changes: [
        "Booted the initial responsive dashboard with dark mode styling.",
        "Created core Sobriety clock with hours, minutes, and seconds resolution.",
        "Configured basic local persistence structures for saving habit states."
      ]
    }
  ];

  return (
    <div className="max-w-4xl mx-auto space-y-8 animate-fade-in text-neutral-200">
      <div className="rounded-2xl border border-neutral-800 bg-[#0F0F10] p-6 sm:p-8 shadow-sm relative overflow-hidden">
        <div className="absolute top-0 right-0 h-40 w-40 bg-primary/5 rounded-full blur-3xl pointer-events-none"></div>
        <button 
          onClick={onBackToDashboard}
          className="inline-flex items-center space-x-1.5 text-xs font-bold text-primary hover:text-primary-hover mb-4 transition-all cursor-pointer"
        >
          <ArrowLeft className="h-4 w-4" />
          <span>Return to Sovereign Dashboard</span>
        </button>
        <div className="flex items-start space-x-4">
          <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-primary/10 text-primary border border-primary/20 shrink-0">
            <RefreshCw className="h-6 w-6 animate-spin" />
          </div>
          <div>
            <h1 className="font-display text-2xl font-bold text-neutral-100">Sanctuary Changelog</h1>
            <p className="mt-1.5 text-xs text-neutral-450 leading-relaxed font-mono">
              The Historical Evolution of the Self-Command Platform
            </p>
          </div>
        </div>
      </div>

      <div className="space-y-6">
        {logs.map((log, idx) => (
          <div key={idx} className="rounded-2xl border border-[#1A1A1B] bg-[#0F0F10] p-6 sm:p-8 space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-2 border-b border-[#1A1A1B] pb-4">
              <div>
                <h3 className="font-display text-base font-bold text-neutral-100">{log.version}</h3>
                <p className="text-xs text-neutral-500 font-mono mt-0.5">{log.date}</p>
              </div>
              <span className={`text-[10px] font-bold px-2.5 py-1 rounded-full font-mono uppercase tracking-wider ${log.color}`}>
                {log.badge}
              </span>
            </div>

            <ul className="space-y-3 pl-4 list-disc text-xs sm:text-sm text-neutral-400 leading-relaxed">
              {log.changes.map((change, cidx) => (
                <li key={cidx}>{change}</li>
              ))}
            </ul>
          </div>
        ))}
      </div>
    </div>
  );
}

// ================= 12. ACCESSIBILITY PAGE =================
export function AccessibilityPage({ onBackToDashboard }: PageProps) {
  return (
    <div className="max-w-4xl mx-auto space-y-8 animate-fade-in text-neutral-200">
      <div className="rounded-2xl border border-neutral-800 bg-[#0F0F10] p-6 sm:p-8 shadow-sm relative overflow-hidden">
        <div className="absolute top-0 right-0 h-40 w-40 bg-primary/5 rounded-full blur-3xl pointer-events-none"></div>
        <button 
          onClick={onBackToDashboard}
          className="inline-flex items-center space-x-1.5 text-xs font-bold text-primary hover:text-primary-hover mb-4 transition-all cursor-pointer"
        >
          <ArrowLeft className="h-4 w-4" />
          <span>Return to Sovereign Dashboard</span>
        </button>
        <div className="flex items-start space-x-4">
          <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-primary/10 text-primary border border-primary/20 shrink-0">
            <Globe className="h-6 w-6" />
          </div>
          <div>
            <h1 className="font-display text-2xl font-bold text-neutral-100">Accessibility Statement</h1>
            <p className="mt-1.5 text-xs text-neutral-450 leading-relaxed font-mono">
              Ensuring Cognitive Recovery Tools are Open and Usable by Everyone
            </p>
          </div>
        </div>
      </div>

      <div className="rounded-2xl border border-[#1A1A1B] bg-[#0F0F10] p-6 sm:p-8 space-y-6 text-xs sm:text-sm leading-relaxed text-neutral-300">
        <p className="text-neutral-400">
          The Sovereign Mind Sanctuary is dedicated to providing an inclusive environment where individuals of all cognitive, visual, and physical abilities can pursue mental sovereignty. We actively configure our platform to align with <strong>Web Content Accessibility Guidelines (WCAG) 2.1 AA</strong> standards.
        </p>

        <section className="space-y-3">
          <h2 className="font-display text-base font-bold text-neutral-100 flex items-center space-x-2">
            <Zap className="h-4.5 w-4.5 text-primary" />
            <span>1. Core Built-In Accessibility Configurations</span>
          </h2>
          <p className="text-neutral-450">
            Our frontend includes multiple system overrides which users can trigger directly or allow their systems to configure:
          </p>
          <ul className="list-disc pl-5 space-y-2 text-neutral-400 text-xs">
            <li>
              <strong>High Contrast Rendering:</strong> Supports default browser high-contrast overrides and ensures deep readability ratios (minimum 4.5:1 text-to-background ratio) throughout the application's slate canvas.
            </li>
            <li>
              <strong>Reduced Motion Mode:</strong> Toggles off active animations, sliding cards, and breathing expansions automatically if the user's operating system requests `prefers-reduced-motion`.
            </li>
            <li>
              <strong>Keyboard Focus Outlines:</strong> Implements prominent focus ring styles (`focus-visible:ring-2 focus-visible:ring-primary`) to guarantee clear, visual focus tracking during tabbed keyboard navigation.
            </li>
            <li>
              <strong>ARIA Landmarks and Screen Reader Accessibility:</strong> Form controls, interactive buttons, and navigation sections contain clean ARIA descriptions, and custom interactive components include proper labels.
            </li>
          </ul>
        </section>

        {/* Ad Space Placement Placeholder */}
        <div className="rounded-xl border border-dashed border-neutral-800 bg-[#0A0A0B] p-4 text-center my-4">
          <span className="text-[9px] font-mono uppercase tracking-widest text-neutral-600 block mb-1">Sponsored Context Area</span>
          <div className="h-16 flex items-center justify-center text-[10px] text-neutral-500 italic">
            AdSense-ready placements adhere strictly to WCAG contrast regulations.
          </div>
        </div>

        <section className="space-y-3">
          <h2 className="font-display text-base font-bold text-neutral-100 flex items-center space-x-2">
            <Lock className="h-4.5 w-4.5 text-primary" />
            <span>2. Feedback and Assistance</span>
          </h2>
          <p className="text-neutral-450">
            If you encounter any layout, contrast, or screen-reader bugs that block your recovery journey, raise a technical support ticket or email our accessibility compliance liaison directly at <span className="text-primary font-semibold">accessibility@hopecore-purity.org</span>. We are fully committed to resolving accessibility issues within 7 business days.
          </p>
        </section>
      </div>
    </div>
  );
}
