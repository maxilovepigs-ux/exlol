/**
 * @license
 * SPDX-License-Identifier: Apache-2.5
 */

import React, { useState, useEffect } from "react";
import confetti from "canvas-confetti";
import { 
  Anchor, 
  Compass, 
  ShieldCheck, 
  Heart, 
  Flame, 
  Sparkles, 
  Crown, 
  Trophy, 
  Lock, 
  CheckCircle2, 
  HelpCircle,
  BrainCircuit,
  X,
  Award,
  Info,
  ChevronRight
} from "lucide-react";
import { User } from "../types";
import { CAREER_BADGES, getActiveBadge, CareerLevelBadge } from "../lib/badges";

interface MilestonesProps {
  currentUser: User | null;
  onUpdateUser?: (user: User) => void;
}

interface MilestoneItem {
  id: string;
  days: number;
  title: string;
  subtitle: string;
  icon: React.ComponentType<any>;
  accentColor: string;
  textColor: string;
  borderColor: string;
  bgLight: string;
  neuroDescription: string;
  actionAdvice: string;
}

const MILESTONES_DATA: MilestoneItem[] = [
  {
    id: "1_day",
    days: 1,
    title: "1 Day Anchor",
    subtitle: "Autonomic Withdrawal Peak",
    icon: Anchor,
    accentColor: "from-blue-500/20 to-blue-600/30",
    textColor: "text-blue-400",
    borderColor: "border-blue-500/30",
    bgLight: "bg-blue-500/5",
    neuroDescription: "Amydgala charge is high as the brain senses the withdrawal of immediate compulsive stimulation. Heart-rate variability changes as your autonomic nervous system begins adjusting. Prefrontal cortex initiates basic executive override.",
    actionAdvice: "Engage in immediate Autonomic Cold Water Splashes. Focus on stabilizing your breathing rate to anchor the central nervous system."
  },
  {
    id: "3_days",
    days: 3,
    title: "3 Day Seed",
    subtitle: "Glutamate Surge Period",
    icon: Compass,
    accentColor: "from-indigo-500/20 to-indigo-600/30",
    textColor: "text-indigo-400",
    borderColor: "border-indigo-500/30",
    bgLight: "bg-indigo-500/5",
    neuroDescription: "Glutamate surges inside the nucleus accumbens, signalling a severe physical cue of craving. The seed of prefrontal command is starting to sprout, but requires heavy protection from reflexive digital actions.",
    actionAdvice: "Employ the 25 Deep Skeletal Air Squats habit. Force blood flow into large skeletal muscle groups to starve pelvic arousal circuits."
  },
  {
    id: "7_days",
    days: 7,
    title: "7 Day Master",
    subtitle: "Dopamine Receptor Upregulation",
    icon: ShieldCheck,
    accentColor: "from-amber-500/20 to-amber-600/30",
    textColor: "text-amber-400",
    borderColor: "border-amber-500/30",
    bgLight: "bg-amber-500/5",
    neuroDescription: "Dopamine receptors (D2) begin upregulating due to decreased toxic overstimulation. Sensitivity to normal everyday stimuli begins its slow ascent. You experience the first noticeable lift of cognitive brain fog.",
    actionAdvice: "Reflect on this week of resilience. Complete your daily checklist fully to cement these behavioral pathways."
  },
  {
    id: "14_days",
    days: 14,
    title: "14 Day Guardian",
    subtitle: "Prefrontal Gray Matter Recovery",
    icon: Heart,
    accentColor: "from-rose-500/20 to-rose-600/30",
    textColor: "text-rose-400",
    borderColor: "border-rose-500/30",
    bgLight: "bg-rose-500/5",
    neuroDescription: "Magnetic resonance studies indicate gray matter density changes in the prefrontal cortex beginning around week two. This significantly boosts your voluntary top-down cognitive control over underlying limbic impulses.",
    actionAdvice: "Use the AI Purity Mentor today to analyze any subtle behavioral shifts or hidden cognitive justifications."
  },
  {
    id: "30_days",
    days: 30,
    title: "30 Day Warrior",
    subtitle: "DeltaFosB Degradation Phase",
    icon: Flame,
    accentColor: "from-orange-500/20 to-orange-600/30",
    textColor: "text-orange-400",
    borderColor: "border-orange-500/30",
    bgLight: "bg-orange-500/5",
    neuroDescription: "The transcription factor DeltaFosB, which accumulates in the striatum during chronic compulsive cycles and acts as an addiction memory switch, begins its first major degradation and clearance phase.",
    actionAdvice: "Celebrate one full month. Your brain is structurally cleaning out its addiction memories. Stay highly guarded against complacency."
  },
  {
    id: "45_days",
    days: 45,
    title: "45 Day Alchemist",
    subtitle: "BDNF Synaptic Plasticity",
    icon: Sparkles,
    accentColor: "from-emerald-500/20 to-emerald-600/30",
    textColor: "text-emerald-400",
    borderColor: "border-emerald-500/30",
    bgLight: "bg-emerald-500/5",
    neuroDescription: "Brain-Derived Neurotrophic Factor (BDNF) expression spikes, enabling accelerated neuroplasticity. The brain is now highly efficient at weaving and insulating non-addictive, highly productive mental pathways.",
    actionAdvice: "Transmute your energy into deep focus: pick up a complex book, practice a new skill, or train heavily in physical fields."
  },
  {
    id: "90_days",
    days: 90,
    title: "90 Day Sovereign",
    subtitle: "Receptor Homeostasis Reset",
    icon: Crown,
    accentColor: "from-purple-500/20 to-purple-600/30",
    textColor: "text-purple-400",
    borderColor: "border-purple-500/30",
    bgLight: "bg-purple-500/5",
    neuroDescription: "The standard gold-standard clinical threshold. Dopamine pathways and deltaFosB levels are returned to standard baseline homeostasis. Compulsive hyper-sensitization is largely reversed, completing the initial reboot cycle.",
    actionAdvice: "You have achieved Sovereign Command. You now experience life through a clean, uncompromised dopaminergic filter."
  },
  {
    id: "120_days",
    days: 120,
    title: "120 Day Immortal",
    subtitle: "Myelin Consolidation State",
    icon: Trophy,
    accentColor: "from-yellow-500/20 to-yellow-600/30",
    textColor: "text-yellow-400",
    borderColor: "border-yellow-500/30",
    bgLight: "bg-yellow-500/5",
    neuroDescription: "The clean neural pathways formed during this journey are now heavily insulated with myelin. Myelination makes signal transmission incredibly rapid, converting conscious self-discipline into an automatic lifestyle default.",
    actionAdvice: "A legend standing tall. Share your wisdom with fellow seekers in the Global Arena Chat to strengthen the legion."
  }
];

export default function Milestones({ currentUser, onUpdateUser }: MilestonesProps) {
  const [selectedMilestone, setSelectedMilestone] = useState<MilestoneItem | null>(null);
  const [activeCelebration, setActiveCelebration] = useState<MilestoneItem | null>(null);
  const [activeSubTab, setActiveSubTab] = useState<"milestones" | "career">("milestones");
  const [equippingId, setEquippingId] = useState<string | null>(null);
  const [selectedBadge, setSelectedBadge] = useState<CareerLevelBadge | null>(null);

  // Load celebrated milestone IDs from localStorage
  const [celebratedMilestones, setCelebratedMilestones] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem("celebrated_milestones");
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  // Trigger a premium fireworks confetti explosion
  const triggerConfettiExplosion = () => {
    // Left side cannon
    confetti({
      particleCount: 50,
      angle: 60,
      spread: 55,
      origin: { x: 0, y: 0.8 },
      colors: ["#F59E0B", "#10B981", "#3B82F6", "#EC4899", "#8B5CF6"]
    });
    // Right side cannon
    confetti({
      particleCount: 50,
      angle: 120,
      spread: 55,
      origin: { x: 1, y: 0.8 },
      colors: ["#F59E0B", "#10B981", "#3B82F6", "#EC4899", "#8B5CF6"]
    });

    // Center sparkles burst slightly delayed
    setTimeout(() => {
      confetti({
        particleCount: 80,
        spread: 80,
        origin: { y: 0.6 },
        colors: ["#F59E0B", "#3B82F6", "#8B5CF6", "#10B981", "#F43F5E"]
      });
    }, 250);
  };

  // Calculate current streak days
  const getStreakDays = () => {
    if (!currentUser?.streakStartDate) return 0;
    const start = new Date(currentUser.streakStartDate);
    const now = new Date();
    const diffMs = now.getTime() - start.getTime();
    return Math.max(0, Math.floor(diffMs / (1000 * 60 * 60 * 24)));
  };

  const currentStreak = getStreakDays();

  // Check for newly unlocked milestones
  useEffect(() => {
    if (!currentUser) return;
    
    // Find all milestones that the user currently qualifies for
    const unlockedMilestones = MILESTONES_DATA.filter(m => currentStreak >= m.days);
    
    // Find any that we haven't celebrated yet in this browser session
    const newlyUnlocked = unlockedMilestones.filter(m => !celebratedMilestones.includes(m.id));
    
    if (newlyUnlocked.length > 0) {
      // Trigger the spectacular fireworks!
      triggerConfettiExplosion();
      
      // Set the highest newly unlocked milestone to show in the celebration popup
      const highestNew = newlyUnlocked[newlyUnlocked.length - 1];
      setActiveCelebration(highestNew);
      
      // Mark all these as celebrated
      const updatedCelebrated = [...celebratedMilestones, ...newlyUnlocked.map(m => m.id)];
      setCelebratedMilestones(updatedCelebrated);
      try {
        localStorage.setItem("celebrated_milestones", JSON.stringify(updatedCelebrated));
      } catch (e) {
        console.error(e);
      }
    }
  }, [currentStreak, currentUser]);

  // Handle streak resets: clean up celebrated milestone IDs that are now locked
  useEffect(() => {
    if (!currentUser) return;
    const activeUnlockedIds = MILESTONES_DATA.filter(m => currentStreak >= m.days).map(m => m.id);
    const validCelebrated = celebratedMilestones.filter(id => activeUnlockedIds.includes(id));
    
    if (validCelebrated.length !== celebratedMilestones.length) {
      setCelebratedMilestones(validCelebrated);
      try {
        localStorage.setItem("celebrated_milestones", JSON.stringify(validCelebrated));
      } catch (e) {
        console.error(e);
      }
    }
  }, [currentStreak]);

  // Find next locked milestone
  const nextMilestone = MILESTONES_DATA.find(m => currentStreak < m.days);
  const prevMilestone = [...MILESTONES_DATA].reverse().find(m => currentStreak >= m.days);

  // Progress percentage to the next milestone
  const getProgressPercentage = () => {
    if (!nextMilestone) return 100;
    const baseDays = prevMilestone ? prevMilestone.days : 0;
    const range = nextMilestone.days - baseDays;
    const progress = currentStreak - baseDays;
    return Math.min(100, Math.max(0, (progress / range) * 100));
  };

  const progressPercent = getProgressPercentage();
  const unlockedCount = MILESTONES_DATA.filter(m => currentStreak >= m.days).length;

  const userXp = currentUser?.totalXp || 0;
  const careerLevel = Math.floor(userXp / 200) + 1;
  const xpInCurrentLevel = userXp % 200;
  const careerXpPercent = Math.min((xpInCurrentLevel / 200) * 100, 100);
  const currentEquippedBadge = currentUser ? getActiveBadge(currentUser.equippedBadgeId, currentUser.totalXp) : null;

  const handleEquipBadge = async (badgeId: string) => {
    if (!currentUser || !onUpdateUser) return;
    setEquippingId(badgeId);
    try {
      const res = await fetch(`/api/user/${currentUser.id}/badge`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ badgeId })
      });
      if (res.ok) {
        const updated = await res.json();
        onUpdateUser(updated);
        triggerConfettiExplosion();
      }
    } catch (e) {
      console.error(e);
    } finally {
      setEquippingId(null);
    }
  };

  return (
    <div id="sovereign-milestones" className="rounded-2xl border border-[#1A1A1B] bg-[#0F0F10] p-6 shadow-sm space-y-6">
      
      {/* Header and Stats row */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-[#1A1A1B] pb-5">
        <div className="space-y-1">
          <div className="flex items-center space-x-2">
            <Trophy className="h-5 w-5 text-amber-500" />
            <h3 className="font-display font-bold text-neutral-100">Progression & Accolades</h3>
          </div>
          <p className="text-xs text-neutral-400">
            Track your neural milestones, level up your career standing, and customize your profile badges.
          </p>
        </div>

        {/* Tab switching buttons */}
        <div className="flex items-center space-x-2 bg-[#0A0A0B] border border-[#1A1A1B] p-1 rounded-xl shrink-0 self-start md:self-auto">
          <button
            onClick={() => setActiveSubTab("milestones")}
            className={`px-3 py-1.5 text-xs font-bold rounded-lg transition-all cursor-pointer ${
              activeSubTab === "milestones"
                ? "bg-amber-500 text-neutral-950"
                : "text-neutral-400 hover:text-neutral-200"
            }`}
          >
            Sovereign Medals
          </button>
          <button
            onClick={() => setActiveSubTab("career")}
            className={`px-3 py-1.5 text-xs font-bold rounded-lg transition-all cursor-pointer flex items-center space-x-1.5 ${
              activeSubTab === "career"
                ? "bg-amber-500 text-neutral-950"
                : "text-neutral-400 hover:text-neutral-200"
            }`}
          >
            <Award className="h-3.5 w-3.5" />
            <span>Career Badges</span>
          </button>
        </div>
      </div>

      {activeSubTab === "milestones" ? (
        <div id="milestones-subtab-content" className="space-y-6">
          {/* Progress to next milestone */}
          {nextMilestone && (
            <div className="space-y-2 bg-[#0A0A0B]/50 border border-[#1A1A1B] p-4 rounded-xl">
              <div className="flex items-center justify-between text-xs font-bold">
                <span className="text-neutral-400 flex items-center space-x-1.5">
                  <BrainCircuit className="h-4 w-4 text-amber-500" />
                  <span>Next Neuro-Shift: <strong className="text-neutral-200">{nextMilestone.title}</strong></span>
                </span>
                <span className="text-amber-500 font-mono">
                  {nextMilestone.days - currentStreak} {nextMilestone.days - currentStreak === 1 ? 'day' : 'days'} remaining
                </span>
              </div>
              
              <div className="relative h-2 w-full rounded-full bg-neutral-900 overflow-hidden">
                <div 
                  className="absolute left-0 top-0 h-full bg-gradient-to-r from-amber-600 to-amber-500 rounded-full transition-all duration-500"
                  style={{ width: `${progressPercent}%` }}
                />
              </div>

              <div className="flex items-center justify-between text-[10px] text-neutral-550 font-semibold uppercase tracking-wider">
                <span>{prevMilestone ? `${prevMilestone.days} Day Milestone` : 'Day 0'}</span>
                <span>{nextMilestone.days} Day Milestone</span>
              </div>
            </div>
          )}

          {/* Milestones Horizontal / Grid list */}
          <div className="grid gap-4 grid-cols-2 sm:grid-cols-4 lg:grid-cols-8">
            {MILESTONES_DATA.map((milestone) => {
              const isUnlocked = currentStreak >= milestone.days;
              const IconComponent = milestone.icon;

              return (
                <button
                  key={milestone.id}
                  onClick={() => setSelectedMilestone(milestone)}
                  className={`group flex flex-col items-center justify-center text-center p-3.5 rounded-2xl border transition-all relative ${
                    isUnlocked 
                      ? `bg-gradient-to-b ${milestone.accentColor} ${milestone.borderColor} hover:scale-[1.03] shadow-md shadow-amber-500/2`
                      : "bg-[#0A0A0B]/60 border-[#1A1A1B] hover:border-neutral-800"
                  }`}
                >
                  {/* Unlocked Checkmark or Lock indicator */}
                  <div className="absolute top-2 right-2">
                    {isUnlocked ? (
                      <CheckCircle2 className={`h-3 w-3 ${milestone.textColor}`} />
                    ) : (
                      <Lock className="h-2.5 w-2.5 text-neutral-700" />
                    )}
                  </div>

                  {/* Icon Sphere */}
                  <div className={`h-11 w-11 rounded-xl flex items-center justify-center border transition-all ${
                    isUnlocked 
                      ? `bg-[#0A0A0B]/80 ${milestone.borderColor} ${milestone.textColor} group-hover:bg-[#0A0A0B]`
                      : "bg-neutral-950 border-neutral-900 text-neutral-700"
                  }`}>
                    <IconComponent className="h-5.5 w-5.5" />
                  </div>

                  {/* Title and Streak Label */}
                  <div className="mt-2.5 space-y-0.5">
                    <p className={`text-[11px] font-black tracking-tight ${isUnlocked ? "text-neutral-200" : "text-neutral-500"}`}>
                      {milestone.title}
                    </p>
                    <p className="text-[9px] text-neutral-500 font-bold uppercase tracking-wider">
                      {milestone.days} {milestone.days === 1 ? 'Day' : 'Days'}
                    </p>
                  </div>

                  {/* Hover / tap guidance */}
                  <div className="mt-2 text-[8px] text-neutral-600 font-bold opacity-0 group-hover:opacity-100 transition-all uppercase tracking-wide">
                    View Science
                  </div>
                </button>
              );
            })}
          </div>
        </div>
      ) : (
        <div id="career-badges-subtab-content" className="space-y-6">
          {!currentUser ? (
            <div className="rounded-2xl border-2 border-dashed border-[#1A1A1B] bg-[#0A0A0B]/60 p-10 text-center space-y-4 shadow-sm max-w-xl mx-auto">
              <Award className="h-12 w-12 text-neutral-650 mx-auto animate-pulse" />
              <h3 className="font-display text-lg font-bold text-neutral-200">Career Progression is Dormant</h3>
              <p className="text-xs text-neutral-450 leading-relaxed max-w-sm mx-auto">
                Authenticate your profile to track combined XP from daily checklists and journal reflections. Unlock and equip gorgeous custom badges!
              </p>
            </div>
          ) : (
            <div className="space-y-6">
              {/* Career Progress Card */}
              <div className="grid gap-6 md:grid-cols-3 bg-[#0A0A0B]/80 border border-[#1A1A1B] p-5 rounded-2xl">
                <div className="space-y-1">
                  <span className="text-[10px] uppercase font-bold tracking-widest text-neutral-500">Career Standing</span>
                  <div className="flex items-center space-x-2">
                    <h4 className="text-2xl font-black text-neutral-100 font-display">Level {careerLevel}</h4>
                    <span className="text-[10px] bg-amber-500/10 text-amber-500 font-bold px-2 py-0.5 rounded-md border border-amber-500/20">
                      Active Rank
                    </span>
                  </div>
                  <p className="text-xs text-neutral-400">
                    Earned from checklists, triggers, & journal entries.
                  </p>
                </div>

                <div className="space-y-2">
                  <div className="flex items-center justify-between text-xs font-bold">
                    <span className="text-neutral-400">Level Experience</span>
                    <span className="text-amber-500">{xpInCurrentLevel} / 200 XP</span>
                  </div>
                  <div className="relative h-2.5 w-full rounded-full bg-neutral-900 overflow-hidden border border-neutral-850">
                    <div 
                      className="absolute left-0 top-0 h-full bg-gradient-to-r from-amber-600 to-amber-500 rounded-full transition-all duration-500"
                      style={{ width: `${careerXpPercent}%` }}
                    />
                  </div>
                  <div className="flex items-center justify-between text-[10px] text-neutral-500 font-semibold">
                    <span>Total: {userXp} XP</span>
                    <span>{200 - xpInCurrentLevel} XP to Lvl {careerLevel + 1}</span>
                  </div>
                </div>

                <div className="flex items-center space-x-3.5 bg-[#121214] border border-[#222225] p-3.5 rounded-xl">
                  {currentEquippedBadge ? (
                    <>
                      <div className="text-3xl p-1 bg-[#0A0A0B] rounded-xl border border-[#222225] h-14 w-14 flex items-center justify-center shrink-0">
                        {currentEquippedBadge.emoji}
                      </div>
                      <div className="min-w-0">
                        <span className="text-[9px] uppercase tracking-wider font-extrabold text-amber-500">Equipped Badge</span>
                        <h5 className="text-sm font-black text-neutral-200 truncate">{currentEquippedBadge.name}</h5>
                        <p className="text-[10px] text-neutral-400 truncate mt-0.5">"{currentEquippedBadge.description}"</p>
                      </div>
                    </>
                  ) : (
                    <div className="text-center w-full py-2 text-xs text-neutral-550">
                      No cosmetic badges equipped yet.
                    </div>
                  )}
                </div>
              </div>

              {/* Badges Grid */}
              <div className="grid gap-4 grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 animate-fade-in">
                {CAREER_BADGES.map((badge) => {
                  const isUnlocked = userXp >= badge.xpRequired;
                  const isEquipped = currentUser.equippedBadgeId === badge.id || 
                    (!currentUser.equippedBadgeId && badge.id === "bronze_sigil"); // Default badge fallback
                  
                  return (
                    <div
                      key={badge.id}
                      onClick={() => setSelectedBadge(badge)}
                      className={`group flex flex-col justify-between p-4 rounded-2xl border transition-all relative text-left cursor-pointer ${
                        isUnlocked
                          ? `${badge.borderColor} bg-[#0F0F10] hover:border-neutral-700 hover:scale-[1.01] shadow-md shadow-amber-500/1`
                          : "border-neutral-900 bg-neutral-950/40 opacity-70"
                      }`}
                    >
                      {/* Top Row: Badge Emblem & Lock/Unlock Status */}
                      <div className="flex items-start justify-between">
                        <div className={`h-12 w-12 rounded-xl flex items-center justify-center border text-2xl bg-[#0A0A0B] ${
                          isUnlocked ? badge.borderColor : "border-neutral-900"
                        }`}>
                          {badge.emoji}
                        </div>
                        
                        <div>
                          {isUnlocked ? (
                            isEquipped ? (
                              <span className="text-[9px] font-black uppercase bg-amber-500/15 text-amber-400 px-2 py-0.5 rounded border border-amber-500/30 animate-pulse">
                                EQUIPPED
                              </span>
                            ) : (
                              <span className="text-[9px] font-black uppercase bg-emerald-500/10 text-emerald-400 px-2 py-0.5 rounded border border-emerald-500/20">
                                UNLOCKED
                              </span>
                            )
                          ) : (
                            <span className="text-[9px] font-black uppercase bg-neutral-900 text-neutral-600 px-2 py-0.5 rounded border border-neutral-850 flex items-center space-x-1">
                              <Lock className="h-2.5 w-2.5" />
                              <span>LOCKED</span>
                            </span>
                          )}
                        </div>
                      </div>

                      {/* Name & Details */}
                      <div className="mt-4 space-y-1">
                        <h5 className={`text-sm font-black ${isUnlocked ? "text-neutral-200" : "text-neutral-500"}`}>
                          {badge.name}
                        </h5>
                        <p className="text-xs text-neutral-450 leading-snug line-clamp-2">
                          {badge.description}
                        </p>
                      </div>

                      {/* Footer XP bar or action */}
                      <div className="mt-4 pt-3 border-t border-[#161618] flex items-center justify-between text-[11px]">
                        <span className="text-neutral-550 font-bold">
                          Required: {badge.xpRequired} XP
                        </span>

                        {isUnlocked ? (
                          isEquipped ? (
                            <span className="text-amber-500 font-bold flex items-center space-x-1">
                              <CheckCircle2 className="h-3 w-3" />
                              <span>Equipped</span>
                            </span>
                          ) : (
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                handleEquipBadge(badge.id);
                              }}
                              disabled={equippingId === badge.id}
                              className="text-xs font-black text-amber-500 hover:text-amber-400 bg-amber-500/5 hover:bg-amber-500/10 px-2.5 py-1 rounded-lg border border-amber-500/25 transition-all cursor-pointer shrink-0"
                            >
                              {equippingId === badge.id ? "Equipping..." : "Equip"}
                            </button>
                          )
                        ) : (
                          <span className="text-neutral-600 font-bold">
                            Locked ({badge.xpRequired - userXp} XP left)
                          </span>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>
      )}

      {/* DETAILED NEUROSCIENCE MODAL / POPUP */}
      {selectedMilestone && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-xs animate-fade-in">
          <div className="relative w-full max-w-lg rounded-2xl border border-[#1A1A1B] bg-[#0F0F10] p-6 text-left shadow-2xl space-y-4">
            
            {/* Close Button */}
            <button
              onClick={() => setSelectedMilestone(null)}
              className="absolute top-4 right-4 rounded-lg p-1.5 hover:bg-[#161618] text-neutral-500 hover:text-neutral-200 transition-all"
            >
              <X className="h-4 w-4" />
            </button>

            {/* Modal Header */}
            <div className="flex items-center space-x-3.5 border-b border-[#1A1A1B] pb-4">
              <div className={`h-12 w-12 rounded-xl flex items-center justify-center border ${
                currentStreak >= selectedMilestone.days
                  ? `bg-[#0A0A0B] ${selectedMilestone.borderColor} ${selectedMilestone.textColor}`
                  : "bg-neutral-950 border-neutral-900 text-neutral-600"
              }`}>
                {React.createElement(selectedMilestone.icon, { className: "h-6 w-6" })}
              </div>
              <div>
                <div className="flex items-center space-x-2">
                  <h4 className="font-display font-black text-base text-neutral-200">
                    {selectedMilestone.title}
                  </h4>
                  {currentStreak >= selectedMilestone.days ? (
                    <span className={`text-[9px] font-black uppercase px-2 py-0.5 rounded ${selectedMilestone.bgLight} ${selectedMilestone.textColor} border ${selectedMilestone.borderColor}`}>
                      UNLOCKED
                    </span>
                  ) : (
                    <span className="text-[9px] font-black uppercase px-2 py-0.5 rounded bg-neutral-900 text-neutral-600 border border-neutral-850">
                      LOCKED
                    </span>
                  )}
                </div>
                <p className="text-xs text-neutral-450 font-medium">{selectedMilestone.subtitle}</p>
              </div>
            </div>

            {/* Neuroscience Description */}
            <div className="space-y-2">
              <h5 className="text-[10px] uppercase font-black tracking-wider text-amber-500 flex items-center space-x-1.5">
                <BrainCircuit className="h-3.5 w-3.5" />
                <span>Neurobiology & Rewiring</span>
              </h5>
              <p className="text-xs text-neutral-300 leading-relaxed bg-[#0A0A0B] border border-[#1A1A1B] p-3 rounded-xl italic">
                "{selectedMilestone.neuroDescription}"
              </p>
            </div>

            {/* Cognitive Defense / Clinical Advice */}
            <div className="space-y-2">
              <h5 className="text-[10px] uppercase font-black tracking-wider text-neutral-400 flex items-center space-x-1.5">
                <HelpCircle className="h-3.5 w-3.5 text-amber-500" />
                <span>Sanctuary Sovereignty Advice</span>
              </h5>
              <p className="text-xs text-neutral-400 leading-relaxed">
                {selectedMilestone.actionAdvice}
              </p>
            </div>

            {/* Status info */}
            <div className="border-t border-[#1A1A1B] pt-4 flex items-center justify-between text-xs text-neutral-500">
              <span>Required streak: <strong className="text-neutral-300">{selectedMilestone.days} Days</strong></span>
              <span>Your current streak: <strong className="text-amber-500">{currentStreak} Days</strong></span>
            </div>

            <button
              onClick={() => setSelectedMilestone(null)}
              className="w-full rounded-xl bg-[#0A0A0B] border border-[#1A1A1B] py-2.5 text-xs font-bold text-neutral-300 hover:bg-[#161618] transition-all"
            >
              Close Codex
            </button>

          </div>
        </div>
      )}

      {/* DETAILED CAREER BADGE MODAL */}
      {selectedBadge && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-xs animate-fade-in">
          <div className="relative w-full max-w-md rounded-2xl border border-[#1A1A1B] bg-[#0F0F10] p-6 text-left shadow-2xl space-y-5">
            
            {/* Close Button */}
            <button
              onClick={() => setSelectedBadge(null)}
              className="absolute top-4 right-4 rounded-lg p-1.5 hover:bg-[#161618] text-neutral-500 hover:text-neutral-200 transition-all"
            >
              <X className="h-4 w-4" />
            </button>

            {/* Modal Header */}
            <div className="flex items-center space-x-4 border-b border-[#1A1A1B] pb-4">
              <div className={`h-14 w-14 rounded-2xl flex items-center justify-center border text-3xl bg-[#0A0A0B] ${
                currentUser && currentUser.totalXp >= selectedBadge.xpRequired
                  ? selectedBadge.borderColor
                  : "border-neutral-900"
              }`}>
                {selectedBadge.emoji}
              </div>
              <div>
                <div className="flex items-center space-x-2">
                  <h4 className="font-display font-black text-lg text-neutral-200">
                    {selectedBadge.name}
                  </h4>
                  {currentUser && currentUser.totalXp >= selectedBadge.xpRequired ? (
                    <span className="text-[9px] font-black uppercase px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                      UNLOCKED
                    </span>
                  ) : (
                    <span className="text-[9px] font-black uppercase px-2 py-0.5 rounded bg-neutral-900 text-neutral-600 border border-neutral-850">
                      LOCKED
                    </span>
                  )}
                </div>
                <p className="text-xs text-neutral-450 font-medium">Cosmetic Profile Badge</p>
              </div>
            </div>

            {/* Description & Philosophy */}
            <div className="space-y-3.5">
              <div className="space-y-1.5">
                <span className="text-[9px] uppercase tracking-widest font-black text-amber-500">Accolade Definition</span>
                <p className="text-xs text-neutral-350 leading-relaxed bg-[#0A0A0B] border border-[#1A1A1B] p-3 rounded-xl italic">
                  "{selectedBadge.description}"
                </p>
              </div>

              <div className="space-y-1.5">
                <span className="text-[9px] uppercase tracking-widest font-black text-neutral-400">Purity Philosophy</span>
                <p className="text-xs text-neutral-400 leading-relaxed bg-[#0A0A0B]/30 p-3 rounded-xl border border-[#1A1A1B]/50">
                  {selectedBadge.philosophy}
                </p>
              </div>
            </div>

            {/* Required details / equip action */}
            <div className="border-t border-[#1A1A1B] pt-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
              <div className="text-neutral-500 font-bold">
                Required combined experience: <strong className="text-neutral-300">{selectedBadge.xpRequired} XP</strong>
                {currentUser && <p className="text-[10px] text-neutral-400 font-medium mt-0.5">Your XP: {currentUser.totalXp} XP</p>}
              </div>

              {currentUser && currentUser.totalXp >= selectedBadge.xpRequired ? (
                currentUser.equippedBadgeId === selectedBadge.id || 
                (!currentUser.equippedBadgeId && selectedBadge.id === "bronze_sigil") ? (
                  <span className="text-amber-500 font-extrabold flex items-center space-x-1 py-2 px-3 rounded bg-amber-500/5 border border-amber-500/10 text-xs shrink-0 self-start sm:self-auto">
                    <CheckCircle2 className="h-4 w-4" />
                    <span>Equipped Badge</span>
                  </span>
                ) : (
                  <button
                    onClick={() => {
                      handleEquipBadge(selectedBadge.id);
                      setSelectedBadge(null);
                    }}
                    disabled={equippingId === selectedBadge.id}
                    className="w-full sm:w-auto rounded-xl bg-gradient-to-r from-amber-600 to-amber-500 text-[#0A0A0B] px-4 py-2 text-xs font-black hover:from-amber-500 hover:to-amber-400 shadow-md shadow-amber-500/10 transition-all cursor-pointer shrink-0"
                  >
                    {equippingId === selectedBadge.id ? "Equipping..." : "Equip Badge"}
                  </button>
                )
              ) : (
                <span className="text-neutral-600 font-bold shrink-0 self-start sm:self-auto flex items-center space-x-1 bg-neutral-950 py-1.5 px-3 rounded border border-neutral-900">
                  <Lock className="h-3.5 w-3.5" />
                  <span>Requires {selectedBadge.xpRequired - userXp} XP</span>
                </span>
              )}
            </div>

          </div>
        </div>
      )}

      {/* SPECTACULAR MILESTONE CELEBRATION MODAL */}
      {activeCelebration && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/90 backdrop-blur-md animate-fade-in">
          <div className="relative w-full max-w-md rounded-2xl border-2 border-amber-500 bg-[#0F0F10] p-8 text-center shadow-[0_0_50px_rgba(245,158,11,0.15)] space-y-6">
            
            {/* Crown/Trophy animated background glow */}
            <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1/2 w-24 h-24 bg-gradient-to-tr from-amber-500/20 to-yellow-500/30 rounded-full blur-xl pointer-events-none" />

            <div className="space-y-2">
              <div className="inline-flex h-16 w-16 rounded-2xl bg-gradient-to-b from-amber-500/20 to-amber-600/30 border border-amber-500 flex items-center justify-center text-amber-400 shadow-lg shadow-amber-500/10 mx-auto">
                {React.createElement(activeCelebration.icon, { className: "h-8 w-8 animate-bounce" })}
              </div>
              <h3 className="font-display font-black text-2xl text-neutral-100 tracking-tight mt-4">
                Milestone Reached!
              </h3>
              <p className="text-xs text-neutral-450 uppercase tracking-widest font-black text-amber-500">
                {activeCelebration.days} {activeCelebration.days === 1 ? 'Day' : 'Days'} of Sovereign Strength
              </p>
            </div>

            <div className="border border-[#1A1A1B] bg-[#0A0A0B] p-4 rounded-xl space-y-2 text-left">
              <h4 className="text-xs font-black uppercase text-neutral-200 tracking-wider">
                {activeCelebration.title}
              </h4>
              <p className="text-xs text-neutral-350 leading-relaxed italic">
                "{activeCelebration.neuroDescription}"
              </p>
            </div>

            <div className="space-y-3">
              <button
                onClick={() => {
                  triggerConfettiExplosion();
                  // Fire another delayed one for extra epicness
                  setTimeout(triggerConfettiExplosion, 350);
                }}
                className="w-full flex items-center justify-center space-x-2 rounded-xl bg-gradient-to-r from-amber-600 to-amber-500 hover:from-amber-500 hover:to-amber-400 px-4 py-3 text-sm font-black text-neutral-950 hover:scale-[1.02] shadow-lg shadow-amber-500/10 transition-all cursor-pointer"
              >
                <Sparkles className="h-4 w-4" />
                <span>More Fireworks!</span>
              </button>
              
              <button
                onClick={() => setActiveCelebration(null)}
                className="w-full rounded-xl bg-neutral-950 border border-[#1A1A1B] hover:border-neutral-800 py-2.5 text-xs font-bold text-neutral-400 hover:text-neutral-200 transition-all"
              >
                Continue My Journey
              </button>
            </div>

          </div>
        </div>
      )}

    </div>
  );
}
