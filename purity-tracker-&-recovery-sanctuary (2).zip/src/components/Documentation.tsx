/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { 
  BookOpen, 
  Brain, 
  Compass, 
  ShieldCheck, 
  Activity, 
  Flame, 
  Award, 
  Search, 
  Sparkles, 
  ChevronDown, 
  ChevronRight,
  Sparkle
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

interface Topic {
  id: string;
  title: string;
  description: string;
  icon: React.ComponentType<any>;
  content: React.ReactNode;
}

export default function Documentation() {
  const [searchQuery, setSearchQuery] = useState("");
  const [activeCategory, setActiveCategory] = useState<"all" | "science" | "tools" | "gamification">("all");
  const [expandedTopicId, setExpandedTopicId] = useState<string | null>("science-neuro");

  const categories = [
    { id: "all", label: "All Wisdom" },
    { id: "science", label: "Science of Recovery" },
    { id: "tools", label: "Sanctuary Toolkit" },
    { id: "gamification", label: "Gamification & Progression" }
  ];

  const topics: (Topic & { category: "science" | "tools" | "gamification" })[] = [
    {
      id: "science-neuro",
      category: "science",
      title: "Neurological Basis of Recovery",
      description: "Understand the DeltaFosB molecular switch, dopamine upregulation, and prefrontal restructuring.",
      icon: Brain,
      content: (
        <div className="space-y-4 text-neutral-300 text-sm leading-relaxed">
          <p>
            Addiction and compulsive urges are not failures of character; they are deeply ingrained neurological adaptations. Purity of mind is achieved by systematically reversing these changes.
          </p>
          <div className="grid gap-4 sm:grid-cols-3 mt-3">
            <div className="rounded-xl bg-[#0A0A0B] p-4 border border-[#1A1A1B]">
              <span className="text-amber-500 font-bold text-xs uppercase tracking-wider block mb-1">DeltaFosB Switch</span>
              <p className="text-neutral-400 text-xs">
                A transcription factor that accumulates in the reward center during repeated high-dopamine behaviors. It acts as a molecular "craving switch." Abstinence slowly depletes this protein, resetting baseline urges.
              </p>
            </div>
            <div className="rounded-xl bg-[#0A0A0B] p-4 border border-[#1A1A1B]">
              <span className="text-amber-500 font-bold text-xs uppercase tracking-wider block mb-1">Dopamine Upregulation</span>
              <p className="text-neutral-400 text-xs">
                Over-stimulation downregulates dopamine D2 receptors, making everyday life feel dull. Committing to sobriety triggers upregulation, restoring joy, drive, and concentration in simple pleasures.
              </p>
            </div>
            <div className="rounded-xl bg-[#0A0A0B] p-4 border border-[#1A1A1B]">
              <span className="text-amber-500 font-bold text-xs uppercase tracking-wider block mb-1">Prefrontal Restructuring</span>
              <p className="text-neutral-400 text-xs">
                Compulsive urges weaken the prefrontal cortex—the brain's command center. Regular mindfulness, objective tracking, and active CBT exercises thicken this tissue, restoring self-governance.
              </p>
            </div>
          </div>
          <p className="mt-2 text-xs text-neutral-400 italic">
            *Source: Harvard Health & National Institute on Drug Abuse (NIDA) Recovery Studies.
          </p>
        </div>
      )
    },
    {
      id: "science-dopamine",
      category: "science",
      title: "The Dopamine Baseline Reset Protocol",
      description: "How the brain adjusts back to healthy levels over 30, 60, and 90-day recovery timelines.",
      icon: Activity,
      content: (
        <div className="space-y-4 text-neutral-300 text-sm leading-relaxed">
          <p>
            Dopamine baseline restoration takes time. Sanctuary's architecture is built to anchor you through the three distinct phases of molecular healing:
          </p>
          <div className="space-y-3">
            <div className="flex items-start space-x-3 bg-[#0A0A0B] p-3 rounded-xl border border-[#1A1A1B]">
              <div className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-amber-500/10 text-amber-500 font-mono text-xs font-bold">1</div>
              <div>
                <strong className="text-neutral-200 block text-xs">Days 1 - 14: Acute Desensitization</strong>
                <p className="text-neutral-400 text-xs mt-0.5">The brain expects high-intensity rewards. Cravings are frequent. Use the <strong>Urge SOS Room</strong> and focus on accumulating hourly milestones. Prefrontal strength is lowest here.</p>
              </div>
            </div>
            <div className="flex items-start space-x-3 bg-[#0A0A0B] p-3 rounded-xl border border-[#1A1A1B]">
              <div className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-amber-500/10 text-amber-500 font-mono text-xs font-bold">2</div>
              <div>
                <strong className="text-neutral-200 block text-xs">Days 15 - 45: Baseline Recalibration</strong>
                <p className="text-neutral-400 text-xs mt-0.5">Neuroreceptor upregulation begins. Motivation fluctuates. Maintain consistency by logging <strong>Daily Objectives</strong> and utilizing the <strong>CBT Logbook</strong> to rewrite automatic negative thoughts.</p>
              </div>
            </div>
            <div className="flex items-start space-x-3 bg-[#0A0A0B] p-3 rounded-xl border border-[#1A1A1B]">
              <div className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-amber-500/10 text-amber-500 font-mono text-xs font-bold">3</div>
              <div>
                <strong className="text-neutral-200 block text-xs">Days 46 - 90+: Neuroplastic Reconstitution</strong>
                <p className="text-neutral-400 text-xs mt-0.5">Synaptic pruning solidifies healthy new behavioral pathways. Natural focus and clarity return. At this stage, seekers are highly active in mentoring others on the <strong>Leaderboard</strong> and <strong>Community Forums</strong>.</p>
              </div>
            </div>
          </div>
        </div>
      )
    },
    {
      id: "tools-clock",
      category: "tools",
      title: "Precision Sobriety Clock & Daily Objectives",
      description: "How to use real-time timestamp-based tracking and the Daily Sovereign Objective matrix.",
      icon: Flame,
      content: (
        <div className="space-y-4 text-neutral-300 text-sm leading-relaxed">
          <p>
            Sanctuary's tracking systems are engineered for high accountability and zero cognitive distortion:
          </p>
          <ul className="list-disc pl-5 space-y-2 text-xs text-neutral-400">
            <li>
              <strong className="text-neutral-200">The Sobriety Clock</strong> calculates pure continuous recovery up to milliseconds. It utilizes local browser precision synced to the central server, preventing manual clock tampering.
            </li>
            <li>
              <strong className="text-neutral-200">Daily Sovereign Objectives</strong> are critical daily micro-commitments. By defining one primary objective and up to 3 supportive targets every morning, you narrow your focal aperture, starving urges of idle cognitive bandwidth.
            </li>
            <li>
              <strong className="text-neutral-200">The Heatmap Grid</strong> records your long-term consistency. Each cell represents a 24-hour cycle. Keeping the cells full builds a powerful visual chain that activates visual reinforcement circuits in the cortex.
            </li>
          </ul>
        </div>
      )
    },
    {
      id: "tools-cbt",
      category: "tools",
      title: "The CBT Logbook & Rational Rewriting",
      description: "Unpacking cognitive distortions: Black-and-white thinking, catastrophizing, and emotional reasoning.",
      icon: Compass,
      content: (
        <div className="space-y-4 text-neutral-300 text-sm leading-relaxed">
          <p>
            Cognitive Behavioral Therapy (CBT) is the gold standard for behavioral transformation. Urges are triggered by automatic thoughts. By logging and restructuring these thoughts, you break the chain before it triggers a physical relapse.
          </p>
          <div className="border border-[#1A1A1B] rounded-xl overflow-hidden text-xs">
            <div className="grid grid-cols-3 bg-[#0A0A0B] p-2.5 font-bold text-neutral-400 border-b border-[#1A1A1B]">
              <div>1. Trigger / Impulse</div>
              <div>2. Cognitive Distortion</div>
              <div>3. Sovereign Reframing</div>
            </div>
            <div className="grid grid-cols-3 p-3 gap-3">
              <div className="text-neutral-300">"I had a stressful day at work. I deserve to indulge just this once to calm down."</div>
              <div className="text-amber-500 font-medium">Emotional Reasoning & Permission Setting</div>
              <div className="text-emerald-400 font-medium">"Stress is a neurological state. Indulging now creates a feedback loop that increases stress tomorrow. Calmness comes from discipline, not relapse."</div>
            </div>
          </div>
          <p className="text-xs text-neutral-400 mt-2">
            Use the **CBT Logbook** tab on the main dashboard to register, identify, and securely re-key automatic negative thoughts. This transforms sub-conscious impulses into conscious choices.
          </p>
        </div>
      )
    },
    {
      id: "tools-sos",
      category: "tools",
      title: "Urge SOS Room & AI Purity Mentor",
      description: "How to use the deep breathing synchronizer, panic response, and server-side AI mentoring guidance.",
      icon: ShieldCheck,
      content: (
        <div className="space-y-4 text-neutral-300 text-sm leading-relaxed">
          <p>
            When an urge peaks, rational thinking shuts down. Sanctuary provides two critical psychological emergency exit routes:
          </p>
          <div className="grid gap-4 sm:grid-cols-2">
            <div className="bg-[#0A0A0B] p-3.5 rounded-xl border border-[#1A1A1B] space-y-2">
              <span className="text-rose-500 font-bold text-xs uppercase tracking-wider flex items-center space-x-1">
                <span className="h-2 w-2 bg-rose-500 rounded-full animate-ping"></span>
                <span>Urge SOS Room</span>
              </span>
              <p className="text-neutral-400 text-xs leading-relaxed">
                Features a tactile 4-7-8 breathing synchronizer. Inhaling for 4 seconds, holding for 7, and exhaling for 8 activates the vagus nerve, initiating an immediate parasympathetic dampening that lowers heart rate and dissolves acute biological tension.
              </p>
            </div>
            <div className="bg-[#0A0A0B] p-3.5 rounded-xl border border-[#1A1A1B] space-y-2">
              <span className="text-[#38BDF8] font-bold text-xs uppercase tracking-wider flex items-center space-x-1">
                <Sparkle className="h-3.5 w-3.5 text-[#38BDF8]" />
                <span>AI Purity Mentor</span>
              </span>
              <p className="text-neutral-400 text-xs leading-relaxed">
                Connects directly to server-side Gemini models with customized behavioral therapy prompt architectures. It acts as an unbiased, non-judgmental accountability advisor, ready to dissect urges, suggest targeted distraction protocols, or parse philosophical scriptures.
              </p>
            </div>
          </div>
        </div>
      )
    },
    {
      id: "gamification-xp",
      category: "gamification",
      title: "Gamification, Streak Freezes, & Milestone Seals",
      description: "How XP accumulation works, how to earn streak freezes, and unlocking levels.",
      icon: Award,
      content: (
        <div className="space-y-4 text-neutral-300 text-sm leading-relaxed">
          <p>
            To sustain motivation, Sanctuary utilizes an intrinsic reward model mapped to neuro-chemical reward systems.
          </p>
          <div className="space-y-3 text-xs text-neutral-400">
            <div className="flex justify-between items-center bg-[#0A0A0B] p-2.5 rounded-lg border border-[#1A1A1B]">
              <span className="font-semibold text-neutral-200">Daily Log-In & Check-In</span>
              <span className="text-amber-500 font-bold font-mono">+10 XP</span>
            </div>
            <div className="flex justify-between items-center bg-[#0A0A0B] p-2.5 rounded-lg border border-[#1A1A1B]">
              <span className="font-semibold text-neutral-200">Daily Sovereign Objective Completion</span>
              <span className="text-amber-500 font-bold font-mono">+30 XP</span>
            </div>
            <div className="flex justify-between items-center bg-[#0A0A0B] p-2.5 rounded-lg border border-[#1A1A1B]">
              <span className="font-semibold text-neutral-200">Writing a CBT Log entry</span>
              <span className="text-amber-500 font-bold font-mono">+25 XP</span>
            </div>
            <div className="flex justify-between items-center bg-[#0A0A0B] p-2.5 rounded-lg border border-[#1A1A1B]">
              <span className="font-semibold text-neutral-200">Answering community requests</span>
              <span className="text-amber-500 font-bold font-mono">+15 XP</span>
            </div>
          </div>
          <div className="mt-3 bg-amber-500/5 p-3 rounded-xl border border-amber-500/15">
            <strong className="text-amber-500 block text-xs mb-1">🛡️ The Streak Freeze Protocol</strong>
            <p className="text-neutral-400 text-xs leading-relaxed">
              Discipline must be accompanied by compassion. Life is volatile. Every user starts with 1 complimentary **Streak Freeze**. On the 1st day of every calendar month, if your current streak is active, you are automatically awarded an additional Streak Freeze (capped at a maximum of 3). If you fail to log in, a freeze is automatically spent to keep your sacred streak intact!
            </p>
          </div>
        </div>
      )
    }
  ];

  // Filter topics based on search query and active category
  const filteredTopics = topics.filter(topic => {
    const matchesCategory = activeCategory === "all" || topic.category === activeCategory;
    const matchesSearch = topic.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          topic.description.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  return (
    <div id="documentation-container" className="mx-auto max-w-4xl px-4 py-8 sm:px-6 lg:px-8">
      
      {/* Title & Description */}
      <div className="mb-8 text-center sm:text-left">
        <div className="flex items-center justify-center sm:justify-start space-x-2.5 mb-2.5">
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-amber-500/10 text-amber-500 border border-amber-500/20">
            <BookOpen className="h-5 w-5" />
          </div>
          <h1 className="font-display text-2xl font-bold tracking-tight text-[#E5E5E5] sm:text-3xl">
            Sanctuary Wisdom Archives
          </h1>
        </div>
        <p className="text-sm text-neutral-400 max-w-2xl">
          Deep-dive into the cognitive behavioral science of dopamine restructuration, mastery mechanics, and interactive tools designed to re-key your psychological willpower shield.
        </p>
      </div>

      {/* Filter and Search Panel */}
      <div className="mb-6 grid gap-4 md:grid-cols-12">
        {/* Search bar */}
        <div className="relative md:col-span-5">
          <Search className="absolute left-3.5 top-3.5 h-4.5 w-4.5 text-neutral-500" />
          <input
            id="docs-search-input"
            type="text"
            placeholder="Search core concepts, tools, or mechanics..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full rounded-xl border border-[#1A1A1B] bg-[#0F0F10] pl-10.5 pr-4 py-2.5 text-sm text-[#E5E5E5] outline-none transition-all focus:border-amber-500"
            aria-label="Search Wisdom Archives"
          />
        </div>

        {/* Category pills */}
        <div className="flex flex-wrap gap-2 md:col-span-7 md:justify-end items-center">
          {categories.map((cat) => (
            <button
              key={cat.id}
              onClick={() => setActiveCategory(cat.id as any)}
              className={`rounded-full px-4 py-1.5 text-xs font-semibold transition-all cursor-pointer ${
                activeCategory === cat.id
                  ? "bg-amber-500 text-[#0A0A0B] shadow-md shadow-amber-500/10"
                  : "bg-[#161618] text-[#888888] border border-[#262626] hover:text-[#E5E5E5] hover:border-[#3a3a3a]"
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>
      </div>

      {/* Topics Accordion Grid */}
      <div className="space-y-4">
        {filteredTopics.length > 0 ? (
          filteredTopics.map((topic) => {
            const Icon = topic.icon;
            const isExpanded = expandedTopicId === topic.id;

            return (
              <div 
                key={topic.id}
                className={`rounded-2xl border border-[#1A1A1B] bg-[#0F0F10] overflow-hidden transition-all duration-300 ${
                  isExpanded ? "ring-2 ring-amber-500/10 border-amber-500/20" : ""
                }`}
              >
                {/* Header */}
                <button
                  onClick={() => setExpandedTopicId(isExpanded ? null : topic.id)}
                  className="w-full flex items-center justify-between p-4 sm:p-5 text-left hover:bg-[#161618]/50 transition-all cursor-pointer"
                  aria-expanded={isExpanded}
                >
                  <div className="flex items-start space-x-3.5">
                    <div className={`flex h-10 w-10 shrink-0 items-center justify-center rounded-xl border transition-all ${
                      isExpanded 
                        ? "bg-amber-500/10 text-amber-500 border-amber-500/20" 
                        : "bg-[#0A0A0B] text-neutral-500 border-[#1A1A1B]"
                    }`}>
                      <Icon className="h-5 w-5" />
                    </div>
                    <div>
                      <h3 className="font-display font-bold text-neutral-200 text-sm sm:text-base tracking-tight hover:text-amber-500 transition-colors">
                        {topic.title}
                      </h3>
                      <p className="text-xs text-neutral-400 mt-1">
                        {topic.description}
                      </p>
                    </div>
                  </div>
                  <div className="text-neutral-500 hover:text-[#E5E5E5] transition-colors p-1">
                    {isExpanded ? (
                      <ChevronDown className="h-5 w-5 text-amber-500" />
                    ) : (
                      <ChevronRight className="h-5 w-5" />
                    )}
                  </div>
                </button>

                {/* Content */}
                <AnimatePresence initial={false}>
                  {isExpanded && (
                    <motion.div
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: "auto", opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      transition={{ duration: 0.25, ease: "easeInOut" }}
                    >
                      <div className="px-4 pb-5 pt-1 sm:px-5 border-t border-[#1A1A1B] bg-[#0C0C0D]">
                        {topic.content}
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            );
          })
        ) : (
          <div className="text-center py-12 rounded-2xl border border-dashed border-[#1A1A1B] bg-[#0F0F10]">
            <Compass className="h-8 w-8 text-neutral-600 mx-auto mb-3 animate-spin" />
            <p className="text-sm font-semibold text-neutral-300">No Wisdom Entries Found</p>
            <p className="text-xs text-neutral-500 mt-1">Try resetting your search filters or change your query keywords.</p>
          </div>
        )}
      </div>

      {/* Interactive Quick Help CTA */}
      <div className="mt-8 rounded-2xl bg-gradient-to-r from-amber-500/10 to-transparent p-5 border border-amber-500/15 flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="space-y-1 text-center sm:text-left">
          <div className="flex items-center justify-center sm:justify-start space-x-1.5 text-amber-500 font-bold text-sm">
            <Sparkles className="h-4 w-4" />
            <span>Need Tailored Cognitive Support?</span>
          </div>
          <p className="text-xs text-neutral-400 leading-relaxed max-w-xl">
            Our AI Purity Mentor is loaded with clinical CBT strategies, philosophical stoicism, and deep recovery scientific models. Chat one-on-one for customized guidance.
          </p>
        </div>
        <button
          onClick={() => {
            const tabBtn = document.getElementById("tab-btn-mentor");
            if (tabBtn) tabBtn.click();
          }}
          className="rounded-xl bg-amber-500 px-4 py-2 text-xs font-bold text-[#0A0A0B] shadow-md shadow-amber-500/10 hover:bg-amber-400 transition-all shrink-0 cursor-pointer"
        >
          Consult AI Mentor
        </button>
      </div>

    </div>
  );
}
