/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from "react";
import { 
  Send, 
  Users, 
  MessageSquare, 
  UserPlus, 
  UserMinus, 
  RefreshCw, 
  Flame, 
  Compass, 
  Sparkles, 
  CheckCircle,
  AlertCircle
} from "lucide-react";
import { User, GlobalChatMessage } from "../types";

interface CommunitySanctuaryProps {
  currentUser: User | null;
  onUpdateUser: (user: User) => void;
  onOpenAuth: () => void;
}

export default function CommunitySanctuary({
  currentUser,
  onUpdateUser,
  onOpenAuth
}: CommunitySanctuaryProps) {
  const [activeSubTab, setActiveSubTab] = useState<"chat" | "buddies">("chat");
  const [chatMessages, setChatMessages] = useState<GlobalChatMessage[]>([]);
  const [chatInput, setChatInput] = useState<string>("");
  const [chatLoading, setChatLoading] = useState<boolean>(false);
  const [buddies, setBuddies] = useState<any[]>([]);
  const [buddiesLoading, setBuddiesLoading] = useState<boolean>(false);
  const [buddyInput, setBuddyInput] = useState<string>("");
  const [buddyActionLoading, setBuddyActionLoading] = useState<boolean>(false);
  const [feedback, setFeedback] = useState<{ text: string; type: "success" | "error" | null }>({ text: "", type: null });
  const [recommendedUsers, setRecommendedUsers] = useState<any[]>([]);

  const chatEndRef = useRef<HTMLDivElement>(null);

  // Fetch chat messages
  const fetchChat = async () => {
    try {
      const res = await fetch("/api/chat");
      if (res.ok) {
        const data = await res.json();
        setChatMessages(data);
      }
    } catch (err) {
      console.error("Error fetching chat messages:", err);
    }
  };

  // Fetch tracking buddies
  const fetchBuddies = async () => {
    if (!currentUser) return;
    setBuddiesLoading(true);
    try {
      const res = await fetch(`/api/user/${currentUser.id}/following`);
      if (res.ok) {
        const data = await res.json();
        setBuddies(data);
      }
    } catch (err) {
      console.error("Error fetching buddies:", err);
    } finally {
      setBuddiesLoading(false);
    }
  };

  // Fetch recommended users from leaderboard
  const fetchRecommendations = async () => {
    try {
      const res = await fetch("/api/leaderboard");
      if (res.ok) {
        const data = await res.json();
        // Filter out self and already followed users
        const followedIds = currentUser?.following || [];
        const filtered = data.filter((u: any) => {
          if (currentUser && u.id === currentUser.id) return false;
          return !followedIds.includes(u.id);
        });
        setRecommendedUsers(filtered.slice(0, 5));
      }
    } catch (err) {
      console.error(err);
    }
  };

  // Auto-refresh chat
  useEffect(() => {
    fetchChat();
    const interval = setInterval(fetchChat, 6000);
    return () => clearInterval(interval);
  }, []);

  // Fetch buddies & recommendations when tab changes or currentUser updates
  useEffect(() => {
    if (activeSubTab === "buddies" && currentUser) {
      fetchBuddies();
      fetchRecommendations();
    }
  }, [activeSubTab, currentUser]);

  // Scroll to bottom of chat
  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [chatMessages]);

  const handleSendChatMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!chatInput.trim()) return;

    if (!currentUser) {
      onOpenAuth();
      return;
    }

    setChatLoading(true);
    try {
      const res = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          userId: currentUser.id,
          username: currentUser.username,
          avatarUrl: currentUser.avatarUrl,
          text: chatInput,
          level: currentUser.level,
          title: currentUser.title
        })
      });

      if (res.ok) {
        const newMsg = await res.json();
        setChatMessages(prev => [...prev, newMsg]);
        setChatInput("");
      }
    } catch (err) {
      console.error(err);
    } finally {
      setChatLoading(false);
    }
  };

  const handleFollowUser = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!buddyInput.trim()) return;

    if (!currentUser) {
      onOpenAuth();
      return;
    }

    setBuddyActionLoading(true);
    setFeedback({ text: "", type: null });

    try {
      const res = await fetch(`/api/user/${currentUser.id}/follow`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ targetUsername: buddyInput.trim() })
      });

      if (res.ok) {
        const updatedUser = await res.json();
        onUpdateUser(updatedUser);
        setBuddyInput("");
        setFeedback({ text: `Successfully tracked ${buddyInput}!`, type: "success" });
        fetchBuddies();
        fetchRecommendations();
      } else {
        const errData = await res.json();
        setFeedback({ text: errData.error || "Could not find warrior.", type: "error" });
      }
    } catch (err) {
      setFeedback({ text: "Failed to add tracking buddy.", type: "error" });
    } finally {
      setBuddyActionLoading(false);
    }
  };

  const handleUnfollowUser = async (targetUserId: string, username: string) => {
    if (!currentUser) return;

    try {
      const res = await fetch(`/api/user/${currentUser.id}/unfollow`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ targetUserId })
      });

      if (res.ok) {
        const updatedUser = await res.json();
        onUpdateUser(updatedUser);
        setFeedback({ text: `Stopped tracking ${username}.`, type: "success" });
        fetchBuddies();
        fetchRecommendations();
      }
    } catch (err) {
      console.error(err);
    }
  };

  const handleFollowRecommended = async (targetUserId: string, username: string) => {
    if (!currentUser) {
      onOpenAuth();
      return;
    }

    try {
      const res = await fetch(`/api/user/${currentUser.id}/follow`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ targetUserId })
      });

      if (res.ok) {
        const updatedUser = await res.json();
        onUpdateUser(updatedUser);
        setFeedback({ text: `Now tracking ${username}!`, type: "success" });
        fetchBuddies();
        fetchRecommendations();
      }
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <div id="community-sanctuary" className="max-w-5xl mx-auto space-y-6 animate-fade-in text-neutral-200">
      
      {/* Sub-Tabs Switcher */}
      <div className="flex border-b border-[#1A1A1B] gap-4">
        <button
          onClick={() => setActiveSubTab("chat")}
          className={`pb-3 text-sm font-bold flex items-center space-x-2 border-b-2 transition-all ${
            activeSubTab === "chat" 
              ? "border-amber-500 text-neutral-100" 
              : "border-transparent text-neutral-500 hover:text-neutral-300"
          }`}
        >
          <MessageSquare className="h-4.5 w-4.5" />
          <span>Global Arena Chat</span>
        </button>
        <button
          onClick={() => setActiveSubTab("buddies")}
          className={`pb-3 text-sm font-bold flex items-center space-x-2 border-b-2 transition-all ${
            activeSubTab === "buddies" 
              ? "border-amber-500 text-neutral-100" 
              : "border-transparent text-neutral-500 hover:text-neutral-300"
          }`}
        >
          <Users className="h-4.5 w-4.5" />
          <span>My Sovereign Circle</span>
        </button>
      </div>

      {/* SUB-VIEW: GLOBAL CHAT */}
      {activeSubTab === "chat" && (
        <div className="grid gap-6 lg:grid-cols-4">
          
          {/* Chat Guidance */}
          <div className="lg:col-span-1 space-y-4">
            <div className="rounded-2xl border border-[#1A1A1B] bg-[#0F0F10] p-4.5 space-y-3">
              <h4 className="font-display font-bold text-xs uppercase tracking-wider text-amber-500 flex items-center space-x-1.5">
                <Sparkles className="h-4 w-4" />
                <span>Arena Rules</span>
              </h4>
              <p className="text-[11px] text-neutral-400 leading-relaxed">
                Welcome to the global focus arena. Speak with clinical truth, support fellow warriors, share daily victories, and maintain ultimate digital respect.
              </p>
              <div className="border-t border-[#1A1A1B] pt-2 text-[10px] text-neutral-500">
                Messages auto-refresh. Maintain your guard!
              </div>
            </div>

            {!currentUser && (
              <div className="rounded-2xl border border-amber-500/10 bg-amber-500/5 p-4 text-center space-y-3">
                <p className="text-xs text-amber-500 font-semibold">Join the conversation</p>
                <p className="text-[10px] text-neutral-400">Authenticate to broadcast chat messages to all standing warriors.</p>
                <button
                  onClick={onOpenAuth}
                  className="w-full rounded-xl bg-amber-500 py-2 text-xs font-bold text-[#0A0A0B] hover:bg-amber-400 transition-all"
                >
                  Enter Sanctuary
                </button>
              </div>
            )}
          </div>

          {/* Chat Window */}
          <div className="lg:col-span-3 rounded-2xl border border-[#1A1A1B] bg-[#0F0F10] flex flex-col h-[520px] overflow-hidden shadow-sm">
            
            {/* Header */}
            <div className="border-b border-[#1A1A1B] bg-[#161618]/30 px-4 py-3.5 flex items-center justify-between">
              <span className="text-xs font-bold text-[#E5E5E5] flex items-center space-x-2">
                <span className="h-2 w-2 rounded-full bg-amber-500 animate-pulse"></span>
                <span>Live Sanctuary Chronicle</span>
              </span>
              <button 
                onClick={fetchChat}
                className="rounded-lg p-1 hover:bg-[#161618] transition-all"
                title="Refresh Chat"
              >
                <RefreshCw className="h-3.5 w-3.5 text-neutral-500 hover:text-neutral-300" />
              </button>
            </div>

            {/* Messages Viewport */}
            <div className="flex-1 overflow-y-auto p-4 space-y-4">
              {chatMessages.length === 0 ? (
                <div className="text-center py-20 text-neutral-500 space-y-2">
                  <MessageSquare className="h-8 w-8 mx-auto text-neutral-700 animate-pulse" />
                  <p className="text-xs">Silence in the arena. Say something to inspire the legion.</p>
                </div>
              ) : (
                chatMessages.map((msg) => {
                  const isSelf = currentUser && msg.userId === currentUser.id;
                  return (
                    <div 
                      key={msg.id}
                      className={`flex items-start space-x-3 max-w-[85%] ${
                        isSelf ? "ml-auto flex-row-reverse space-x-reverse" : "mr-auto"
                      }`}
                    >
                      <img
                        src={msg.avatarUrl}
                        alt={msg.username}
                        className="h-8.5 w-8.5 rounded-xl border border-[#1A1A1B] bg-[#0A0A0B] object-cover shrink-0"
                      />
                      <div>
                        {/* Name & Title */}
                        <div className={`flex items-center space-x-1.5 mb-1 ${isSelf ? "justify-end" : ""}`}>
                          <span className={`text-[11px] font-bold ${isSelf ? "text-amber-400 font-extrabold" : "text-neutral-300"}`}>
                            {msg.username}
                          </span>
                          <span className="text-[9px] text-neutral-500 font-bold bg-neutral-900 px-1.5 py-0.25 rounded">
                            Lvl {msg.level}
                          </span>
                          <span className="hidden sm:inline-block text-[9px] text-neutral-500 font-medium italic">
                            {msg.title}
                          </span>
                        </div>

                        {/* Msg Body */}
                        <div className={`rounded-2xl p-3 text-xs leading-relaxed ${
                          isSelf 
                            ? "bg-amber-500 text-[#0A0A0B] font-medium rounded-tr-none" 
                            : "bg-[#161618] text-neutral-200 border border-[#262626] rounded-tl-none"
                        }`}>
                          {msg.text}
                        </div>
                      </div>
                    </div>
                  );
                })
              )}
              <div ref={chatEndRef} />
            </div>

            {/* Input Form */}
            <form onSubmit={handleSendChatMessage} className="border-t border-[#1A1A1B] bg-[#161618]/20 p-4 flex items-center space-x-2">
              <input
                type="text"
                disabled={!currentUser || chatLoading}
                placeholder={currentUser ? "Write a word of encouragement or report your progress..." : "Authenticate to send chat messages..."}
                value={chatInput}
                onChange={(e) => setChatInput(e.target.value)}
                maxLength={250}
                className="flex-1 rounded-xl border border-[#1A1A1B] bg-[#0A0A0B] text-neutral-200 px-4 py-3 text-xs outline-none focus:border-amber-500 transition-all disabled:opacity-50"
              />
              <button
                type="submit"
                disabled={!currentUser || chatLoading || !chatInput.trim()}
                className="rounded-xl bg-amber-500 text-[#0A0A0B] font-bold p-3 hover:bg-amber-400 transition-all disabled:bg-neutral-800 disabled:text-neutral-500"
              >
                <Send className="h-4.5 w-4.5" />
              </button>
            </form>

          </div>

        </div>
      )}

      {/* SUB-VIEW: BUDDIES TRACKING */}
      {activeSubTab === "buddies" && (
        <div className="grid gap-6 lg:grid-cols-3">
          
          {/* Tracker Form & Suggestions */}
          <div className="lg:col-span-1 space-y-6">
            
            {/* Form */}
            <div className="rounded-2xl border border-[#1A1A1B] bg-[#0F0F10] p-6 space-y-4">
              <div className="flex items-center space-x-2">
                <Users className="h-5 w-5 text-amber-500" />
                <h3 className="font-display font-bold text-neutral-100">Add Buddy to Track</h3>
              </div>
              <p className="text-xs text-neutral-400 leading-relaxed">
                Enter the username of a fellow warrior. Track their streak and status updates side-by-side to strengthen mutual accountability.
              </p>

              <form onSubmit={handleFollowUser} className="space-y-3">
                <div className="relative">
                  <input
                    type="text"
                    disabled={!currentUser || buddyActionLoading}
                    placeholder="Enter username (e.g. Socrates_Mind)"
                    value={buddyInput}
                    onChange={(e) => setBuddyInput(e.target.value)}
                    className="w-full rounded-xl border border-[#1A1A1B] bg-[#0A0A0B] text-neutral-250 px-4 py-3 text-xs outline-none focus:border-amber-500 transition-all disabled:opacity-50"
                  />
                </div>

                {feedback.text && (
                  <div className={`flex items-start space-x-1.5 text-[11px] p-2.5 rounded-lg border ${
                    feedback.type === "success" 
                      ? "bg-emerald-500/5 border-emerald-500/20 text-emerald-400" 
                      : "bg-rose-500/5 border-rose-500/20 text-rose-400"
                  }`}>
                    {feedback.type === "success" ? <CheckCircle className="h-3.5 w-3.5 shrink-0 mt-0.5" /> : <AlertCircle className="h-3.5 w-3.5 shrink-0 mt-0.5" />}
                    <span>{feedback.text}</span>
                  </div>
                )}

                <button
                  type="submit"
                  disabled={!currentUser || buddyActionLoading || !buddyInput.trim()}
                  className="w-full rounded-xl bg-amber-500 py-2.5 text-xs font-bold text-[#0A0A0B] hover:bg-amber-400 transition-all flex items-center justify-center space-x-1.5 disabled:bg-neutral-800 disabled:text-neutral-500"
                >
                  {buddyActionLoading ? <RefreshCw className="h-3.5 w-3.5 animate-spin" /> : <UserPlus className="h-3.5 w-3.5" />}
                  <span>Track Warrior</span>
                </button>
              </form>
            </div>

            {/* Recommended Users */}
            <div className="rounded-2xl border border-[#1A1A1B] bg-[#0F0F10] p-4.5 space-y-3">
              <h4 className="font-display font-bold text-xs uppercase tracking-wider text-neutral-400 flex items-center space-x-1.5">
                <Compass className="h-4 w-4 text-amber-500" />
                <span>Active Companions</span>
              </h4>
              <p className="text-[10px] text-neutral-500">
                Warriors standing tall on the leaderboards. Build your focus alliance.
              </p>

              <div className="divide-y divide-[#1A1A1B]">
                {recommendedUsers.length === 0 ? (
                  <p className="text-[11px] text-neutral-500 py-3 text-center">No other active warriors available.</p>
                ) : (
                  recommendedUsers.map((user) => (
                    <div key={user.id} className="flex items-center justify-between py-2.5 first:pt-0 last:pb-0">
                      <div className="flex items-center space-x-2 min-w-0">
                        <img
                          src={user.avatarUrl}
                          alt={user.username}
                          className="h-8 w-8 rounded-lg border border-[#1A1A1B] bg-[#0A0A0B] object-cover"
                        />
                        <div className="min-w-0">
                          <p className="text-xs font-bold text-neutral-350 truncate">{user.username}</p>
                          <div className="flex items-center space-x-1 text-[9px] text-neutral-550 font-bold mt-0.5">
                            <Flame className="h-3 w-3 text-amber-500 fill-amber-500/10" />
                            <span>{user.currentStreak} Days</span>
                          </div>
                        </div>
                      </div>
                      <button
                        onClick={() => handleFollowRecommended(user.id, user.username)}
                        className="rounded-lg border border-[#1A1A1B] bg-[#0A0A0B] p-1.5 hover:border-amber-500 transition-all group"
                        title={`Track ${user.username}`}
                      >
                        <UserPlus className="h-3.5 w-3.5 text-neutral-500 group-hover:text-amber-500" />
                      </button>
                    </div>
                  ))
                )}
              </div>
            </div>

          </div>

          {/* List of Tracked Buddies */}
          <div className="lg:col-span-2 space-y-4">
            
            <div className="rounded-2xl border border-neutral-850 bg-[#0F0F10] p-6 shadow-sm flex items-start space-x-4">
              <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-amber-500/10 text-amber-500 border border-amber-500/20 shrink-0">
                <Users className="h-5.5 w-5.5" />
              </div>
              <div>
                <h2 className="font-display text-lg font-bold text-neutral-100">Sovereign Alliance Panel</h2>
                <p className="mt-1 text-xs text-neutral-400 leading-relaxed">
                  These are your designated tracking buddies. Monitor their streak progression, levels, titles, and public broadcasts.
                </p>
              </div>
            </div>

            {/* Buddies Grid */}
            {buddiesLoading ? (
              <div className="text-center py-20 rounded-2xl border border-[#1A1A1B] bg-[#0F0F10] text-neutral-500">
                <RefreshCw className="h-6 w-6 mx-auto animate-spin text-amber-500 mb-2" />
                <p className="text-xs">Connecting with your alliance...</p>
              </div>
            ) : buddies.length === 0 ? (
              <div className="rounded-2xl border border-[#1A1A1B] bg-[#0F0F10] p-12 text-center text-neutral-500 space-y-3">
                <Users className="h-8 w-8 mx-auto text-neutral-700" />
                <p className="text-sm font-bold text-neutral-450">Circle is empty</p>
                <p className="text-xs text-neutral-600 max-w-sm mx-auto">
                  You are not tracking any companion warriors. Add users in the tracking panel to build solid mutual accountability.
                </p>
              </div>
            ) : (
              <div className="grid gap-4 md:grid-cols-2">
                {buddies.map((buddy) => (
                  <div 
                    key={buddy.id}
                    className="rounded-2xl border border-[#1A1A1B] bg-[#0F0F10] p-4.5 flex flex-col justify-between space-y-4 transition-all hover:border-[#262626]"
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex items-center space-x-3 min-w-0">
                        <img
                          src={buddy.avatarUrl}
                          alt={buddy.username}
                          className="h-11 w-11 rounded-xl object-cover border border-[#1A1A1B] bg-[#0A0A0B]"
                        />
                        <div className="min-w-0">
                          <div className="flex items-center space-x-1">
                            <span className="font-bold text-xs text-neutral-200 truncate">{buddy.username}</span>
                            <span className="text-[9px] font-bold text-neutral-500 bg-neutral-900 px-1.5 rounded">
                              Lvl {buddy.level}
                            </span>
                          </div>
                          <span className="text-[10px] text-neutral-500 font-semibold">{buddy.title}</span>
                        </div>
                      </div>

                      <button
                        onClick={() => handleUnfollowUser(buddy.id, buddy.username)}
                        className="rounded-lg p-1.5 hover:bg-[#161618] transition-all text-neutral-500 hover:text-rose-400 group"
                        title={`Stop tracking ${buddy.username}`}
                      >
                        <UserMinus className="h-3.5 w-3.5" />
                      </button>
                    </div>

                    {/* Sigil / status message */}
                    {buddy.statusMessage && (
                      <p className="text-[11px] text-neutral-400 italic bg-[#0A0A0B] border border-[#161618] p-2.5 rounded-xl">
                        "{buddy.statusMessage}"
                      </p>
                    )}

                    {/* Streak indicator */}
                    <div className="flex items-center justify-between border-t border-[#1A1A1B] pt-3 mt-1 text-[11px]">
                      <span className="text-neutral-500 font-medium">Active Pure Streak</span>
                      <div className="flex items-center space-x-1 text-amber-500">
                        <Flame className="h-4 w-4 fill-amber-500 text-amber-500" />
                        <span className="font-display font-black">{buddy.currentStreak} Days</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}

          </div>

        </div>
      )}

    </div>
  );
}
