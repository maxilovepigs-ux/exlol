/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef, useEffect } from "react";
import { 
  Calendar, 
  BarChart3, 
  PlusCircle, 
  Compass, 
  Activity, 
  Smile, 
  HelpCircle,
  AlertCircle,
  TrendingUp,
  Sparkles,
  Snowflake,
  Mic,
  PenTool,
  Image,
  Search,
  Check,
  Heart,
  BookOpen,
  Trash2,
  Sliders,
  ChevronRight,
  Sparkle
} from "lucide-react";
import { User, JournalEntry, TriggerLog } from "../types";

interface JournalLogsProps {
  currentUser: User;
  onUpdateUser: (user: User) => void;
}

export default function JournalLogs({ currentUser, onUpdateUser }: JournalLogsProps) {
  const [activeSubTab, setActiveSubTab] = useState<"diary" | "history" | "analysis" | "log-trigger">("diary");
  
  // ================= STATE: TRIGGER FORM =================
  const [triggerType, setTriggerType] = useState<"Boredom" | "Stress" | "Social Media" | "Late Night" | "Fatigue" | "Loneliness">("Boredom");
  const [intensity, setIntensity] = useState(5);
  const [mitigation, setMitigation] = useState("");
  const [logging, setLogging] = useState(false);
  const [logSuccess, setLogSuccess] = useState(false);

  // ================= STATE: SOVEREIGN DIARY & GRATITUDE =================
  const [diaryNote, setDiaryNote] = useState("");
  const [diaryMood, setDiaryMood] = useState<"peaceful" | "focused" | "restless" | "tempted" | "victorious">("focused");
  const [gratitude1, setGratitude1] = useState("");
  const [gratitude2, setGratitude2] = useState("");
  const [gratitude3, setGratitude3] = useState("");
  const [selectedWeather, setSelectedWeather] = useState<"alabaster" | "forest" | "ocean" | "cosmic" | "charcoal">("ocean");
  const [searchQuery, setSearchQuery] = useState("");

  // Editor rich style states (visual simulated toggles)
  const [boldActive, setBoldActive] = useState(false);
  const [italicActive, setItalicActive] = useState(false);
  const [quoteActive, setQuoteActive] = useState(false);

  // Voice recording simulation state
  const [isRecording, setIsRecording] = useState(false);
  const [voiceWave, setVoiceWave] = useState<number[]>([12, 18, 8, 14, 22, 28, 10, 16, 20, 14, 8, 12]);
  const recordingTimerRef = useRef<any>(null);

  // Toggle dynamic voice transcription
  const toggleVoiceRecording = () => {
    if (isRecording) {
      if (recordingTimerRef.current) clearInterval(recordingTimerRef.current);
      setIsRecording(false);
      
      const moodReflections: Record<string, string> = {
        peaceful: "Voice entry: Attained a tranquil state of mind today. Diverted scrolling cravings toward deep nature walks. Feeling peaceful, clean, and re-regulated.",
        focused: "Voice entry: Maintained exceptional cognitive focus. Smashed my sovereign objective while reinforcing the prefrontal cortex filter. Receptors are upregulating.",
        restless: "Voice entry: Background restlessness spiked, but I utilized compound air squats to transmute raw somatic energy successfully. Relapsed avoided.",
        tempted: "Voice entry: Encountered a high digital trigger trigger, but immediately executed mammalian cold splashes and 4-4-4-4 box breathing to restore command.",
        victorious: "Voice entry: Triumph locked in! Conquered a heavy late-night craving surge, claimed the daily streak chest, and protected my purity with honor."
      };
      
      setDiaryNote(prev => {
        const spacer = prev ? "\n\n" : "";
        return prev + spacer + moodReflections[diaryMood];
      });
    } else {
      setIsRecording(true);
      recordingTimerRef.current = setInterval(() => {
        setVoiceWave(Array.from({ length: 12 }, () => Math.floor(Math.random() * 24) + 6));
      }, 150);
    }
  };

  useEffect(() => {
    return () => {
      if (recordingTimerRef.current) clearInterval(recordingTimerRef.current);
    };
  }, []);

  // Submit trigger log
  const handleSubmitTrigger = async (e: React.FormEvent) => {
    e.preventDefault();
    setLogging(true);
    try {
      const res = await fetch(`/api/user/${currentUser.id}/trigger`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          type: triggerType,
          intensity,
          mitigationStrategy: mitigation || "Used mindfulness exercises to neutralize the impulse."
        })
      });
      if (res.ok) {
        const data = await res.json();
        onUpdateUser(data.user);
        setLogSuccess(true);
        setMitigation("");
        setIntensity(5);
        setTimeout(() => {
          setLogSuccess(false);
          setActiveSubTab("history");
        }, 1500);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLogging(false);
    }
  };

  // Submit complete freeform diary (Rich checks & gratitude points)
  const handleSubmitDiary = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!diaryNote.trim() && !gratitude1.trim()) return;

    setLogging(true);
    let compositeNote = diaryNote;
    
    // Formatting simulated wrappers if active
    if (boldActive && compositeNote) compositeNote = `**${compositeNote}**`;
    if (italicActive && compositeNote) compositeNote = `*${compositeNote}*`;
    if (quoteActive && compositeNote) compositeNote = `> ${compositeNote}`;

    const gratList = [gratitude1, gratitude2, gratitude3].filter(g => g.trim());
    if (gratList.length > 0) {
      compositeNote += "\n\n✨ Daily Gratitude Targets:\n" + gratList.map(g => `• ${g}`).join("\n");
    }

    compositeNote += `\n\n[Climate Visualizer: ${selectedWeather.toUpperCase()}]`;

    try {
      const res = await fetch(`/api/user/${currentUser.id}/checkin`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          note: compositeNote,
          mood: diaryMood,
          cleanDay: diaryMood !== "tempted" && diaryMood !== "restless"
        })
      });
      if (res.ok) {
        const data = await res.json();
        onUpdateUser(data.user);
        setDiaryNote("");
        setGratitude1("");
        setGratitude2("");
        setGratitude3("");
        setLogSuccess(true);
        setTimeout(() => {
          setLogSuccess(false);
          setActiveSubTab("history");
        }, 1500);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLogging(false);
    }
  };

  // Compile Trigger Statistics
  const getTriggerStats = () => {
    const counts: Record<string, { total: number; sumIntensity: number }> = {
      "Boredom": { total: 0, sumIntensity: 0 },
      "Stress": { total: 0, sumIntensity: 0 },
      "Social Media": { total: 0, sumIntensity: 0 },
      "Late Night": { total: 0, sumIntensity: 0 },
      "Fatigue": { total: 0, sumIntensity: 0 },
      "Loneliness": { total: 0, sumIntensity: 0 }
    };

    currentUser.triggers?.forEach((t) => {
      if (counts[t.type]) {
        counts[t.type].total += 1;
        counts[t.type].sumIntensity += t.intensity;
      }
    });

    return Object.keys(counts).map((key) => ({
      name: key,
      count: counts[key].total,
      avgIntensity: counts[key].total > 0 ? (counts[key].sumIntensity / counts[key].total).toFixed(1) : 0
    }));
  };

  const stats = getTriggerStats();
  const maxCount = Math.max(...stats.map(s => s.count), 1);

  // Filter history based on search query
  const combinedEntries = [
    ...(currentUser.logs || []).map(l => ({ ...l, timelineType: "checkin" as const })),
    ...(currentUser.triggers || []).map(t => ({ ...t, timelineType: "trigger" as const }))
  ].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

  const filteredTimeline = combinedEntries.filter(item => {
    if (!searchQuery.trim()) return true;
    const q = searchQuery.toLowerCase();
    if (item.timelineType === "checkin") {
      return (item as any).note.toLowerCase().includes(q) || (item as any).mood.toLowerCase().includes(q);
    } else {
      return (item as any).type.toLowerCase().includes(q) || (item as any).mitigationStrategy.toLowerCase().includes(q);
    }
  });

  // Calculate quick summary metrics
  const peacefulCount = currentUser.logs?.filter(l => l.mood === "peaceful" || l.mood === "victorious").length || 0;
  const totalEntriesCount = currentUser.logs?.length || 0;
  const prefrontalIndex = totalEntriesCount > 0 ? Math.round((peacefulCount / totalEntriesCount) * 100) : 100;

  return (
    <div id="journal-logs-container" className="rounded-2xl border border-neutral-850 bg-[#0F0F10] p-6 shadow-sm fade-in text-neutral-200 space-y-6">
      
      {/* Tab Selectors & Header */}
      <div className="flex border-b border-[#1A1A1B] pb-3 items-center justify-between flex-wrap gap-4">
        <div className="flex items-center space-x-2">
          <BookOpen className="h-5 w-5 text-amber-500 animate-pulse" />
          <h3 className="font-display font-bold text-neutral-100">CBT Logbook & Reflection</h3>
        </div>
        
        <div className="flex flex-wrap gap-1 bg-[#161618] p-1 rounded-xl border border-[#262626]">
          {[
            { id: "diary", label: "Sovereign Journal", icon: PenTool },
            { id: "history", label: "History Timeline", icon: Calendar },
            { id: "analysis", label: "Trigger Analysis", icon: BarChart3 },
            { id: "log-trigger", label: "Log Trigger", icon: PlusCircle }
          ].map((tab) => {
            const Icon = tab.icon;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveSubTab(tab.id as any)}
                className={`rounded-lg px-3 py-1.5 text-xs font-bold flex items-center space-x-1.5 transition-all cursor-pointer ${
                  activeSubTab === tab.id
                    ? "bg-[#0F0F10] text-amber-500 shadow-sm border border-[#262626]"
                    : "text-neutral-400 hover:text-[#E5E5E5]"
                }`}
              >
                <Icon className="h-3.5 w-3.5" />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* ================= SUB-TAB: SOVEREIGN JOURNAL & GRATITUDE ================= */}
      {activeSubTab === "diary" && (
        <form onSubmit={handleSubmitDiary} className="grid gap-6 md:grid-cols-3">
          
          {/* Main text editor block */}
          <div className="md:col-span-2 space-y-4">
            
            {/* Editor Top Options: Mood Selector */}
            <div className="space-y-1.5">
              <label className="block text-xs font-bold text-neutral-500 uppercase tracking-widest">
                1. Emotional Climate (CBT Weather):
              </label>
              <div className="flex flex-wrap gap-1.5">
                {[
                  { id: "peaceful", label: "Peaceful", color: "text-emerald-400 border-emerald-500/20 bg-emerald-500/5" },
                  { id: "focused", label: "Focused", color: "text-amber-500 border-amber-500/20 bg-amber-500/5" },
                  { id: "restless", label: "Restless", color: "text-indigo-400 border-indigo-500/20 bg-indigo-500/5" },
                  { id: "tempted", label: "Tempted", color: "text-red-400 border-red-500/20 bg-red-500/5" },
                  { id: "victorious", label: "Victorious", color: "text-purple-400 border-purple-500/20 bg-purple-500/5" }
                ].map((moodItem) => (
                  <button
                    key={moodItem.id}
                    type="button"
                    onClick={() => setDiaryMood(moodItem.id as any)}
                    className={`px-3 py-1.5 rounded-lg border text-xs font-bold transition-all cursor-pointer ${
                      diaryMood === moodItem.id 
                        ? `${moodItem.color} border-current ring-1 ring-current/40`
                        : "border-[#1B1B1C] bg-[#0A0A0B] text-neutral-400 hover:text-neutral-200"
                    }`}
                  >
                    {moodItem.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Visual style wrapper selector (Emotional Wallpaper Indic) */}
            <div className="space-y-1.5">
              <label className="block text-xs font-bold text-neutral-500 uppercase tracking-widest">
                2. Visual Climate (Photo Journal Style):
              </label>
              <div className="grid grid-cols-5 gap-1.5">
                {[
                  { id: "alabaster", label: "Dawn", style: "from-amber-200 to-indigo-100 text-neutral-900" },
                  { id: "forest", label: "Forest", style: "from-emerald-900 to-teal-950 text-emerald-200" },
                  { id: "ocean", label: "Ocean", style: "from-blue-900 to-indigo-950 text-blue-200" },
                  { id: "cosmic", label: "Cosmic", style: "from-purple-900 to-neutral-950 text-purple-200" },
                  { id: "charcoal", label: "Slate", style: "from-[#111112] to-[#1e1e21] text-neutral-300" }
                ].map((weather) => (
                  <button
                    key={weather.id}
                    type="button"
                    onClick={() => setSelectedWeather(weather.id as any)}
                    className={`rounded-lg p-2 text-[10px] font-black border text-center bg-gradient-to-br transition-all cursor-pointer ${
                      selectedWeather === weather.id
                        ? "border-amber-500 ring-2 ring-amber-500/30 font-extrabold"
                        : "border-[#1B1B1C]"
                    } ${weather.style}`}
                  >
                    {weather.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Rich Editor Simulated Formatting Toolbar */}
            <div className="rounded-xl border border-[#1B1B1C] bg-[#0A0A0B] overflow-hidden">
              <div className="flex items-center space-x-1.5 bg-[#161618] px-3 py-2 border-b border-[#1B1B1C]">
                <button
                  type="button"
                  onClick={() => setBoldActive(!boldActive)}
                  className={`p-1 rounded text-xs font-black transition-all cursor-pointer ${boldActive ? "bg-amber-500/20 text-amber-500 font-extrabold" : "text-neutral-500 hover:text-neutral-300"}`}
                  title="Toggle Bold style"
                >
                  B
                </button>
                <button
                  type="button"
                  onClick={() => setItalicActive(!italicActive)}
                  className={`p-1 rounded text-xs italic transition-all cursor-pointer ${italicActive ? "bg-amber-500/20 text-amber-500 font-extrabold" : "text-neutral-500 hover:text-neutral-300"}`}
                  title="Toggle Italic style"
                >
                  I
                </button>
                <button
                  type="button"
                  onClick={() => setQuoteActive(!quoteActive)}
                  className={`p-1 rounded text-xs transition-all cursor-pointer ${quoteActive ? "bg-amber-500/20 text-amber-500 font-extrabold" : "text-neutral-500 hover:text-neutral-300"}`}
                  title="Simulate Quote block"
                >
                  ”
                </button>
                <div className="h-4 w-[1px] bg-neutral-800 mx-1"></div>
                <span className="text-[9px] text-neutral-600 font-mono font-bold uppercase">Sovereign Focus Slate</span>
              </div>

              <textarea
                required
                value={diaryNote}
                onChange={(e) => setDiaryNote(e.target.value)}
                placeholder="Type your deep recovery reflection, environmental trigger audit, or cognitive reorganization points here..."
                className={`w-full h-44 p-3.5 bg-transparent outline-none text-xs text-neutral-250 placeholder-neutral-600 resize-none leading-relaxed ${
                  boldActive ? "font-bold" : ""
                } ${italicActive ? "italic" : ""} ${quoteActive ? "border-l-2 border-amber-500 pl-4 bg-amber-500/5" : ""}`}
              />
            </div>

            {/* Simulated Voice Journal Trigger */}
            <div className="rounded-xl border border-[#1B1B1C] p-3 bg-[#0A0A0B]/60 flex items-center justify-between flex-wrap gap-3">
              <div className="flex items-center space-x-2.5">
                <button
                  type="button"
                  onClick={toggleVoiceRecording}
                  className={`h-9 w-9 rounded-lg flex items-center justify-center transition-all cursor-pointer ${
                    isRecording 
                      ? "bg-red-500 text-white animate-pulse" 
                      : "bg-amber-500/10 border border-amber-500/20 text-amber-500 hover:bg-amber-500/20"
                  }`}
                  title={isRecording ? "Stop voice journal reflection" : "Activate voice entry simulation"}
                >
                  <Mic className="h-4.5 w-4.5" />
                </button>
                <div>
                  <span className="text-[11px] font-bold text-neutral-300 block">
                    {isRecording ? "Transcribing sovereign frequency..." : "Voice Journal Transcription Engine"}
                  </span>
                  <span className="text-[9px] text-neutral-500">Record a verbal entry. AI transcribes and summarizes instantly based on active mood.</span>
                </div>
              </div>

              {/* Waveform graphic */}
              {isRecording && (
                <div className="flex items-end space-x-1 pr-2">
                  {voiceWave.map((h, i) => (
                    <div 
                      key={i} 
                      className="w-1 bg-red-400 rounded-full transition-all duration-150"
                      style={{ height: `${h}px` }}
                    ></div>
                  ))}
                </div>
              )}
            </div>

          </div>

          {/* Right Column: Gratitude Inputs & AI Summary */}
          <div className="space-y-4">
            
            {/* Gratitude checklist card */}
            <div className="rounded-xl border border-[#1B1B1C] bg-[#0A0A0B] p-4 space-y-3">
              <div className="flex items-center space-x-1.5 text-xs font-bold text-neutral-200">
                <Heart className="h-4 w-4 text-rose-500 shrink-0" />
                <span>3 Focus Gratitudes (CBT Shift)</span>
              </div>
              <p className="text-[10px] text-neutral-500">
                Identify 3 clean offline objects, people, or targets you appreciate today to reset your prefrontal cortex.
              </p>

              <div className="space-y-2">
                <input
                  type="text"
                  value={gratitude1}
                  onChange={(e) => setGratitude1(e.target.value)}
                  placeholder="1. e.g. Clear morning eye-sight"
                  className="w-full bg-[#161618] border border-[#262626] rounded px-2.5 py-1.5 text-xs outline-none focus:border-amber-500/40"
                />
                <input
                  type="text"
                  value={gratitude2}
                  onChange={(e) => setGratitude2(e.target.value)}
                  placeholder="2. e.g. High focus on coding"
                  className="w-full bg-[#161618] border border-[#262626] rounded px-2.5 py-1.5 text-xs outline-none focus:border-amber-500/40"
                />
                <input
                  type="text"
                  value={gratitude3}
                  onChange={(e) => setGratitude3(e.target.value)}
                  placeholder="3. e.g. Supportive community circles"
                  className="w-full bg-[#161618] border border-[#262626] rounded px-2.5 py-1.5 text-xs outline-none focus:border-amber-500/40"
                />
              </div>
            </div>

            {/* AI Summary Panel */}
            <div className="rounded-xl border border-[#1B1B1C] bg-[#0A0A0B] p-4 space-y-2">
              <div className="flex items-center space-x-1.5 text-xs font-bold text-indigo-400">
                <Sparkle className="h-4 w-4 text-indigo-400 shrink-0" />
                <span>AI Cognitive Summary</span>
              </div>
              
              <div className="text-[11px] leading-relaxed text-neutral-400 space-y-2 font-medium">
                <div className="flex justify-between items-center text-[10px] border-b border-[#1A1A1B] pb-1.5 font-mono">
                  <span>PREFRONTAL COMMAND:</span>
                  <span className="text-indigo-400 font-bold">{prefrontalIndex}% Robust</span>
                </div>
                
                {diaryNote.length > 5 ? (
                  <p className="italic text-[10px] text-neutral-500">
                     "Your logged notes suggest high self-knowledge. Neuroplastic recovery pathways are healthy. DeltaFosB molecular clearances are expanding as streak progress continues."
                  </p>
                ) : (
                  <p className="text-[10px] text-neutral-600">
                    Write at least one complete sentence to generate real-time neural sentiment summary.
                  </p>
                )}
              </div>
            </div>

            {/* Submit Entry Button */}
            <button
              id="submit-diary-btn"
              type="submit"
              disabled={logging || logSuccess || (!diaryNote.trim() && !gratitude1.trim())}
              className="w-full bg-amber-500 hover:bg-amber-400 disabled:bg-neutral-800 disabled:text-neutral-500 text-[#0A0A0B] font-bold text-xs py-3.5 rounded-xl transition-all cursor-pointer shadow-lg shadow-amber-500/10"
            >
              {logSuccess ? "Reflection Securely Saved!" : logging ? "Securing Entry..." : "Submit Sovereign Reflection (+50 XP)"}
            </button>

          </div>

        </form>
      )}

      {/* ================= SUB-TAB: HISTORY TIMELINE ================= */}
      {activeSubTab === "history" && (
        <div className="space-y-6">
          
          {/* Search and Filters */}
          <div className="rounded-xl bg-[#0A0A0B] p-4 border border-[#1A1A1B] flex items-center justify-between flex-wrap gap-4">
            <div className="flex items-center space-x-2.5 text-xs font-bold text-neutral-300">
              <Search className="h-4.5 w-4.5 text-neutral-500" />
              <span>Search Archives:</span>
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search words, moods, triggers..."
                className="bg-[#161618] border border-[#262626] rounded-lg px-3 py-1.5 text-xs outline-none text-neutral-200 focus:border-amber-500"
              />
            </div>
            
            <div className="text-[11px] font-mono text-neutral-500 font-bold">
              TIMELINE MATCHES: <span className="text-amber-500">{filteredTimeline.length}</span>
            </div>
          </div>

          {filteredTimeline.length === 0 ? (
            <div className="text-center py-12 max-w-sm mx-auto">
              <Compass className="h-12 w-12 text-amber-500/35 mx-auto mb-3 animate-spin" style={{ animationDuration: "12s" }} />
              <h4 className="text-sm font-bold text-neutral-200">No matching logs found.</h4>
              <p className="text-xs text-neutral-400 mt-1">
                Refine your query or write a new sovereign diary entry above to build your timeline of resilience.
              </p>
            </div>
          ) : (
            <div className="relative border-l-2 border-[#1A1A1B] pl-5 ml-2.5 space-y-6">
              {filteredTimeline.map((item, idx) => {
                const dateLabel = new Date(item.date).toLocaleDateString(undefined, {
                  month: "short",
                  day: "numeric",
                  year: "numeric"
                });

                if (item.timelineType === "checkin") {
                  const l = item as any;
                  const isFreeze = l.isFreeze;
                  const isMilestoneFreeze = l.isMilestoneFreeze;

                  let borderClass = l.cleanDay ? "border-emerald-500 text-emerald-400" : "border-rose-400 text-rose-400";
                  let icon = <Smile className="h-3 w-3" />;
                  let badgeLabel = l.cleanDay ? "Victory Checked" : "Reflection Day";
                  let badgeClass = l.cleanDay
                    ? "bg-emerald-500/10 border border-emerald-500/25 text-emerald-400"
                    : "bg-rose-500/10 border border-rose-500/25 text-rose-400";
                  let cardClass = "border-[#1A1A1B] bg-[#161618]/30 hover:bg-[#161618]/50";

                  if (isFreeze) {
                    borderClass = "border-blue-500 text-blue-400";
                    icon = <Snowflake className="h-3 w-3 text-blue-400" />;
                    badgeLabel = "Streak Frozen";
                    badgeClass = "bg-blue-500/10 border border-blue-500/25 text-blue-400";
                    cardClass = "border-blue-500/20 bg-blue-500/5 hover:bg-blue-500/10";
                  } else if (isMilestoneFreeze) {
                    borderClass = "border-amber-500 text-amber-400";
                    icon = <Sparkles className="h-3 w-3 text-amber-400" />;
                    badgeLabel = "Milestone Freeze Earned";
                    badgeClass = "bg-amber-500/10 border border-amber-500/25 text-amber-400";
                    cardClass = "border-amber-500/20 bg-amber-500/5 hover:bg-amber-500/10";
                  }

                  return (
                    <div key={l.id} className="relative fade-in">
                      <span className={`absolute -left-[31px] top-1.5 flex h-5 w-5 items-center justify-center rounded-full border-2 bg-[#0F0F10] ${borderClass}`}>
                        {icon}
                      </span>

                      <div className={`rounded-xl border p-4 shadow-sm transition-colors ${cardClass}`}>
                        <div className="flex items-center justify-between mb-2">
                          <span className="text-[11px] font-bold text-neutral-500">
                            {dateLabel}
                          </span>
                          <span className={`inline-block rounded-full px-2 py-0.5 text-[9px] font-bold tracking-wider uppercase ${badgeClass}`}>
                            {badgeLabel}
                          </span>
                        </div>
                        <p className="text-xs text-neutral-200 leading-relaxed italic whitespace-pre-line">
                          "{l.note}"
                        </p>
                      </div>
                    </div>
                  );
                } else {
                  const t = item as TriggerLog;
                  return (
                    <div key={t.id} className="relative fade-in">
                      <span className="absolute -left-[31px] top-1.5 flex h-5 w-5 items-center justify-center rounded-full border-2 border-amber-500 bg-[#0F0F10] text-amber-500">
                        <AlertCircle className="h-3 w-3" />
                      </span>

                      <div className="rounded-xl border border-[#262626] bg-[#161618]/30 p-4 shadow-sm hover:bg-[#161618]/50 transition-colors">
                        <div className="flex items-center justify-between mb-2">
                          <span className="text-[11px] font-bold text-neutral-500">
                            {dateLabel}
                          </span>
                          <div className="flex items-center space-x-1.5">
                            <span className="rounded-full bg-amber-500/10 border border-amber-500/20 px-2 py-0.5 text-[9px] font-bold uppercase text-amber-400">
                              Trigger: {t.type}
                            </span>
                            <span className="text-[9px] font-bold text-amber-400 bg-amber-500/15 border border-amber-500/25 px-1.5 rounded">
                              Int: {t.intensity}/10
                            </span>
                          </div>
                        </div>
                        <p className="text-xs text-neutral-250 font-medium">
                          <span className="text-[10px] uppercase tracking-wider text-amber-500 font-bold block mb-0.5">Mitigated via:</span>
                          "{t.mitigationStrategy}"
                        </p>
                      </div>
                    </div>
                  );
                }
              })}
            </div>
          )}
        </div>
      )}

      {/* ================= SUB-TAB: ANALYSIS ================= */}
      {activeSubTab === "analysis" && (
        <div className="space-y-6">
          <div className="rounded-xl bg-[#161618] p-4 border border-[#262626]">
            <h4 className="text-xs font-bold text-neutral-300 uppercase tracking-wider mb-1 flex items-center space-x-1.5">
              <TrendingUp className="h-4 w-4 text-amber-500" />
              <span>CBT Vulnerability Breakdown</span>
            </h4>
            <p className="text-[11px] text-neutral-450 leading-relaxed">
              Scientific recovery hinges on recognizing patterns. When you log triggers, our tracker structures your vulnerabilities below. Target these spaces for environment design changes.
            </p>
          </div>

          {/* Custom SVG Bar Chart */}
          <div className="rounded-xl border border-[#1A1A1B] p-4 bg-[#0A0A0B] shadow-inner">
            <div className="space-y-4">
              {stats.map((s) => {
                const percentage = (s.count / maxCount) * 100;
                return (
                  <div key={s.name} className="space-y-1">
                    <div className="flex items-center justify-between text-xs">
                      <span className="font-bold text-neutral-300">{s.name}</span>
                      <div className="flex items-center space-x-2 text-[11px] text-neutral-500 font-medium">
                        <span>{s.count} Incidents</span>
                        {s.count > 0 && (
                          <span className="text-amber-400 bg-amber-500/10 border border-amber-500/20 px-1.5 rounded text-[10px] font-bold">
                            Avg Intensity: {s.avgIntensity}/10
                          </span>
                        )}
                      </div>
                    </div>
                    {/* Bar */}
                    <div className="h-3 w-full bg-[#161618] border border-[#262626] rounded-full overflow-hidden flex">
                      <div 
                        className="h-full bg-amber-500 rounded-full transition-all duration-700"
                        style={{ width: `${Math.max(percentage, 2)}%` }}
                      ></div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Interactive Advice block */}
          <div className="rounded-xl bg-amber-500/5 p-4 border border-amber-500/10 text-xs text-amber-400 space-y-1.5">
            <h5 className="font-bold flex items-center space-x-1.5">
              <Sparkles className="h-4 w-4 text-amber-500 shrink-0" />
              <span>Sentry Guard Recommendations:</span>
            </h5>
            <ul className="list-disc list-inside space-y-1 text-[11px] text-neutral-350 leading-relaxed pl-1 font-medium">
              <li><strong>Late Night:</strong> Establish a strict 'digital sundown'—no phone screens inside the bedroom past 10 PM.</li>
              <li><strong>Boredom:</strong> Pre-program three positive offline habits: pushups, reading a philosophy book, or playing an instrument.</li>
              <li><strong>Social Media:</strong> De-clutter your feeds. Unfollow provocative accounts instantly. Use block utilities.</li>
            </ul>
          </div>
        </div>
      )}

      {/* ================= SUB-TAB: LOG TRIGGER FORM ================= */}
      {activeSubTab === "log-trigger" && (
        <form onSubmit={handleSubmitTrigger} className="space-y-5">
          
          {/* Select Category */}
          <div>
            <label className="block text-xs font-bold text-neutral-400 uppercase tracking-wider mb-1.5">
              1. What kind of trigger did you experience?
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
              {["Boredom", "Stress", "Social Media", "Late Night", "Fatigue", "Loneliness"].map((type) => (
                <button
                  key={type}
                  type="button"
                  onClick={() => setTriggerType(type as any)}
                  className={`rounded-lg py-2.5 text-xs font-semibold border text-center transition-all cursor-pointer ${
                    triggerType === type
                      ? "bg-amber-500/10 border-amber-500 text-amber-400 font-bold"
                      : "border-[#1A1A1B] text-neutral-400 bg-[#0A0A0B] hover:bg-[#161618]"
                  }`}
                >
                  {type}
                </button>
              ))}
            </div>
          </div>

          {/* Intensity Slider */}
          <div>
            <div className="flex items-center justify-between mb-1">
              <label className="block text-xs font-bold text-neutral-400 uppercase tracking-wider">
                2. Sensation Intensity: {intensity} / 10
              </label>
              <span className="text-[10px] font-bold text-neutral-500">
                {intensity <= 3 ? "Mild Twitch" : intensity <= 7 ? "Definite Urge" : "Severe Surge!"}
              </span>
            </div>
            <input
              type="range"
              min="1"
              max="10"
              value={intensity}
              onChange={(e) => setIntensity(Number(e.target.value))}
              className="w-full accent-amber-500 h-1.5 bg-[#161618] rounded-lg appearance-none cursor-pointer"
            />
          </div>

          {/* Mitigation input */}
          <div>
            <label className="block text-xs font-bold text-neutral-400 uppercase tracking-wider mb-1.5">
              3. Defensive Actions (How did you defuse it?)
            </label>
            <textarea
              required
              placeholder="e.g. Left the room immediately, opened the Urge SOS Box Breathing window, and put cold water on my face."
              value={mitigation}
              onChange={(e) => setMitigation(e.target.value)}
              className="w-full h-24 rounded-xl border border-[#1A1A1B] bg-[#0A0A0B] text-neutral-200 p-2.5 text-xs outline-none focus:border-amber-500"
            />
          </div>

          {/* Submit */}
          <button
            id="submit-trigger-btn"
            type="submit"
            disabled={logging || logSuccess}
            className="w-full rounded-xl bg-amber-500 hover:bg-amber-400 disabled:bg-neutral-800 disabled:text-neutral-500 text-[#0A0A0B] font-bold text-sm py-3 transition-all cursor-pointer"
          >
            {logSuccess ? "Trigger Securely Logged!" : logging ? "Logging defense..." : "Record Trigger Defused (+25 XP)"}
          </button>
        </form>
      )}

    </div>
  );
}
