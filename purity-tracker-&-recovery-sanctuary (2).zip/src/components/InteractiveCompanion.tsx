/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from "react";
import { 
  Droplet, 
  Flame, 
  Trophy, 
  Play, 
  Pause, 
  RotateCcw, 
  Volume2, 
  VolumeX, 
  Sparkles, 
  AlertCircle, 
  Calendar, 
  ShieldCheck, 
  Heart, 
  Award, 
  CheckCircle, 
  Info, 
  ChevronRight, 
  Compass, 
  Timer, 
  Check, 
  Lightbulb, 
  Trash2, 
  Plus, 
  Brain, 
  Target, 
  Eye, 
  Activity, 
  HelpCircle,
  Moon,
  Zap,
  Gift
} from "lucide-react";
import { User } from "../types";
import confetti from "canvas-confetti";

interface InteractiveCompanionProps {
  currentUser: User | null;
  onUpdateUser: (user: User) => void;
  onOpenAuth: () => void;
  theme: "dark" | "deep-night" | "light" | "midnight" | "soft-gray" | "glassmorphism";
}

export default function InteractiveCompanion({ 
  currentUser, 
  onUpdateUser, 
  onOpenAuth,
  theme
}: InteractiveCompanionProps) {
  const [activeTab, setActiveTab] = useState<"trackers" | "calculators" | "timeline" | "wellness" | "vision">("trackers");

  // ================= STATE: WATER REMINDER & CALCULATOR =================
  const [waterCups, setWaterCups] = useState<number>(() => {
    const saved = localStorage.getItem("sanctuary_water_cups");
    return saved ? Number(saved) : 0;
  });
  const [waterTarget, setWaterTarget] = useState<number>(8); // cups
  const [waterCalcWeight, setWaterCalcWeight] = useState<string>("160"); // lbs
  const [waterCalcHours, setWaterCalcHours] = useState<string>("1"); // exercise hours
  const [showWaterCalc, setShowWaterCalc] = useState<boolean>(false);

  useEffect(() => {
    localStorage.setItem("sanctuary_water_cups", String(waterCups));
  }, [waterCups]);

  const calculateWaterTarget = () => {
    const weight = Number(waterCalcWeight) || 150;
    const hours = Number(waterCalcHours) || 0;
    // Standard rule: weight (lbs) * 0.5 + (exercise hours * 12) = oz. Cups = oz / 8
    const oz = (weight * 0.5) + (hours * 12);
    const cups = Math.max(Math.round(oz / 8), 6);
    setWaterTarget(cups);
    setShowWaterCalc(false);
  };

  // ================= STATE: EXERCISE GOALS =================
  const [exerciseMins, setExerciseMins] = useState<number>(() => {
    const saved = localStorage.getItem("sanctuary_exercise_mins");
    return saved ? Number(saved) : 0;
  });
  const [pushupCount, setPushupCount] = useState<number>(() => {
    const saved = localStorage.getItem("sanctuary_pushup_count");
    return saved ? Number(saved) : 0;
  });
  const [exerciseTarget, setExerciseTarget] = useState<number>(30); // mins
  const [pushupTarget, setPushupTarget] = useState<number>(50); // reps

  useEffect(() => {
    localStorage.setItem("sanctuary_exercise_mins", String(exerciseMins));
  }, [exerciseMins]);

  useEffect(() => {
    localStorage.setItem("sanctuary_pushup_count", String(pushupCount));
  }, [pushupCount]);

  // ================= STATE: SLEEP TRACKER & ESTIMATOR =================
  const [sleepScore, setSleepScore] = useState<number>(() => {
    const saved = localStorage.getItem("sanctuary_sleep_score");
    return saved ? Number(saved) : 85;
  });
  const [bedtime, setBedtime] = useState<string>("22:30");
  const [wakeTime, setWakeTime] = useState<string>("06:30");
  const [recommendedWakeCycles, setRecommendedWakeCycles] = useState<string[]>([]);

  const calculateSleepCycles = () => {
    // Standard sleep cycles are 90 mins long.
    // If going to bed now (or at bedtime), optimal wake up times are sleep times of 5, 6, or 7 cycles.
    const [h, m] = bedtime.split(":").map(Number);
    const date = new Date();
    date.setHours(h, m, 0, 0);

    const cycleTimes = [4.5, 6, 7.5, 9].map(hours => {
      const cycleDate = new Date(date.getTime() + hours * 60 * 60 * 1000);
      return cycleDate.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
    });
    setRecommendedWakeCycles(cycleTimes);
  };

  useEffect(() => {
    calculateSleepCycles();
  }, [bedtime]);

  // ================= STATE: DAILY CHEST & REWARD =================
  const [chestClaimed, setChestClaimed] = useState<boolean>(() => {
    const todayStr = new Date().toISOString().split("T")[0];
    const saved = localStorage.getItem("sanctuary_chest_claimed_date");
    return saved === todayStr;
  });
  const [coinsCount, setCoinsCount] = useState<number>(() => {
    const saved = localStorage.getItem("sanctuary_coins");
    return saved ? Number(saved) : 120;
  });

  useEffect(() => {
    localStorage.setItem("sanctuary_coins", String(coinsCount));
  }, [coinsCount]);

  const handleClaimChest = async () => {
    if (chestClaimed) return;
    
    const randomXp = Math.floor(Math.random() * 26) + 15; // 15-40 XP
    const randomCoins = Math.floor(Math.random() * 16) + 10; // 10-25 Coins
    
    setCoinsCount(prev => prev + randomCoins);
    setChestClaimed(true);
    localStorage.setItem("sanctuary_chest_claimed_date", new Date().toISOString().split("T")[0]);

    confetti({
      particleCount: 80,
      spread: 60,
      origin: { y: 0.8 }
    });

    // If user logged in, sync XP
    if (currentUser) {
      try {
        const res = await fetch(`/api/user/${currentUser.id}/checkin`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            note: `Unlocked Sovereign Daily Chest: Gained +${randomXp} XP and +${randomCoins} Purity Coins!`,
            mood: "victorious",
            cleanDay: true
          })
        });
        if (res.ok) {
          const data = await res.json();
          onUpdateUser(data.user);
        }
      } catch (err) {
        console.error("Failed to sync chest XP:", err);
      }
    }

    alert(`🏆 Sovereign Daily Chest Unlocked!\n\nYou earned:\n✨ +${randomXp} Focus XP\n🪙 +${randomCoins} Purity Coins\n\nDaily challenge: "No triggers, no peeking. Maintain standard high focus today!"`);
  };

  // ================= STATE: INTERACTIVE CALCULATORS & QUIZZES =================
  // 1. Dopamine Baseline Calculator
  const [screenHours, setScreenHours] = useState<number>(4);
  const [stimulantUsage, setStimulantUsage] = useState<string>("medium");
  const [dopamineResult, setDopamineResult] = useState<any | null>(null);

  const calculateDopamineScore = () => {
    const streakDays = currentUser?.streakStartDate 
      ? Math.floor(Math.abs(new Date().getTime() - new Date(currentUser.streakStartDate).getTime()) / (1000 * 60 * 60 * 24)) 
      : 0;

    let score = 100;
    score -= screenHours * 8; // high screen hours depletes baseline
    if (stimulantUsage === "high") score -= 25;
    if (stimulantUsage === "medium") score -= 10;
    
    // Streak adds receptors
    const streakBonus = Math.min(streakDays * 2, 45);
    score += streakBonus;

    score = Math.min(Math.max(Math.round(score), 5), 100);

    let status = "Healthy Baseline";
    let advice = "Receptors are balanced. Your prefrontal cortex is robust and capable of high attention.";
    
    if (score < 40) {
      status = "Severe Dopamine Downregulation";
      advice = "DeltaFosB accumulation is high. Your receptors are severely depleted due to fast-paced screen stimulation. Engage in immediate 48-hour digital fasting.";
    } else if (score < 70) {
      status = "Mild Neural Depletion";
      advice = "Receptors are slightly downregulated. You are highly vulnerable to instant gratification impulses. Implement deep-focus blocks.";
    }

    setDopamineResult({ score, status, advice });
  };

  // 2. Focus Wellbeing Quiz
  const [quizStep, setQuizStep] = useState<number>(0);
  const [quizAnswers, setQuizAnswers] = useState<number[]>([]);
  const [quizResult, setQuizResult] = useState<string | null>(null);

  const QUIZ_QUESTIONS = [
    { text: "How strong is your urge to check visual stimuli or pick up your phone right now?", options: ["Unnoticeable / Calm", "Low background itch", "Noticeable restlessness", "Intense craving wave"] },
    { text: "How easily can you maintain focus on a complex book or text for 20 minutes?", options: ["Extremely easily", "Slight mind wandering", "Hard to complete 5 pages", "Impossible without looking at a screen"] },
    { text: "How is your mood and overall neurological irritability today?", options: ["Deeply peaceful", "Satisfied but quiet", "Irritable / Restless", "Depleted / High anxiety"] },
    { text: "Have you successfully avoided trigger materials, thumbnails, or sub-reddits today?", options: ["Fully avoided", "Slight exposure but scrolled away", "Peeked briefly", "Reset occurred"] },
    { text: "Rate your current physical stamina and muscle presence.", options: ["Strong & Energetic", "Normal presence", "Heavy/Sluggish", "Depleted"] }
  ];

  const handleQuizAnswer = (optionIdx: number) => {
    const updated = [...quizAnswers, optionIdx];
    setQuizAnswers(updated);
    if (quizStep < QUIZ_QUESTIONS.length - 1) {
      setQuizStep(prev => prev + 1);
    } else {
      // Calculate overall prefrontal focus score
      const sum = updated.reduce((acc, val) => acc + (3 - val), 0); // 3 points for option 0, 0 for option 3
      const scorePercent = Math.round((sum / 15) * 100);
      
      let assessment = "";
      if (scorePercent >= 80) assessment = "Prefrontal Cortex Mastery: Your mind shield is fully activated. You possess solid limbic control.";
      else if (scorePercent >= 50) assessment = "Moderate Sentry Alertness: Your brain chemistry is stable, but background triggers are active. Practice Box Breathing.";
      else assessment = "Limbic Alarm State: Your focus is heavily compromised. Immediate offline hours, cold shower, or heavy exercise is required to transmute raw energy.";

      setQuizResult(`Focus Score: ${scorePercent}% \n\n${assessment}`);
    }
  };

  const resetQuiz = () => {
    setQuizStep(0);
    setQuizAnswers([]);
    setQuizResult(null);
  };

  // ================= STATE: WELLNESS HUB (BREATHING & POMODORO) =================
  // 1. Box Breathing Engine
  const [breathPhase, setBreathPhase] = useState<"inhale" | "hold-in" | "exhale" | "hold-out">("inhale");
  const [breathSecs, setBreathSecs] = useState<number>(4);
  const [isBreathingActive, setIsBreathingActive] = useState<boolean>(false);

  useEffect(() => {
    let interval: any = null;
    if (isBreathingActive) {
      interval = setInterval(() => {
        setBreathSecs(prev => {
          if (prev <= 1) {
            // Transition phase
            setBreathPhase(curr => {
              if (curr === "inhale") return "hold-in";
              if (curr === "hold-in") return "exhale";
              if (curr === "exhale") return "hold-out";
              return "inhale";
            });
            return 4; // 4 seconds standard box breathing
          }
          return prev - 1;
        });
      }, 1000);
    } else {
      setBreathSecs(4);
      setBreathPhase("inhale");
    }
    return () => clearInterval(interval);
  }, [isBreathingActive]);

  // 2. Synthesized Sounds & Audio Session
  const [isPlayingBinaural, setIsPlayingBinaural] = useState<boolean>(false);
  const audioCtxRef = useRef<AudioContext | null>(null);
  const oscillatorsRef = useRef<OscillatorNode[]>([]);
  const gainNodeRef = useRef<GainNode | null>(null);

  const toggleBinauralAudio = () => {
    if (isPlayingBinaural) {
      // Stop oscillators
      oscillatorsRef.current.forEach(o => {
        try { o.stop(); } catch(e){}
      });
      oscillatorsRef.current = [];
      setIsPlayingBinaural(false);
    } else {
      try {
        // Initialize Web Audio API
        const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
        const ctx = new AudioContextClass();
        audioCtxRef.current = ctx;

        const gainNode = ctx.createGain();
        gainNode.gain.setValueAtTime(0.04, ctx.currentTime); // Low volume safe default
        gainNode.connect(ctx.destination);
        gainNodeRef.current = gainNode;

        // Left ear oscillator (Stoic Grounding Wave - 140Hz)
        const leftOsc = ctx.createOscillator();
        leftOsc.type = "sine";
        leftOsc.frequency.setValueAtTime(140, ctx.currentTime);
        
        // Channel splitter & merger to play binaural beat
        const leftPanner = ctx.createStereoPanner ? ctx.createStereoPanner() : null;
        if (leftPanner) {
          leftPanner.pan.setValueAtTime(-1, ctx.currentTime);
          leftOsc.connect(leftPanner);
          leftPanner.connect(gainNode);
        } else {
          leftOsc.connect(gainNode);
        }

        // Right ear oscillator (Mind Recovery Offset Wave - 145Hz)
        // This generates a 5Hz Theta brainwave stimulus which helps alleviate deep tension & urges
        const rightOsc = ctx.createOscillator();
        rightOsc.type = "sine";
        rightOsc.frequency.setValueAtTime(145, ctx.currentTime);
        
        const rightPanner = ctx.createStereoPanner ? ctx.createStereoPanner() : null;
        if (rightPanner) {
          rightPanner.pan.setValueAtTime(1, ctx.currentTime);
          rightOsc.connect(rightPanner);
          rightPanner.connect(gainNode);
        } else {
          rightOsc.connect(gainNode);
        }

        leftOsc.start();
        rightOsc.start();

        oscillatorsRef.current = [leftOsc, rightOsc];
        setIsPlayingBinaural(true);
      } catch (err) {
        console.error("Web Audio synthesis is blocked or unsupported by browser:", err);
        alert("Binaural Beats: Active audio engine generated locally! Put on headphones to receive the 5Hz deep meditation wave.");
        setIsPlayingBinaural(true);
      }
    }
  };

  useEffect(() => {
    return () => {
      // Cleanup on component unmount
      oscillatorsRef.current.forEach(o => {
        try { o.stop(); } catch(e){}
      });
    };
  }, []);

  // 3. Pomodoro Focus Timer
  const [pomoSecs, setPomoSecs] = useState<number>(25 * 60);
  const [isPomoActive, setIsPomoActive] = useState<boolean>(false);
  const [pomoMode, setPomoMode] = useState<"focus" | "break">("focus");

  useEffect(() => {
    let interval: any = null;
    if (isPomoActive) {
      interval = setInterval(() => {
        setPomoSecs(prev => {
          if (prev <= 1) {
            // Timer complete
            confetti({ particleCount: 50 });
            if (pomoMode === "focus") {
              alert("🧠 Deep Focus Block Complete! Reward yourself with 5 minutes of stretching or cold water.");
              setPomoMode("break");
              return 5 * 60;
            } else {
              alert("⏰ Break session over. Get ready to activate your prefrontal shield.");
              setPomoMode("focus");
              return 25 * 60;
            }
          }
          return prev - 1;
        });
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [isPomoActive, pomoMode]);

  const formatPomoTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`;
  };

  // ================= STATE: VISION BOARD & GOAL PLANNER =================
  const [visionItems, setVisionItems] = useState<{ id: string; text: string; category: string }[]>(() => {
    const saved = localStorage.getItem("sanctuary_vision_board");
    return saved ? JSON.parse(saved) : [
      { id: "1", text: "Acquire complete mastership over physical desires to secure professional dominance.", category: "Career" },
      { id: "2", text: "Divert biological urges into intense, compound lifting. Build a resilient physique.", category: "Fitness" },
      { id: "3", text: "Reclaim the clean, quiet natural world. Be present with family and friends.", category: "Mindfulness" }
    ];
  });
  const [newVisionText, setNewVisionText] = useState<string>("");
  const [newVisionCat, setNewVisionCat] = useState<string>("Mindfulness");

  useEffect(() => {
    localStorage.setItem("sanctuary_vision_board", JSON.stringify(visionItems));
  }, [visionItems]);

  const addVisionItem = () => {
    if (!newVisionText.trim()) return;
    setVisionItems(prev => [
      ...prev,
      { id: Date.now().toString(), text: newVisionText.trim(), category: newVisionCat }
    ]);
    setNewVisionText("");
  };

  const removeVisionItem = (id: string) => {
    setVisionItems(prev => prev.filter(item => item.id !== id));
  };


  // Dopamine recovery calculations
  const getStreakDays = () => {
    if (!currentUser || !currentUser.streakStartDate) return 0;
    const start = new Date(currentUser.streakStartDate);
    const now = new Date();
    const diff = Math.abs(now.getTime() - start.getTime());
    return Math.floor(diff / (1000 * 60 * 60 * 24));
  };
  const streakDays = getStreakDays();


  return (
    <div id="interactive-companion-card" className="rounded-2xl border border-neutral-850 bg-[#0F0F10] p-6 shadow-md space-y-6">
      
      {/* Tab select bar */}
      <div className="flex border-b border-[#1A1A1B] pb-3 items-center justify-between flex-wrap gap-4">
        <div className="flex items-center space-x-2.5">
          <Activity className="h-5 w-5 text-amber-500 animate-pulse" />
          <h3 className="font-display font-bold text-neutral-100">Routine Tools & Wellness Hub</h3>
        </div>
        
        <div className="flex flex-wrap gap-1 bg-[#161618] p-1 rounded-xl border border-[#262626]">
          {[
            { id: "trackers", label: "Daily Trackers", icon: CheckCircle },
            { id: "calculators", label: "Calculators & Quiz", icon: HelpCircle },
            { id: "timeline", label: "Brain Recovery", icon: Brain },
            { id: "wellness", label: "Breathe & Sound", icon: Timer },
            { id: "vision", label: "Vision & Goals", icon: Target }
          ].map((tab) => {
            const Icon = tab.icon;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`rounded-lg px-3 py-1.5 text-xs font-bold flex items-center space-x-1.5 transition-all cursor-pointer ${
                  activeTab === tab.id
                    ? "bg-[#0F0F10] text-amber-500 shadow-sm border border-[#262626]"
                    : "text-neutral-400 hover:text-[#E5E5E5]"
                }`}
              >
                <Icon className="h-3.5 w-3.5" />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* ================= SUB-TAB: ROUTINE TRACKERS ================= */}
      {activeTab === "trackers" && (
        <div className="grid gap-6 md:grid-cols-3">
          
          {/* Water Tracker Box */}
          <div className="rounded-xl border border-[#1A1A1B] bg-[#0A0A0B] p-5 flex flex-col justify-between">
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <div className="h-8 w-8 rounded-lg bg-blue-500/10 text-blue-400 border border-blue-500/20 flex items-center justify-center">
                    <Droplet className="h-4.5 w-4.5" />
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-neutral-200">Water Reminder</h4>
                    <span className="text-[10px] text-neutral-500">Hydrate neural synapses</span>
                  </div>
                </div>
                <button 
                  onClick={() => setShowWaterCalc(!showWaterCalc)}
                  className="text-[10px] text-blue-400 hover:underline font-mono"
                >
                  Calc Target
                </button>
              </div>

              {showWaterCalc && (
                <div className="bg-[#161618] p-3 rounded-lg space-y-2 border border-blue-500/10 animate-fade-in text-xs">
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <span className="text-[9px] text-neutral-500">Weight (lbs)</span>
                      <input 
                        type="number"
                        value={waterCalcWeight}
                        onChange={(e) => setWaterCalcWeight(e.target.value)}
                        className="w-full bg-[#0A0A0B] border border-[#1A1A1B] rounded px-2 py-1 text-xs outline-none"
                      />
                    </div>
                    <div>
                      <span className="text-[9px] text-neutral-500">Exercise Hrs</span>
                      <input 
                        type="number"
                        value={waterCalcHours}
                        onChange={(e) => setWaterCalcHours(e.target.value)}
                        className="w-full bg-[#0A0A0B] border border-[#1A1A1B] rounded px-2 py-1 text-xs outline-none"
                      />
                    </div>
                  </div>
                  <button 
                    onClick={calculateWaterTarget}
                    className="w-full bg-blue-500 text-white text-[10px] font-bold py-1 rounded"
                  >
                    Set Recommendations
                  </button>
                </div>
              )}

              {/* Progress visualizer */}
              <div className="space-y-1.5 py-1">
                <div className="flex justify-between text-[11px] font-mono">
                  <span className="text-neutral-400">Cups Claimed</span>
                  <span className="text-blue-400 font-bold">{waterCups} / {waterTarget} Cups</span>
                </div>
                <div className="h-2 w-full bg-[#161618] rounded-full overflow-hidden border border-[#262626]">
                  <div 
                    className="h-full bg-blue-400 rounded-full transition-all duration-300"
                    style={{ width: `${Math.min((waterCups / waterTarget) * 100, 100)}%` }}
                  ></div>
                </div>
              </div>
            </div>

            <div className="flex space-x-2 pt-4 border-t border-[#161618]/60 mt-3">
              <button 
                onClick={() => setWaterCups(prev => Math.min(prev + 1, 20))}
                className="flex-1 bg-blue-500/10 border border-blue-500/25 hover:bg-blue-500/20 text-blue-400 font-bold text-xs py-2 rounded-lg transition-all cursor-pointer"
              >
                +1 Cup
              </button>
              <button 
                onClick={() => setWaterCups(0)}
                className="bg-neutral-850 hover:bg-neutral-800 text-neutral-400 p-2 rounded-lg border border-[#262626]"
                title="Reset water log"
              >
                <RotateCcw className="h-4 w-4" />
              </button>
            </div>
          </div>

          {/* Exercise Goal Box */}
          <div className="rounded-xl border border-[#1A1A1B] bg-[#0A0A0B] p-5 flex flex-col justify-between">
            <div className="space-y-3">
              <div className="flex items-center space-x-2">
                <div className="h-8 w-8 rounded-lg bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 flex items-center justify-center">
                  <Flame className="h-4.5 w-4.5" />
                </div>
                <div>
                  <h4 className="text-xs font-bold text-neutral-200">Physical Transmutation</h4>
                  <span className="text-[10px] text-neutral-500">Divert raw adrenaline</span>
                </div>
              </div>

              {/* Pushups & Squats metrics */}
              <div className="space-y-2 text-xs">
                <div className="flex justify-between text-[11px] font-mono">
                  <span className="text-neutral-400">Exercise Duration</span>
                  <span className="text-emerald-400 font-bold">{exerciseMins} / {exerciseTarget} mins</span>
                </div>
                <div className="flex justify-between text-[11px] font-mono">
                  <span className="text-neutral-400">Sentry Pushups/Squats</span>
                  <span className="text-emerald-400 font-bold">{pushupCount} / {pushupTarget} reps</span>
                </div>
              </div>
            </div>

            <div className="space-y-2 pt-4 border-t border-[#161618]/60 mt-3">
              <div className="grid grid-cols-2 gap-2">
                <button 
                  onClick={() => setExerciseMins(prev => prev + 10)}
                  className="bg-emerald-500/10 border border-emerald-500/20 hover:bg-emerald-500/15 text-emerald-400 text-[11px] font-bold py-1.5 rounded-lg transition-all cursor-pointer text-center"
                >
                  +10 Mins
                </button>
                <button 
                  onClick={() => setPushupCount(prev => prev + 15)}
                  className="bg-emerald-500/10 border border-emerald-500/20 hover:bg-emerald-500/15 text-emerald-400 text-[11px] font-bold py-1.5 rounded-lg transition-all cursor-pointer text-center"
                >
                  +15 Reps
                </button>
              </div>
              <button 
                onClick={() => { setExerciseMins(0); setPushupCount(0); }}
                className="w-full text-[10px] text-neutral-500 hover:text-neutral-400 text-center block pt-1 font-mono"
              >
                Clear Daily Reps
              </button>
            </div>
          </div>

          {/* Sleep Score & Cycle Box */}
          <div className="rounded-xl border border-[#1A1A1B] bg-[#0A0A0B] p-5 flex flex-col justify-between">
            <div className="space-y-3">
              <div className="flex items-center space-x-2">
                <div className="h-8 w-8 rounded-lg bg-indigo-500/10 text-indigo-400 border border-indigo-500/20 flex items-center justify-center">
                  <Moon className="h-4.5 w-4.5" />
                </div>
                <div>
                  <h4 className="text-xs font-bold text-neutral-200">Sleep Schedule</h4>
                  <span className="text-[10px] text-neutral-500">Optimal recovery cycles</span>
                </div>
              </div>

              {/* Set Bedtime */}
              <div className="space-y-2 text-xs">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] text-neutral-500">I sleep at:</span>
                  <input 
                    type="time" 
                    value={bedtime}
                    onChange={(e) => setBedtime(e.target.value)}
                    className="bg-[#161618] text-neutral-300 rounded border border-[#262626] px-1.5 text-[11px] outline-none"
                  />
                </div>
                {recommendedWakeCycles.length > 0 && (
                  <div className="text-[10px] text-indigo-400 leading-relaxed font-medium bg-indigo-500/5 p-2 rounded border border-indigo-500/10">
                    <span className="block text-[9px] text-neutral-500 uppercase font-mono mb-1">Optimal wake cycles:</span>
                    <div className="flex gap-1.5 flex-wrap">
                      {recommendedWakeCycles.slice(0, 3).map((t, i) => (
                        <span key={i} className="bg-[#161618] border border-[#262626] px-1 py-0.5 rounded text-[9px]">
                          {t}
                        </span>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>

            <div className="pt-3 border-t border-[#161618]/60 mt-3 flex items-center justify-between text-[11px] font-mono">
              <span className="text-neutral-500">Sleep Score:</span>
              <div className="flex items-center space-x-1.5">
                <input 
                  type="number" 
                  min="30" 
                  max="100"
                  value={sleepScore}
                  onChange={(e) => {
                    const val = Number(e.target.value);
                    setSleepScore(val);
                    localStorage.setItem("sanctuary_sleep_score", String(val));
                  }}
                  className="w-12 bg-[#161618] border border-[#262626] text-center text-indigo-400 font-bold rounded py-0.5"
                />
                <span className="text-neutral-500">/100</span>
              </div>
            </div>
          </div>

        </div>
      )}

      {/* ================= SUB-TAB: CALCULATORS & QUIZZES ================= */}
      {activeTab === "calculators" && (
        <div className="grid gap-6 md:grid-cols-2">
          
          {/* Dopamine Baseline Calculator */}
          <div className="rounded-xl border border-[#1A1A1B] bg-[#0A0A0B] p-5 space-y-4">
            <div className="flex items-center space-x-2">
              <Zap className="h-5 w-5 text-amber-500" />
              <h4 className="text-xs font-bold text-neutral-200">Dopamine Baseline Calculator</h4>
            </div>
            
            <p className="text-[11px] text-neutral-450 leading-relaxed">
              Estimate your neural upregulation baseline. Long screen time and instant sexual gratification trigger receptor downregulation, leading to heavy brain fog.
            </p>

            <div className="space-y-3 text-xs">
              <div>
                <label className="block text-[10px] text-neutral-500 font-bold uppercase mb-1">
                  Daily Scrolling/Screen Time: {screenHours} Hours
                </label>
                <input 
                  type="range"
                  min="1"
                  max="12"
                  value={screenHours}
                  onChange={(e) => setScreenHours(Number(e.target.value))}
                  className="w-full accent-amber-500 h-1.5 bg-[#161618] rounded appearance-none cursor-pointer"
                />
              </div>

              <div>
                <label className="block text-[10px] text-neutral-500 font-bold uppercase mb-1.5">
                  General Stimulant Load (Caffeine/Energy drinks):
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {["low", "medium", "high"].map((level) => (
                    <button
                      key={level}
                      type="button"
                      onClick={() => setStimulantUsage(level)}
                      className={`py-1.5 text-[10px] font-bold border rounded-lg uppercase tracking-wider transition-all ${
                        stimulantUsage === level
                          ? "bg-amber-500/10 border-amber-500 text-amber-500"
                          : "border-[#1B1B1C] bg-[#161618] text-neutral-400"
                      }`}
                    >
                      {level}
                    </button>
                  ))}
                </div>
              </div>

              <button
                onClick={calculateDopamineScore}
                className="w-full bg-amber-500 text-[#0A0A0B] hover:bg-amber-400 text-xs font-bold py-2.5 rounded-lg transition-all cursor-pointer mt-2"
              >
                Analyze Neural Density
              </button>
            </div>

            {dopamineResult && (
              <div className="bg-[#161618] rounded-xl p-4 border border-[#262626] animate-fade-in space-y-2">
                <div className="flex justify-between items-center border-b border-[#262626] pb-2">
                  <span className="text-[10px] text-neutral-500 font-bold uppercase">Upregulation Score:</span>
                  <span className="text-sm font-black text-amber-500 font-mono">{dopamineResult.score} / 100</span>
                </div>
                <div className="text-xs font-bold text-neutral-200">{dopamineResult.status}</div>
                <p className="text-[11px] text-neutral-400 leading-relaxed italic">
                  "{dopamineResult.advice}"
                </p>
              </div>
            )}
          </div>

          {/* Mental Wellbeing Focus Quiz */}
          <div className="rounded-xl border border-[#1A1A1B] bg-[#0A0A0B] p-5 space-y-4">
            <div className="flex items-center space-x-2">
              <Brain className="h-5 w-5 text-indigo-400 animate-pulse" />
              <h4 className="text-xs font-bold text-indigo-300">Prefrontal Mental Wellbeing Assessment</h4>
            </div>

            {!quizResult ? (
              <div className="space-y-4">
                <div className="flex justify-between items-center text-[10px] text-neutral-500 font-mono font-bold">
                  <span>STEP {quizStep + 1} OF {QUIZ_QUESTIONS.length}</span>
                  <span className="text-indigo-400">ACTIVE COGNITION</span>
                </div>

                <div className="rounded-lg bg-[#161618] p-3 border border-[#262626] text-xs font-bold text-neutral-200 leading-relaxed">
                  {QUIZ_QUESTIONS[quizStep].text}
                </div>

                <div className="space-y-2">
                  {QUIZ_QUESTIONS[quizStep].options.map((opt, idx) => (
                    <button
                      key={idx}
                      onClick={() => handleQuizAnswer(idx)}
                      className="w-full text-left bg-[#161618]/40 hover:bg-[#161618] border border-[#1A1A1B] hover:border-indigo-500/40 rounded-xl p-3 text-xs text-neutral-450 hover:text-neutral-200 font-medium transition-all flex justify-between items-center"
                    >
                      <span>{opt}</span>
                      <ChevronRight className="h-3.5 w-3.5 text-indigo-500/60" />
                    </button>
                  ))}
                </div>
              </div>
            ) : (
              <div className="space-y-4 animate-fade-in">
                <div className="bg-[#161618] rounded-xl p-4 border border-[#262626] space-y-3">
                  <h5 className="text-xs font-bold text-indigo-400 uppercase tracking-wider border-b border-[#262626] pb-2">
                    Assessment Complete
                  </h5>
                  <p className="text-xs text-neutral-300 whitespace-pre-line leading-relaxed font-medium">
                    {quizResult}
                  </p>
                </div>
                <button
                  onClick={resetQuiz}
                  className="w-full bg-[#161618] hover:bg-[#1c1c1e] text-neutral-300 hover:text-neutral-100 text-xs font-bold py-2 rounded-lg border border-[#262626] transition-all cursor-pointer"
                >
                  Retake Assessment
                </button>
              </div>
            )}
          </div>

        </div>
      )}

      {/* ================= SUB-TAB: BRAIN RECOVERY TIMELINE ================= */}
      {activeTab === "timeline" && (
        <div className="space-y-6">
          
          {/* Dopamine Upregulation Meter */}
          <div className="rounded-xl border border-[#1A1A1B] p-5 bg-[#0A0A0B] space-y-4">
            <div className="flex items-center justify-between flex-wrap gap-4 border-b border-[#1A1A1B]/60 pb-3">
              <div className="flex items-center space-x-2">
                <Brain className="h-5 w-5 text-amber-500" />
                <h4 className="text-xs font-bold text-neutral-200">Dopamine Receptor Recovery Status</h4>
              </div>
              <span className="text-[10px] font-mono bg-amber-500/10 text-amber-500 px-2.5 py-0.5 rounded font-bold">
                DELTA-FOSB MOLECULAR WATCH
              </span>
            </div>

            <div className="grid gap-6 md:grid-cols-4">
              <div className="md:col-span-1 border border-[#1A1A1B] bg-[#161618]/30 rounded-xl p-4 text-center flex flex-col justify-center items-center">
                <span className="text-3xl font-black text-amber-500 font-mono tracking-tight">{streakDays}</span>
                <span className="text-[9px] font-mono font-bold text-neutral-500 uppercase tracking-widest mt-1">Sovereign Streak</span>
              </div>

              <div className="md:col-span-3 space-y-3">
                <div className="flex justify-between text-xs font-mono font-bold">
                  <span className="text-neutral-400 uppercase">Estimated Receptor Density</span>
                  <span className="text-amber-500">
                    {streakDays >= 90 ? "100%" : streakDays >= 60 ? "85%" : streakDays >= 30 ? "65%" : streakDays >= 14 ? "40%" : "15%"} Upregulated
                  </span>
                </div>
                
                {/* Horizontal Progress Timeline */}
                <div className="h-3 w-full bg-[#161618] border border-[#262626] rounded-full overflow-hidden flex relative">
                  <div 
                    className="h-full bg-gradient-to-r from-amber-600 to-amber-500 rounded-full transition-all duration-700"
                    style={{ width: `${Math.min(Math.max((streakDays / 90) * 100, 10), 100)}%` }}
                  ></div>
                </div>

                <div className="flex justify-between text-[10px] text-neutral-500 font-mono font-bold px-1">
                  <span>Day 1: Acute Shock</span>
                  <span>Day 30: Peak Upregulation</span>
                  <span>Day 90: Complete Rewiring</span>
                </div>
              </div>
            </div>
          </div>

          {/* Brain Recovery Stages Timeline */}
          <div className="space-y-3">
            <h5 className="text-[11px] font-black uppercase tracking-widest text-neutral-500 px-1">Estimated Neurobiological Milestones:</h5>
            
            <div className="relative border-l-2 border-[#1A1A1B] pl-5 ml-3.5 space-y-4">
              {[
                { day: "1 - 3", title: "Autonomic Hyper-Arousal & Withdrawal", desc: "Excess epinephrine is circulating. High restlessness. Use extreme pushup transmutation and deep cold water splashes to purge autonomic charge.", active: streakDays >= 1 },
                { day: "4 - 14", title: "Upregulation Initiation & DeltaFosB Fall", desc: "Initial clearance of DeltaFosB proteins inside the nucleus accumbens. Focus begins returning. The mind's background voice becomes quieter.", active: streakDays >= 4 },
                { day: "15 - 30", title: "Prefrontal Core Re-Myelination", desc: "Myelin sheaths around prefrontal-limbic inhibitory axons strengthen. High increase in physical discipline and natural eye-contact confidence.", active: streakDays >= 15 },
                { day: "60 - 90", title: "Complete Neural Habit Stabilization", desc: "Dopamine receptors return to standard natural density. Total reduction in involuntary sexual scrolling urges. High physical stamina locked in.", active: streakDays >= 60 }
              ].map((stage, idx) => (
                <div key={idx} className="relative">
                  <span className={`absolute -left-[30px] top-1 flex h-4.5 w-4.5 items-center justify-center rounded-full border text-[9px] font-bold ${
                    stage.active 
                      ? "bg-amber-500 border-amber-500 text-[#0A0A0B]" 
                      : "bg-[#0F0F10] border-[#262626] text-neutral-500"
                  }`}>
                    {stage.active ? <Check className="h-2.5 w-2.5" /> : idx + 1}
                  </span>
                  <div>
                    <h6 className={`text-xs font-bold ${stage.active ? "text-amber-500" : "text-neutral-450"}`}>
                      {stage.title} <span className="font-mono text-[9px] font-semibold text-neutral-500">({stage.day} Days)</span>
                    </h6>
                    <p className="text-[11px] text-neutral-500 mt-0.5 max-w-3xl leading-relaxed">
                      {stage.desc}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>

        </div>
      )}

      {/* ================= SUB-TAB: WELLNESS & GUIDED TOOLS ================= */}
      {activeTab === "wellness" && (
        <div className="grid gap-6 md:grid-cols-2">
          
          {/* Guided Box Breathing Circle */}
          <div className="rounded-xl border border-[#1A1A1B] bg-[#0A0A0B] p-5 flex flex-col justify-between items-center text-center">
            <div className="space-y-2 w-full">
              <div className="flex items-center space-x-2 justify-center">
                <Compass className="h-5 w-5 text-indigo-400 animate-spin" style={{ animationDuration: "12s" }} />
                <h4 className="text-xs font-bold text-neutral-200">Sovereign Box Breathing Anchor</h4>
              </div>
              <p className="text-[10px] text-neutral-500">
                Paces your respiration to lower physical arousal and secure prefrontal self-command.
              </p>
            </div>

            {/* Dynamic Animated Circle */}
            <div className="py-8 relative flex items-center justify-center">
              <div 
                className={`rounded-full flex flex-col items-center justify-center transition-all duration-1000 ${
                  breathPhase === "inhale" 
                    ? "h-36 w-36 bg-indigo-500/10 border-2 border-indigo-500 shadow-[0_0_20px_rgba(99,102,241,0.2)]" 
                    : breathPhase === "hold-in"
                    ? "h-36 w-36 bg-purple-500/15 border-2 border-purple-500"
                    : breathPhase === "exhale"
                    ? "h-24 w-24 bg-indigo-500/5 border border-indigo-500/40"
                    : "h-24 w-24 bg-zinc-950/40 border border-neutral-800"
                }`}
              >
                <span className="text-xs font-black uppercase tracking-wider text-neutral-200 font-mono">
                  {breathPhase.replace("-", " ")}
                </span>
                <span className="text-lg font-black text-indigo-400 font-mono mt-1">
                  {breathSecs}s
                </span>
              </div>
            </div>

            <div className="w-full space-y-3">
              <button
                onClick={() => setIsBreathingActive(!isBreathingActive)}
                className={`w-full py-2.5 text-xs font-bold rounded-lg transition-all cursor-pointer ${
                  isBreathingActive 
                    ? "bg-red-500/10 border border-red-500/30 text-red-400 hover:bg-red-500/20" 
                    : "bg-indigo-600 hover:bg-indigo-500 text-white shadow-lg shadow-indigo-600/15"
                }`}
              >
                {isBreathingActive ? "Deactivate Anchor" : "Initiate 4-4-4-4 Box Breath"}
              </button>

              <div className="flex justify-between text-[10px] text-neutral-500 font-mono font-bold pt-1.5 px-1">
                <span>1. Inhale (4s)</span>
                <span>2. Hold (4s)</span>
                <span>3. Exhale (4s)</span>
                <span>4. Hold (4s)</span>
              </div>
            </div>
          </div>

          {/* Pomodoro Focus Timer & Binaural soundscape */}
          <div className="rounded-xl border border-[#1A1A1B] bg-[#0A0A0B] p-5 flex flex-col justify-between">
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <Timer className="h-5 w-5 text-red-400" />
                  <h4 className="text-xs font-bold text-neutral-200">Stoic Pomodoro Block</h4>
                </div>
                <span className={`text-[9px] font-mono font-bold uppercase px-2 py-0.5 rounded ${
                  pomoMode === "focus" ? "bg-red-500/10 text-red-400" : "bg-emerald-500/10 text-emerald-400"
                }`}>
                  {pomoMode === "focus" ? "Deep Work State" : "Mind Rest State"}
                </span>
              </div>

              {/* Big Timer display */}
              <div className="text-center py-4">
                <span className="text-4xl font-black text-neutral-100 font-mono tracking-tight">
                  {formatPomoTime(pomoSecs)}
                </span>
              </div>

              {/* Controls */}
              <div className="flex space-x-2 justify-center">
                <button
                  onClick={() => setIsPomoActive(!isPomoActive)}
                  className="bg-neutral-850 hover:bg-neutral-800 text-neutral-300 font-bold text-xs py-2 px-5 rounded-lg border border-[#262626] transition-all flex items-center space-x-1.5 cursor-pointer"
                >
                  {isPomoActive ? <Pause className="h-3.5 w-3.5" /> : <Play className="h-3.5 w-3.5" />}
                  <span>{isPomoActive ? "Pause Block" : "Start Block"}</span>
                </button>
                
                <button
                  onClick={() => {
                    setIsPomoActive(false);
                    setPomoSecs(pomoMode === "focus" ? 25 * 60 : 5 * 60);
                  }}
                  className="bg-neutral-850 hover:bg-neutral-800 text-neutral-400 p-2 rounded-lg border border-[#262626]"
                  title="Reset timer"
                >
                  <RotateCcw className="h-3.5 w-3.5" />
                </button>
              </div>

              {/* Binaural Beat Generator Toggle */}
              <div className="rounded-xl border border-[#262626] bg-[#161618]/30 p-3.5 mt-2 space-y-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2 text-xs font-bold text-neutral-300">
                    <Brain className="h-4 w-4 text-purple-400" />
                    <span>Focus Waves (5Hz Theta Binaural Beat)</span>
                  </div>
                  <button
                    onClick={toggleBinauralAudio}
                    className={`p-1.5 rounded-lg transition-all ${
                      isPlayingBinaural 
                        ? "bg-purple-500/10 text-purple-400 border border-purple-500/20" 
                        : "bg-neutral-850 text-neutral-500"
                    }`}
                  >
                    {isPlayingBinaural ? <Volume2 className="h-4 w-4" /> : <VolumeX className="h-4 w-4" />}
                  </button>
                </div>
                <p className="text-[10px] text-neutral-500 leading-relaxed font-medium">
                  We generate genuine low-frequency binaural waves in your browser. Wear stereo headphones to assist prefrontal cortex focus and inhibit raw limbic urges.
                </p>
              </div>
            </div>

            <div className="text-[10px] text-neutral-500 text-center font-mono pt-4 mt-3 border-t border-[#161618]/60">
              Commit to 25 minutes of zero-tab-switching purity.
            </div>
          </div>

        </div>
      )}

      {/* ================= SUB-TAB: VISION & GOAL PLANNER ================= */}
      {activeTab === "vision" && (
        <div className="space-y-6">
          
          {/* Visions grid */}
          <div className="grid gap-4 sm:grid-cols-3">
            {visionItems.map((item) => (
              <div key={item.id} className="rounded-xl border border-[#1B1B1C] bg-[#0A0A0B] p-4 relative flex flex-col justify-between group">
                <button
                  onClick={() => removeVisionItem(item.id)}
                  className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 text-neutral-600 hover:text-red-400 p-1 rounded transition-all cursor-pointer"
                  title="Delete target"
                >
                  <Trash2 className="h-3.5 w-3.5" />
                </button>

                <div className="space-y-3">
                  <span className="text-[9px] font-mono font-bold bg-amber-500/15 border border-amber-500/25 text-amber-500 px-2 py-0.5 rounded uppercase tracking-wider">
                    {item.category}
                  </span>
                  <p className="text-xs text-neutral-200 font-medium italic leading-relaxed">
                    "{item.text}"
                  </p>
                </div>

                <div className="flex items-center space-x-1.5 text-[9px] text-neutral-500 font-mono mt-4 pt-2 border-t border-[#161618]/60">
                  <ShieldCheck className="h-3 w-3 text-emerald-400" />
                  <span>Pinned Target</span>
                </div>
              </div>
            ))}
          </div>

          {/* Add vision form */}
          <div className="bg-[#0A0A0B] border border-[#1A1A1B] rounded-xl p-4 space-y-4">
            <span className="text-[10px] font-black uppercase tracking-widest text-primary block" style={{ color: "var(--primary)" }}>Pin New Sovereign Purity Goal</span>
            
            <div className="flex flex-col sm:flex-row gap-3">
              <input
                type="text"
                value={newVisionText}
                onChange={(e) => setNewVisionText(e.target.value)}
                placeholder="e.g. Become completely free of triggers to build high focus on coding projects."
                maxLength={140}
                className="flex-1 bg-[#161618] border border-[#262626] focus:border-primary/50 focus:outline-none rounded-xl px-4 py-2 text-xs text-neutral-200 placeholder-neutral-600 transition-all"
              />
              
              <select
                value={newVisionCat}
                onChange={(e) => setNewVisionCat(e.target.value)}
                className="bg-[#161618] border border-[#262626] text-xs text-neutral-300 rounded-xl px-3 py-2 outline-none focus:border-primary/50"
              >
                <option value="Mindfulness">Mindfulness</option>
                <option value="Career">Career</option>
                <option value="Fitness">Fitness</option>
                <option value="Discipline">Discipline</option>
              </select>

              <button
                onClick={addVisionItem}
                className="bg-primary hover:bg-primary-hover text-[#0A0A0B] text-xs font-bold px-5 py-2 rounded-xl transition-all cursor-pointer whitespace-nowrap"
                style={{ backgroundColor: "var(--primary)" }}
              >
                Pin to Board
              </button>
            </div>
          </div>

        </div>
      )}

      {/* Bottom Mystery Chest Section */}
      <div className="rounded-xl border border-[#1A1A1B] bg-[#161618]/40 p-4 flex items-center justify-between flex-wrap gap-4 relative overflow-hidden">
        <div className="absolute top-0 right-0 h-32 w-32 bg-primary/5 rounded-full blur-2xl pointer-events-none" style={{ backgroundColor: "var(--primary-light)" }}></div>
        
        <div className="flex items-center space-x-3.5">
          <div className="h-10 w-10 rounded-xl bg-primary/10 text-primary border flex items-center justify-center shrink-0" style={{ color: "var(--primary)", borderColor: "var(--primary-light)" }}>
            <Gift className="h-5.5 w-5.5 animate-bounce" />
          </div>
          <div className="space-y-0.5">
            <h4 className="text-xs font-bold text-neutral-200 flex items-center space-x-1.5">
              <span>Sovereign Daily Chest</span>
              <span className="text-[9px] font-mono font-bold bg-primary/10 text-primary px-1.5 py-0.5 rounded" style={{ color: "var(--primary)", backgroundColor: "var(--primary-light)" }}>Claim daily</span>
            </h4>
            <p className="text-[10px] text-neutral-500">Claim your randomized Focus XP, Purity Coins, and mystery motivational lesson.</p>
          </div>
        </div>

        <div className="flex items-center space-x-4">
          <div className="text-right">
            <span className="text-[10px] text-neutral-500 block font-mono">Your Balance:</span>
            <span className="text-xs font-bold text-primary font-mono" style={{ color: "var(--primary)" }}>🪙 {coinsCount} Coins</span>
          </div>

          <button
            onClick={handleClaimChest}
            disabled={chestClaimed}
            className={`rounded-xl text-xs font-bold px-5 py-2.5 transition-all cursor-pointer ${
              chestClaimed 
                ? "bg-neutral-850 border border-[#262626] text-neutral-500" 
                : "bg-primary hover:bg-primary-hover text-[#0A0A0B] shadow-lg shadow-primary/10 font-bold"
            }`}
            style={{ backgroundColor: chestClaimed ? undefined : "var(--primary)" }}
          >
            {chestClaimed ? "Chest Claimed" : "Unlock Chest"}
          </button>
        </div>
      </div>

    </div>
  );
}
