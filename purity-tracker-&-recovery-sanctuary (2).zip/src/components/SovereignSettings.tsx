/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from "react";
import { 
  User, 
  Settings, 
  Key, 
  ShieldAlert, 
  Trash2, 
  Download, 
  Clock, 
  RefreshCw, 
  BarChart2, 
  Activity, 
  Calendar, 
  CheckSquare, 
  Compass, 
  Bell, 
  Flame, 
  ChevronRight, 
  Zap, 
  ListTodo, 
  ExternalLink,
  ShieldCheck,
  Award,
  Sparkles
} from "lucide-react";
import { User as UserType } from "../types";

interface SovereignSettingsProps {
  currentUser: UserType | null;
  onUpdateUser: (user: UserType) => void;
  onLogout: () => void;
  onOpenAuth: () => void;
  theme: "dark" | "deep-night" | "light" | "midnight" | "soft-gray" | "glassmorphism" | "amoled" | "glass" | "ocean";
  onSetTheme: (theme: "dark" | "deep-night" | "light" | "midnight" | "soft-gray" | "glassmorphism" | "amoled" | "glass" | "ocean") => void;
  accentColor: "emerald" | "amber" | "indigo" | "rose" | "violet" | "orange";
  onSetAccentColor: (color: "emerald" | "amber" | "indigo" | "rose" | "violet" | "orange") => void;
  glassmorphism: boolean;
  onSetGlassmorphism: (enabled: boolean) => void;
  fontSize: "normal" | "medium" | "large";
  onSetFontSize: (size: "normal" | "medium" | "large") => void;
  reducedMotion: boolean;
  onSetReducedMotion: (enabled: boolean) => void;
  highContrast: boolean;
  onSetHighContrast: (enabled: boolean) => void;
  customCursor: boolean;
  onSetCustomCursor: (enabled: boolean) => void;
}

const AVATAR_PRESETS = [
  "https://api.dicebear.com/7.x/bottts/svg?seed=Archon",
  "https://api.dicebear.com/7.x/bottts/svg?seed=Aegis",
  "https://api.dicebear.com/7.x/bottts/svg?seed=Sovereign",
  "https://api.dicebear.com/7.x/bottts/svg?seed=Vanguard",
  "https://api.dicebear.com/7.x/bottts/svg?seed=Fortitude",
  "https://api.dicebear.com/7.x/bottts/svg?seed=Purity"
];

const BANNER_PRESETS = [
  { name: "Sovereign Gold", css: "from-amber-600/30 to-zinc-900" },
  { name: "Cosmic Twilight", css: "from-purple-900/30 to-zinc-900" },
  { name: "Limbic Shield", css: "from-emerald-900/30 to-zinc-900" },
  { name: "Deep Abyssal Blue", css: "from-blue-950/40 to-zinc-900" },
  { name: "Crimson Fortitude", css: "from-rose-950/40 to-zinc-900" }
];

export default function SovereignSettings({ 
  currentUser, 
  onUpdateUser, 
  onLogout,
  onOpenAuth,
  theme,
  onSetTheme,
  accentColor,
  onSetAccentColor,
  glassmorphism,
  onSetGlassmorphism,
  fontSize,
  onSetFontSize,
  reducedMotion,
  onSetReducedMotion,
  highContrast,
  onSetHighContrast,
  customCursor,
  onSetCustomCursor
}: SovereignSettingsProps) {
  const [activeSubTab, setActiveSubTab] = useState<"profile" | "customization" | "analytics" | "security">("profile");

  // Profile forms
  const [username, setUsername] = useState("");
  const [statusMessage, setStatusMessage] = useState("");
  const [customStatus, setCustomStatus] = useState("");
  const [socialLink, setSocialLink] = useState("");
  const [avatarUrl, setAvatarUrl] = useState("");
  const [bannerColor, setBannerColor] = useState("from-amber-600/30 to-zinc-900");
  
  // Security Password Form
  const [currentPassword, setCurrentPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");

  const [loading, setLoading] = useState(false);
  const [successMsg, setSuccessMsg] = useState("");
  const [errorMsg, setErrorMsg] = useState("");

  // Populate fields on load
  useEffect(() => {
    if (currentUser) {
      setUsername(currentUser.username || "");
      setStatusMessage(currentUser.statusMessage || "");
      setCustomStatus(currentUser.customStatus || "");
      setSocialLink(currentUser.socialLink || "");
      setAvatarUrl(currentUser.avatarUrl || "");
      setBannerColor(currentUser.bannerColor || "from-amber-600/30 to-zinc-900");
    }
  }, [currentUser]);

  if (!currentUser) {
    return (
      <div className="mx-auto max-w-4xl px-4 py-16 text-center space-y-6">
        <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-2xl bg-primary/10 text-primary border border-primary/20" style={{ color: "var(--primary)", borderColor: "var(--primary-light)" }}>
          <Settings className="h-8 w-8 animate-spin" />
        </div>
        <h2 className="font-display text-2xl font-bold tracking-tight text-neutral-100">Settings Locked</h2>
        <p className="text-sm text-neutral-400 max-w-sm mx-auto leading-relaxed">
          Unlock your profile customizer, real-time analytics dashboards, security panels, and data tools by authenticating.
        </p>
        <button
          onClick={onOpenAuth}
          className="rounded-xl bg-primary px-6 py-3 text-xs font-bold text-[#0A0A0B] shadow-lg shadow-primary/10 hover:bg-primary-hover transition-all cursor-pointer"
          style={{ backgroundColor: "var(--primary)" }}
        >
          Enter the Sanctuary
        </button>
      </div>
    );
  }

  // Handle profile save
  const handleSaveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setErrorMsg("");
    setSuccessMsg("");

    try {
      const res = await fetch(`/api/user/${currentUser.id}/settings`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          username,
          statusMessage,
          avatarUrl,
          bannerColor,
          customStatus,
          socialLink
        })
      });

      const data = await res.json();
      if (res.ok) {
        onUpdateUser(data);
        setSuccessMsg("Sovereign profile successfully updated in Sanctuary records!");
        setTimeout(() => setSuccessMsg(""), 4000);
      } else {
        setErrorMsg(data.error || "Failed to update settings.");
      }
    } catch (err) {
      setErrorMsg("Connection to central sanctuary databases lost.");
    } finally {
      setLoading(false);
    }
  };

  // Handle password update
  const handleUpdatePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg("");
    setSuccessMsg("");

    if (newPassword !== confirmPassword) {
      setErrorMsg("Confirmation password shield does not match.");
      return;
    }

    if (newPassword.length < 6) {
      setErrorMsg("Your new password must contain at least 6 characters.");
      return;
    }

    setLoading(true);
    try {
      const res = await fetch(`/api/user/${currentUser.id}/change-password`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          currentPassword,
          newPassword
        })
      });

      const data = await res.json();
      if (res.ok) {
        setSuccessMsg("Cognitive security shield re-keyed successfully!");
        setCurrentPassword("");
        setNewPassword("");
        setConfirmPassword("");
        setTimeout(() => setSuccessMsg(""), 4000);
      } else {
        setErrorMsg(data.error || "Verification failed. Shield remains in active state.");
      }
    } catch (err) {
      setErrorMsg("Failed to re-key security coordinates.");
    } finally {
      setLoading(false);
    }
  };

  // Handle data export
  const handleExportData = async () => {
    try {
      const res = await fetch(`/api/user/${currentUser.id}/export`);
      if (res.ok) {
        const data = await res.json();
        const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(data, null, 2));
        const downloadAnchor = document.createElement("a");
        downloadAnchor.setAttribute("href", dataStr);
        downloadAnchor.setAttribute("download", `sovereign_mind_backup_${currentUser.username}.json`);
        document.body.appendChild(downloadAnchor);
        downloadAnchor.click();
        downloadAnchor.remove();
      } else {
        alert("Failed to export data from archive.");
      }
    } catch (err) {
      console.error(err);
    }
  };

  // Handle account deletion
  const handleDeleteAccount = async () => {
    const confirmation = confirm("CRITICAL ACCORD: Are you absolutely sure you want to permanently dissolve your Sovereign Sanctuary soul? This will immediately wipe your logs, milestones, streak history, and cannot be undone.");
    if (!confirmation) return;

    try {
      const res = await fetch(`/api/user/${currentUser.id}/delete`, {
        method: "DELETE"
      });
      if (res.ok) {
        alert("Your soul has been dissolved cleanly. Return to base.");
        onLogout();
      } else {
        alert("Failed to wipe database record.");
      }
    } catch (err) {
      console.error(err);
    }
  };

  // Mocked login history
  const loginHistory = [
    { ip: "84.22.190.11", date: "Just now", device: "Chrome / Linux Preview Tab", status: "Secure" },
    { ip: "84.22.190.11", date: "2 hours ago", device: "Vite Development Proxy", status: "Secure" },
    { ip: "216.58.214.14", date: "Yesterday at 14:23", device: "Simulated OAuth Token", status: "Closed" }
  ];

  return (
    <div id="sovereign-settings-container" className="mx-auto max-w-5xl px-4 py-8 sm:px-6 lg:px-8 space-y-8 animate-fade-in text-neutral-200">
      
      {/* Banner / Header Area */}
      <div className={`relative overflow-hidden rounded-3xl border border-[#1A1A1B] bg-gradient-to-r ${bannerColor} p-6 sm:p-8 shadow-sm flex flex-col md:flex-row items-center justify-between gap-6 transition-all duration-500`}>
        <div className="absolute top-0 right-0 h-40 w-40 bg-primary/5 rounded-full blur-3xl pointer-events-none" style={{ backgroundColor: "var(--primary-light)" }}></div>
        
        {/* User Card */}
        <div className="flex flex-col sm:flex-row items-center text-center sm:text-left space-y-4 sm:space-y-0 sm:space-x-5">
          <img 
            src={avatarUrl || currentUser.avatarUrl} 
            alt={username} 
            className="h-20 w-20 rounded-2xl border bg-[#0F0F10] object-cover shadow-lg"
            style={{ borderColor: "var(--primary-light)" }}
          />
          <div className="space-y-1">
            <div className="flex items-center justify-center sm:justify-start space-x-2">
              <h1 className="font-display text-xl font-bold tracking-tight text-neutral-100 sm:text-2xl">
                {currentUser.username}
              </h1>
              <span className="inline-block rounded-lg bg-primary/10 border px-2 py-0.5 text-[10px] font-bold text-primary uppercase tracking-wider" style={{ color: "var(--primary)", borderColor: "var(--primary-light)" }}>
                Lvl {currentUser.level}
              </span>
            </div>
            <p className="text-xs text-neutral-400 font-medium">
              {currentUser.title || "Elite Sovereign Scholar"}
            </p>
            {customStatus && (
              <span className="inline-flex items-center rounded-full bg-neutral-900/50 px-2.5 py-0.5 text-[10px] font-mono text-primary border" style={{ color: "var(--primary)", borderColor: "var(--primary-light)" }}>
                "{customStatus}"
              </span>
            )}
          </div>
        </div>

        {/* Action button */}
        <div className="flex items-center space-x-3">
          <button
            onClick={handleExportData}
            className="flex items-center space-x-1.5 rounded-xl border border-[#1A1A1B] bg-[#0A0A0B] px-4 py-2 text-xs font-bold text-neutral-300 hover:bg-[#161618] hover:text-[#E5E5E5] transition-all cursor-pointer"
            title="Download full backup of all data"
          >
            <Download className="h-4 w-4" />
            <span className="hidden sm:inline">Export Mind Data</span>
            <span className="sm:hidden">Export</span>
          </button>
          
          <button
            onClick={onLogout}
            className="flex items-center space-x-1.5 rounded-xl bg-rose-500/10 hover:bg-rose-500/20 border border-rose-500/25 px-4 py-2 text-xs font-bold text-rose-400 transition-all cursor-pointer"
          >
            <span>Leave Sanctuary</span>
          </button>
        </div>
      </div>

      {/* Navigation sub-tabs */}
      <div className="flex items-center space-x-1.5 border-b border-[#1A1A1B] pb-px overflow-x-auto scrollbar-none">
        {[
          { id: "profile", label: "Profile Command", icon: User },
          { id: "customization", label: "Customization & Vibe", icon: Sparkles },
          { id: "analytics", label: "Real-Time Analytics", icon: BarChart2 },
          { id: "security", label: "Shield Security", icon: Settings }
        ].map((tab) => {
          const Icon = tab.icon;
          const isActive = activeSubTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => {
                setActiveSubTab(tab.id as any);
                setSuccessMsg("");
                setErrorMsg("");
              }}
              className={`flex items-center space-x-2 border-b-2 px-4 py-3 text-xs font-bold transition-all whitespace-nowrap cursor-pointer ${
                isActive 
                  ? "text-primary" 
                  : "border-transparent text-neutral-500 hover:text-neutral-300"
              }`}
              style={{ borderColor: isActive ? "var(--primary)" : "transparent", color: isActive ? "var(--primary)" : undefined }}
            >
              <Icon className="h-4 w-4" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* Notifications and messages banner */}
      {(successMsg || errorMsg) && (
        <div className="animate-fade-in">
          {successMsg && (
            <div className="rounded-xl border border-emerald-500/20 bg-emerald-500/5 p-4 flex items-center space-x-3">
              <ShieldCheck className="h-5 w-5 text-emerald-400 shrink-0" />
              <p className="text-xs text-neutral-300">{successMsg}</p>
            </div>
          )}
          {errorMsg && (
            <div className="rounded-xl border border-rose-500/20 bg-rose-500/5 p-4 flex items-center space-x-3">
              <ShieldAlert className="h-5 w-5 text-rose-400 shrink-0" />
              <p className="text-xs text-neutral-300">{errorMsg}</p>
            </div>
          )}
        </div>
      )}

      {/* ================= SUBTAB: PROFILE CUSTOMIZATION ================= */}
      {activeSubTab === "profile" && (
        <div className="grid gap-6 md:grid-cols-12">
          {/* Customizer form */}
          <form onSubmit={handleSaveProfile} className="md:col-span-8 bg-[#0F0F10] border border-[#1A1A1B] rounded-2xl p-6 space-y-6">
            <h2 className="font-display text-base font-bold text-neutral-100 flex items-center space-x-2">
              <User className="h-4.5 w-4.5 text-amber-500" />
              <span>Personalize Mind Signature</span>
            </h2>

            <div className="grid gap-4 sm:grid-cols-2">
              {/* Username change */}
              <div className="space-y-1.5">
                <label className="text-[11px] font-bold text-neutral-400 uppercase tracking-wider block">Sovereign Username</label>
                <input
                  type="text"
                  required
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  placeholder="e.g. Marcus_Will"
                  className="w-full bg-[#0A0A0B] border border-[#1A1A1B] focus:border-amber-500 focus:outline-none rounded-xl px-3.5 py-2.5 text-xs text-neutral-200 transition-all"
                />
              </div>

              {/* Social links */}
              <div className="space-y-1.5">
                <label className="text-[11px] font-bold text-neutral-400 uppercase tracking-wider block">Social Network / Portfolio URL</label>
                <input
                  type="text"
                  value={socialLink}
                  onChange={(e) => setSocialLink(e.target.value)}
                  placeholder="e.g. github.com/Marcus"
                  className="w-full bg-[#0A0A0B] border border-[#1A1A1B] focus:border-amber-500 focus:outline-none rounded-xl px-3.5 py-2.5 text-xs text-neutral-200 transition-all"
                />
              </div>

              {/* Status Message */}
              <div className="space-y-1.5 sm:col-span-2">
                <label className="text-[11px] font-bold text-neutral-400 uppercase tracking-wider block">Leaderboard Bio Motto</label>
                <input
                  type="text"
                  value={statusMessage}
                  onChange={(e) => setStatusMessage(e.target.value)}
                  placeholder="e.g. Standing firm. Dopamine reset timeline in action."
                  maxLength={150}
                  className="w-full bg-[#0A0A0B] border border-[#1A1A1B] focus:border-amber-500 focus:outline-none rounded-xl px-3.5 py-2.5 text-xs text-neutral-200 transition-all"
                />
              </div>

              {/* Custom micro status */}
              <div className="space-y-1.5">
                <label className="text-[11px] font-bold text-neutral-400 uppercase tracking-wider block">Custom Status Pill</label>
                <input
                  type="text"
                  value={customStatus}
                  onChange={(e) => setCustomStatus(e.target.value)}
                  placeholder="e.g. 🧘 Mindful Mode"
                  maxLength={25}
                  className="w-full bg-[#0A0A0B] border border-[#1A1A1B] focus:border-amber-500 focus:outline-none rounded-xl px-3.5 py-2.5 text-xs text-neutral-200 transition-all"
                />
              </div>

              {/* Avatar Preset Select */}
              <div className="space-y-1.5 sm:col-span-2">
                <label className="text-[11px] font-bold text-neutral-400 uppercase tracking-wider block">Avatar Sigil Presets</label>
                <div className="flex flex-wrap gap-2.5">
                  {AVATAR_PRESETS.map((preset, idx) => (
                    <button
                      key={idx}
                      type="button"
                      onClick={() => setAvatarUrl(preset)}
                      className={`h-12 w-12 rounded-xl bg-[#0A0A0B] p-1 border transition-all cursor-pointer ${
                        avatarUrl === preset ? "border-amber-500 ring-2 ring-amber-500/20" : "border-[#1A1A1B]"
                      }`}
                    >
                      <img src={preset} alt={`Preset ${idx}`} className="h-full w-full object-cover rounded-lg" />
                    </button>
                  ))}
                  
                  {/* Custom URL Option */}
                  <input
                    type="text"
                    placeholder="Or paste custom image URL..."
                    value={avatarUrl}
                    onChange={(e) => setAvatarUrl(e.target.value)}
                    className="flex-1 bg-[#0A0A0B] border border-[#1A1A1B] focus:border-amber-500 focus:outline-none rounded-xl px-3.5 py-2 text-xs text-neutral-200 transition-all min-w-[200px]"
                  />
                </div>
              </div>

              {/* Banner Preset Select */}
              <div className="space-y-1.5 sm:col-span-2">
                <label className="text-[11px] font-bold text-neutral-400 uppercase tracking-wider block">Profile Card Banner Gradient</label>
                <div className="grid gap-2 sm:grid-cols-5">
                  {BANNER_PRESETS.map((bp) => (
                    <button
                      key={bp.name}
                      type="button"
                      onClick={() => setBannerColor(bp.css)}
                      className={`rounded-xl border p-2 text-left bg-gradient-to-r ${bp.css} transition-all cursor-pointer ${
                        bannerColor === bp.css ? "border-amber-500 ring-2 ring-amber-500/20" : "border-[#1A1A1B]"
                      }`}
                    >
                      <span className="text-[9px] font-bold text-[#E5E5E5] block truncate">{bp.name}</span>
                    </button>
                  ))}
                </div>
              </div>
            </div>

            <div className="pt-2 flex justify-end">
              <button
                type="submit"
                disabled={loading}
                className="rounded-xl bg-amber-500 hover:bg-amber-400 text-[#0A0A0B] text-xs font-bold px-6 py-2.5 transition-all cursor-pointer disabled:opacity-50"
              >
                {loading ? "Syncing coordinates..." : "Update Mind Signature"}
              </button>
            </div>
          </form>

          {/* Quick info card */}
          <div className="md:col-span-4 space-y-4">
            <div className="bg-[#0F0F10] border border-[#1A1A1B] rounded-2xl p-5 space-y-4">
              <h3 className="font-display font-bold text-xs uppercase tracking-wider text-amber-500">
                Sovereignty Level Perks
              </h3>
              <p className="text-xs text-neutral-400 leading-relaxed">
                As your level grows, you unlock rare cosmetic badges, custom status matrices, and higher visibility ranks on the scroll of honor.
              </p>
              
              <div className="space-y-3 pt-2 text-xs">
                <div className="flex justify-between items-center bg-[#0A0A0B] p-2.5 rounded-lg border border-[#1A1A1B]">
                  <span className="font-semibold text-neutral-300">Level 1 - 4</span>
                  <span className="text-amber-500 font-bold font-mono">Starter Sigil</span>
                </div>
                <div className="flex justify-between items-center bg-[#0A0A0B] p-2.5 rounded-lg border border-[#1A1A1B]">
                  <span className="font-semibold text-neutral-300">Level 5 - 9</span>
                  <span className="text-amber-500 font-bold font-mono">Sovereign Glow</span>
                </div>
                <div className="flex justify-between items-center bg-[#0A0A0B] p-2.5 rounded-lg border border-[#1A1A1B]">
                  <span className="font-semibold text-neutral-300">Level 10+</span>
                  <span className="text-amber-500 font-bold font-mono">Golden Accent</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ================= SUBTAB: CUSTOMIZATION & VIBE ================= */}
      {activeSubTab === "customization" && (
        <div className="grid gap-6 md:grid-cols-12 animate-fade-in text-neutral-200">
          {/* Main options column */}
          <div className="md:col-span-8 space-y-6">
            <div className="bg-[#0F0F10] border border-[#1A1A1B] rounded-2xl p-6 space-y-6">
              <div className="space-y-1">
                <h2 className="font-display text-base font-bold text-neutral-100 flex items-center space-x-2">
                  <Sparkles className="h-4.5 w-4.5 text-amber-500 animate-pulse" />
                  <span>Sovereign Interface Coordinates</span>
                </h2>
                <p className="text-xs text-neutral-400">
                  Configure the visual dimensions of your private recovery sanctuary. Adjust the aesthetic frequencies to matches your psychological state.
                </p>
              </div>

              {/* 1. Theme Picker */}
              <div className="space-y-3">
                <label className="text-[11px] font-bold text-neutral-400 uppercase tracking-wider block">
                  Select Core Theme
                </label>
                <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
                  {[
                    {
                      id: "dark",
                      name: "Sophisticated Dark",
                      desc: "Charcoal & pure gray accents for optimal nightly focus and calm thoughts.",
                      bg: "bg-[#0A0A0B]",
                      border: "border-[#1A1A1B]",
                      indicator: "bg-neutral-800"
                    },
                    {
                      id: "deep-night",
                      name: "Pure Deep Night",
                      desc: "Monochromatic dark velvet. Infinite contrast, maximum device power saving.",
                      bg: "bg-black",
                      border: "border-[#111112]",
                      indicator: "bg-zinc-900"
                    },
                    {
                      id: "light",
                      name: "Alabaster Sanctuary",
                      desc: "Pure whiter mode. Premium paper-white design for dynamic morning clarity.",
                      bg: "bg-[#FAF9F6]",
                      border: "border-slate-200",
                      indicator: "bg-slate-200"
                    },
                    {
                      id: "midnight",
                      name: "Midnight Cosmic",
                      desc: "Deep starry navy & oceanic indigo colors. Immersive celestial aesthetics.",
                      bg: "bg-[#070913]",
                      border: "border-[#1F274B]",
                      indicator: "bg-[#151A3C]"
                    },
                    {
                      id: "soft-gray",
                      name: "Soft Slate Gray",
                      desc: "Warm minimalist slate-gray matte texture. Soft on eyes, incredibly modern.",
                      bg: "bg-[#121315]",
                      border: "border-[#2A2D31]",
                      indicator: "bg-[#232529]"
                    },
                    {
                      id: "glassmorphism",
                      name: "Frosted Glass",
                      desc: "Hyper-translucent card layers with blur effects and organic gradient glows.",
                      bg: "bg-zinc-900/40",
                      border: "border-white/10",
                      indicator: "bg-purple-900/30"
                    },
                    {
                      id: "amoled",
                      name: "AMOLED Infinite Black",
                      desc: "True pitch-black pixels (#000000) with thin gray accents. Maximum battery conservation.",
                      bg: "bg-black",
                      border: "border-[#121212]",
                      indicator: "bg-neutral-900"
                    },
                    {
                      id: "glass",
                      name: "Liquid Glass",
                      desc: "Glossy neon translucent sheets with premium backdrop saturation filters and glow boundaries.",
                      bg: "bg-white/5",
                      border: "border-white/12",
                      indicator: "bg-white/10"
                    },
                    {
                      id: "ocean",
                      name: "Ocean Breeze",
                      desc: "Sub-aquatic deep marine hues with starry cyan glow, reminiscent of deep ocean depths.",
                      bg: "bg-[#020B19]",
                      border: "border-[#0C2445]",
                      indicator: "bg-[#082042]"
                    }
                  ].map((t) => {
                    const isSelected = theme === t.id;
                    return (
                      <button
                        key={t.id}
                        type="button"
                        onClick={() => onSetTheme(t.id as any)}
                        className={`group text-left p-4 rounded-xl border transition-all cursor-pointer flex flex-col justify-between h-36 ${
                          isSelected 
                            ? "bg-amber-500/5 border-amber-500 shadow-md shadow-amber-500/5" 
                            : "bg-[#0A0A0B] border-[#1A1A1B] hover:border-neutral-700 hover:bg-[#161618]/30"
                        }`}
                      >
                        <div className="space-y-1">
                          <span className={`text-xs font-bold block ${isSelected ? "text-amber-400" : "text-neutral-300 group-hover:text-neutral-100"}`}>
                            {t.name}
                          </span>
                          <span className="text-[10px] text-neutral-500 line-clamp-3 leading-relaxed">
                            {t.desc}
                          </span>
                        </div>
                        <div className="flex items-center space-x-1.5 mt-2">
                          <span className={`h-4 w-4 rounded-full border border-neutral-800 shrink-0 ${t.bg}`}></span>
                          <span className="text-[9px] font-mono font-semibold uppercase tracking-wider text-neutral-550">
                            {isSelected ? "Active Core" : "Select Coordinates"}
                          </span>
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* 2. Accent Color Picker */}
              <div className="space-y-3.5 pt-2">
                <label className="text-[11px] font-bold text-neutral-400 uppercase tracking-wider block">
                  Select Pulse Accent Color
                </label>
                <div className="grid gap-3 sm:grid-cols-6">
                  {[
                    { id: "emerald", name: "Healing Emerald", color: "bg-[#10b981]", text: "text-[#10b981]", hover: "hover:bg-[#10b981]/20", desc: "Green (Growth & Recovery)" },
                    { id: "amber", name: "Sovereign Gold", color: "bg-[#f59e0b]", text: "text-[#f59e0b]", hover: "hover:bg-[#f59e0b]/20", desc: "Gold (Focus & Wisdom)" },
                    { id: "indigo", name: "Oceanic Indigo", color: "bg-[#6366f1]", text: "text-[#6366f1]", hover: "hover:bg-[#6366f1]/20", desc: "Indigo (Calm & Serenity)" },
                    { id: "rose", name: "Compassion Rose", color: "bg-[#f43f5e]", text: "text-[#f43f5e]", hover: "hover:bg-[#f43f5e]/20", desc: "Crimson (Self-Love & Care)" },
                    { id: "violet", name: "Mystic Violet", color: "bg-[#8b5cf6]", text: "text-[#8b5cf6]", hover: "hover:bg-[#8b5cf6]/20", desc: "Purple (Purity & Energy)" },
                    { id: "orange", name: "Volcanic Orange", color: "bg-[#f97316]", text: "text-[#f97316]", hover: "hover:bg-[#f97316]/20", desc: "Orange (Energy & Radiance)" }
                  ].map((acc) => {
                    const isSelected = accentColor === acc.id;
                    return (
                      <button
                        key={acc.id}
                        type="button"
                        onClick={() => onSetAccentColor(acc.id as any)}
                        className={`p-3 rounded-xl border text-center transition-all cursor-pointer flex flex-col items-center space-y-2 ${
                          isSelected 
                            ? "bg-neutral-900 border-amber-500 shadow-sm" 
                            : "bg-[#0A0A0B] border-[#1A1A1B] hover:border-neutral-700"
                        }`}
                      >
                        <span className={`h-6.5 w-6.5 rounded-full ${acc.color} shadow-inner shrink-0 relative flex items-center justify-center`}>
                          {isSelected && (
                            <span className="absolute inset-0 rounded-full border-2 border-neutral-900 animate-ping"></span>
                          )}
                        </span>
                        <div className="space-y-0.5">
                          <span className={`text-[10px] font-bold block ${isSelected ? "text-amber-400" : "text-neutral-450"}`}>
                            {acc.name.split(" ")[1]}
                          </span>
                          <span className="text-[8px] text-neutral-550 whitespace-nowrap">{acc.desc.split(" ")[0]}</span>
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* 3. Glassmorphism Switch */}
              <div className="border-t border-[#1A1A1B] pt-5 flex items-start justify-between gap-6">
                <div className="space-y-1 max-w-lg">
                  <label className="text-[11px] font-bold text-neutral-400 uppercase tracking-wider block">
                    Atmospheric Glassmorphism (Frosted Layering)
                  </label>
                  <p className="text-xs text-neutral-400 leading-relaxed">
                    Introduces a beautiful physical realism effect by blending background-saturation, frosted backdrop-blur, and ultra-fine highlight borders into cards and overlays. Requires modern hardware acceleration.
                  </p>
                </div>

                <button
                  type="button"
                  onClick={() => onSetGlassmorphism(!glassmorphism)}
                  className={`relative inline-flex h-6 w-11 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none ${
                    glassmorphism ? "bg-amber-500" : "bg-neutral-800"
                  }`}
                >
                  <span
                    className={`pointer-events-none inline-block h-5 w-5 transform rounded-full bg-[#0F0F10] shadow ring-0 transition duration-200 ease-in-out ${
                      glassmorphism ? "translate-x-5" : "translate-x-0"
                    }`}
                  />
                </button>
              </div>

              {/* 4. Accessibility Panel */}
              <div className="border-t border-[#1A1A1B] pt-6 space-y-5">
                <div className="space-y-1">
                  <h3 className="text-xs font-bold text-neutral-200 uppercase tracking-widest flex items-center space-x-2">
                    <Settings className="h-4 w-4 text-amber-500" />
                    <span>Sensory & Accessibility Coordinates</span>
                  </h3>
                  <p className="text-[11px] text-neutral-450 leading-relaxed">
                    Configure high-contrast parameters, disable active visual motions, and adjust font sizes for long-form comfort.
                  </p>
                </div>

                <div className="grid gap-6 md:grid-cols-2">
                  {/* Font Size Selector */}
                  <div className="space-y-2.5">
                    <label className="text-[10px] font-bold text-neutral-450 uppercase tracking-wider block">
                      Core Font Size
                    </label>
                    <div className="flex rounded-xl bg-[#0A0A0B] border border-[#1A1A1B] p-1">
                      {[
                        { id: "normal", name: "Standard" },
                        { id: "medium", name: "Medium (110%)" },
                        { id: "large", name: "Large (120%)" }
                      ].map((sz) => {
                        const isSel = fontSize === sz.id;
                        return (
                          <button
                            key={sz.id}
                            type="button"
                            onClick={() => onSetFontSize(sz.id as any)}
                            className={`flex-1 text-center py-2 text-[10px] font-bold rounded-lg cursor-pointer transition-all ${
                              isSel 
                                ? "bg-amber-500 text-[#0A0A0B] shadow-sm font-black" 
                                : "text-neutral-450 hover:text-neutral-300"
                            }`}
                          >
                            {sz.name}
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  {/* Accessibility Switches */}
                  <div className="space-y-4">
                    {/* Reduced Motion Toggle */}
                    <div className="flex items-center justify-between">
                      <div className="space-y-0.5 max-w-xs">
                        <label className="text-[10px] font-bold text-neutral-400 uppercase tracking-wider block">
                          Reduced Motion
                        </label>
                        <p className="text-[10px] text-neutral-500">
                          Disables dynamic page sweeps, pulse ripples, and breathing loops.
                        </p>
                      </div>
                      <button
                        type="button"
                        onClick={() => onSetReducedMotion(!reducedMotion)}
                        className={`relative inline-flex h-5 w-10 shrink-0 cursor-pointer rounded-full border border-transparent transition-colors duration-200 ease-in-out focus:outline-none ${
                          reducedMotion ? "bg-amber-500" : "bg-neutral-800"
                        }`}
                      >
                        <span
                          className={`pointer-events-none inline-block h-4.5 w-4.5 transform rounded-full bg-[#0F0F10] shadow ring-0 transition duration-200 ease-in-out ${
                            reducedMotion ? "translate-x-5" : "translate-x-0"
                          }`}
                        />
                      </button>
                    </div>

                    {/* High Contrast Toggle */}
                    <div className="flex items-center justify-between border-t border-[#1A1A1B]/50 pt-3.5">
                      <div className="space-y-0.5 max-w-xs">
                        <label className="text-[10px] font-bold text-neutral-400 uppercase tracking-wider block">
                          High Contrast Outlines
                        </label>
                        <p className="text-[10px] text-neutral-500">
                          Increases border contrast and simplifies text hierarchies.
                        </p>
                      </div>
                      <button
                        type="button"
                        onClick={() => onSetHighContrast(!highContrast)}
                        className={`relative inline-flex h-5 w-10 shrink-0 cursor-pointer rounded-full border border-transparent transition-colors duration-200 ease-in-out focus:outline-none ${
                          highContrast ? "bg-amber-500" : "bg-neutral-800"
                        }`}
                      >
                        <span
                          className={`pointer-events-none inline-block h-4.5 w-4.5 transform rounded-full bg-[#0F0F10] shadow ring-0 transition duration-200 ease-in-out ${
                            highContrast ? "translate-x-5" : "translate-x-0"
                          }`}
                        />
                      </button>
                    </div>

                    {/* Premium Custom Cursor Toggle */}
                    <div className="flex items-center justify-between border-t border-[#1A1A1B]/50 pt-3.5">
                      <div className="space-y-0.5 max-w-xs">
                        <label className="text-[10px] font-bold text-neutral-400 uppercase tracking-wider block">
                          Premium Custom Cursor
                        </label>
                        <p className="text-[10px] text-neutral-500">
                          Enables a fluid, interpolating custom cursor with micro-hover and click reactions. (Desktop only)
                        </p>
                      </div>
                      <button
                        type="button"
                        onClick={() => onSetCustomCursor(!customCursor)}
                        className={`relative inline-flex h-5 w-10 shrink-0 cursor-pointer rounded-full border border-transparent transition-colors duration-200 ease-in-out focus:outline-none ${
                          customCursor ? "bg-amber-500" : "bg-neutral-800"
                        }`}
                      >
                        <span
                          className={`pointer-events-none inline-block h-4.5 w-4.5 transform rounded-full bg-[#0F0F10] shadow ring-0 transition duration-200 ease-in-out ${
                            customCursor ? "translate-x-5" : "translate-x-0"
                          }`}
                        />
                      </button>
                    </div>
                  </div>
                </div>
              </div>

            </div>
          </div>

          {/* Interactive Preview Sidebar */}
          <div className="md:col-span-4 space-y-4">
            <div className="bg-[#0F0F10] border border-[#1A1A1B] rounded-2xl p-5 space-y-4">
              <h3 className="font-display font-bold text-xs uppercase tracking-wider text-amber-500">
                Aesthetic Telemetry Preview
              </h3>
              <p className="text-xs text-neutral-450 leading-relaxed">
                Interact with the dynamic coordinate card below to experience the current theme filter settings instantly:
              </p>

              {/* Real Glassmorphism Card Sample */}
              <div className={`p-5 rounded-2xl border transition-all duration-300 relative overflow-hidden flex flex-col justify-between h-44 ${
                glassmorphism ? "bg-[#0F0F10]/30 backdrop-blur-md border-white/15" : "bg-[#0A0A0B] border-[#1A1A1B]"
              }`}>
                {/* Simulated colorful blurred spot inside preview */}
                {glassmorphism && (
                  <div className="absolute -top-10 -right-10 h-28 w-28 bg-gradient-to-tr from-amber-500/20 to-purple-500/20 rounded-full blur-2xl pointer-events-none"></div>
                )}
                
                <div>
                  <div className="flex items-center justify-between">
                    <span className="text-[9px] font-mono font-bold tracking-widest text-neutral-500 uppercase block">Sanctuary Node</span>
                    <span className="h-2 w-2 rounded-full bg-emerald-500 animate-ping"></span>
                  </div>
                  <h4 className="font-display font-bold text-sm text-neutral-200 mt-2">Mind Resonance Monitor</h4>
                  <p className="text-[10px] text-neutral-450 leading-relaxed mt-1">
                    Frosted filters are active. Sensory feedback parameters adjusted to optimal grounding.
                  </p>
                </div>

                <div className="flex items-center justify-between border-t border-neutral-900/40 pt-2.5 mt-2">
                  <span className="text-[9px] font-mono text-neutral-550 font-semibold uppercase">Freq: 82Hz</span>
                  <span className="text-[10px] font-bold text-amber-500">Lv.14 Secure</span>
                </div>
              </div>

              <div className="rounded-xl bg-amber-500/5 border border-amber-500/10 p-3 text-[10px] text-neutral-400 leading-relaxed">
                <strong>💡 Tip:</strong> You can also quickly switch themes by pressing the <kbd className="border border-neutral-800 bg-[#0A0A0B] px-1 py-0.25 rounded text-[9px] font-mono text-neutral-400">T</kbd> key anywhere on your keyboard, or open the Command Palette with <kbd className="border border-neutral-800 bg-[#0A0A0B] px-1 py-0.25 rounded text-[9px] font-mono text-neutral-400">Ctrl+K</kbd>!
              </div>
            </div>
          </div>
        </div>
      )}
      {activeSubTab === "analytics" && (
        <div className="space-y-6">
          
          {/* Key Metric Dials */}
          <div className="grid gap-4 sm:grid-cols-4">
            <div className="rounded-2xl border border-[#1A1A1B] bg-[#0F0F10] p-4 space-y-2">
              <span className="text-[10px] font-bold text-neutral-500 uppercase tracking-widest block">Mind Purity Coefficient</span>
              <div className="flex items-baseline space-x-2">
                <span className="text-2xl font-display font-black text-amber-500">
                  {currentUser.logs ? Math.min(100, Math.floor((currentUser.logs.filter(l => l.cleanDay).length || 1) * 12.5)) : 82}%
                </span>
                <span className="text-[10px] font-bold text-emerald-500">+4.2% today</span>
              </div>
              <p className="text-[10px] text-neutral-500 leading-relaxed">Based on weekly successful daily task metrics & clean check-ins.</p>
            </div>

            <div className="rounded-2xl border border-[#1A1A1B] bg-[#0F0F10] p-4 space-y-2">
              <span className="text-[10px] font-bold text-neutral-500 uppercase tracking-widest block">Limbic Trigger Defenses</span>
              <div className="flex items-baseline space-x-2">
                <span className="text-2xl font-display font-black text-amber-500">
                  {currentUser.triggers ? currentUser.triggers.length : 3} Logged
                </span>
                <span className="text-[10px] font-bold text-neutral-400">100% defused</span>
              </div>
              <p className="text-[10px] text-neutral-500 leading-relaxed">Conscious logs written to dismantle automatic trigger responses.</p>
            </div>

            <div className="rounded-2xl border border-[#1A1A1B] bg-[#0F0F10] p-4 space-y-2">
              <span className="text-[10px] font-bold text-neutral-500 uppercase tracking-widest block">Prefrontal Willpower Level</span>
              <div className="flex items-baseline space-x-2">
                <span className="text-2xl font-display font-black text-amber-500">Lv {currentUser.level}</span>
                <span className="text-[10px] font-bold text-amber-400">{currentUser.totalXp} XP</span>
              </div>
              <p className="text-[10px] text-neutral-500 leading-relaxed">Accumulating XP from checklists, Stoic passages, & SOS deep breathing.</p>
            </div>

            <div className="rounded-2xl border border-[#1A1A1B] bg-[#0F0F10] p-4 space-y-2">
              <span className="text-[10px] font-bold text-neutral-500 uppercase tracking-widest block">Sacred Streak Freeze Pool</span>
              <div className="flex items-baseline space-x-2">
                <span className="text-2xl font-display font-black text-amber-500">
                  {currentUser.streakFreezes !== undefined ? currentUser.streakFreezes : 1} Shielded
                </span>
                <span className="text-[10px] font-bold text-emerald-400">Next: Month Start</span>
              </div>
              <p className="text-[10px] text-neutral-500 leading-relaxed">Protective filters that safeguard your hard work from stumbles.</p>
            </div>
          </div>

          {/* Activity Timeline and To-Do lists */}
          <div className="grid gap-6 md:grid-cols-12">
            
            {/* Timeline logs */}
            <div className="md:col-span-7 bg-[#0F0F10] border border-[#1A1A1B] rounded-2xl p-6 space-y-4">
              <h3 className="font-display text-sm font-bold text-neutral-100 flex items-center space-x-2">
                <Activity className="h-4.5 w-4.5 text-amber-500" />
                <span>Live Sovereignty Activity Timeline</span>
              </h3>

              <div className="space-y-4 relative before:absolute before:left-3 before:top-2 before:bottom-2 before:w-px before:bg-[#1A1A1B] pl-6">
                {currentUser.logs && currentUser.logs.length > 0 ? (
                  currentUser.logs.slice(-4).reverse().map((log) => (
                    <div key={log.id} className="relative space-y-1">
                      <span className={`absolute -left-7.5 h-3.5 w-3.5 rounded-full border border-[#0F0F10] ${
                        log.cleanDay ? "bg-emerald-500" : "bg-rose-500"
                      }`}></span>
                      <div className="flex items-center justify-between">
                        <strong className="text-xs text-neutral-200">{log.note}</strong>
                        <span className="text-[9px] font-mono font-bold text-neutral-500">{log.date}</span>
                      </div>
                      <p className="text-[10px] text-neutral-450 italic">Mood identified as {log.mood}. Streak state: {log.cleanDay ? "Pure" : "Reset"}</p>
                    </div>
                  ))
                ) : (
                  <>
                    <div className="relative space-y-1">
                      <span className="absolute -left-7.5 h-3.5 w-3.5 rounded-full bg-amber-500 border border-[#0F0F10]"></span>
                      <div className="flex items-center justify-between">
                        <strong className="text-xs text-neutral-200">Enrolled in Purity Path</strong>
                        <span className="text-[9px] font-mono font-bold text-neutral-500">Today</span>
                      </div>
                      <p className="text-[10px] text-neutral-450 leading-relaxed">Secured Google/Local authentication parameters. Starter gift of 100 Focus XP credited.</p>
                    </div>
                    <div className="relative space-y-1">
                      <span className="absolute -left-7.5 h-3.5 w-3.5 rounded-full bg-neutral-600 border border-[#0F0F10]"></span>
                      <div className="flex items-center justify-between">
                        <strong className="text-xs text-neutral-200">First Mind Shield Programmed</strong>
                        <span className="text-[9px] font-mono font-bold text-neutral-500">Today</span>
                      </div>
                      <p className="text-[10px] text-neutral-450 leading-relaxed">Custom habit metrics loaded to tracking chronometers.</p>
                    </div>
                  </>
                )}
              </div>
            </div>

            {/* Quick Actions & Saved items */}
            <div className="md:col-span-5 space-y-4">
              <div className="bg-[#0F0F10] border border-[#1A1A1B] rounded-2xl p-5 space-y-4">
                <h3 className="font-display font-bold text-xs uppercase tracking-wider text-amber-500 flex items-center space-x-1.5">
                  <ListTodo className="h-4 w-4" />
                  <span>Sovereign Quick Actions</span>
                </h3>
                
                <div className="grid gap-2.5 text-xs">
                  <button 
                    onClick={() => {
                      const cbtBtn = document.getElementById("tab-btn-sos");
                      if (cbtBtn) cbtBtn.click();
                    }}
                    className="w-full flex items-center justify-between rounded-xl bg-[#0A0A0B] p-3 text-left hover:bg-[#161618] transition-all border border-[#1A1A1B] hover:border-amber-500/25 cursor-pointer"
                  >
                    <div>
                      <strong className="text-neutral-200 block text-xs">Calm Autonomic Nervous System</strong>
                      <span className="text-[10px] text-neutral-500 mt-0.5">Activate parasympathetic breathing anchor</span>
                    </div>
                    <ChevronRight className="h-4 w-4 text-amber-500 shrink-0" />
                  </button>

                  <button 
                    onClick={() => {
                      const mBtn = document.getElementById("tab-btn-mentor");
                      if (mBtn) mBtn.click();
                    }}
                    className="w-full flex items-center justify-between rounded-xl bg-[#0A0A0B] p-3 text-left hover:bg-[#161618] transition-all border border-[#1A1A1B] hover:border-amber-500/25 cursor-pointer"
                  >
                    <div>
                      <strong className="text-neutral-200 block text-xs">Inquire Stoic Solutions</strong>
                      <span className="text-[10px] text-neutral-500 mt-0.5">Prompt your clinical AI recovery coach</span>
                    </div>
                    <ChevronRight className="h-4 w-4 text-amber-500 shrink-0" />
                  </button>
                </div>
              </div>

              {/* Saved Stoic Coordinates */}
              <div className="bg-[#0F0F10] border border-[#1A1A1B] rounded-2xl p-5 space-y-3.5">
                <h3 className="font-display font-bold text-xs uppercase tracking-wider text-neutral-400 block">Saved Core Coordinates</h3>
                <p className="text-[11px] text-neutral-400 leading-relaxed">
                  Keeping your coordinates close builds a cognitive fortress. Access stoic maxims and scientific paradigms anytime.
                </p>
                <div className="border border-[#1A1A1B] bg-[#0A0A0B] p-3 rounded-xl">
                  <span className="text-[9px] font-bold text-amber-500 block uppercase tracking-wider font-mono mb-1">CBT Rule of Thumb</span>
                  <p className="text-[10px] text-neutral-400 leading-normal italic">"You feel what you think. Thoughts lead to chemistry. Chemistry leads to actions."</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ================= SUBTAB: SECURITY & DANGER ZONE ================= */}
      {activeSubTab === "security" && (
        <div className="grid gap-6 md:grid-cols-12">
          
          {/* Change Password Panel */}
          <div className="md:col-span-8 space-y-6">
            <form onSubmit={handleUpdatePassword} className="bg-[#0F0F10] border border-[#1A1A1B] rounded-2xl p-6 space-y-5">
              <h2 className="font-display text-base font-bold text-neutral-100 flex items-center space-x-2">
                <Key className="h-4.5 w-4.5 text-amber-500" />
                <span>Re-Key Cognitive Security Shield</span>
              </h2>

              <p className="text-xs text-neutral-400 leading-relaxed">
                Re-keying your account password guarantees that your private journal reflections, daily targets, and clinical CBT logs remain strictly protected on your terms.
              </p>

              <div className="space-y-4 pt-1">
                {/* Current password if they have one */}
                {!currentUser.password?.startsWith("google_oauth_authorized_") && (
                  <div className="space-y-1.5">
                    <label className="text-[11px] font-bold text-neutral-400 uppercase tracking-wider block">Current Shield Password</label>
                    <input
                      type="password"
                      required
                      value={currentPassword}
                      onChange={(e) => setCurrentPassword(e.target.value)}
                      placeholder="Enter current password..."
                      className="w-full bg-[#0A0A0B] border border-[#1A1A1B] focus:border-amber-500 focus:outline-none rounded-xl px-3.5 py-2.5 text-xs text-neutral-200 transition-all"
                    />
                  </div>
                )}

                {/* New password input */}
                <div className="grid gap-4 sm:grid-cols-2">
                  <div className="space-y-1.5">
                    <label className="text-[11px] font-bold text-neutral-400 uppercase tracking-wider block">New Sovereign Password</label>
                    <input
                      type="password"
                      required
                      value={newPassword}
                      onChange={(e) => setNewPassword(e.target.value)}
                      placeholder="At least 6 characters..."
                      className="w-full bg-[#0A0A0B] border border-[#1A1A1B] focus:border-amber-500 focus:outline-none rounded-xl px-3.5 py-2.5 text-xs text-neutral-200 transition-all"
                    />
                  </div>

                  <div className="space-y-1.5">
                    <label className="text-[11px] font-bold text-neutral-400 uppercase tracking-wider block">Confirm New Password</label>
                    <input
                      type="password"
                      required
                      value={confirmPassword}
                      onChange={(e) => setConfirmPassword(e.target.value)}
                      placeholder="Verify coordinates..."
                      className="w-full bg-[#0A0A0B] border border-[#1A1A1B] focus:border-amber-500 focus:outline-none rounded-xl px-3.5 py-2.5 text-xs text-neutral-200 transition-all"
                    />
                  </div>
                </div>
              </div>

              <div className="pt-2 flex justify-end">
                <button
                  type="submit"
                  disabled={loading}
                  className="rounded-xl bg-amber-500 hover:bg-amber-400 text-[#0A0A0B] text-xs font-bold px-6 py-2.5 transition-all cursor-pointer disabled:opacity-50"
                >
                  {loading ? "Re-keying lock..." : "Update Password Shield"}
                </button>
              </div>
            </form>

            {/* Login History Terminal */}
            <div className="bg-[#0F0F10] border border-[#1A1A1B] rounded-2xl p-6 space-y-4">
              <h3 className="font-display text-xs font-bold uppercase tracking-wider text-neutral-400 block">Sovereign Gate Entry Log</h3>
              <p className="text-xs text-neutral-400 leading-relaxed">
                Monitors active sessions and locations accessing your cognitive shield archives. Zero third-party auditing is permitted.
              </p>

              <div className="border border-[#1A1A1B] rounded-xl overflow-hidden text-xs">
                <div className="grid grid-cols-4 bg-[#0A0A0B] p-2.5 font-bold text-neutral-500 border-b border-[#1A1A1B]">
                  <div>Security IP</div>
                  <div>Gate Date</div>
                  <div className="col-span-2">Device Specification</div>
                </div>
                {loginHistory.map((lh, idx) => (
                  <div key={idx} className="grid grid-cols-4 p-3 gap-3 border-b border-[#1A1A1B]/50 last:border-b-0">
                    <div className="font-mono text-[11px] text-neutral-300">{lh.ip}</div>
                    <div className="text-neutral-400">{lh.date}</div>
                    <div className="text-neutral-500 col-span-2 truncate flex items-center justify-between">
                      <span>{lh.device}</span>
                      <span className="text-[10px] bg-emerald-500/10 text-emerald-400 px-1.5 py-0.25 rounded font-mono font-bold uppercase">{lh.status}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Danger zone / Account Deletion */}
          <div className="md:col-span-4 space-y-4">
            <div className="bg-[#0F0F10] border border-rose-500/15 bg-gradient-to-b from-rose-500/5 to-transparent rounded-2xl p-5 space-y-4">
              <h3 className="font-display font-bold text-xs uppercase tracking-wider text-rose-400 flex items-center space-x-1.5">
                <ShieldAlert className="h-4.5 w-4.5 text-rose-400 shrink-0" />
                <span>Sanctuary Danger Zone</span>
              </h3>
              <p className="text-xs text-neutral-400 leading-relaxed">
                These steps wipe all records from cloud and local servers. Wiped coordinates cannot be restored.
              </p>

              <div className="pt-2">
                <button
                  onClick={handleDeleteAccount}
                  className="w-full flex items-center justify-center space-x-2 rounded-xl bg-rose-500/10 hover:bg-rose-500/20 border border-rose-500/20 px-4 py-2.5 text-xs font-bold text-rose-400 transition-all cursor-pointer"
                >
                  <Trash2 className="h-4 w-4" />
                  <span>Permanently Wipe Account</span>
                </button>
              </div>
            </div>
          </div>

        </div>
      )}

    </div>
  );
}
