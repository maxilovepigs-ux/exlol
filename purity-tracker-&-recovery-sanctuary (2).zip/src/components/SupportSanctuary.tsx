/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from "react";
import { 
  LifeBuoy, 
  Brain, 
  UserCheck, 
  Plus, 
  Send, 
  CheckCircle2, 
  Clock, 
  HelpCircle, 
  User, 
  FileText,
  ShieldAlert,
  ArrowLeft,
  Lock,
  RefreshCw,
  Sparkles
} from "lucide-react";
import { User as UserType, SupportTicket, SupportMessage } from "../types";

interface SupportSanctuaryProps {
  currentUser: UserType | null;
  onOpenAuth: () => void;
}

export default function SupportSanctuary({
  currentUser,
  onOpenAuth
}: SupportSanctuaryProps) {
  const isMod = currentUser?.username === "ollymckee101" || currentUser?.role === "moderator" || currentUser?.role === "admin";

  const [tickets, setTickets] = useState<SupportTicket[]>([]);
  const [loading, setLoading] = useState<boolean>(false);
  const [activeTicket, setActiveTicket] = useState<SupportTicket | null>(null);
  
  // Create ticket states
  const [showCreate, setShowCreate] = useState<boolean>(false);
  const [ticketTitle, setTicketTitle] = useState<string>("");
  const [ticketType, setTicketType] = useState<"ai" | "real">("ai");
  const [ticketMessage, setTicketMessage] = useState<string>("");
  const [createLoading, setCreateLoading] = useState<boolean>(false);

  // Send message states
  const [replyInput, setReplyInput] = useState<string>("");
  const [sendLoading, setSendLoading] = useState<boolean>(false);

  // Admin filter states
  const [adminFilter, setAdminFilter] = useState<"all" | "open" | "resolved">("open");

  // Admin / Moderator Extended Dashboard States
  const [adminSubTab, setAdminSubTab] = useState<"tickets" | "security" | "roles">("tickets");
  const [securityLogs, setSecurityLogs] = useState<any[]>([]);
  const [securityLoading, setSecurityLoading] = useState<boolean>(false);
  const [usersList, setUsersList] = useState<any[]>([]);
  const [usersLoading, setUsersLoading] = useState<boolean>(false);
  const [adminStatusMessage, setAdminStatusMessage] = useState<string | null>(null);

  const fetchSecurityLogs = async () => {
    if (!currentUser) return;
    setSecurityLoading(true);
    try {
      const res = await fetch(`/api/admin/security-logs?requesterId=${currentUser.id}`);
      if (res.ok) {
        const data = await res.json();
        setSecurityLogs(data);
      }
    } catch (err) {
      console.error("Error fetching security logs:", err);
    } finally {
      setSecurityLoading(false);
    }
  };

  const fetchUsersList = async () => {
    if (!currentUser) return;
    setUsersLoading(true);
    try {
      const res = await fetch(`/api/admin/roles?requesterId=${currentUser.id}`);
      if (res.ok) {
        const data = await res.json();
        setUsersList(data);
      }
    } catch (err) {
      console.error("Error fetching users list:", err);
    } finally {
      setUsersLoading(false);
    }
  };

  const handleUpdateRole = async (targetUserId: string, newRole: string) => {
    if (!currentUser) return;
    setAdminStatusMessage(null);
    try {
      const res = await fetch("/api/admin/roles", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          requesterId: currentUser.id,
          targetUserId,
          newRole
        })
      });
      if (res.ok) {
        fetchUsersList();
        setAdminStatusMessage("Success: User role has been updated.");
        setTimeout(() => setAdminStatusMessage(null), 4000);
      } else {
        const errData = await res.json();
        setAdminStatusMessage(`Error: ${errData.error || "Failed to update role."}`);
      }
    } catch (err) {
      console.error("Failed to update user role:", err);
      setAdminStatusMessage("Error: Failed to connect to serverless worker.");
    }
  };

  const messageEndRef = useRef<HTMLDivElement>(null);

  // Fetch tickets for active user or all tickets for mod
  const fetchTickets = async () => {
    setLoading(true);
    try {
      const url = currentUser 
        ? `/api/support/tickets?userId=${currentUser.id}&username=${currentUser.username}` 
        : `/api/support/tickets`;
      const res = await fetch(url);
      if (res.ok) {
        const data = await res.json();
        setTickets(data);
        
        // If we have an active ticket open, update its state from the fetched list
        if (activeTicket) {
          const updated = data.find((t: SupportTicket) => t.id === activeTicket.id);
          if (updated) {
            setActiveTicket(updated);
          }
        }
      }
    } catch (err) {
      console.error("Error fetching support tickets:", err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchTickets();
  }, [currentUser]);

  // Keep chat scrolled to bottom
  useEffect(() => {
    messageEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [activeTicket?.messages]);

  const handleCreateTicket = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!ticketTitle.trim() || !ticketMessage.trim()) return;

    if (!currentUser) {
      onOpenAuth();
      return;
    }

    setCreateLoading(true);
    try {
      const res = await fetch("/api/support/tickets", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          userId: currentUser.id,
          username: currentUser.username,
          avatarUrl: currentUser.avatarUrl,
          title: ticketTitle.trim(),
          type: ticketType,
          initialMessage: ticketMessage.trim()
        })
      });

      if (res.ok) {
        const newTicket = await res.json();
        setTickets(prev => [...prev, newTicket]);
        setActiveTicket(newTicket);
        setTicketTitle("");
        setTicketMessage("");
        setShowCreate(false);
      }
    } catch (err) {
      console.error("Failed to create support ticket:", err);
    } finally {
      setCreateLoading(false);
    }
  };

  const handleSendReply = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!replyInput.trim() || !activeTicket) return;

    if (!currentUser) {
      onOpenAuth();
      return;
    }

    setSendLoading(true);
    try {
      const res = await fetch(`/api/support/tickets/${activeTicket.id}/messages`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          userId: currentUser.id,
          username: currentUser.username,
          text: replyInput.trim()
        })
      });

      if (res.ok) {
        const updatedTicket = await res.json();
        // Update local state list
        setTickets(prev => prev.map(t => t.id === updatedTicket.id ? updatedTicket : t));
        setActiveTicket(updatedTicket);
        setReplyInput("");
      }
    } catch (err) {
      console.error(err);
    } finally {
      setSendLoading(false);
    }
  };

  const handleResolveTicket = async (ticketId: string) => {
    try {
      const res = await fetch(`/api/support/tickets/${ticketId}/resolve`, {
        method: "POST"
      });
      if (res.ok) {
        const updated = await res.json();
        setTickets(prev => prev.map(t => t.id === updated.id ? updated : t));
        if (activeTicket?.id === ticketId) {
          setActiveTicket(updated);
        }
      }
    } catch (err) {
      console.error(err);
    }
  };

  // Filter tickets for Mod view
  const getFilteredTickets = () => {
    if (adminFilter === "all") return tickets;
    return tickets.filter(t => t.status === adminFilter);
  };

  const filteredTickets = getFilteredTickets();

  // Sort tickets by creation date descending
  const sortedTickets = [...filteredTickets].sort((a, b) => 
    new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
  );

  return (
    <div id="support-sanctuary" className="max-w-5xl mx-auto space-y-6 animate-fade-in text-neutral-200">
      
      {/* EXCLUSIVE MODERATOR HEADER */}
      {isMod ? (
        <div className="rounded-2xl border border-purple-500/25 bg-purple-500/5 p-6 shadow-sm flex items-start space-x-4">
          <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-purple-500/10 text-purple-400 border border-purple-500/20 shrink-0">
            <ShieldAlert className="h-5.5 w-5.5" />
          </div>
          <div className="flex-1">
            <div className="flex items-center space-x-2">
              <h2 className="font-display text-lg font-bold text-purple-300">Sovereign Moderator Dashboard</h2>
              <span className="bg-purple-500 text-[#0A0A0B] text-[9px] font-black uppercase px-2 py-0.5 rounded tracking-wider">
                MODERATOR ACCESS
              </span>
            </div>
            <p className="mt-1 text-xs text-neutral-400 leading-relaxed">
              You are signed in as a Sovereign Moderator. You have administrative control over the support channels. Read issues, resolve technical problems, and coordinate manual support replies.
            </p>
          </div>
        </div>
      ) : (
        /* STANDARD USER HELP HEADER */
        <div className="rounded-2xl border border-neutral-850 bg-[#0F0F10] p-6 shadow-sm flex items-start space-x-4">
          <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-amber-500/10 text-amber-500 border border-amber-500/20 shrink-0">
            <LifeBuoy className="h-5.5 w-5.5" />
          </div>
          <div>
            <h2 className="font-display text-lg font-bold text-neutral-100">Sanctuary Support Sanctuary</h2>
            <p className="mt-1 text-xs text-neutral-400 leading-relaxed">
              Facing clock issues, XP discrepancies, or setup challenges? Consult our instant, clinically grounded **AI Support Bot** or open a secure **Real Support Ticket** for our moderator panel to review.
            </p>
          </div>
        </div>
      )}

      {isMod && (
        <div className="flex border-b border-[#1A1A1B] pb-1 space-x-6">
          <button
            onClick={() => setAdminSubTab("tickets")}
            className={`pb-2 text-xs font-bold transition-all border-b-2 ${
              adminSubTab === "tickets" ? "border-purple-500 text-purple-300" : "border-transparent text-neutral-450 hover:text-neutral-300"
            }`}
          >
            Support Cases
          </button>
          <button
            onClick={() => {
              setAdminSubTab("security");
              fetchSecurityLogs();
            }}
            className={`pb-2 text-xs font-bold transition-all border-b-2 ${
              adminSubTab === "security" ? "border-purple-500 text-purple-300" : "border-transparent text-neutral-450 hover:text-neutral-300"
            }`}
          >
            🛡️ Security Monitors
          </button>
          <button
            onClick={() => {
              setAdminSubTab("roles");
              fetchUsersList();
            }}
            className={`pb-2 text-xs font-bold transition-all border-b-2 ${
              adminSubTab === "roles" ? "border-purple-500 text-purple-300" : "border-transparent text-neutral-450 hover:text-neutral-300"
            }`}
          >
            👥 Manage Roles
          </button>
        </div>
      )}

      {adminStatusMessage && (
        <div className="p-4 rounded-xl border border-purple-500/20 bg-purple-500/5 text-purple-300 text-xs font-semibold">
          {adminStatusMessage}
        </div>
      )}

      {/* Guest Mode Protection for standard users */}
      {!currentUser && (
        <div className="rounded-2xl border border-amber-500/20 bg-amber-500/5 p-8 text-center space-y-4 max-w-lg mx-auto">
          <Lock className="h-10 w-10 text-amber-500/50 mx-auto animate-pulse" />
          <h3 className="font-display font-semibold text-neutral-300">Support Desk Secured</h3>
          <p className="text-xs text-neutral-450 leading-relaxed">
            Please authenticate your sovereign account to view support chronicles, interact with the help bot, or log a real ticket with our moderators.
          </p>
          <button
            onClick={onOpenAuth}
            className="rounded-xl bg-amber-500 px-6 py-2.5 text-xs font-bold text-[#0A0A0B] hover:bg-amber-400 transition-all"
          >
            Authenticate Profile
          </button>
        </div>
      )}

      {currentUser && isMod && adminSubTab === "security" && (
        <div className="rounded-2xl border border-[#1A1A1B] bg-[#0F0F10] p-6 space-y-6">
          <div className="flex items-center justify-between border-b border-[#1A1A1B] pb-4">
            <div>
              <h3 className="font-display font-semibold text-neutral-200">Security Incident Logs</h3>
              <p className="text-[11px] text-neutral-450 mt-1">Live platform telemetry tracking logins, suspicious injections, rate triggers, and clearance shifts.</p>
            </div>
            <button
              onClick={fetchSecurityLogs}
              className="rounded-lg bg-neutral-850 border border-neutral-800 px-3 py-1.5 text-[10px] font-bold text-neutral-300 hover:bg-neutral-800 transition-all"
            >
              Refresh Monitor
            </button>
          </div>

          {securityLoading ? (
            <div className="py-12 text-center text-xs text-neutral-500 font-medium">Scanning security logs...</div>
          ) : securityLogs.length === 0 ? (
            <div className="py-12 text-center text-xs text-neutral-500">No anomalous security alerts logged in current cycle.</div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs text-neutral-350">
                <thead>
                  <tr className="border-b border-[#1A1A1B] text-neutral-450 font-semibold">
                    <th className="py-2.5">Time</th>
                    <th className="py-2.5">Incident Type</th>
                    <th className="py-2.5">Severity</th>
                    <th className="py-2.5">Description</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#161617]/40">
                  {securityLogs.map((log: any) => {
                    const sevColor = 
                      log.severity === "critical" ? "text-red-400 bg-red-500/10 border-red-500/20" :
                      log.severity === "high" ? "text-amber-400 bg-amber-500/10 border-amber-500/20" :
                      log.severity === "medium" ? "text-yellow-400 bg-yellow-400/10 border-yellow-400/20" :
                      "text-blue-400 bg-blue-400/10 border-blue-400/20";
                    return (
                      <tr key={log.id} className="hover:bg-[#161617]/10 transition-all">
                        <td className="py-3 font-mono text-[10px] text-neutral-500">
                          {new Date(log.timestamp).toLocaleString()}
                        </td>
                        <td className="py-3">
                          <span className="font-semibold text-neutral-200">{log.eventType}</span>
                        </td>
                        <td className="py-3">
                          <span className={`px-2 py-0.5 rounded border text-[9px] font-bold uppercase ${sevColor}`}>
                            {log.severity}
                          </span>
                        </td>
                        <td className="py-3 text-neutral-400 font-mono text-[11px] leading-normal">{log.description}</td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {currentUser && isMod && adminSubTab === "roles" && (
        <div className="rounded-2xl border border-[#1A1A1B] bg-[#0F0F10] p-6 space-y-6">
          <div className="flex items-center justify-between border-b border-[#1A1A1B] pb-4">
            <div>
              <h3 className="font-display font-semibold text-neutral-200">Staff & Identity Clearance Directory</h3>
              <p className="text-[11px] text-neutral-450 mt-1">Assign, audit, or restrict operational staff roles and dashboard credentials.</p>
            </div>
            <button
              onClick={fetchUsersList}
              className="rounded-lg bg-neutral-850 border border-neutral-800 px-3 py-1.5 text-[10px] font-bold text-neutral-300 hover:bg-neutral-800 transition-all"
            >
              Refresh Directory
            </button>
          </div>

          {usersLoading ? (
            <div className="py-12 text-center text-xs text-neutral-500 font-medium">Reading user registry...</div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs text-neutral-350">
                <thead>
                  <tr className="border-b border-[#1A1A1B] text-neutral-450 font-semibold">
                    <th className="py-2.5">Warrior Username</th>
                    <th className="py-2.5">Sovereign Email Address</th>
                    <th className="py-2.5">Assigned clearance</th>
                    <th className="py-2.5">XP Level</th>
                    <th className="py-2.5 text-right">Clearance Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#161617]/40">
                  {usersList.map((usr: any) => (
                    <tr key={usr.id} className="hover:bg-[#161617]/10 transition-all">
                      <td className="py-3 font-semibold text-neutral-200">{usr.username}</td>
                      <td className="py-3 text-neutral-400 font-mono text-[11px]">{usr.email}</td>
                      <td className="py-3">
                        <span className={`px-2.5 py-0.5 rounded text-[10px] font-bold border ${
                          usr.role === "moderator" || usr.role === "admin"
                            ? "bg-purple-500/10 text-purple-400 border-purple-500/20"
                            : "bg-neutral-850 text-neutral-400 border-neutral-800"
                        }`}>
                          {usr.role?.toUpperCase() || "USER"}
                        </span>
                      </td>
                      <td className="py-3 text-neutral-450">
                        Lvl {usr.level} <span className="text-[10px] text-neutral-600">({usr.title})</span>
                      </td>
                      <td className="py-3 text-right">
                        {usr.email?.toLowerCase() === "max@carsonmail.uk" ? (
                          <span className="text-[10px] text-purple-400 font-bold italic pr-2">Primary Mod</span>
                        ) : (
                          <div className="inline-flex rounded-lg border border-neutral-800 bg-[#0A0A0B] p-0.5">
                            <button
                              onClick={() => handleUpdateRole(usr.id, "user")}
                              className={`px-2 py-1 text-[10px] font-bold rounded ${
                                usr.role !== "moderator" && usr.role !== "admin"
                                  ? "bg-neutral-800 text-neutral-200"
                                  : "text-neutral-500 hover:text-neutral-350"
                              }`}
                            >
                              User
                            </button>
                            <button
                              onClick={() => handleUpdateRole(usr.id, "moderator")}
                              className={`px-2 py-1 text-[10px] font-bold rounded ${
                                usr.role === "moderator"
                                  ? "bg-purple-500 text-[#0A0A0B]"
                                  : "text-neutral-500 hover:text-purple-400"
                              }`}
                            >
                              Moderator
                            </button>
                          </div>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {currentUser && adminSubTab === "tickets" && (
        <div className="grid gap-6 lg:grid-cols-3">
          
          {/* LEFT PANEL: LIST OF TICKETS */}
          <div className="lg:col-span-1 space-y-4">
            
            <div className="rounded-2xl border border-[#1A1A1B] bg-[#0F0F10] p-4.5 space-y-4 flex flex-col justify-between">
              
              {/* Controls and Stats */}
              <div>
                <div className="flex items-center justify-between border-b border-[#1A1A1B] pb-3 mb-3">
                  <span className="text-xs font-bold text-neutral-400">
                    {isMod ? "All Support Queues" : "Your Support Tickets"}
                  </span>
                  
                  <button 
                    onClick={fetchTickets}
                    disabled={loading}
                    className="p-1 rounded hover:bg-[#161618] transition-all"
                    title="Refresh List"
                  >
                    <RefreshCw className={`h-3.5 w-3.5 text-neutral-500 hover:text-neutral-300 ${loading ? 'animate-spin' : ''}`} />
                  </button>
                </div>

                {/* Mod queue filters */}
                {isMod && (
                  <div className="grid grid-cols-3 gap-1.5 p-1 bg-[#0A0A0B] rounded-lg border border-[#1A1A1B] mb-3">
                    {(["open", "resolved", "all"] as const).map((filter) => (
                      <button
                        key={filter}
                        onClick={() => setAdminFilter(filter)}
                        className={`py-1 text-[10px] font-bold rounded capitalize transition-all ${
                          adminFilter === filter 
                            ? "bg-purple-500/20 text-purple-400 border border-purple-500/15 font-extrabold" 
                            : "text-neutral-500 hover:text-neutral-300"
                        }`}
                      >
                        {filter}
                      </button>
                    ))}
                  </div>
                )}

                {/* Standard users: Create Ticket Button */}
                {!isMod && (
                  <button
                    onClick={() => {
                      setShowCreate(true);
                      setActiveTicket(null);
                    }}
                    className="w-full mb-3 rounded-xl bg-amber-500 py-2 text-xs font-bold text-[#0A0A0B] hover:bg-amber-400 transition-all flex items-center justify-center space-x-1.5 shadow-md shadow-amber-500/5"
                  >
                    <Plus className="h-4 w-4" />
                    <span>Open Support Ticket</span>
                  </button>
                )}
              </div>

              {/* Ticket Cards List */}
              <div className="space-y-2 max-h-[360px] overflow-y-auto pr-1">
                {tickets.length === 0 ? (
                  <div className="text-center py-10 text-neutral-500">
                    <FileText className="h-7 w-7 mx-auto text-neutral-700 mb-1" />
                    <p className="text-[11px]">No support cases found.</p>
                  </div>
                ) : (
                  sortedTickets.map((t) => {
                    const isSelected = activeTicket?.id === t.id;
                    const latestMsg = t.messages[t.messages.length - 1];
                    const isOpen = t.status === "open";
                    const isAITicket = t.type === "ai";

                    return (
                      <div
                        key={t.id}
                        onClick={() => {
                          setActiveTicket(t);
                          setShowCreate(false);
                        }}
                        className={`rounded-xl border p-3.5 cursor-pointer transition-all text-left ${
                          isSelected 
                            ? isMod 
                              ? "bg-purple-500/5 border-purple-500/30" 
                              : "bg-amber-500/5 border-amber-500/30"
                            : "bg-[#0A0A0B] border-[#1A1A1B] hover:bg-[#161618]/50"
                        }`}
                      >
                        <div className="flex items-start justify-between gap-1.5">
                          <span className="font-bold text-xs text-neutral-200 truncate pr-2">
                            {t.title}
                          </span>
                          
                          {/* Status Badge */}
                          <span className={`text-[8px] font-black uppercase px-1.5 py-0.25 rounded shrink-0 ${
                            isOpen 
                              ? "bg-amber-500/10 text-amber-400 border border-amber-500/20" 
                              : "bg-emerald-500/10 text-emerald-400 border border-emerald-500/20"
                          }`}>
                            {t.status}
                          </span>
                        </div>

                        {/* Appended info */}
                        <div className="flex items-center justify-between text-[9px] text-neutral-550 mt-2 font-bold uppercase tracking-wider">
                          <span className="flex items-center space-x-1">
                            {isAITicket ? (
                              <span className="text-blue-400 flex items-center space-x-0.5">
                                <Brain className="h-2.5 w-2.5" />
                                <span>AI BOT</span>
                              </span>
                            ) : (
                              <span className="text-purple-400 flex items-center space-x-0.5">
                                <UserCheck className="h-2.5 w-2.5" />
                                <span>HUMAN</span>
                              </span>
                            )}
                          </span>
                          
                          {/* Mod view: show who submitted */}
                          {isMod && (
                            <span className="text-neutral-500">
                              By: {t.username}
                            </span>
                          )}
                        </div>
                        
                        {/* Latest message preview */}
                        {latestMsg && (
                          <p className="text-[10px] text-neutral-500 truncate mt-1.5 leading-tight italic">
                            "{latestMsg.text}"
                          </p>
                        )}
                      </div>
                    );
                  })
                )}
              </div>

            </div>

          </div>

          {/* RIGHT PANEL: SELECTED SUPPORT CHAT OR TICKET FORM */}
          <div className="lg:col-span-2">
            
            {/* 1. TICKET CREATION FORM */}
            {showCreate && (
              <div className="rounded-2xl border border-[#1A1A1B] bg-[#0F0F10] p-6 shadow-sm space-y-4 animate-fade-in">
                <div className="flex items-center space-x-2 border-b border-[#1A1A1B] pb-3">
                  <LifeBuoy className="h-5 w-5 text-amber-500" />
                  <h3 className="font-display font-bold text-neutral-100">Draft Support Case</h3>
                </div>

                <form onSubmit={handleCreateTicket} className="space-y-4">
                  
                  {/* Title */}
                  <div className="space-y-1.5">
                    <label className="text-xs font-bold text-neutral-400 block">Case Subject / Title</label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. Sobriety clock didn't reset on relapse"
                      value={ticketTitle}
                      onChange={(e) => setTicketTitle(e.target.value)}
                      className="w-full rounded-xl border border-[#1A1A1B] bg-[#0A0A0B] text-neutral-200 px-4 py-3 text-xs outline-none focus:border-amber-500 transition-all"
                    />
                  </div>

                  {/* Dual System Selector */}
                  <div className="space-y-1.5">
                    <label className="text-xs font-bold text-neutral-400 block">Select Help Channel</label>
                    <div className="grid grid-cols-2 gap-3">
                      
                      {/* AI Channel */}
                      <div 
                        onClick={() => setTicketType("ai")}
                        className={`rounded-xl border p-4.5 cursor-pointer transition-all flex flex-col justify-between text-left ${
                          ticketType === "ai"
                            ? "bg-blue-500/5 border-blue-500/40 text-neutral-100"
                            : "bg-[#0A0A0B] border-[#1A1A1B] text-neutral-400 hover:bg-[#161618]"
                        }`}
                      >
                        <div className="flex items-center space-x-2 mb-1">
                          <Brain className={`h-4.5 w-4.5 ${ticketType === "ai" ? "text-blue-400" : "text-neutral-500"}`} />
                          <h4 className="text-xs font-bold">AI Support (Instant)</h4>
                        </div>
                        <p className="text-[10px] text-neutral-500 leading-relaxed">
                          Clinical & technical bot assistance. Instant, automated, accurate, and 24/7 available.
                        </p>
                      </div>

                      {/* Human Channel */}
                      <div 
                        onClick={() => setTicketType("real")}
                        className={`rounded-xl border p-4.5 cursor-pointer transition-all flex flex-col justify-between text-left ${
                          ticketType === "real"
                            ? "bg-purple-500/5 border-purple-500/40 text-neutral-100"
                            : "bg-[#0A0A0B] border-[#1A1A1B] text-neutral-400 hover:bg-[#161618]"
                        }`}
                      >
                        <div className="flex items-center space-x-2 mb-1">
                          <UserCheck className={`h-4.5 w-4.5 ${ticketType === "real" ? "text-purple-400" : "text-neutral-500"}`} />
                          <h4 className="text-xs font-bold">Real Mod (Human)</h4>
                        </div>
                        <p className="text-[10px] text-neutral-500 leading-relaxed">
                          Secure direct support reviewed manually by our dedicated moderators. (Replies within hours).
                        </p>
                      </div>

                    </div>
                  </div>

                  {/* Message details */}
                  <div className="space-y-1.5">
                    <label className="text-xs font-bold text-neutral-400 block">Elaborate Your Situation</label>
                    <textarea
                      required
                      rows={4}
                      placeholder="Please specify your browser, what action you took, and any logs you observed to help our system or moderator assist you."
                      value={ticketMessage}
                      onChange={(e) => setTicketMessage(e.target.value)}
                      className="w-full rounded-xl border border-[#1A1A1B] bg-[#0A0A0B] text-neutral-200 p-4 text-xs outline-none focus:border-amber-500 transition-all leading-relaxed"
                    />
                  </div>

                  {/* Submit actions */}
                  <div className="flex items-center justify-end space-x-3 pt-2">
                    <button
                      type="button"
                      onClick={() => setShowCreate(false)}
                      className="rounded-xl border border-[#1A1A1B] px-5 py-2.5 text-xs font-bold text-neutral-450 hover:bg-[#161618] transition-all"
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      disabled={createLoading}
                      className="rounded-xl bg-amber-500 px-6 py-2.5 text-xs font-bold text-[#0A0A0B] hover:bg-amber-400 transition-all flex items-center space-x-1.5 shadow-md shadow-amber-500/5"
                    >
                      {createLoading ? <RefreshCw className="h-3.5 w-3.5 animate-spin" /> : <Send className="h-3.5 w-3.5" />}
                      <span>Dispatch Ticket</span>
                    </button>
                  </div>

                </form>
              </div>
            )}

            {/* 2. CHAT VIEWPORT FOR SELECTED ACTIVE TICKET */}
            {activeTicket && (
              <div className="rounded-2xl border border-[#1A1A1B] bg-[#0F0F10] flex flex-col h-[520px] overflow-hidden shadow-sm animate-fade-in">
                
                {/* Active Ticket Header */}
                <div className="border-b border-[#1A1A1B] bg-[#161618]/40 px-4.5 py-4 flex items-center justify-between flex-wrap gap-2">
                  <div className="flex items-center space-x-3">
                    <div className={`flex h-9 w-9 items-center justify-center rounded-lg border shrink-0 ${
                      activeTicket.type === "ai" 
                        ? "bg-blue-500/10 border-blue-500/20 text-blue-400" 
                        : "bg-purple-500/10 border-purple-500/20 text-purple-400"
                    }`}>
                      {activeTicket.type === "ai" ? <Brain className="h-4.5 w-4.5" /> : <UserCheck className="h-4.5 w-4.5" />}
                    </div>
                    <div className="min-w-0">
                      <h4 className="font-bold text-sm text-[#E5E5E5] truncate max-w-xs sm:max-w-md">
                        {activeTicket.title}
                      </h4>
                      <p className="text-[10px] text-neutral-500 font-bold tracking-wide uppercase mt-0.5 flex items-center space-x-2">
                        <span>ID: {activeTicket.id}</span>
                        <span>•</span>
                        <span>Type: {activeTicket.type.toUpperCase()} Support</span>
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center space-x-2">
                    {/* Resolve Action */}
                    {activeTicket.status === "open" && (
                      <button
                        onClick={() => handleResolveTicket(activeTicket.id)}
                        className="rounded-lg border border-emerald-500/20 bg-emerald-500/5 px-2.5 py-1.5 text-[10px] font-bold text-emerald-400 hover:bg-emerald-500/15 transition-all flex items-center space-x-1"
                        title="Mark Resolved"
                      >
                        <CheckCircle2 className="h-3 w-3" />
                        <span className="hidden sm:inline">Close Case</span>
                      </button>
                    )}

                    {/* Status Badge */}
                    <span className={`text-[10px] font-black uppercase px-2.5 py-1 rounded ${
                      activeTicket.status === "open"
                        ? "bg-amber-500/10 text-amber-400 border border-amber-500/20"
                        : "bg-emerald-500/10 text-emerald-400 border border-emerald-500/20"
                    }`}>
                      {activeTicket.status}
                    </span>
                  </div>
                </div>

                {/* Messages List Area */}
                <div className="flex-1 overflow-y-auto p-4 space-y-4">
                  {activeTicket.messages.map((m) => {
                    const isSenderAI = m.sender === "ai";
                    const isSenderMod = m.sender === "mod";
                    const isSenderSelf = !isSenderAI && !isSenderMod;

                    return (
                      <div
                        key={m.id}
                        className={`flex items-start space-x-3 max-w-[85%] ${
                          isSenderSelf ? "ml-auto flex-row-reverse space-x-reverse" : "mr-auto"
                        }`}
                      >
                        {/* Sigil Icon */}
                        <div className={`h-8 w-8 rounded-lg border flex items-center justify-center shrink-0 ${
                          isSenderAI
                            ? "bg-blue-500/10 border-blue-500/20 text-blue-400"
                            : isSenderMod
                            ? "bg-purple-500/10 border-purple-500/20 text-purple-400"
                            : "bg-[#0A0A0B] border-[#1A1A1B] text-amber-500"
                        }`}>
                          {isSenderAI ? <Brain className="h-4.5 w-4.5" /> : isSenderMod ? <ShieldAlert className="h-4.5 w-4.5" /> : <User className="h-4.5 w-4.5" />}
                        </div>

                        <div>
                          {/* Name and Meta */}
                          <div className={`flex items-center space-x-1.5 mb-1 ${isSenderSelf ? "justify-end" : ""}`}>
                            <span className="text-[10px] font-black text-neutral-450">
                              {m.senderName}
                            </span>
                            <span className="text-[8px] text-neutral-600 font-mono">
                              {new Date(m.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                            </span>
                          </div>

                          {/* Text bubble */}
                          <div className={`rounded-xl p-3 text-xs leading-relaxed ${
                            isSenderSelf
                              ? "bg-amber-500 text-[#0A0A0B] font-semibold rounded-tr-none"
                              : isSenderMod
                              ? "bg-purple-500/10 text-[#E5E5E5] border border-purple-500/20 rounded-tl-none"
                              : "bg-[#161618] text-neutral-200 border border-[#262626] rounded-tl-none"
                          }`}>
                            <p className="whitespace-pre-wrap">{m.text}</p>
                          </div>
                        </div>

                      </div>
                    );
                  })}
                  <div ref={messageEndRef} />
                </div>

                {/* Reply Form */}
                {activeTicket.status === "open" ? (
                  <form onSubmit={handleSendReply} className="border-t border-[#1A1A1B] bg-[#161618]/20 p-4 flex items-center space-x-2">
                    <input
                      type="text"
                      disabled={sendLoading}
                      placeholder={isMod ? "Type moderator reply..." : "Add information or follow up on your support case..."}
                      value={replyInput}
                      onChange={(e) => setReplyInput(e.target.value)}
                      className="flex-1 rounded-xl border border-[#1A1A1B] bg-[#0A0A0B] text-neutral-200 px-4 py-3 text-xs outline-none focus:border-amber-500 transition-all disabled:opacity-50"
                    />
                    <button
                      type="submit"
                      disabled={sendLoading || !replyInput.trim()}
                      className={`rounded-xl font-bold p-3 transition-all ${
                        isMod 
                          ? "bg-purple-500 text-[#0A0A0B] hover:bg-purple-400" 
                          : "bg-amber-500 text-[#0A0A0B] hover:bg-amber-400"
                      } disabled:bg-neutral-800 disabled:text-neutral-500`}
                    >
                      <Send className="h-4.5 w-4.5" />
                    </button>
                  </form>
                ) : (
                  <div className="border-t border-[#1A1A1B] bg-[#161618]/20 p-4 text-center text-xs text-neutral-500 font-medium">
                    This support case is resolved and locked. Open a new ticket if you need further help.
                  </div>
                )}

              </div>
            )}

            {/* 3. DORMANT PLACEHOLDER (NOTHING CHOSEN) */}
            {!activeTicket && !showCreate && (
              <div className="rounded-2xl border border-[#1A1A1B] bg-[#0F0F10] p-12 text-center h-full flex flex-col items-center justify-center space-y-4 shadow-sm min-h-[420px]">
                <HelpCircle className="h-11 w-11 text-neutral-700 animate-pulse" />
                <h3 className="font-display font-semibold text-neutral-300">
                  {isMod ? "Sovereign Queue Standby" : "No Active Case Selected"}
                </h3>
                <p className="text-xs text-neutral-500 max-w-sm leading-relaxed">
                  {isMod 
                    ? "Select an open human support ticket from the list on the left to coordinate replies, verify user issues, and manage status."
                    : "Select an existing support ticket from the archive queue on the left, or open a fresh support ticket to request assistance."
                  }
                </p>
                {!isMod && (
                  <button
                    onClick={() => setShowCreate(true)}
                    className="rounded-xl bg-amber-500 px-5 py-2.5 text-xs font-bold text-[#0A0A0B] hover:bg-amber-400 transition-all shadow-md shadow-amber-500/5"
                  >
                    Draft First Ticket
                  </button>
                )}
              </div>
            )}

          </div>

        </div>
      )}

    </div>
  );
}
