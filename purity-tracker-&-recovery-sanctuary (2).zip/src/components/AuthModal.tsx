/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from "react";
import { X, Sparkles, AlertCircle, Mail, KeyRound, CheckCircle } from "lucide-react";

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAuthSuccess: (user: any) => void;
}

const AVATARS = [
  { name: "Sovereign Stag (Will)", url: "https://images.unsplash.com/photo-1549488344-1f9b8d2bd1f3?w=120&auto=format&fit=crop&q=80" },
  { name: "Noble Lion (Integrity)", url: "https://images.unsplash.com/photo-1614027164847-1b2809eb7b9b?w=120&auto=format&fit=crop&q=80" },
  { name: "Pure Lotus (Peace)", url: "https://images.unsplash.com/photo-1502082553048-f009c37129b9?w=120&auto=format&fit=crop&q=80" },
  { name: "Silent Forest (Focus)", url: "https://images.unsplash.com/photo-1448375240586-882707db888b?w=120&auto=format&fit=crop&q=80" },
  { name: "Soaring Eagle (Freedom)", url: "https://images.unsplash.com/photo-1611689342806-0863700ce1e4?w=120&auto=format&fit=crop&q=80" },
  { name: "Quiet Mountain (Strength)", url: "https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?w=120&auto=format&fit=crop&q=80" },
];

export default function AuthModal({ isOpen, onClose, onAuthSuccess }: AuthModalProps) {
  const [formType, setFormType] = useState<"login" | "register" | "forgot" | "reset">("login");
  const isLogin = formType === "login";
  
  const [username, setUsername] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [avatarUrl, setAvatarUrl] = useState(AVATARS[0].url);
  const [resetCode, setResetCode] = useState("");
  const [newPassword, setNewPassword] = useState("");
  
  const [error, setError] = useState("");
  const [successMessage, setSuccessMessage] = useState("");
  const [simulatedCode, setSimulatedCode] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  // Hook to handle Google Sign-In postMessage success notification
  useEffect(() => {
    const handleOAuthMessage = (event: MessageEvent) => {
      const origin = event.origin;
      if (!origin.endsWith(".run.app") && !origin.includes("localhost")) {
        return;
      }
      if (event.data?.type === "OAUTH_AUTH_SUCCESS" && event.data?.user) {
        onAuthSuccess(event.data.user);
        onClose();
      }
    };
    window.addEventListener("message", handleOAuthMessage);
    return () => window.removeEventListener("message", handleOAuthMessage);
  }, [onAuthSuccess, onClose]);

  if (!isOpen) return null;

  const handleGoogleSignIn = async () => {
    setError("");
    setSuccessMessage("");
    setLoading(true);
    try {
      const res = await fetch("/api/auth/google/url");
      if (!res.ok) throw new Error("Failed to initialize Google gateway");
      const { url } = await res.json();
      
      const width = 500;
      const height = 650;
      const left = window.screenX + (window.outerWidth - width) / 2;
      const top = window.screenY + (window.outerHeight - height) / 2;

      const popup = window.open(
        url,
        "google_oauth_popup",
        `width=${width},height=${height},left=${left},top=${top}`
      );
      if (!popup) {
        throw new Error("Popup blocked. Please allow popups to sign in with Google.");
      }
    } catch (err: any) {
      setError(err.message || "Could not connect to Google Gateway.");
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setSuccessMessage("");
    setLoading(true);

    const endpoint = isLogin ? "/api/auth/login" : "/api/auth/register";
    const body = isLogin 
      ? { email, password } 
      : { username, email, password, avatarUrl };

    try {
      const response = await fetch(endpoint, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || "Something went wrong. Please try again.");
      }

      onAuthSuccess(data.user);
      onClose();
    } catch (err: any) {
      setError(err.message || "Connection error. Please try again later.");
    } finally {
      setLoading(false);
    }
  };

  const handleForgotPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setSuccessMessage("");
    setLoading(true);
    setSimulatedCode(null);

    try {
      const response = await fetch("/api/auth/forgot-password", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email }),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || "Recovery failed.");
      }

      if (data.code) {
        setSimulatedCode(data.code);
      }
      setSuccessMessage("A recovery verification code has been dispatched.");
      setFormType("reset");
    } catch (err: any) {
      setError(err.message || "Connection error. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  const handleResetPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setSuccessMessage("");
    setLoading(true);

    try {
      const response = await fetch("/api/auth/reset-password", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, code: resetCode, newPassword }),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || "Password reset failed.");
      }

      setSuccessMessage(data.message || "Password successfully reset!");
      setFormType("login");
      setPassword("");
      setResetCode("");
      setNewPassword("");
      setSimulatedCode(null);
    } catch (err: any) {
      setError(err.message || "Reset failed. Please verify your code.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div id="auth-modal-overlay" className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 px-4 py-6 backdrop-blur-sm animate-fade-in overflow-y-auto">
      <div id="auth-modal-content" className="relative w-full max-w-md max-h-[90vh] overflow-y-auto scrollbar-none rounded-2xl border border-[#1A1A1B] bg-[#0F0F10] p-6 shadow-2xl sm:p-8 fade-in">
        
        {/* Close Button */}
        <button
          id="close-auth-btn"
          onClick={onClose}
          className="absolute right-4 top-4 rounded-xl p-1.5 text-neutral-500 hover:bg-[#161618] hover:text-[#E5E5E5]"
        >
          <X className="h-5 w-5" />
        </button>

        {/* Brand Banner */}
        <div className="mb-6 text-center">
          <div className="mx-auto mb-3 flex h-12 w-12 items-center justify-center rounded-2xl bg-amber-500/10 text-amber-500 border border-amber-500/20">
            <Sparkles className="h-6 w-6" />
          </div>
          <h2 className="font-display text-2xl font-bold tracking-tight text-[#E5E5E5]">
            {formType === "login" 
              ? "Welcome Back, Warrior" 
              : formType === "register"
              ? "Begin Your Quest"
              : formType === "forgot"
              ? "Recover Your Key"
              : "Set New Password"
            }
          </h2>
          <p className="mt-1.5 text-sm text-[#888888]">
            {formType === "login" 
              ? "Re-enter the sanctuary of focus, discipline, and mental clarity." 
              : formType === "register"
              ? "Set your path, claim your shield, and stand with fellow seekers."
              : formType === "forgot"
              ? "Input your registered email to dispatch your security recovery code."
              : "The gates of self-command reopen. Anchor your new secure password."
            }
          </p>
        </div>

        {/* Error Alert */}
        {error && (
          <div className="mb-4 flex items-start space-x-2 rounded-xl bg-rose-500/10 p-3.5 text-xs font-medium text-rose-400 border border-rose-500/20">
            <AlertCircle className="h-4.5 w-4.5 shrink-0 text-rose-500" />
            <span>{error}</span>
          </div>
        )}

        {/* Success Alert */}
        {successMessage && (
          <div className="mb-4 flex items-start space-x-2 rounded-xl bg-emerald-500/10 p-3.5 text-xs font-medium text-emerald-400 border border-emerald-500/20">
            <CheckCircle className="h-4.5 w-4.5 shrink-0 text-emerald-500" />
            <span>{successMessage}</span>
          </div>
        )}

        {/* Simulated Code Interception box */}
        {simulatedCode && (
          <div className="mb-4 rounded-xl bg-amber-500/10 border border-amber-500/20 p-4 space-y-2 text-left">
            <div className="flex items-center space-x-1.5 text-amber-500 font-bold text-xs">
              <Sparkles className="h-4 w-4" />
              <span>Simulated SMS/Email Dispatch Intercepted</span>
            </div>
            <p className="text-[11px] text-neutral-450 leading-relaxed">
              In production, an automated email would be delivered securely. In this local developer sandbox, your recovery code has been routed on-screen for direct testing:
            </p>
            <div className="flex items-center justify-between bg-[#0A0A0B] border border-amber-500/30 rounded-lg p-2.5">
              <span className="font-mono text-sm font-black tracking-widest text-amber-400">{simulatedCode}</span>
              <span className="text-[9px] bg-amber-500 text-[#0A0A0B] px-1.5 py-0.5 rounded font-black uppercase">Developer Key</span>
            </div>
          </div>
        )}

        {/* 1. LOGIN & REGISTER FORMS */}
        {(formType === "login" || formType === "register") && (
          <form onSubmit={handleSubmit} className="space-y-4">
            
            {/* Username Field (Register only) */}
            {formType === "register" && (
              <div>
                <label className="block text-xs font-bold text-neutral-400 uppercase tracking-wider mb-1.5">
                  Warrior Pseudonym
                </label>
                <input
                  id="username-input"
                  type="text"
                  required
                  placeholder="e.g. Marcus_Will"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  className="w-full rounded-xl border border-[#1A1A1B] bg-[#0A0A0B] text-[#E5E5E5] px-3.5 py-2.5 text-sm outline-none transition-all focus:border-amber-500"
                />
              </div>
            )}

            {/* Email Field */}
            <div>
              <label className="block text-xs font-bold text-neutral-400 uppercase tracking-wider mb-1.5">
                Email Address
              </label>
              <input
                id="email-input"
                type="email"
                required
                placeholder="name@domain.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full rounded-xl border border-[#1A1A1B] bg-[#0A0A0B] text-[#E5E5E5] px-3.5 py-2.5 text-sm outline-none transition-all focus:border-amber-500"
              />
            </div>

            {/* Password Field */}
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className="block text-xs font-bold text-neutral-400 uppercase tracking-wider">
                  Password
                </label>
                {formType === "login" && (
                  <button
                    id="trigger-forgot-btn"
                    type="button"
                    onClick={() => {
                      setFormType("forgot");
                      setError("");
                      setSuccessMessage("");
                      setSimulatedCode(null);
                    }}
                    className="text-xs font-bold text-amber-500 hover:underline hover:text-amber-400"
                  >
                    Forgot Password?
                  </button>
                )}
              </div>
              <input
                id="password-input"
                type="password"
                required
                placeholder="••••••••"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full rounded-xl border border-[#1A1A1B] bg-[#0A0A0B] text-[#E5E5E5] px-3.5 py-2.5 text-sm outline-none transition-all focus:border-amber-500"
              />
            </div>

            {/* Avatar Selector (Register only) */}
            {formType === "register" && (
              <div>
                <label className="block text-xs font-bold text-neutral-400 uppercase tracking-wider mb-2">
                  Choose Purity Sigil (Avatar)
                </label>
                <div className="grid grid-cols-6 gap-2.5">
                  {AVATARS.map((avatar, idx) => (
                    <button
                      key={idx}
                      type="button"
                      onClick={() => setAvatarUrl(avatar.url)}
                      title={avatar.name}
                      className={`relative aspect-square overflow-hidden rounded-xl border-2 transition-all ${
                        avatarUrl === avatar.url 
                          ? "border-amber-500 ring-4 ring-amber-500/15 scale-105" 
                          : "border-[#1A1A1B] bg-[#0A0A0B] hover:border-[#262626] hover:scale-102"
                      }`}
                    >
                      <img 
                        src={avatar.url} 
                        alt={avatar.name} 
                        className="h-full w-full object-cover"
                      />
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Submit Button */}
            <button
              id="auth-submit-btn"
              type="submit"
              disabled={loading}
              className="w-full rounded-xl bg-amber-500 py-3 text-sm font-bold text-[#0A0A0B] shadow-lg shadow-amber-500/10 transition-all hover:bg-amber-400 disabled:bg-neutral-800 disabled:text-neutral-500"
            >
              {loading ? "Aligning stars..." : formType === "login" ? "Enter Sanctuary" : "Initialize Quest"}
            </button>

            {/* OR divider */}
            <div className="relative my-4 flex py-1 items-center">
              <div className="flex-grow border-t border-[#1A1A1B]"></div>
              <span className="flex-shrink mx-3 text-[10px] uppercase font-bold tracking-widest text-neutral-500">Or Access Via</span>
              <div className="flex-grow border-t border-[#1A1A1B]"></div>
            </div>

            {/* Google Sign-In Button */}
            <button
              id="google-signin-btn"
              type="button"
              onClick={handleGoogleSignIn}
              disabled={loading}
              className="w-full flex items-center justify-center space-x-2.5 rounded-xl border border-[#262626] bg-[#161618] py-2.5 text-sm font-bold text-[#E5E5E5] transition-all hover:bg-[#1C1C1E] hover:border-[#3a3a3a] disabled:opacity-50"
            >
              <span className="font-display font-black text-rose-500 text-base leading-none">G</span>
              <span>Sign in with Google</span>
            </button>
          </form>
        )}

        {/* 2. FORGOT PASSWORD FORM */}
        {formType === "forgot" && (
          <form onSubmit={handleForgotPassword} className="space-y-4">
            <div>
              <label className="block text-xs font-bold text-neutral-400 uppercase tracking-wider mb-1.5">
                Registered Email Address
              </label>
              <div className="relative">
                <Mail className="absolute left-3.5 top-3.5 h-4.5 w-4.5 text-neutral-500" />
                <input
                  id="forgot-email-input"
                  type="email"
                  required
                  placeholder="name@domain.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full rounded-xl border border-[#1A1A1B] bg-[#0A0A0B] text-[#E5E5E5] pl-11 pr-3.5 py-2.5 text-sm outline-none transition-all focus:border-amber-500"
                />
              </div>
            </div>

            <button
              id="forgot-submit-btn"
              type="submit"
              disabled={loading}
              className="w-full rounded-xl bg-amber-500 py-3 text-sm font-bold text-[#0A0A0B] shadow-lg shadow-amber-500/10 transition-all hover:bg-amber-400 disabled:bg-neutral-800 disabled:text-neutral-500"
            >
              {loading ? "Aligning archives..." : "Dispatch Recovery Code"}
            </button>
          </form>
        )}

        {/* 3. RESET PASSWORD FORM */}
        {formType === "reset" && (
          <form onSubmit={handleResetPassword} className="space-y-4">
            <div>
              <label className="block text-xs font-bold text-neutral-400 uppercase tracking-wider mb-1.5 text-center">
                6-Digit Recovery Verification Code
              </label>
              <div className="relative">
                <KeyRound className="absolute left-3.5 top-3.5 h-4.5 w-4.5 text-neutral-500" />
                <input
                  id="reset-code-input"
                  type="text"
                  required
                  maxLength={6}
                  placeholder="e.g. 123456"
                  value={resetCode}
                  onChange={(e) => setResetCode(e.target.value)}
                  className="w-full text-center tracking-widest font-mono rounded-xl border border-[#1A1A1B] bg-[#0A0A0B] text-[#E5E5E5] pl-11 pr-3.5 py-2.5 text-sm outline-none transition-all focus:border-amber-500"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-neutral-400 uppercase tracking-wider mb-1.5">
                New Secure Password
              </label>
              <input
                id="reset-password-input"
                type="password"
                required
                placeholder="••••••••"
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                className="w-full rounded-xl border border-[#1A1A1B] bg-[#0A0A0B] text-[#E5E5E5] px-3.5 py-2.5 text-sm outline-none transition-all focus:border-amber-500"
              />
            </div>

            <button
              id="reset-submit-btn"
              type="submit"
              disabled={loading}
              className="w-full rounded-xl bg-amber-500 py-3 text-sm font-bold text-[#0A0A0B] shadow-lg shadow-amber-500/10 transition-all hover:bg-amber-400 disabled:bg-neutral-800 disabled:text-neutral-500"
            >
              {loading ? "Re-keying fortress..." : "Update Password Shield"}
            </button>
          </form>
        )}

        {/* Toggle Mode Footer */}
        <div className="mt-6 text-center text-xs text-[#888888]">
          {formType === "login" && (
            <span>
              New to the quest?{" "}
              <button
                id="toggle-register-btn"
                onClick={() => {
                  setFormType("register");
                  setError("");
                  setSuccessMessage("");
                }}
                className="font-bold text-amber-500 hover:underline hover:text-amber-400"
              >
                Create an Account
              </button>
            </span>
          )}
          {formType === "register" && (
            <span>
              Already registered?{" "}
              <button
                id="toggle-login-btn"
                onClick={() => {
                  setFormType("login");
                  setError("");
                  setSuccessMessage("");
                }}
                className="font-bold text-amber-500 hover:underline hover:text-amber-400"
              >
                Log In Here
              </button>
            </span>
          )}
          {(formType === "forgot" || formType === "reset") && (
            <span>
              Remembered your credentials?{" "}
              <button
                id="back-to-login-btn"
                onClick={() => {
                  setFormType("login");
                  setError("");
                  setSuccessMessage("");
                  setSimulatedCode(null);
                }}
                className="font-bold text-amber-500 hover:underline hover:text-amber-400"
              >
                Back to Login
              </button>
            </span>
          )}
        </div>
      </div>
    </div>
  );
}
