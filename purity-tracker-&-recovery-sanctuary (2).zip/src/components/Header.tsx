/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from "react";
import { 
  HeartHandshake, 
  ShieldAlert, 
  BookOpen, 
  Award, 
  Brain, 
  User, 
  LogOut, 
  LogIn, 
  Activity,
  Flame,
  MessageSquare,
  LifeBuoy,
  ExternalLink,
  Moon,
  Sparkles,
  Settings,
  Sun
} from "lucide-react";
import { User as UserType } from "../types";
import { getActiveBadge } from "../lib/badges";

interface HeaderProps {
  currentUser: UserType | null;
  activeTab: string;
  setActiveTab: (tab: string) => void;
  onOpenAuth: () => void;
  onLogout: () => void;
  isFocusMode: boolean;
  onToggleFocusMode: () => void;
  theme: "dark" | "deep-night" | "light" | "midnight" | "soft-gray" | "glassmorphism";
  onToggleTheme: () => void;
  onOpenCommandPalette: () => void;
}

export default function Header({
  currentUser,
  activeTab,
  setActiveTab,
  onOpenAuth,
  onLogout,
  isFocusMode,
  onToggleFocusMode,
  theme,
  onToggleTheme,
  onOpenCommandPalette
}: HeaderProps) {
  const isModUser = currentUser?.username === "ollymckee101" || currentUser?.role === "moderator" || currentUser?.role === "admin";
  const tabs = [
    { id: "dashboard", label: "Dashboard", icon: Activity },
    { id: "sos", label: "Urge SOS Room", icon: ShieldAlert, badge: "Rescue" },
    { id: "wisdom", label: "Wisdom & Science", icon: BookOpen },
    { id: "leaderboard", label: "Leaderboards", icon: Award },
    { id: "community", label: "Community & Chat", icon: MessageSquare },
    { id: "mentor", label: "AI Purity Mentor", icon: Brain },
    { id: "support", label: isModUser ? "Manual Mod View" : "Support", icon: LifeBuoy }
  ].filter((tab) => {
    if (isFocusMode) {
      // In Focus Mode, hide leaderboards, community chat, support, and mentor to avoid distractions
      return ["dashboard", "sos", "wisdom"].includes(tab.id);
    }
    return true;
  });

  // Helper to format streak count
  const getStreakDisplay = () => {
    if (!currentUser || !currentUser.streakStartDate) return 0;
    const start = new Date(currentUser.streakStartDate);
    const now = new Date();
    const diff = Math.abs(now.getTime() - start.getTime());
    return Math.floor(diff / (1000 * 60 * 60 * 24));
  };

  const currentStreak = getStreakDisplay();
  const equippedBadge = currentUser ? getActiveBadge(currentUser.equippedBadgeId, currentUser.totalXp) : null;

  return (
    <header id="app-header" className="sticky top-0 z-40 w-full border-b border-[#1A1A1B] bg-[#0F0F10]/85 backdrop-blur-md">
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-4 sm:px-6 lg:px-8">
        
        {/* Logo and Brand */}
        <div 
          id="brand-logo"
          onClick={() => setActiveTab("dashboard")} 
          className="flex cursor-pointer items-center space-x-2.5 transition-opacity hover:opacity-90"
        >
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary text-[#0A0A0B] shadow-md shadow-primary/10">
            <HeartHandshake className="h-5.5 w-5.5" />
          </div>
          <div>
            <h1 className="font-display text-lg font-bold tracking-tight text-[#E5E5E5] sm:text-xl">
              Sanctuary
            </h1>
            <p className="hidden text-[10px] font-medium uppercase tracking-wider text-primary sm:block">
              Mind & Spirit Purity
            </p>
          </div>
        </div>

        {/* Desktop Navigation */}
        <nav id="desktop-nav" className="hidden lg:flex lg:space-x-1">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                id={`tab-btn-${tab.id}`}
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`relative flex items-center space-x-2 rounded-lg px-3.5 py-2 text-sm font-medium transition-all ${
                  isActive 
                    ? "bg-[#161618] text-[#E5E5E5] font-semibold border border-[#262626]" 
                    : "text-[#888888] hover:bg-[#161618]/50 hover:text-[#E5E5E5]"
                }`}
              >
                <Icon className={`h-4.5 w-4.5 ${isActive ? "text-primary" : "text-neutral-500"}`} />
                <span>{tab.label}</span>
                
                {tab.badge && (
                  <span className="absolute -top-1 -right-1 flex h-4 items-center justify-center rounded-full bg-rose-500 px-1 text-[8px] font-bold text-white uppercase tracking-wider animate-pulse">
                    {tab.badge}
                  </span>
                )}
              </button>
            );
          })}
        </nav>

        {/* User Status / Auth Actions */}
        <div id="user-actions" className="flex items-center space-x-3">
          {/* Discord Community Link */}
          <a
            id="discord-invite-header"
            href="https://discord.gg/XFusvy4xKP"
            target="_blank"
            rel="noopener noreferrer"
            className="hidden md:flex items-center space-x-1.5 rounded-full bg-[#5865F2]/10 hover:bg-[#5865F2]/20 text-[#5865F2] border border-[#5865F2]/30 px-3 py-1 text-xs font-bold transition-all cursor-pointer"
            title="Join our Discord Community"
          >
            <MessageSquare className="h-3.5 w-3.5" />
            <span>Discord</span>
            <ExternalLink className="h-3 w-3 opacity-60" />
          </a>

          {/* Command Console Trigger */}
          <button
            id="command-console-header-btn"
            onClick={onOpenCommandPalette}
            className="flex items-center space-x-1 rounded-full bg-neutral-900/60 hover:bg-[#161618] hover:text-[#E5E5E5] text-[#888888] border border-[#262626] px-2.5 py-1 text-xs font-bold transition-all cursor-pointer"
            title="Open Sovereign Command Palette (Ctrl+K)"
          >
            <span className="text-[10px] bg-neutral-950 px-1.5 py-0.5 rounded border border-[#1A1A1B] text-neutral-400 font-mono">⌘K</span>
            <span className="hidden sm:inline">Console</span>
          </button>

          {/* Theme Toggle */}
          <button
            id="theme-toggle"
            onClick={onToggleTheme}
            className={`flex items-center space-x-1.5 rounded-full px-2.5 py-1 text-xs font-bold border transition-all cursor-pointer ${
              theme === "deep-night"
                ? "bg-zinc-800/20 text-zinc-400 border-zinc-750/30 hover:text-zinc-300"
                : theme === "light"
                ? "bg-amber-500/10 text-amber-600 border-amber-500/25 hover:text-amber-700"
                : theme === "midnight"
                ? "bg-indigo-950/20 text-indigo-400 border-indigo-500/20 hover:text-indigo-300"
                : theme === "soft-gray"
                ? "bg-slate-800/20 text-slate-300 border-slate-700/30 hover:text-slate-200"
                : theme === "glassmorphism"
                ? "bg-white/5 text-purple-300 border-white/10 hover:text-purple-200 backdrop-blur-md"
                : "bg-[#161618] text-[#888888] border-[#262626] hover:text-[#E5E5E5] hover:border-[#3a3a3a]"
            }`}
            title="Cycle Sanctuary Appearance Preset"
          >
            {theme === "deep-night" ? (
              <>
                <Moon className="h-3.5 w-3.5 text-zinc-400 animate-pulse" />
                <span className="hidden sm:inline">AMOLED Black</span>
              </>
            ) : theme === "light" ? (
              <>
                <Sun className="h-3.5 w-3.5 text-amber-600" />
                <span className="hidden sm:inline">Alabaster Light</span>
              </>
            ) : theme === "midnight" ? (
              <>
                <Brain className="h-3.5 w-3.5 text-indigo-400" />
                <span className="hidden sm:inline">Midnight Cosmic</span>
              </>
            ) : theme === "soft-gray" ? (
              <>
                <Activity className="h-3.5 w-3.5 text-slate-300" />
                <span className="hidden sm:inline">Soft Slate</span>
              </>
            ) : theme === "glassmorphism" ? (
              <>
                <Sparkles className="h-3.5 w-3.5 text-purple-300 animate-pulse" />
                <span className="hidden sm:inline">Frosted Glass</span>
              </>
            ) : (
              <>
                <Sparkles className="h-3.5 w-3.5 text-amber-500" />
                <span className="hidden sm:inline">Sophisticated Dark</span>
              </>
            )}
          </button>

          {/* Focus Mode Toggle */}
          <button
            id="focus-mode-toggle"
            onClick={onToggleFocusMode}
            className={`flex items-center space-x-1.5 rounded-full px-3 py-1 text-xs font-bold border transition-all cursor-pointer ${
              isFocusMode 
                ? "bg-amber-500/15 text-amber-400 border-amber-500/40 shadow-[0_0_12px_rgba(245,158,11,0.08)]" 
                : "bg-[#161618] text-[#888888] border-[#262626] hover:text-[#E5E5E5] hover:border-[#3a3a3a]"
            }`}
            title={isFocusMode ? "Deactivate Focus Mode" : "Activate Focus Mode"}
          >
            <span className="relative flex h-2 w-2">
              {isFocusMode && (
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-amber-400 opacity-75"></span>
              )}
              <span className={`relative inline-flex rounded-full h-2 w-2 ${isFocusMode ? 'bg-amber-500' : 'bg-neutral-600'}`}></span>
            </span>
            <span className="hidden sm:inline">Focus Mode</span>
            <span className="sm:hidden">Focus</span>
          </button>

          {currentUser ? (
            <div className="flex items-center space-x-3">
              {/* Quick Streak Indicator */}
              <div className="flex items-center space-x-1.5 rounded-full bg-[#161618] px-3 py-1 text-xs font-semibold text-primary border border-[#262626]">
                <Flame className="h-4 w-4 fill-primary text-primary animate-bounce" />
                <span>{currentStreak} Days</span>
              </div>

              {/* User Bio Stats (Desktop) */}
              <div className="hidden text-right sm:block">
                <div className="text-sm font-bold text-[#E5E5E5] flex items-center justify-end space-x-1.5">
                  {equippedBadge && (
                    <span className="text-sm cursor-help" title={`Equipped Badge: ${equippedBadge.name}`}>
                      {equippedBadge.emoji}
                    </span>
                  )}
                  <span>{currentUser.username}</span>
                  <span className="inline-block rounded bg-primary/10 border border-primary/25 px-1.5 py-0.25 text-[10px] font-bold text-primary">
                    Lvl {currentUser.level}
                  </span>
                </div>
                <div className="text-[11px] font-medium text-[#888888]">
                  {currentUser.title}
                </div>
              </div>

              {/* User Avatar & Logout */}
              <div className="group relative">
                <img
                  id="user-avatar"
                  onClick={() => { setActiveTab("settings"); window.scrollTo(0, 0); }}
                  src={currentUser.avatarUrl}
                  alt={currentUser.username}
                  className="h-9 w-9 cursor-pointer rounded-xl border border-[#1A1A1B] bg-[#0F0F10] object-cover hover:ring-2 hover:ring-primary/50 transition-all"
                  title="Open Sovereign Settings"
                />
                
                {/* Micro Dropdown on hover */}
                <div className="absolute right-0 top-full mt-2 hidden w-48 rounded-xl border border-[#1A1A1B] bg-[#0F0F10] p-1.5 shadow-xl group-hover:block z-50 animate-fade-in">
                  <div className="px-2.5 py-1.5 text-xs text-[#888888] font-medium flex items-center space-x-1.5">
                    {equippedBadge ? (
                      <>
                        <span className="text-sm">{equippedBadge.emoji}</span>
                        <span className="truncate text-neutral-350 font-bold">{equippedBadge.name}</span>
                      </>
                    ) : (
                      <span>Sanctuary Member</span>
                    )}
                  </div>
                  <div className="border-t border-[#1A1A1B] my-1"></div>
                  
                  <button
                    id="dropdown-settings-btn"
                    onClick={() => { setActiveTab("settings"); window.scrollTo(0, 0); }}
                    className="flex w-full items-center space-x-2 rounded-lg px-2.5 py-1.5 text-left text-xs font-semibold text-neutral-300 hover:bg-[#161618] hover:text-primary transition-all cursor-pointer"
                  >
                    <Settings className="h-4 w-4" />
                    <span>Sovereign Settings</span>
                  </button>

                  <button
                    id="logout-btn"
                    onClick={onLogout}
                    className="flex w-full items-center space-x-2 rounded-lg px-2.5 py-1.5 text-left text-xs font-semibold text-rose-400 hover:bg-rose-500/10 transition-all cursor-pointer"
                  >
                    <LogOut className="h-4 w-4" />
                    <span>Exit Sanctuary</span>
                  </button>
                </div>
              </div>
            </div>
          ) : (
            <button
              id="login-trigger-btn"
              onClick={onOpenAuth}
              className="flex items-center space-x-1.5 sm:space-x-2 rounded-xl bg-primary px-3 sm:px-4 py-2 sm:py-2.5 text-xs font-bold text-[#0A0A0B] shadow-lg shadow-primary/10 transition-all hover:bg-primary-hover"
            >
              <LogIn className="h-3.5 w-3.5 sm:h-4 sm:w-4" />
              <span className="hidden sm:inline">Enter Sanctuary</span>
              <span className="sm:hidden">Enter</span>
            </button>
          )}
        </div>
      </div>

      {/* Mobile Sticky Bottom Tab Bar Navigation */}
      <div 
        id="mobile-nav" 
        className="fixed bottom-0 left-0 right-0 z-50 flex border-t border-[#1A1A1B] bg-[#0F0F10]/95 backdrop-blur-md lg:hidden overflow-x-auto py-2.5 px-3 scrollbar-none justify-around items-center safe-bottom shadow-[0_-8px_30px_rgba(0,0,0,0.65)] pb-4"
      >
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              id={`mobile-tab-btn-${tab.id}`}
              key={tab.id}
              onClick={() => {
                setActiveTab(tab.id);
                window.scrollTo({ top: 0, behavior: "smooth" });
              }}
              className={`flex flex-col items-center justify-center rounded-xl py-1.5 px-2.5 text-center transition-all duration-200 ${
                isActive 
                  ? "text-primary font-bold scale-110 bg-primary/5 border border-primary/10" 
                  : "text-[#888888] hover:text-[#E5E5E5]"
              }`}
              style={{ minWidth: "56px" }}
            >
              <Icon className={`h-4.5 w-4.5 mb-0.5 ${isActive ? "text-primary animate-pulse" : "text-neutral-500"}`} />
              <span className="text-[9px] font-medium tracking-tight whitespace-nowrap">
                {tab.label.split(" ")[0]}
              </span>
            </button>
          );
        })}
      </div>
    </header>
  );
}
