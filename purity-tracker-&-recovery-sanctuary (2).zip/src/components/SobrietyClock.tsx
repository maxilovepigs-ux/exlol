/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from "react";
import { motion } from "motion/react";
import { Timer, RefreshCw, AlertTriangle, ShieldCheck, HelpCircle, Heart, Star, CheckCircle, Snowflake } from "lucide-react";
import { User } from "../types";

interface SobrietyClockProps {
  currentUser: User;
  onUpdateUser: (user: User) => void;
  onOpenSOS: () => void;
}

export default function SobrietyClock({ currentUser, onUpdateUser, onOpenSOS }: SobrietyClockProps) {
  const [timePassed, setTimePassed] = useState({ days: 0, hours: 0, minutes: 0, seconds: 0 });
  const [showRelapseModal, setShowRelapseModal] = useState(false);
  const [relapseNote, setRelapseNote] = useState("");
  const [relapseTrigger, setRelapseTrigger] = useState("Boredom");
  const [checkingIn, setCheckingIn] = useState(false);
  const [checkinSuccess, setCheckinSuccess] = useState(false);
  const [checkinNote, setCheckinNote] = useState("");
  const [showCheckinForm, setShowCheckinForm] = useState(false);

  // Tick the clock every second
  useEffect(() => {
    if (!currentUser.streakStartDate) return;

    const interval = setInterval(() => {
      const start = new Date(currentUser.streakStartDate!);
      const now = new Date();
      const diffMs = now.getTime() - start.getTime();

      const days = Math.floor(diffMs / (1000 * 60 * 60 * 24));
      const hours = Math.floor((diffMs % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
      const minutes = Math.floor((diffMs % (1000 * 60 * 60)) / (1000 * 60));
      const seconds = Math.floor((diffMs % (1000 * 60)) / 1000);

      setTimePassed({ days, hours, minutes, seconds });
    }, 1000);

    return () => clearInterval(interval);
  }, [currentUser.streakStartDate]);

  // Check if user already checked in today (YYYY-MM-DD)
  const hasCheckedInToday = () => {
    const todayStr = new Date().toISOString().split("T")[0];
    return currentUser.logs?.some(log => log.date === todayStr && log.cleanDay);
  };

  const handleCheckin = async (e: React.FormEvent) => {
    e.preventDefault();
    setCheckingIn(true);
    try {
      const res = await fetch(`/api/user/${currentUser.id}/checkin`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          note: checkinNote || "Logged a victory! Focused and maintained purity today.",
          mood: "focused",
          cleanDay: true
        })
      });
      if (res.ok) {
        const data = await res.json();
        onUpdateUser(data.user);
        setCheckinSuccess(true);
        setTimeout(() => {
          setCheckinSuccess(false);
          setShowCheckinForm(false);
          setCheckinNote("");
        }, 2500);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setCheckingIn(false);
    }
  };

  const handleRelapseReset = async () => {
    try {
      const res = await fetch(`/api/user/${currentUser.id}/streak`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          action: "relapse",
          note: relapseNote || "Streak reset. Embracing cognitive lessons, staying mindful, and resetting the sail.",
          triggerType: relapseTrigger,
          relapseMood: "restless"
        })
      });
      if (res.ok) {
        const updatedUser = await res.json();
        onUpdateUser(updatedUser);
        setShowRelapseModal(false);
        setRelapseNote("");
      }
    } catch (err) {
      console.error(err);
    }
  };

  // XP Progress ring logic
  const xpInCurrentLevel = currentUser.totalXp % 200;
  const xpPercent = Math.min((xpInCurrentLevel / 200) * 100, 100);

  // Title description and next reward helper
  const getNextTier = () => {
    const d = timePassed.days;
    if (d < 3) return { days: 3 - d, title: "Sprout of Discipline" };
    if (d < 7) return { days: 7 - d, title: "Guardian of the Mind" };
    if (d < 15) return { days: 15 - d, title: "Defender of Purity" };
    if (d < 30) return { days: 30 - d, title: "Sovereign of Focus" };
    if (d < 60) return { days: 60 - d, title: "Aegis of Integrity" };
    if (d < 90) return { days: 90 - d, title: "Ascended Spirit" };
    return null;
  };

  const nextTier = getNextTier();

  return (
    <div id="sobriety-clock-container" className="grid gap-6 lg:grid-cols-3 fade-in text-neutral-200">
      
      {/* Dynamic Visual Streak Wheel */}
      <div className="lg:col-span-2 rounded-2xl border border-[#1A1A1B] bg-[#0F0F10] p-6 shadow-sm flex flex-col items-center justify-between min-h-[400px]">
        
        {/* Tracker Header */}
        <div className="w-full flex items-center justify-between border-b border-[#1A1A1B] pb-4 mb-4">
          <div className="flex items-center space-x-2">
            <Timer className="h-5 w-5 text-primary" />
            <h3 className="font-display font-bold text-neutral-100">Sobriety Chronometer</h3>
          </div>
          <span className="text-[10px] uppercase font-bold tracking-widest text-primary bg-primary/10 border border-primary/20 px-2.5 py-1 rounded-full">
            Realtime Purity
          </span>
        </div>

        {/* The Core Ring */}
        <div className="relative flex h-60 w-60 items-center justify-center rounded-full bg-gradient-to-tr from-primary/5 via-[#0F0F10] to-[#161618] p-2 border-2 border-[#1A1A1B]">
          
          {/* Svg Circle Progress */}
          <svg className="absolute inset-0 h-full w-full rotate-270">
            <circle
              cx="120"
              cy="120"
              r="105"
              className="fill-none stroke-[#1A1A1B]"
              strokeWidth="10"
              transform="translate(0,0)"
            />
            <circle
              cx="120"
              cy="120"
              r="105"
              className="fill-none transition-all duration-1000 ease-in-out"
              style={{ stroke: "var(--primary)" }}
              strokeWidth="10"
              strokeDasharray={659}
              strokeDashoffset={659 - (659 * Math.min(timePassed.days, 90)) / 90}
              strokeLinecap="round"
            />
          </svg>

          {/* Time text inside */}
          <div className="text-center z-10 flex flex-col items-center justify-center">
            <span className="text-[11px] font-bold text-primary tracking-widest uppercase">
              Current Stand
            </span>
            <div className="my-1 flex items-baseline justify-center">
              <motion.span
                key={timePassed.days}
                initial={{ scale: 0.8, opacity: 0.8 }}
                animate={{ scale: 1, opacity: 1 }}
                transition={{ type: "spring", stiffness: 300, damping: 15 }}
                className="text-5xl font-extrabold tracking-tight font-display text-neutral-100 inline-block"
              >
                {timePassed.days}
              </motion.span>
              <span className="ml-1 text-sm font-bold text-neutral-500">days</span>
            </div>
            
            {/* Monospace clock readout */}
            <div className="mt-1 font-mono text-sm font-semibold tracking-wider text-neutral-200 bg-[#161618] px-3 py-1 rounded-lg border border-[#262626]">
              {String(timePassed.hours).padStart(2, "0")}:
              {String(timePassed.minutes).padStart(2, "0")}:
              {String(timePassed.seconds).padStart(2, "0")}
            </div>

            <div className="mt-3 inline-flex items-center space-x-1 rounded bg-primary/10 border border-primary/20 px-2.5 py-0.5 text-[10px] font-bold text-primary">
              <ShieldCheck className="h-3.5 w-3.5 text-primary" style={{ color: "var(--primary)" }} />
              <span>{currentUser.title}</span>
            </div>
          </div>
        </div>

        {/* Counter Action Footer */}
        <div className="w-full mt-6 flex items-center justify-between space-x-4 border-t border-[#1A1A1B] pt-4">
          <button
            id="open-relapse-modal-btn"
            onClick={() => setShowRelapseModal(true)}
            className="flex items-center space-x-2 rounded-xl border border-[#1A1A1B] bg-[#0A0A0B] px-4 py-2.5 text-xs font-semibold text-neutral-400 hover:bg-rose-500/10 hover:text-rose-400 hover:border-rose-500/20 transition-all"
          >
            <RefreshCw className="h-4 w-4" />
            <span>Reflect & Reset Sail</span>
          </button>

          <button
            id="emergency-sos-shortcut-btn"
            onClick={onOpenSOS}
            className="flex items-center space-x-2 rounded-xl bg-rose-600 hover:bg-rose-500 px-5 py-2.5 text-xs font-bold text-white shadow-md shadow-rose-600/10 hover:shadow-rose-600/20 transition-all animate-pulse"
          >
            <AlertTriangle className="h-4 w-4" />
            <span>I Have An Urge!</span>
          </button>
        </div>
      </div>

      {/* Stats, Level, Check-in panel */}
      <div className="rounded-2xl border border-[#1A1A1B] bg-[#0F0F10] p-6 shadow-sm flex flex-col justify-between">
        
        {/* Title / XP tracker */}
        <div className="space-y-4">
          <div className="flex items-center space-x-2 border-b border-[#1A1A1B] pb-4">
            <Star className="h-5 w-5 text-primary" style={{ color: "var(--primary)" }} />
            <h3 className="font-display font-bold text-neutral-100">Sovereign Progress</h3>
          </div>

          {/* Level read */}
          <div className="flex items-center justify-between">
            <div>
              <span className="text-[10px] font-bold text-neutral-500 uppercase tracking-widest">
                Discipline Rating
              </span>
              <h4 className="text-xl font-bold text-neutral-200">Level {currentUser.level}</h4>
            </div>
            <div className="text-right">
              <span className="text-xs font-medium text-neutral-400">
                {currentUser.totalXp} XP total
              </span>
            </div>
          </div>

          {/* Progress bar */}
          <div className="space-y-1.5">
            <div className="h-2.5 w-full rounded-full bg-[#161618] border border-[#262626] overflow-hidden">
              <div 
                className="h-full rounded-full transition-all duration-500"
                style={{ width: `${xpPercent}%`, backgroundColor: "var(--primary)" }}
              ></div>
            </div>
            <div className="flex items-center justify-between text-[11px] text-neutral-500 font-medium">
              <span>{xpInCurrentLevel} / 200 XP</span>
              <span>{200 - xpInCurrentLevel} XP to Lvl {currentUser.level + 1}</span>
            </div>
          </div>

          {/* Streak Freeze Block */}
          <div className="rounded-xl border border-blue-500/10 bg-blue-500/5 p-3.5 flex items-center justify-between">
            <div className="flex items-center space-x-2.5">
              <div className="rounded-lg bg-blue-500/15 p-2 border border-blue-500/20 shrink-0">
                <Snowflake className="h-4.5 w-4.5 text-blue-400" />
              </div>
              <div>
                <h4 className="text-xs font-bold text-blue-400 uppercase tracking-wide">Streak Freezes</h4>
                <p className="text-[10px] text-neutral-400 mt-0.5 leading-normal">
                  Protects streak status if you miss a single daily checklist day. Earned at monthly 30+ day milestones.
                </p>
              </div>
            </div>
            <div className="text-center bg-blue-500/20 border border-blue-500/30 rounded-xl px-3 py-1 shrink-0">
              <span className="text-lg font-extrabold text-blue-300 font-display">
                {currentUser.streakFreezes ?? 0}
              </span>
            </div>
          </div>

          {/* Next milestone */}
          {nextTier && (
            <div className="rounded-xl bg-primary/5 border border-primary/10 p-3 text-xs text-primary" style={{ color: "var(--primary)", borderColor: "var(--primary-light)" }}>
              <span className="font-bold">Next Title Unlock: </span>
              In <span className="font-extrabold" style={{ color: "var(--primary)" }}>{nextTier.days} days</span>, you will reach the status of <span className="font-bold underline">{nextTier.title}</span>. Keep standing tall!
            </div>
          )}

          <div className="border-t border-[#1A1A1B] my-2 pt-2">
            <div className="flex items-center justify-between text-xs text-neutral-400 mb-1">
              <span>Highest Recorded Streak:</span>
              <span className="font-bold text-neutral-200">{Math.max(currentUser.highestStreak || 0, timePassed.days)} Days</span>
            </div>
            <div className="flex items-center justify-between text-xs text-neutral-400">
              <span>Joined Purity Quest:</span>
              <span className="font-semibold text-neutral-300">
                {new Date(currentUser.joinedDate).toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' })}
              </span>
            </div>
          </div>
        </div>

        {/* Daily Check-In Widget */}
        <div className="mt-6 border-t border-[#1A1A1B] pt-4">
          {hasCheckedInToday() ? (
            <div className="flex flex-col items-center justify-center py-4 text-center rounded-xl bg-emerald-500/5 border border-emerald-500/20">
              <CheckCircle className="h-10 w-10 text-emerald-500 mb-2" />
              <h4 className="text-sm font-bold text-emerald-400">Today's Check-In Logged</h4>
              <p className="text-[11px] text-neutral-400 mt-1">
                You declared purity today and secured 50 XP. Rest easy.
              </p>
            </div>
          ) : !showCheckinForm ? (
            <button
              id="show-checkin-form-btn"
              onClick={() => setShowCheckinForm(true)}
              className="w-full flex items-center justify-center space-x-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-sm py-3 transition-all"
            >
              <ShieldCheck className="h-4.5 w-4.5" />
              <span>Log Today's Victory (+50 XP)</span>
            </button>
          ) : (
            <form onSubmit={handleCheckin} className="space-y-3 p-3.5 rounded-xl bg-[#161618] border border-[#262626]">
              <h4 className="text-xs font-bold text-neutral-300 uppercase tracking-wider">
                Daily Check-In Reflections
              </h4>
              <textarea
                required
                placeholder="Write a brief sentence about your frame of mind today..."
                value={checkinNote}
                onChange={(e) => setCheckinNote(e.target.value)}
                className="w-full h-16 rounded-lg border border-[#1A1A1B] bg-[#0A0A0B] p-2 text-xs text-neutral-200 outline-none focus:border-primary"
              />
              <div className="flex justify-end space-x-2">
                <button
                  type="button"
                  onClick={() => setShowCheckinForm(false)}
                  className="rounded-lg px-2.5 py-1 text-xs font-medium text-neutral-500 hover:bg-[#0A0A0B]"
                >
                  Cancel
                </button>
                <button
                  id="submit-checkin-btn"
                  type="submit"
                  disabled={checkingIn || checkinSuccess}
                  className="rounded-lg bg-emerald-600 text-white px-3.5 py-1 text-xs font-bold hover:bg-emerald-500"
                >
                  {checkinSuccess ? "Logged!" : checkingIn ? "Saving..." : "Verify Clean"}
                </button>
              </div>
            </form>
          )}
        </div>
      </div>

      {/* Cognitive Reflection / Relapse Reset Modal */}
      {showRelapseModal && (
        <div id="relapse-modal-overlay" className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 px-4 py-6 backdrop-blur-sm animate-fade-in overflow-y-auto">
          <div id="relapse-modal-content" className="w-full max-w-lg max-h-[90vh] overflow-y-auto scrollbar-none rounded-2xl border border-[#1A1A1B] bg-[#0F0F10] p-6 shadow-2xl sm:p-8 fade-in">
            <h3 className="font-display text-xl font-bold text-neutral-100 flex items-center space-x-2">
              <RefreshCw className="h-5.5 w-5.5 text-rose-500" />
              <span>A Clear Reset: The Compassionate Harbor</span>
            </h3>
            
            <p className="mt-2.5 text-xs text-neutral-400 leading-relaxed">
              We do not condemn. In our sanctuary, a stumble is not a "failure" — it is a piece of cognitive information. Your brain has not lost the healing neural pathways you built. To reset safely, complete this reflection. We will clear the chronometer together and start our new trek instantly.
            </p>

            <div className="mt-5 space-y-4">
              {/* Trigger category */}
              <div>
                <label className="block text-xs font-bold text-neutral-400 uppercase tracking-wider mb-1.5">
                  1. What Trigger Environment Preceded This?
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {["Social Media", "Stress", "Boredom", "Late Night", "Fatigue", "Loneliness"].map((type) => (
                    <button
                      key={type}
                      type="button"
                      onClick={() => setRelapseTrigger(type)}
                      className={`rounded-lg py-1.5 text-xs font-medium border text-center transition-all ${
                        relapseTrigger === type
                          ? "bg-rose-500/10 border-rose-500/40 text-rose-400 font-bold"
                          : "border-[#1A1A1B] bg-[#0A0A0B] text-neutral-400 hover:bg-[#161618]"
                      }`}
                    >
                      {type}
                    </button>
                  ))}
                </div>
              </div>

              {/* Reflective log text */}
              <div>
                <label className="block text-xs font-bold text-neutral-400 uppercase tracking-wider mb-1.5">
                  2. Honest Reflection & Strategic Safeties
                </label>
                <textarea
                  required
                  placeholder="What was the sequence of events? What app/habit can we block or change to support you next time? (Be kind to yourself)."
                  value={relapseNote}
                  onChange={(e) => setRelapseNote(e.target.value)}
                  className="w-full h-24 rounded-xl border border-[#1A1A1B] bg-[#0A0A0B] p-2.5 text-xs text-neutral-200 outline-none focus:border-rose-500"
                />
              </div>

              {/* Compassion block */}
              <div className="rounded-xl bg-primary/5 border border-primary/10 p-3 text-[11px] text-primary leading-relaxed flex items-start space-x-2" style={{ color: "var(--primary)", borderColor: "var(--primary-light)" }}>
                <Heart className="h-4.5 w-4.5 text-primary shrink-0 mt-0.5" style={{ color: "var(--primary)" }} />
                <span>
                  <strong>Forgiveness Protocol:</strong> "I release guilt. I built {timePassed.days} days of clean thinking. My brain is healthier than it was. Purity starts again with my next breath."
                </span>
              </div>
            </div>

            {/* Actions */}
            <div className="mt-6 flex justify-end space-x-2.5 border-t border-[#1A1A1B] pt-4">
              <button
                type="button"
                onClick={() => setShowRelapseModal(false)}
                className="rounded-xl border border-[#1A1A1B] bg-[#0A0A0B] px-4 py-2.5 text-xs font-semibold text-neutral-400 hover:bg-[#161618]"
              >
                Go Back (Save Streak)
              </button>
              <button
                id="confirm-relapse-reset-btn"
                type="button"
                onClick={handleRelapseReset}
                className="rounded-xl bg-rose-600 hover:bg-rose-500 px-5 py-2.5 text-xs font-bold text-white shadow-lg shadow-rose-600/10"
              >
                Resume Purity Journey Now
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
