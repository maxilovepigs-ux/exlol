/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface User {
  id: string;
  username: string;
  email: string;
  avatarUrl: string;
  streakStartDate: string | null; // ISO string when the streak began, null if not started
  highestStreak: number; // in days
  totalXp: number;
  level: number;
  title: string;
  joinedDate: string;
  statusMessage?: string;
  equippedBadgeId?: string | null;
  logs?: JournalEntry[];
  triggers?: TriggerLog[];
  following?: string[]; // Array of followed user IDs
  streakFreezes?: number;
  lastEarnedFreezeMonth?: string | null;
  bannerColor?: string;
  customStatus?: string;
  socialLink?: string;
  password?: string;
  role?: "user" | "moderator" | "admin";
}

export interface GlobalChatMessage {
  id: string;
  userId: string;
  username: string;
  avatarUrl: string;
  text: string;
  timestamp: string; // ISO string
  level: number;
  title: string;
}

export interface SupportTicket {
  id: string;
  userId: string;
  username: string;
  avatarUrl: string;
  title: string;
  status: "open" | "resolved";
  type: "ai" | "real";
  messages: SupportMessage[];
  createdAt: string; // ISO string
}

export interface SupportMessage {
  id: string;
  sender: "user" | "ai" | "mod";
  senderName: string;
  text: string;
  createdAt: string; // ISO string
}

export interface JournalEntry {
  id: string;
  userId: string;
  date: string; // YYYY-MM-DD
  note: string;
  mood: "peaceful" | "focused" | "restless" | "tempted" | "victorious";
  checkInCompleted: boolean;
  cleanDay: boolean; // true if maintained purity, false if relapsed
}

export interface TriggerLog {
  id: string;
  userId: string;
  date: string; // ISO string
  intensity: number; // 1-10
  type: "Boredom" | "Stress" | "Social Media" | "Late Night" | "Fatigue" | "Loneliness";
  mitigationStrategy: string;
}

export interface LeaderboardEntry {
  id: string;
  rank?: number;
  username: string;
  avatarUrl: string;
  currentStreak: number; // in days
  highestStreak: number;
  level: number;
  title: string;
  isRealUser?: boolean;
  statusMessage?: string;
  equippedBadgeId?: string | null;
}

export interface ChatMessage {
  id: string;
  sender: "user" | "mentor";
  text: string;
  timestamp: string; // ISO string
}
