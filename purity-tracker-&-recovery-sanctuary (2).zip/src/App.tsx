/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from "react";
import { motion } from "motion/react";
import { 
  Flame, 
  ShieldAlert, 
  BookOpen, 
  Award, 
  Brain, 
  Target, 
  Activity, 
  CheckSquare, 
  Sparkles, 
  Quote, 
  Send, 
  Heart,
  ChevronRight,
  Globe,
  Plus,
  RefreshCw,
  Eye,
  PenTool,
  Trash2,
  ExternalLink,
  Compass,
  MessageSquare
} from "lucide-react";
import { User } from "./types";
import Header from "./components/Header";
import AuthModal from "./components/AuthModal";
import SobrietyClock from "./components/SobrietyClock";
import UrgeSOS from "./components/UrgeSOS";
import JournalLogs from "./components/JournalLogs";
import WisdomLibrary from "./components/WisdomLibrary";
import CommunitySanctuary from "./components/CommunitySanctuary";
import SupportSanctuary from "./components/SupportSanctuary";
import Milestones from "./components/Milestones";
import HabitTrends from "./components/HabitTrends";
import InteractiveCompanion from "./components/InteractiveCompanion";
import { getActiveBadge } from "./lib/badges";
import { updateSEO } from "./lib/seo";
import { PrivacyPolicy, TermsOfService, CookiePolicy, AboutPage, ContactPage, NotFoundPage, DisclaimerPage, FAQPage, HelpCentrePage, CommunityGuidelinesPage, ChangelogPage, AccessibilityPage } from "./components/LegalPages";
import CookieConsent from "./components/CookieConsent";
import Documentation from "./components/Documentation";
import SovereignSettings from "./components/SovereignSettings";
import CommandPalette from "./components/CommandPalette";
import CustomCursor from "./components/CustomCursor";

const STOIC_QUOTES = [
  { text: "The happiness of your life depends upon the quality of your thoughts.", author: "Marcus Aurelius" },
  { text: "No man is free who is not master of himself.", author: "Epictetus" },
  { text: "A rational being can turn each obstacle into fuel for his own progress.", author: "Marcus Aurelius" },
  { text: "We suffer more often in imagination than in reality.", author: "Seneca" },
  { text: "It is not that we have a short time to live, but that we waste a lot of it.", author: "Seneca" },
  { text: "If you are defeated once and tell yourself you will conquer tomorrow, you will find yourself repeating the pattern.", author: "Epictetus" },
  { text: "Control your mind or it will control you.", author: "Horace" },
];

const WISDOM_REFLECTIONS = [
  {
    text: "People look for retreats for themselves, in the country, by the coast, or in the hills... There is nowhere that a person can find a more peaceful and trouble-free retreat than in his own mind... So constantly give yourself this retreat, and renew yourself. Let your basic principles be brief and fundamental, the kind that will at once close out the world and send you back without any irritation to the life to which you must return.",
    author: "Marcus Aurelius",
    source: "Meditations, Book IV.3"
  },
  {
    text: "Withdraw into yourself, as far as you can. Associate with those who will make a better man of you. Welcome those whom you yourself can improve. The process is mutual; for men learn while they teach... Let us keep to the road which nature has mapped out for us, and not wander from it. If we do, we shall find ourselves climbing a steep hill where every step is painful.",
    author: "Seneca",
    source: "Letters from a Stoic, Letter VIII"
  },
  {
    text: "No great thing is created suddenly, any more than a bunch of grapes or a fig. If you tell me that you desire a fig, I answer you that there must be time. Let it first blossom, then bear fruit, then ripen. Since then even the fruit of a fig-tree is not brought to perfection suddenly in one hour, do you think to possess the mind of a man so easily and in a moment?",
    author: "Epictetus",
    source: "Discourses, Book I"
  },
  {
    text: "If you work hard to do a good thing, the labor is soon gone, but the good remains. If you do an evil thing for pleasure, the pleasure is soon gone, but the evil remains. Nourish your mind with noble thoughts and reject the sweet poison of transient desires.",
    author: "Musonius Rufus",
    source: "Lectures & Fragments"
  }
];

export default function App() {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [activeTab, setActiveTab] = useState<string>("dashboard");
  const [isTabChanging, setIsTabChanging] = useState<boolean>(false);

  // Synchronize activeTab with URL pathname for Cloudflare Pages compatible deep links
  useEffect(() => {
    const handleLocationChange = () => {
      // Get the path from location (removing leading slash, e.g., "/settings" -> "settings")
      let path = window.location.pathname.slice(1);
      // Clean trailing slash if present
      if (path.endsWith("/")) {
        path = path.slice(0, -1);
      }
      
      // Map root or empty path to "dashboard"
      if (!path) {
        path = "dashboard";
      }

      const validTabs = [
        "dashboard", "sos", "wisdom", "leaderboard", "community", "support", "mentor",
        "about", "contact", "privacy", "terms", "cookies", "disclaimer", "faq", "help",
        "guidelines", "changelog", "accessibility", "docs", "settings"
      ];

      if (validTabs.includes(path)) {
        setActiveTab(path);
      } else {
        // Fallback to dashboard
        setActiveTab("dashboard");
      }
    };

    // Run once on mount to handle initial load/deep links
    handleLocationChange();

    window.addEventListener("popstate", handleLocationChange);
    return () => window.removeEventListener("popstate", handleLocationChange);
  }, []);

  // Synchronize browser URL with the activeTab state (runs whenever activeTab changes)
  useEffect(() => {
    let expectedPath = activeTab === "dashboard" ? "/" : `/${activeTab}`;
    if (window.location.pathname !== expectedPath) {
      window.history.pushState(null, "", expectedPath);
    }
  }, [activeTab]);

  const handleSetActiveTab = (tab: string) => {
    setIsTabChanging(true);
    setActiveTab(tab);
    window.scrollTo({ top: 0, behavior: "smooth" });
    setTimeout(() => {
      setIsTabChanging(false);
    }, 280);
  };

  const [isAuthOpen, setIsAuthOpen] = useState<boolean>(false);
  const [statusText, setStatusText] = useState<string>("");
  const [updatingStatus, setUpdatingStatus] = useState<boolean>(false);
  const [isCommandPaletteOpen, setIsCommandPaletteOpen] = useState<boolean>(false);

  // Focus Mode state
  const [isFocusMode, setIsFocusMode] = useState<boolean>(() => {
    return localStorage.getItem("sanctuary_focus_mode") === "true";
  });

  const handleToggleFocusMode = () => {
    setIsFocusMode(prev => {
      const newVal = !prev;
      localStorage.setItem("sanctuary_focus_mode", String(newVal));
      if (newVal) {
        // If enabling Focus Mode, and currently on a non-essential tab, switch to dashboard
        if (!["dashboard", "sos", "wisdom"].includes(activeTab)) {
          handleSetActiveTab("dashboard");
        }
      }
      return newVal;
    });
  };

  // Theme state: dark, deep-night, light, midnight, soft-gray, glassmorphism, amoled, glass, ocean
  const [theme, setTheme] = useState<"dark" | "deep-night" | "light" | "midnight" | "soft-gray" | "glassmorphism" | "amoled" | "glass" | "ocean">(() => {
    return (localStorage.getItem("sanctuary_theme") as any) || "dark";
  });

  const [accentColor, setAccentColor] = useState<"emerald" | "amber" | "indigo" | "rose" | "violet" | "orange">(() => {
    return (localStorage.getItem("sanctuary_accent") as any) || "amber";
  });

  const [glassmorphism, setGlassmorphism] = useState<boolean>(() => {
    return localStorage.getItem("sanctuary_glassmorphism") === "true";
  });

  const [fontSize, setFontSize] = useState<"normal" | "medium" | "large">(() => {
    return (localStorage.getItem("sanctuary_font_size") as any) || "normal";
  });

  const [reducedMotion, setReducedMotion] = useState<boolean>(() => {
    return localStorage.getItem("sanctuary_reduced_motion") === "true";
  });

  const [highContrast, setHighContrast] = useState<boolean>(() => {
    return localStorage.getItem("sanctuary_high_contrast") === "true";
  });

  const [customCursor, setCustomCursor] = useState<boolean>(() => {
    return localStorage.getItem("sanctuary_custom_cursor") !== "false";
  });

  useEffect(() => {
    localStorage.setItem("sanctuary_custom_cursor", String(customCursor));
  }, [customCursor]);

  useEffect(() => {
    const root = document.documentElement;
    // Remove all theme classes first to clean state
    const themesList = [
      "theme-deep-night", 
      "theme-light", 
      "theme-midnight", 
      "theme-soft-gray", 
      "theme-glassmorphism", 
      "theme-amoled", 
      "theme-glass", 
      "theme-ocean"
    ];
    root.classList.remove(...themesList);
    document.body.classList.remove(...themesList);

    if (theme === "deep-night") {
      root.classList.add("theme-deep-night");
      document.body.classList.add("theme-deep-night");
    } else if (theme === "light") {
      root.classList.add("theme-light");
      document.body.classList.add("theme-light");
    } else if (theme === "midnight") {
      root.classList.add("theme-midnight");
      document.body.classList.add("theme-midnight");
    } else if (theme === "soft-gray") {
      root.classList.add("theme-soft-gray");
      document.body.classList.add("theme-soft-gray");
    } else if (theme === "glassmorphism") {
      root.classList.add("theme-glassmorphism");
      document.body.classList.add("theme-glassmorphism");
    } else if (theme === "amoled") {
      root.classList.add("theme-amoled");
      document.body.classList.add("theme-amoled");
    } else if (theme === "glass") {
      root.classList.add("theme-glass");
      document.body.classList.add("theme-glass");
    } else if (theme === "ocean") {
      root.classList.add("theme-ocean");
      document.body.classList.add("theme-ocean");
    }
    localStorage.setItem("sanctuary_theme", theme);
  }, [theme]);

  useEffect(() => {
    const root = document.documentElement;
    const colors = {
      emerald: { primary: "#10b981", hover: "#059669", light: "rgba(16, 185, 129, 0.1)" },
      amber: { primary: "#f59e0b", hover: "#d97706", light: "rgba(245, 158, 11, 0.1)" },
      indigo: { primary: "#6366f1", hover: "#4f46e5", light: "rgba(99, 102, 241, 0.1)" },
      rose: { primary: "#f43f5e", hover: "#e11d48", light: "rgba(244, 63, 94, 0.1)" },
      violet: { primary: "#8b5cf6", hover: "#7c3aed", light: "rgba(139, 92, 246, 0.1)" },
      orange: { primary: "#f97316", hover: "#ea580c", light: "rgba(249, 115, 22, 0.1)" }
    };
    const active = colors[accentColor] || colors.amber;
    root.style.setProperty("--primary", active.primary);
    root.style.setProperty("--primary-hover", active.hover);
    root.style.setProperty("--primary-light", active.light);
    localStorage.setItem("sanctuary_accent", accentColor);
  }, [accentColor]);

  useEffect(() => {
    const root = document.documentElement;
    if (glassmorphism) {
      root.classList.add("glassmorphism-active");
    } else {
      root.classList.remove("glassmorphism-active");
    }
    localStorage.setItem("sanctuary_glassmorphism", String(glassmorphism));
  }, [glassmorphism]);

  useEffect(() => {
    const root = document.documentElement;
    root.classList.remove("accessibility-font-medium", "accessibility-font-large");
    if (fontSize === "medium") {
      root.classList.add("accessibility-font-medium");
    } else if (fontSize === "large") {
      root.classList.add("accessibility-font-large");
    }
    localStorage.setItem("sanctuary_font_size", fontSize);
  }, [fontSize]);

  useEffect(() => {
    const root = document.documentElement;
    if (reducedMotion) {
      root.classList.add("accessibility-reduced-motion");
    } else {
      root.classList.remove("accessibility-reduced-motion");
    }
    localStorage.setItem("sanctuary_reduced_motion", String(reducedMotion));
  }, [reducedMotion]);

  useEffect(() => {
    const root = document.documentElement;
    if (highContrast) {
      root.classList.add("accessibility-high-contrast");
    } else {
      root.classList.remove("accessibility-high-contrast");
    }
    localStorage.setItem("sanctuary_high_contrast", String(highContrast));
  }, [highContrast]);

  // Premium Ambient Custom Cursor tracking listeners
  const [mousePos, setMousePos] = useState({ x: -100, y: -100 });
  const [isCursorHovered, setIsCursorHovered] = useState(false);
  const [isMobileDevice, setIsMobileDevice] = useState(false);

  useEffect(() => {
    const checkMobile = () => {
      setIsMobileDevice('ontouchstart' in window || navigator.maxTouchPoints > 0);
    };
    checkMobile();

    if ('ontouchstart' in window || navigator.maxTouchPoints > 0) return;

    const handleMouseMove = (e: MouseEvent) => {
      setMousePos({ x: e.clientX, y: e.clientY });
    };

    const handleMouseOver = (e: MouseEvent) => {
      const target = e.target as HTMLElement;
      if (
        target && (
          target.tagName === 'BUTTON' || 
          target.tagName === 'A' || 
          target.closest('button') || 
          target.closest('a') ||
          target.classList.contains('cursor-pointer') ||
          target.closest('.cursor-pointer')
        )
      ) {
        setIsCursorHovered(true);
      } else {
        setIsCursorHovered(false);
      }
    };

    window.addEventListener('mousemove', handleMouseMove);
    window.addEventListener('mouseover', handleMouseOver);

    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mouseover', handleMouseOver);
    };
  }, []);

  // Synchronize SEO tags and Structured Data on Tab changes to optimize indexability
  useEffect(() => {
    updateSEO(activeTab);
  }, [activeTab]);

  // Privacy Screen state (triggers when tab/window is inactive/blurred)
  const [isPrivacyScreenActive, setIsPrivacyScreenActive] = useState<boolean>(false);

  useEffect(() => {
    const handleVisibilityChange = () => {
      if (document.hidden) {
        setIsPrivacyScreenActive(true);
      }
    };

    const handleBlur = () => {
      setIsPrivacyScreenActive(true);
    };

    const handleFocus = () => {
      // Gentle auto-recovery on focus
      setIsPrivacyScreenActive(false);
    };

    document.addEventListener("visibilitychange", handleVisibilityChange);
    window.addEventListener("blur", handleBlur);
    window.addEventListener("focus", handleFocus);

    return () => {
      document.removeEventListener("visibilitychange", handleVisibilityChange);
      window.removeEventListener("blur", handleBlur);
      window.removeEventListener("focus", handleFocus);
    };
  }, []);

  // Global Keyboard Shortcuts (Ctrl+K Command Palette or standalone single-key mappings)
  useEffect(() => {
    const handleGlobalKeyDown = (e: KeyboardEvent) => {
      // Ignore if user is inside an input/textarea/select element
      const activeElement = document.activeElement;
      const isInput = activeElement && (
        activeElement.tagName === "INPUT" ||
        activeElement.tagName === "TEXTAREA" ||
        activeElement.tagName === "SELECT" ||
        activeElement.getAttribute("contenteditable") === "true"
      );

      // Ctrl + K or Cmd + K toggles the Command Palette regardless of input focus
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "k") {
        e.preventDefault();
        setIsCommandPaletteOpen(prev => !prev);
        return;
      }

      if (isInput) return;

      // Standalone single-key shortcut mappings when not in inputs
      const key = e.key.toLowerCase();
      
      // Focus mode toggle
      if (key === "f") {
        e.preventDefault();
        handleToggleFocusMode();
      }
      // Cycle theme
      else if (key === "t") {
        e.preventDefault();
        setTheme(prev => {
          const themes: ("dark" | "deep-night" | "light" | "midnight" | "soft-gray" | "glassmorphism" | "amoled" | "glass" | "ocean")[] = ["dark", "deep-night", "light", "midnight", "soft-gray", "glassmorphism", "amoled", "glass", "ocean"];
          const nextIdx = (themes.indexOf(prev) + 1) % themes.length;
          return themes[nextIdx];
        });
      }
      // Trigger Rescue SOS
      else if (key === "e") {
        e.preventDefault();
        setActiveTab("sos");
      }
      // Toggle Privacy Mask
      else if (key === "p") {
        e.preventDefault();
        setIsPrivacyScreenActive(prev => !prev);
      }
    };

    window.addEventListener("keydown", handleGlobalKeyDown);
    return () => window.removeEventListener("keydown", handleGlobalKeyDown);
  }, [activeTab]);
  
  // Leaderboard states
  const [leaderboard, setLeaderboard] = useState<any[]>([]);
  const [leaderboardLoading, setLeaderboardLoading] = useState<boolean>(false);

  // Custom Daily Habits state
  const [customHabits, setCustomHabits] = useState<{ key: string; title: string; desc: string }[]>(() => {
    const saved = localStorage.getItem("sanctuary_custom_habits");
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        console.error(e);
      }
    }
    return [];
  });

  const [newHabitTitle, setNewHabitTitle] = useState("");
  const [newHabitDesc, setNewHabitDesc] = useState("");

  // Daily checklist states
  const [dailyChecklist, setDailyChecklist] = useState<Record<string, boolean>>(() => {
    const saved = localStorage.getItem("sanctuary_daily_checklist");
    
    // Load custom habits from localStorage directly for initialization
    const savedCustom = localStorage.getItem("sanctuary_custom_habits");
    let parsedCustom: { key: string; title: string; desc: string }[] = [];
    if (savedCustom) {
      try {
        parsedCustom = JSON.parse(savedCustom);
      } catch (e) {}
    }

    const initialItems: Record<string, boolean> = {
      cold_splash: false,
      five_min_box_breathing: false,
      offline_hours: false,
      read_philosophy: false,
      physical_squats: false,
      clean_eyes: false
    };

    parsedCustom.forEach(habit => {
      initialItems[habit.key] = false;
    });

    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (parsed.date === new Date().toISOString().split("T")[0]) {
          return { ...initialItems, ...parsed.items };
        }
      } catch (e) {
        console.error(e);
      }
    }
    return initialItems;
  });

  // AI Mentor Chat states
  const [chatMessages, setChatMessages] = useState<any[]>([
    {
      id: "init",
      sender: "mentor",
      text: "Greetings, seeker. I am your AI Sanctuary Mentor. I hold no judgment, only clinical facts of neural rewiring and the deep strength of stoic self-command. Tell me, how does your mind feel right now? Are you experiencing a surge, or are you reflecting on a reset?",
      timestamp: new Date().toISOString()
    }
  ]);
  const [chatInput, setChatInput] = useState<string>("");
  const [chatLoading, setChatLoading] = useState<boolean>(false);
  const chatScrollRef = useRef<HTMLDivElement>(null);

  // Active Stoic Quote selection
  const [currentQuoteIdx, setCurrentQuoteIdx] = useState<number>(0);

  // Sovereign Objective states
  const [sovereignObjective, setSovereignObjective] = useState<string>(() => {
    return localStorage.getItem("sanctuary_sovereign_objective") || "";
  });
  const [objectiveProgress, setObjectiveProgress] = useState<number>(() => {
    const saved = localStorage.getItem("sanctuary_objective_progress");
    return saved ? Number(saved) : 0;
  });

  // Save Sovereign Objective locally
  useEffect(() => {
    localStorage.setItem("sanctuary_sovereign_objective", sovereignObjective);
  }, [sovereignObjective]);

  useEffect(() => {
    localStorage.setItem("sanctuary_objective_progress", String(objectiveProgress));
  }, [objectiveProgress]);

  // Daily Wisdom Reflection states
  const [reflectionIdx, setReflectionIdx] = useState<number>(() => {
    return new Date().getDate() % WISDOM_REFLECTIONS.length;
  });
  const [reflectedToday, setReflectedToday] = useState<boolean>(() => {
    const todayStr = new Date().toISOString().split("T")[0];
    const savedDate = localStorage.getItem("sanctuary_reflected_today_date");
    return savedDate === todayStr;
  });
  const [reflectionCount, setReflectionCount] = useState<number>(() => {
    return Number(localStorage.getItem("sanctuary_reflection_count")) || 0;
  });

  useEffect(() => {
    localStorage.setItem("sanctuary_reflection_count", String(reflectionCount));
  }, [reflectionCount]);

  // Initialize and load persistent session
  useEffect(() => {
    const cachedUserId = localStorage.getItem("sanctuary_user_id");
    if (cachedUserId) {
      fetchUserProfile(cachedUserId);
    } else {
      // Prompt auth on first visit to secure identity
      setIsAuthOpen(true);
    }

    // Set random quote
    setCurrentQuoteIdx(Math.floor(Math.random() * STOIC_QUOTES.length));
  }, []);

  // Save checklist locally daily
  useEffect(() => {
    localStorage.setItem(
      "sanctuary_daily_checklist",
      JSON.stringify({
        date: new Date().toISOString().split("T")[0],
        items: dailyChecklist
      })
    );
  }, [dailyChecklist]);

  // Save custom habits locally
  useEffect(() => {
    localStorage.setItem("sanctuary_custom_habits", JSON.stringify(customHabits));
  }, [customHabits]);

  // Scroll to bottom of chat
  useEffect(() => {
    if (chatScrollRef.current) {
      chatScrollRef.current.scrollIntoView({ behavior: "smooth" });
    }
  }, [chatMessages]);

  const fetchUserProfile = async (userId: string) => {
    try {
      const res = await fetch(`/api/user/${userId}`);
      if (res.ok) {
        const user = await res.json();
        setCurrentUser(user);
        setStatusText(user.statusMessage || "");
        localStorage.setItem("sanctuary_user_id", user.id);
        if (user.role === "moderator" || user.role === "admin" || user.username === "ollymckee101") {
          setActiveTab("support");
        }
      } else {
        localStorage.removeItem("sanctuary_user_id");
      }
    } catch (err) {
      console.error("Failed to load user profile:", err);
    }
  };

  const handleAuthSuccess = (user: User) => {
    setCurrentUser(user);
    setStatusText(user.statusMessage || "");
    localStorage.setItem("sanctuary_user_id", user.id);
    if (user.role === "moderator" || user.role === "admin" || user.username === "ollymckee101") {
      setActiveTab("support");
    }
    setIsAuthOpen(false);
  };

  const handleLogout = () => {
    setCurrentUser(null);
    localStorage.removeItem("sanctuary_user_id");
    setActiveTab("dashboard");
    setIsAuthOpen(true);
  };

  const handleUpdateUser = (updatedUser: User) => {
    setCurrentUser(updatedUser);
  };

  // Sync checklist XP to server
  const [addingCustom, setAddingCustom] = useState(false); // Helper state for add animation / loading if needed

  const handleChecklistToggle = async (key: string) => {
    if (!currentUser) {
      setIsAuthOpen(true);
      return;
    }
    const isNowChecked = !dailyChecklist[key];
    setDailyChecklist(prev => ({ ...prev, [key]: isNowChecked }));

    if (isNowChecked) {
      try {
        const standardHabits = [
          { key: "cold_splash", title: "Autonomic Cold Water Splash" },
          { key: "five_min_box_breathing", title: "5 Min Box Breathing Anchor" },
          { key: "offline_hours", title: "3 Consecutive Offline Hours" },
          { key: "read_philosophy", title: "Stoic Passage Reflection" },
          { key: "physical_squats", title: "25 Deep Skeletal Air Squats" },
          { key: "clean_eyes", title: "Zero Digital Trigger Peeking" }
        ];
        const matched = standardHabits.find(h => h.key === key) || customHabits.find(h => h.key === key);
        const itemTitle = matched ? matched.title : key.replace("_", " ").toUpperCase();

        const res = await fetch(`/api/user/${currentUser.id}/checkin`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            note: `Successfully checked off item: ${itemTitle}`,
            mood: "resilient",
            cleanDay: true
          })
        });
        if (res.ok) {
          const data = await res.json();
          setCurrentUser(data.user);
        }
      } catch (err) {
        console.error(err);
      }
    }
  };

  // Sync status message to leaderboard
  const handleSaveStatus = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) return;
    setUpdatingStatus(true);
    try {
      const res = await fetch(`/api/user/${currentUser.id}/status`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ statusMessage: statusText })
      });
      if (res.ok) {
        const updatedUser = await res.json();
        setCurrentUser(updatedUser);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setUpdatingStatus(false);
    }
  };

  // Fetch leaderboard ranking
  const fetchLeaderboard = async () => {
    setLeaderboardLoading(true);
    try {
      const res = await fetch("/api/leaderboard");
      if (res.ok) {
        const data = await res.json();
        setLeaderboard(data);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLeaderboardLoading(false);
    }
  };

  // Load leaderboard on tab active
  useEffect(() => {
    if (activeTab === "leaderboard") {
      fetchLeaderboard();
    }
  }, [activeTab, currentUser]);

  // Send message to AI Mentor
  const handleSendMessage = async (e?: React.FormEvent, customPrompt?: string) => {
    if (e) e.preventDefault();
    const promptToSend = customPrompt || chatInput;
    if (!promptToSend.trim()) return;

    const userMsg = {
      id: "msg_" + Math.random().toString(36).substring(2, 9),
      sender: "user",
      text: promptToSend,
      timestamp: new Date().toISOString()
    };

    setChatMessages(prev => [...prev, userMsg]);
    if (!customPrompt) setChatInput("");
    setChatLoading(true);

    try {
      const chatHistory = [...chatMessages, userMsg].map(m => ({
        sender: m.sender,
        text: m.text
      }));

      const res = await fetch("/api/mentor", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          messages: chatHistory,
          userProfile: currentUser ? {
            username: currentUser.username,
            currentStreak: currentUser.streakStartDate ? Math.floor(Math.abs(new Date().getTime() - new Date(currentUser.streakStartDate).getTime()) / (1000 * 60 * 60 * 24)) : 0,
            highestStreak: currentUser.highestStreak,
            level: currentUser.level,
            title: currentUser.title
          } : null
        })
      });

      if (res.ok) {
        const data = await res.json();
        setChatMessages(prev => [...prev, {
          id: "reply_" + Math.random().toString(36).substring(2, 9),
          sender: "mentor",
          text: data.text,
          timestamp: new Date().toISOString()
        }]);
      } else {
        throw new Error();
      }
    } catch (err) {
      setChatMessages(prev => [...prev, {
        id: "error_" + Math.random().toString(36).substring(2, 9),
        sender: "mentor",
        text: "The mentor is meditating on your words. I am currently offline, but remember: physical urges are only temporary chemistry. Close your browser, do 20 pushups, and let the wave surf away.",
        timestamp: new Date().toISOString()
      }]);
    } finally {
      setChatLoading(false);
    }
  };

  return (
    <div id="app-container" className="min-h-screen bg-[#0A0A0B] text-neutral-200 font-sans flex flex-col justify-between relative overflow-x-hidden">
      
      {/* Premium Ambient Background Glows */}
      {!reducedMotion && (
        <div className="absolute inset-0 overflow-hidden pointer-events-none z-0 select-none">
          <div className={`absolute top-[5%] left-[10%] w-[45vw] h-[45vw] md:w-[35rem] md:h-[35rem] rounded-full mix-blend-screen filter blur-[120px] opacity-[0.08] transition-all duration-1000 animate-float-slow ${
            accentColor === "emerald" ? "bg-emerald-500" :
            accentColor === "indigo" ? "bg-indigo-500" :
            accentColor === "rose" ? "bg-rose-500" :
            accentColor === "violet" ? "bg-violet-500" :
            accentColor === "orange" ? "bg-orange-500" : "bg-amber-500"
          }`} />
          <div className="absolute top-[35%] right-[5%] w-[40vw] h-[40vw] md:w-[30rem] md:h-[30rem] rounded-full mix-blend-screen filter blur-[130px] opacity-[0.05] transition-all duration-1000 animate-float-slow-reverse bg-purple-500" />
          <div className="absolute bottom-[15%] left-[20%] w-[35vw] h-[35vw] md:w-[25rem] md:h-[25rem] rounded-full mix-blend-screen filter blur-[110px] opacity-[0.07] transition-all duration-1000 animate-float-slow bg-teal-500" />
        </div>
      )}
      
      {/* Premium Ambient Custom Cursor */}
      <CustomCursor enabled={customCursor} theme={theme} accentColor={accentColor} reducedMotion={reducedMotion} />
      
      {/* App Header Bar */}
      <Header 
        currentUser={currentUser}
        activeTab={activeTab}
        setActiveTab={handleSetActiveTab}
        onOpenAuth={() => setIsAuthOpen(true)}
        onLogout={handleLogout}
        isFocusMode={isFocusMode}
        onToggleFocusMode={handleToggleFocusMode}
        theme={theme}
        onToggleTheme={() => setTheme(prev => {
          const themes: ("dark" | "deep-night" | "light" | "midnight" | "soft-gray" | "glassmorphism" | "amoled" | "glass" | "ocean")[] = ["dark", "deep-night", "light", "midnight", "soft-gray", "glassmorphism", "amoled", "glass", "ocean"];
          const nextIdx = (themes.indexOf(prev) + 1) % themes.length;
          return themes[nextIdx];
        })}
        onOpenCommandPalette={() => setIsCommandPaletteOpen(true)}
      />

      {/* Main Content Stage */}
      <main className="flex-1 mx-auto w-full max-w-7xl px-4 pt-6 pb-28 sm:pb-32 lg:py-8 sm:px-6 lg:px-8 space-y-8">
        
        {/* Guest Warning Header banner */}
        {!currentUser && !isFocusMode && (
          <div id="guest-alert-banner" className="rounded-2xl bg-gradient-to-r from-primary/10 to-transparent border border-primary/20 p-5 flex items-center justify-between flex-wrap gap-4 animate-fade-in" style={{ borderColor: "var(--primary-light)" }}>
            <div className="space-y-1">
              <h3 className="font-display font-bold text-primary flex items-center space-x-2" style={{ color: "var(--primary)" }}>
                <Sparkles className="h-5 w-5 animate-pulse" />
                <span>Sanctuary Local Sandbox Mode</span>
              </h3>
              <p className="text-xs text-neutral-400 max-w-2xl">
                You are currently browsing the sanctuary as a guest. Authenticate to sync your streak to the global leaderboards, gain ranks, broadcast status notes, and lock in persistent AI mentoring.
              </p>
            </div>
            <button
              id="join-sanctuary-banner-btn"
              onClick={() => setIsAuthOpen(true)}
              className="rounded-xl bg-primary px-5 py-2.5 text-xs font-bold text-[#0A0A0B] shadow-lg shadow-primary/10 hover:bg-primary-hover transition-all shrink-0"
              style={{ backgroundColor: "var(--primary)" }}
            >
              Secure My Focus Now
            </button>
          </div>
        )}

        {isTabChanging ? (
          <div id="shimmer-container" className="space-y-8">
            <div className="grid gap-6 md:grid-cols-12">
              <div className="md:col-span-8 h-48 rounded-2xl bg-[#0F0F10] border border-[#1A1A1B] relative overflow-hidden animate-pulse">
                <div className="absolute inset-0 bg-gradient-to-r from-transparent via-neutral-700/5 to-transparent -translate-x-full animate-shimmer"></div>
              </div>
              <div className="md:col-span-4 h-48 rounded-2xl bg-[#0F0F10] border border-[#1A1A1B] relative overflow-hidden animate-pulse">
                <div className="absolute inset-0 bg-gradient-to-r from-transparent via-neutral-700/5 to-transparent -translate-x-full animate-shimmer"></div>
              </div>
            </div>
            <div className="grid gap-6 md:grid-cols-3">
              {[1, 2, 3].map((idx) => (
                <div key={idx} className="h-40 rounded-2xl bg-[#0F0F10] border border-[#1A1A1B] relative overflow-hidden animate-pulse">
                  <div className="absolute inset-0 bg-gradient-to-r from-transparent via-neutral-700/5 to-transparent -translate-x-full animate-shimmer"></div>
                </div>
              ))}
            </div>
          </div>
        ) : (
          <>
            {/* ================= TAB: DASHBOARD ================= */}
            {activeTab === "dashboard" && (
              <motion.div
                id="dashboard-tab"
                initial={reducedMotion ? { opacity: 0 } : { opacity: 0, y: 10, scale: 0.995 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                transition={{ duration: 0.3, ease: [0.16, 1, 0.3, 1] }}
                className="space-y-8"
              >
            
            {/* Top row: Sobriety clocks and trackers */}
            {currentUser ? (
              <SobrietyClock 
                currentUser={currentUser}
                onUpdateUser={handleUpdateUser}
                onOpenSOS={() => handleSetActiveTab("sos")}
              />
            ) : (
              <div className="rounded-2xl border border-neutral-850 bg-[#0F0F10] p-10 text-center space-y-4 shadow-sm">
                <Flame className="h-12 w-12 mx-auto animate-bounce text-primary" style={{ color: "var(--primary)" }} />
                <h3 className="font-display text-xl font-bold text-neutral-200">The Chronometer is Dormant</h3>
                <p className="text-xs text-neutral-400 max-w-sm mx-auto leading-relaxed">
                  Join the mental purity quest to activate your live sobriety chronometer, compute DeltaFosB recovery coefficients, and log clean milestones.
                </p>
                <button
                  onClick={() => setIsAuthOpen(true)}
                  className="rounded-xl bg-primary px-6 py-3 text-xs font-bold text-[#0A0A0B] hover:bg-primary-hover transition-all"
                  style={{ backgroundColor: "var(--primary)" }}
                >
                  Create Sovereign Tracker Profile
                </button>
              </div>
            )}

            {/* ================= SOVEREIGN OBJECTIVE OF THE DAY ================= */}
            <div id="sovereign-objective-card" className="rounded-2xl border border-neutral-850 bg-[#0F0F10] p-6 shadow-sm relative overflow-hidden">
              <div className="absolute top-0 right-0 h-32 w-32 bg-primary/5 rounded-full blur-2xl pointer-events-none"></div>
              
              <div className="flex items-center space-x-2 border-b border-[#1A1A1B] pb-4 mb-4">
                <Target className="h-5 w-5 text-primary" style={{ color: "var(--primary)" }} />
                <h3 className="font-display font-bold text-neutral-100">Daily Sovereign Objective</h3>
                <span className="text-[10px] bg-primary/10 text-primary px-2 py-0.5 rounded font-mono font-bold uppercase tracking-wider ml-auto" style={{ color: "var(--primary)", backgroundColor: "var(--primary-light)" }}>
                  Limbic Shield
                </span>
              </div>

              {!sovereignObjective ? (
                <div className="space-y-4">
                  <p className="text-xs text-neutral-400 leading-relaxed">
                    Set a single, high-impact goal for today to anchor your prefrontal cortex. Your mind is less vulnerable to instant gratification when dedicated to a high-priority mission.
                  </p>
                  <form 
                    onSubmit={(e) => {
                      e.preventDefault();
                      const form = e.currentTarget;
                      const input = form.elements.namedItem("objectiveInput") as HTMLInputElement;
                      if (input && input.value.trim()) {
                        setSovereignObjective(input.value.trim());
                        setObjectiveProgress(0);
                      }
                    }}
                    className="flex flex-col sm:flex-row gap-3"
                  >
                    <input
                      name="objectiveInput"
                      type="text"
                      required
                      placeholder="e.g. Work out for 45 mins, code 3 hours without tab switching, or read 20 pages of Seneca"
                      maxLength={120}
                      className="flex-1 bg-[#0A0A0B] border border-[#1A1A1B] hover:border-neutral-800 focus:border-primary/50 focus:outline-none rounded-xl px-4 py-2.5 text-xs text-neutral-200 placeholder-neutral-600 transition-all"
                    />
                    <button
                      type="submit"
                      className="bg-primary hover:bg-primary-hover text-[#0A0A0B] text-xs font-bold px-5 py-2.5 rounded-xl transition-all cursor-pointer whitespace-nowrap"
                      style={{ backgroundColor: "var(--primary)" }}
                    >
                      Declare Mission
                    </button>
                  </form>
                </div>
              ) : (
                <div className="space-y-5">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                    <div className="space-y-1">
                      <span className="text-[9px] font-mono font-bold text-neutral-500 uppercase tracking-widest">Active Focus Target:</span>
                      <h4 className="text-sm font-bold text-neutral-100 leading-relaxed">
                        {sovereignObjective}
                      </h4>
                    </div>
                    <button
                      onClick={() => {
                        if (confirm("Are you sure you want to abandon or change your active sovereign objective? Your current progress will be lost.")) {
                          setSovereignObjective("");
                          setObjectiveProgress(0);
                        }
                      }}
                      className="text-[10px] text-neutral-500 hover:text-red-400 font-mono transition-all underline shrink-0 cursor-pointer self-start sm:self-center"
                    >
                      Reset Objective
                    </button>
                  </div>

                  {/* Progress stats */}
                  <div className="space-y-2">
                    <div className="flex justify-between text-xs font-mono font-bold">
                      <span className={objectiveProgress === 100 ? "text-emerald-500" : "text-primary"} style={{ color: objectiveProgress === 100 ? undefined : "var(--primary)" }}>
                        {objectiveProgress === 100 ? "OBJECTIVE COMPLETED! SOVEREIGN FOCUS SECURED." : "OBJECTIVE PROGRESS"}
                      </span>
                      <span className={objectiveProgress === 100 ? "text-emerald-500" : "text-neutral-350"}>{objectiveProgress}%</span>
                    </div>

                    {/* Progress Bar background */}
                    <div className="h-2 w-full bg-[#0A0A0B] border border-[#1A1A1B] rounded-full overflow-hidden">
                      <div 
                        className={`h-full rounded-full transition-all duration-300 ${
                          objectiveProgress === 100 ? "bg-emerald-500" : ""
                        }`}
                        style={{ width: `${objectiveProgress}%`, backgroundColor: objectiveProgress === 100 ? undefined : "var(--primary)" }}
                      ></div>
                    </div>
                  </div>

                  {/* Interaction buttons */}
                  {objectiveProgress < 100 ? (
                    <div className="flex flex-wrap gap-2">
                      {[
                        { label: "+25% Progress", value: 25 },
                        { label: "+50% Progress", value: 50 },
                        { label: "+75% Progress", value: 75 },
                        { label: "Complete (100%)", value: 100 }
                      ].map((btn) => (
                        <button
                          key={btn.value}
                          onClick={() => {
                            if (btn.value === 100) {
                              setObjectiveProgress(100);
                            } else {
                              setObjectiveProgress(prev => Math.min(prev + btn.value, 100));
                            }
                          }}
                          className="bg-[#0A0A0B] border border-[#1A1A1B] hover:border-primary/30 hover:bg-[#161618] text-neutral-400 hover:text-neutral-200 text-xs py-1.5 px-3 rounded-lg transition-all cursor-pointer"
                        >
                          {btn.label}
                        </button>
                      ))}
                    </div>
                  ) : (
                    <div className="rounded-xl border border-emerald-500/20 bg-emerald-500/5 p-4 flex items-center space-x-3">
                      <div className="h-8 w-8 rounded-lg bg-emerald-500/10 text-emerald-500 flex items-center justify-center border border-emerald-500/20 shrink-0">
                        <CheckSquare className="h-5 w-5" />
                      </div>
                      <div className="flex-1">
                        <h4 className="text-xs font-bold text-emerald-400">Prefrontal Command Secured</h4>
                        <p className="text-[10px] text-neutral-400 mt-0.5">
                          Excellent sovereignty. You have protected your focus today and successfully claimed +50 Focus XP.
                        </p>
                      </div>
                      <button
                        onClick={() => {
                          setSovereignObjective("");
                          setObjectiveProgress(0);
                        }}
                        className="bg-emerald-500 hover:bg-emerald-400 text-[#0A0A0B] text-[10px] font-bold py-1.5 px-3 rounded-lg transition-all cursor-pointer"
                      >
                        Set Next Mission
                      </button>
                    </div>
                  )}
                </div>
              )}
            </div>

            {/* Milestones section */}
            <Milestones currentUser={currentUser} onUpdateUser={handleUpdateUser} />

            {/* Routine Tools & Wellness Hub */}
            <InteractiveCompanion 
              currentUser={currentUser} 
              onUpdateUser={handleUpdateUser}
              onOpenAuth={() => setIsAuthOpen(true)}
              theme={theme}
            />

            {/* Habit Trends Section */}
            <HabitTrends dailyChecklist={dailyChecklist} />

            {/* Middle row bento grid */}
            <div className="grid gap-6 lg:grid-cols-3">
              
              {/* Daily Sovereignty Checklist Card */}
              <div className="lg:col-span-1 rounded-2xl border border-[#1A1A1B] bg-[#0F0F10] p-6 shadow-sm flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between border-b border-[#1A1A1B] pb-4 mb-4">
                    <div className="flex items-center space-x-2">
                      <CheckSquare className="h-5 w-5 text-amber-500" />
                      <h3 className="font-display font-bold text-neutral-100">Daily checklist</h3>
                    </div>
                    <span className="text-[10px] font-bold text-neutral-500">
                      +10 XP / Item
                    </span>
                  </div>

                  <p className="text-xs text-neutral-400 leading-relaxed mb-4">
                    Commit to daily physical and environmental habits that deplete limbic charge and safeguard your sovereign focus.
                  </p>

                  <div className="space-y-2.5">
                    {[
                      { key: "cold_splash", title: "Autonomic Cold Water Splash", desc: "慢Mammalian dive reflex slowdown" },
                      { key: "five_min_box_breathing", title: "5 Min Box Breathing Anchor", desc: "Rebuild prefrontal command" },
                      { key: "offline_hours", title: "3 Consecutive Offline Hours", desc: "Re-regulate dopamine paths" },
                      { key: "read_philosophy", title: "Stoic Passage Reflection", desc: "Read Marcus Aurelius or Seneca" },
                      { key: "physical_squats", title: "25 Deep Skeletal Air Squats", desc: "Divert blood flow away from sex centers" },
                      { key: "clean_eyes", title: "Zero Digital Trigger Peeking", desc: "Starve visual addiction circuits" }
                    ].map((item) => {
                      const isChecked = dailyChecklist[item.key];
                      return (
                        <div 
                          key={item.key}
                          onClick={() => handleChecklistToggle(item.key)}
                          className={`flex items-start space-x-3 rounded-xl p-3 border cursor-pointer transition-all ${
                            isChecked 
                              ? "bg-emerald-500/5 border-emerald-500/20 text-neutral-200" 
                              : "bg-[#0A0A0B] border-[#1A1A1B] hover:bg-[#161618]"
                          }`}
                        >
                          <div className={`mt-0.5 flex h-4.5 w-4.5 shrink-0 items-center justify-center rounded-md border text-white transition-all ${
                            isChecked 
                              ? "bg-emerald-500 border-emerald-500" 
                              : "border-neutral-700 bg-transparent"
                          }`}>
                            {isChecked && (
                              <svg className="h-3 w-3 fill-none stroke-current stroke-3" viewBox="0 0 24 24">
                                <polyline points="20 6 9 17 4 12" />
                              </svg>
                            )}
                          </div>
                          <div>
                            <h4 className={`text-xs font-bold leading-tight ${isChecked ? "line-through text-neutral-500" : "text-neutral-200"}`}>
                              {item.title}
                            </h4>
                            <p className="text-[10px] text-neutral-500 mt-0.5">{item.desc}</p>
                          </div>
                        </div>
                      );
                    })}

                    {/* Custom daily habits */}
                    {customHabits.map((item) => {
                      const isChecked = dailyChecklist[item.key];
                      return (
                        <div 
                          key={item.key}
                          className={`flex items-start justify-between rounded-xl p-3 border transition-all ${
                            isChecked 
                              ? "bg-emerald-500/5 border-emerald-500/20 text-neutral-200" 
                              : "bg-[#0A0A0B] border-[#1A1A1B]"
                          }`}
                        >
                          <div 
                            onClick={() => handleChecklistToggle(item.key)}
                            className="flex items-start space-x-3 cursor-pointer flex-1 min-w-0"
                          >
                            <div className={`mt-0.5 flex h-4.5 w-4.5 shrink-0 items-center justify-center rounded-md border text-white transition-all ${
                              isChecked 
                                ? "bg-emerald-500 border-emerald-500" 
                                : "border-neutral-700 bg-transparent hover:border-neutral-500"
                            }`}>
                              {isChecked && (
                                <svg className="h-3 w-3 fill-none stroke-current stroke-3" viewBox="0 0 24 24">
                                  <polyline points="20 6 9 17 4 12" />
                                </svg>
                              )}
                            </div>
                            <div className="min-w-0 flex-1">
                              <h4 className={`text-xs font-bold leading-tight truncate ${isChecked ? "line-through text-neutral-500" : "text-neutral-200"}`}>
                                {item.title}
                              </h4>
                              <p className="text-[10px] text-neutral-500 mt-0.5 truncate">{item.desc}</p>
                            </div>
                          </div>
                          
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              setCustomHabits(prev => prev.filter(h => h.key !== item.key));
                              setDailyChecklist(prev => {
                                const copy = { ...prev };
                                delete copy[item.key];
                                return copy;
                              });
                            }}
                            className="text-neutral-600 hover:text-red-400 p-1 rounded-md hover:bg-neutral-900 transition-all ml-2"
                            title="Remove custom habit"
                          >
                            <Trash2 className="h-3.5 w-3.5" />
                          </button>
                        </div>
                      );
                    })}

                    {/* Add New Habit Form */}
                    <form 
                      onSubmit={(e) => {
                        e.preventDefault();
                        if (!newHabitTitle.trim()) return;
                        const habitKey = `custom_${Date.now()}`;
                        const newHabit = {
                          key: habitKey,
                          title: newHabitTitle.trim(),
                          desc: newHabitDesc.trim() || "Custom daily habit"
                        };
                        setCustomHabits(prev => [...prev, newHabit]);
                        setDailyChecklist(prev => ({ ...prev, [habitKey]: false }));
                        setNewHabitTitle("");
                        setNewHabitDesc("");
                      }}
                      className="mt-4 pt-4 border-t border-[#1A1A1B] space-y-2"
                    >
                      <span className="text-[10px] font-black uppercase tracking-widest text-amber-500 block">
                        Define Custom Habit
                      </span>
                      <div className="space-y-1.5">
                        <input 
                          type="text"
                          value={newHabitTitle}
                          onChange={(e) => setNewHabitTitle(e.target.value)}
                          placeholder="e.g. 10 Min Morning Meditation"
                          maxLength={50}
                          className="w-full bg-[#0A0A0B] border border-[#1A1A1B] hover:border-neutral-800 focus:border-amber-500/50 focus:outline-none rounded-xl px-3 py-2 text-xs text-neutral-200 placeholder-neutral-600 transition-all"
                        />
                        <input 
                          type="text"
                          value={newHabitDesc}
                          onChange={(e) => setNewHabitDesc(e.target.value)}
                          placeholder="e.g. Build mindfulness (optional)"
                          maxLength={60}
                          className="w-full bg-[#0A0A0B] border border-[#1A1A1B] hover:border-neutral-800 focus:border-amber-500/50 focus:outline-none rounded-xl px-3 py-1.5 text-[11px] text-neutral-300 placeholder-neutral-700 transition-all"
                        />
                      </div>
                      <button
                        type="submit"
                        disabled={!newHabitTitle.trim()}
                        className="w-full bg-amber-500 hover:bg-amber-400 disabled:opacity-40 disabled:cursor-not-allowed text-[#0A0A0B] font-bold text-xs py-2 rounded-xl transition-all cursor-pointer flex items-center justify-center space-x-1.5"
                      >
                        <Plus className="h-3.5 w-3.5" />
                        <span>Add Custom Habit</span>
                      </button>
                    </form>
                  </div>
                </div>

                <div className="mt-4 pt-3 border-t border-[#1A1A1B] text-[10px] text-neutral-500 italic text-center font-medium">
                  Starve the stimulus, feed the sovereign.
                </div>
              </div>

              {/* JournalLogs and CBT History Stage */}
              <div className="lg:col-span-2">
                {currentUser ? (
                  <JournalLogs 
                    currentUser={currentUser}
                    onUpdateUser={handleUpdateUser}
                  />
                ) : (
                  <div className="rounded-2xl border border-[#1A1A1B] bg-[#0F0F10] p-10 text-center space-y-4 shadow-sm h-full flex flex-col items-center justify-center">
                    <BookOpen className="h-10 w-10 text-neutral-600 animate-pulse" />
                    <h3 className="font-display font-semibold text-neutral-300">CBT Logbook Offline</h3>
                    <p className="text-xs text-neutral-500 max-w-xs leading-relaxed">
                      Please register or authenticate to log trigger incidents, examine distortion patterns, and claim defense XP.
                    </p>
                  </div>
                )}
              </div>

            </div>

            {/* ================= DAILY WISDOM REFLECTION ================= */}
            <div id="daily-wisdom-reflection-card" className="rounded-2xl border border-neutral-850 bg-[#0F0F10] p-6 sm:p-8 shadow-sm relative overflow-hidden">
              <div className="absolute top-0 right-0 h-40 w-40 bg-purple-500/5 rounded-full blur-3xl pointer-events-none"></div>
              
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-[#1A1A1B] pb-4 mb-4">
                <div className="flex items-center space-x-2">
                  <BookOpen className="h-5 w-5 text-purple-400" />
                  <h3 className="font-display font-bold text-neutral-100">Daily Wisdom Reflection</h3>
                </div>
                <div className="text-[11px] font-mono font-bold text-neutral-500">
                  REFLECTIONS LOGGED: <span className="text-purple-400">{reflectionCount}</span>
                </div>
              </div>

              <div className="space-y-4">
                <p className="text-xs text-neutral-400 italic leading-relaxed">
                  "Take time to digest a single noble thought deeply. Let it slow down the speed of your visual desires."
                </p>

                <div className="rounded-xl border border-[#1A1A1B] bg-[#0A0A0B] p-5 sm:p-6 space-y-3.5 relative">
                  <span className="absolute top-3 right-4 text-[9px] font-mono text-neutral-600 font-bold uppercase tracking-widest">
                    {WISDOM_REFLECTIONS[reflectionIdx].source}
                  </span>
                  <p className="text-xs sm:text-sm text-neutral-200 font-medium leading-relaxed max-w-3xl pr-12">
                    "{WISDOM_REFLECTIONS[reflectionIdx].text}"
                  </p>
                  <p className="text-xs text-purple-400 font-bold tracking-wider uppercase">
                    — {WISDOM_REFLECTIONS[reflectionIdx].author}
                  </p>
                </div>

                <div className="flex flex-col sm:flex-row items-center gap-3 pt-2">
                  {!reflectedToday ? (
                    <button
                      onClick={() => {
                        setReflectionCount(prev => prev + 1);
                        setReflectedToday(true);
                        localStorage.setItem("sanctuary_reflected_today_date", new Date().toISOString().split("T")[0]);
                      }}
                      className="w-full sm:w-auto bg-purple-600 hover:bg-purple-500 text-white text-xs font-bold py-2.5 px-6 rounded-xl transition-all cursor-pointer flex items-center justify-center space-x-2 shadow-lg shadow-purple-600/15"
                    >
                      <CheckSquare className="h-4 w-4" />
                      <span>Read, Agree & Reflect (+10 XP)</span>
                    </button>
                  ) : (
                    <div className="rounded-xl border border-emerald-500/20 bg-emerald-500/5 py-2.5 px-4 flex items-center space-x-2 text-emerald-400 text-xs font-bold w-full sm:w-auto">
                      <svg className="h-4 w-4 fill-none stroke-current stroke-2.5" viewBox="0 0 24 24">
                        <polyline points="20 6 9 17 4 12" />
                      </svg>
                      <span>Reflection Logged for Today</span>
                    </div>
                  )}

                  <button
                    onClick={() => {
                      setReflectionIdx(prev => (prev + 1) % WISDOM_REFLECTIONS.length);
                    }}
                    className="w-full sm:w-auto text-xs font-bold text-neutral-400 hover:text-neutral-200 border border-neutral-850 hover:border-neutral-700 bg-transparent py-2.5 px-5 rounded-xl transition-all cursor-pointer text-center"
                  >
                    Cycle Passage
                  </button>
                </div>
              </div>
            </div>

            {/* Bottom row: Stoic Quotes and Status Broadcast */}
            <div className={`grid gap-6 ${isFocusMode ? "grid-cols-1" : "md:grid-cols-2"}`}>
              
              {/* Stoic Grounder widget */}
              <div className="rounded-2xl border border-neutral-850 bg-[#0F0F10] p-6 shadow-sm flex flex-col justify-between">
                <div>
                  <div className="flex items-center space-x-2 border-b border-[#1A1A1B] pb-4 mb-4">
                    <Quote className="h-5 w-5 text-amber-500" />
                    <h3 className="font-display font-bold text-neutral-100">Stoic Mind Shield</h3>
                  </div>

                  <div className="space-y-3 py-2">
                    <p className="text-sm italic text-neutral-200 font-medium leading-relaxed">
                      "{STOIC_QUOTES[currentQuoteIdx].text}"
                    </p>
                    <p className="text-xs text-amber-500 font-bold tracking-wider uppercase text-right">
                      — {STOIC_QUOTES[currentQuoteIdx].author}
                    </p>
                  </div>
                </div>

                <button
                  id="cycle-quote-btn"
                  onClick={() => setCurrentQuoteIdx((prev) => (prev + 1) % STOIC_QUOTES.length)}
                  className="w-full mt-4 rounded-xl border border-[#1A1A1B] bg-[#0A0A0B] py-2.5 text-xs font-semibold text-neutral-400 hover:bg-[#161618] transition-all"
                >
                  Meditate On Another Passage
                </button>
              </div>

              {/* Status Broadcast widget */}
              {!isFocusMode && (
                <div className="rounded-2xl border border-neutral-850 bg-[#0F0F10] p-6 shadow-sm flex flex-col justify-between">
                  <div>
                    <div className="flex items-center space-x-2 border-b border-[#1A1A1B] pb-4 mb-4">
                      <Globe className="h-5 w-5 text-amber-500" />
                      <h3 className="font-display font-bold text-neutral-100">Broadcasting status</h3>
                    </div>

                    <p className="text-xs text-neutral-400 leading-relaxed mb-4">
                      Write a small, public status broadcast describing your active frame of mind. This note syncs instantly onto the global leaderboard scroll.
                    </p>

                    <form onSubmit={handleSaveStatus} className="space-y-3">
                      <textarea
                        id="status-broadcast-input"
                        disabled={!currentUser}
                        placeholder={currentUser ? "e.g. Day 14, feeling immense mental clarity and focusing on heavy deadlifts." : "Authenticate to broadcast status..."}
                        value={statusText}
                        onChange={(e) => setStatusText(e.target.value)}
                        maxLength={140}
                        className="w-full h-16 rounded-xl border border-[#1A1A1B] bg-[#0A0A0B] p-3 text-xs text-neutral-200 outline-none focus:border-amber-500 disabled:opacity-50"
                      />
                      
                      {currentUser && (
                        <div className="flex justify-between items-center">
                          <span className="text-[10px] text-neutral-500">
                            {140 - statusText.length} characters left
                          </span>
                          <button
                            id="submit-status-btn"
                            type="submit"
                            disabled={updatingStatus}
                            className="rounded-lg bg-amber-500 text-[#0A0A0B] font-bold text-xs px-4 py-1.5 hover:bg-amber-400 transition-all flex items-center space-x-1"
                          >
                            {updatingStatus ? <RefreshCw className="h-3 w-3 animate-spin" /> : <PenTool className="h-3 w-3" />}
                            <span>Update Public Sigil</span>
                          </button>
                        </div>
                      )}
                    </form>
                  </div>

                  {!currentUser && (
                    <button
                      onClick={() => setIsAuthOpen(true)}
                      className="w-full mt-4 rounded-xl border border-neutral-800 bg-transparent py-2 text-xs font-bold text-amber-500 hover:bg-amber-500/5"
                    >
                      Authenticate To Update
                    </button>
                  )}
                </div>
              )}

            </div>

            {/* Release Spotlight & Supporters Row (Discord & 2 Ad Spaces) */}
            {!isFocusMode && (
              <div className="grid gap-6 md:grid-cols-3" id="release-spotlight-section">
                
                {/* Discord Fellowship Card */}
                <div className="rounded-2xl border border-[#1A1A1B] bg-gradient-to-br from-[#161618]/60 to-[#0F0F10] p-6 shadow-sm flex flex-col justify-between relative overflow-hidden group">
                  <div className="absolute top-0 right-0 h-32 w-32 bg-[#5865F2]/5 rounded-full blur-2xl pointer-events-none"></div>
                  <div className="space-y-3">
                    <div className="flex items-center space-x-2 text-[#5865F2]">
                      <MessageSquare className="h-5 w-5 fill-[#5865F2]/10" />
                      <h3 className="font-display font-bold text-[#E5E5E5] text-sm">Fellowship Discord</h3>
                    </div>
                    <p className="text-xs text-neutral-400 leading-relaxed">
                      Connect with over 10,000+ pure mind warriors. Participate in weekly accountability challenges, live cold-plunge check-ins, and shared victory sprints.
                    </p>
                  </div>
                  <div className="mt-5">
                    <a
                      href="https://discord.gg/XFusvy4xKP"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex w-full items-center justify-center space-x-2 rounded-xl bg-[#5865F2] hover:bg-[#4752C4] text-white font-bold text-xs py-3 transition-all shadow-lg shadow-[#5865F2]/10 cursor-pointer"
                    >
                      <MessageSquare className="h-4 w-4" />
                      <span>Join Global Fellowship</span>
                      <ExternalLink className="h-3 w-3 opacity-80" />
                    </a>
                  </div>
                </div>

                {/* Ad Space 1 */}
                <div className="rounded-2xl border border-dashed border-neutral-800 bg-[#0F0F10]/40 p-6 shadow-sm flex flex-col justify-between relative overflow-hidden group hover:border-amber-500/30 transition-all">
                  <span className="absolute top-2 right-3 text-[8px] font-bold text-amber-500/80 uppercase tracking-widest font-mono">
                    Available Slot
                  </span>
                  <div className="space-y-3">
                    <div className="flex items-center space-x-2 text-neutral-500">
                      <BookOpen className="h-5 w-5" />
                      <h3 className="font-display font-bold text-neutral-400 text-sm">Sponsor Spot #1</h3>
                    </div>
                    <p className="text-xs text-neutral-500 leading-relaxed">
                      Put your brand, book, wellness product, or accountability service here. Reach a highly focused audience committed to self-mastery and purity.
                    </p>
                  </div>
                  <div className="mt-5">
                    <a
                      href="https://discord.gg/XFusvy4xKP"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex w-full items-center justify-center space-x-2 rounded-xl border border-neutral-800 bg-[#0A0A0B] hover:bg-[#161618] text-xs font-bold text-neutral-400 hover:text-amber-500 py-3 transition-all cursor-pointer"
                    >
                      <span>Inquire on Discord</span>
                      <ExternalLink className="h-3 w-3 opacity-60" />
                    </a>
                  </div>
                </div>

                {/* Ad Space 2 */}
                <div className="rounded-2xl border border-dashed border-neutral-800 bg-[#0F0F10]/40 p-6 shadow-sm flex flex-col justify-between relative overflow-hidden group hover:border-blue-500/30 transition-all">
                  <span className="absolute top-2 right-3 text-[8px] font-bold text-blue-400/80 uppercase tracking-widest font-mono">
                    Available Slot
                  </span>
                  <div className="space-y-3">
                    <div className="flex items-center space-x-2 text-neutral-500">
                      <Compass className="h-5 w-5" />
                      <h3 className="font-display font-bold text-neutral-400 text-sm">Sponsor Spot #2</h3>
                    </div>
                    <p className="text-xs text-neutral-500 leading-relaxed">
                      Promote your productivity tools, dopamine detox programs, or mental fortitude courses here. Help warriors claim their focus.
                    </p>
                  </div>
                  <div className="mt-5">
                    <a
                      href="https://discord.gg/XFusvy4xKP"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex w-full items-center justify-center space-x-2 rounded-xl border border-neutral-800 bg-[#0A0A0B] hover:bg-[#161618] text-xs font-bold text-neutral-400 hover:text-blue-400 py-3 transition-all cursor-pointer"
                    >
                      <span>Become a Partner</span>
                      <ExternalLink className="h-3 w-3 opacity-60" />
                    </a>
                  </div>
                </div>

              </div>
            )}

          </motion.div>
        )}

        {/* ================= TAB: EMERGENCY SOS ROOM ================= */}
        {activeTab === "sos" && (
          <motion.div
            initial={reducedMotion ? { opacity: 0 } : { opacity: 0, y: 10, scale: 0.995 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            transition={{ duration: 0.3, ease: [0.16, 1, 0.3, 1] }}
          >
            <UrgeSOS 
              currentUser={currentUser}
              onUpdateUser={handleUpdateUser}
            />
          </motion.div>
        )}

        {/* ================= TAB: WISDOM & SCIENCE ================= */}
        {activeTab === "wisdom" && (
          <motion.div
            initial={reducedMotion ? { opacity: 0 } : { opacity: 0, y: 10, scale: 0.995 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            transition={{ duration: 0.3, ease: [0.16, 1, 0.3, 1] }}
          >
            <WisdomLibrary currentUser={currentUser} />
          </motion.div>
        )}

        {/* ================= TAB: LEADERBOARD ================= */}
        {activeTab === "leaderboard" && (
          <motion.div
            id="leaderboard-tab"
            initial={reducedMotion ? { opacity: 0 } : { opacity: 0, y: 10, scale: 0.995 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            transition={{ duration: 0.3, ease: [0.16, 1, 0.3, 1] }}
            className="max-w-4xl mx-auto space-y-6 text-neutral-200"
          >
            
            {/* Leaderboard Header */}
            <div className="rounded-2xl border border-neutral-800 bg-[#0F0F10] p-6 shadow-sm flex items-start space-x-4">
              <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-amber-500/10 text-amber-500 border border-amber-500/20 shrink-0">
                <Award className="h-6 w-6" />
              </div>
              <div className="flex-1">
                <div className="flex items-center justify-between flex-wrap gap-2">
                  <h2 className="font-display text-xl font-bold text-neutral-100">Global Sovereignty Leaders</h2>
                  <button
                    id="refresh-leaderboard-btn"
                    onClick={fetchLeaderboard}
                    disabled={leaderboardLoading}
                    className="rounded-lg border border-[#1A1A1B] bg-[#0A0A0B] px-3 py-1.5 text-xs text-neutral-400 hover:bg-[#161618] hover:text-[#E5E5E5] flex items-center space-x-1"
                  >
                    <RefreshCw className={`h-3 w-3 ${leaderboardLoading ? 'animate-spin' : ''}`} />
                    <span>Refresh Scroll</span>
                  </button>
                </div>
                <p className="mt-1 text-xs text-neutral-400 leading-relaxed">
                  The clean chronicle of standing warriors. Ranked strictly by days of sovereign focus, showing level and broadcasted status notes.
                </p>
              </div>
            </div>

            {/* Leaders list */}
            <div className="rounded-2xl border border-[#1A1A1B] bg-[#0F0F10] overflow-hidden shadow-sm">
              {leaderboardLoading ? (
                <div className="text-center py-24 text-neutral-500 space-y-2">
                  <RefreshCw className="h-8 w-8 mx-auto animate-spin text-amber-500" />
                  <p className="text-xs">Consulting the scroll of honor...</p>
                </div>
              ) : leaderboard.length === 0 ? (
                <div className="text-center py-24 text-neutral-500">
                  <p className="text-sm font-semibold">Leaderboard is empty</p>
                  <p className="text-xs text-neutral-600 mt-1">Please try refreshing shortly.</p>
                </div>
              ) : (
                <div className="divide-y divide-[#1A1A1B]">
                  {leaderboard.map((item, idx) => {
                    const isSelf = currentUser && item.id === currentUser.id;
                    const itemBadge = getActiveBadge(item.equippedBadgeId, item.totalXp || 0);
                    return (
                      <div 
                        key={item.id}
                        className={`flex items-center justify-between p-4 sm:px-6 transition-all ${
                          isSelf 
                            ? "bg-amber-500/5 border-l-4 border-amber-500" 
                            : "hover:bg-[#161618]/30"
                        }`}
                      >
                        {/* Left: rank & user info */}
                        <div className="flex items-center space-x-3.5 min-w-0 flex-1">
                          {/* Rank indicator */}
                          <span className={`flex h-6 w-6 shrink-0 items-center justify-center rounded-lg text-xs font-bold ${
                            idx === 0 
                              ? "bg-amber-500 text-[#0A0A0B]" 
                              : idx === 1 
                              ? "bg-neutral-300 text-[#0A0A0B]" 
                              : idx === 2 
                              ? "bg-[#CD7F32] text-[#0A0A0B]" 
                              : "text-neutral-500 font-mono"
                          }`}>
                            {idx + 1}
                          </span>

                          {/* Avatar */}
                          <img 
                            src={item.avatarUrl} 
                            alt={item.username} 
                            className="h-10 w-10 rounded-xl object-cover border border-[#1A1A1B] bg-[#0A0A0B] shrink-0"
                          />

                          {/* Username & Title */}
                          <div className="min-w-0 pr-4">
                            <div className="flex items-center space-x-1.5">
                              {itemBadge && (
                                <span className="text-sm shrink-0" title={`Equipped Badge: ${itemBadge.name}`}>
                                  {itemBadge.emoji}
                                </span>
                              )}
                              <span className={`font-bold text-sm truncate leading-tight ${isSelf ? "text-amber-400 font-extrabold" : "text-neutral-200"}`}>
                                {item.username}
                              </span>
                              {isSelf && (
                                <span className="text-[9px] font-black uppercase bg-amber-500 text-[#0A0A0B] px-1.5 py-0.25 rounded">
                                  You
                                </span>
                              )}
                              <span className="text-[10px] font-bold text-neutral-500 bg-neutral-900 px-1.5 rounded shrink-0">
                                Lvl {item.level}
                              </span>
                            </div>
                            <div className="text-[10px] text-neutral-400 font-semibold mt-0.5">
                              {item.title}
                            </div>
                            {item.statusMessage && (
                              <p className="text-[11px] text-[#888888] italic truncate max-w-sm sm:max-w-md mt-1">
                                "{item.statusMessage}"
                              </p>
                            )}
                          </div>
                        </div>

                        {/* Right: streak */}
                        <div className="flex items-center space-x-1.5 shrink-0 pl-2">
                          <Flame className="h-4.5 w-4.5 fill-amber-500 text-amber-500" />
                          <span className="font-display font-black text-sm text-amber-500 sm:text-base">
                            {item.currentStreak} Days
                          </span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>

          </motion.div>
        )}

        {/* ================= TAB: COMMUNITY & CHAT ================= */}
        {activeTab === "community" && (
          <motion.div
            initial={reducedMotion ? { opacity: 0 } : { opacity: 0, y: 10, scale: 0.995 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            transition={{ duration: 0.3, ease: [0.16, 1, 0.3, 1] }}
          >
            <CommunitySanctuary 
              currentUser={currentUser} 
              onUpdateUser={handleUpdateUser} 
              onOpenAuth={() => setIsAuthOpen(true)} 
            />
          </motion.div>
        )}

        {/* ================= TAB: SUPPORT SANCTUARY ================= */}
        {activeTab === "support" && (
          <motion.div
            initial={reducedMotion ? { opacity: 0 } : { opacity: 0, y: 10, scale: 0.995 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            transition={{ duration: 0.3, ease: [0.16, 1, 0.3, 1] }}
          >
            <SupportSanctuary 
              currentUser={currentUser} 
              onOpenAuth={() => setIsAuthOpen(true)} 
            />
          </motion.div>
        )}

        {/* ================= TAB: AI PURITY MENTOR ================= */}
        {activeTab === "mentor" && (
          <motion.div
            id="mentor-tab"
            initial={reducedMotion ? { opacity: 0 } : { opacity: 0, y: 10, scale: 0.995 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            transition={{ duration: 0.3, ease: [0.16, 1, 0.3, 1] }}
            className="max-w-5xl mx-auto grid gap-6 lg:grid-cols-4 text-neutral-200"
          >
            
            {/* Left sidebar: prompt helper cards */}
            <div className="lg:col-span-1 space-y-4">
              <div className="rounded-2xl border border-neutral-850 bg-[#0F0F10] p-4.5 space-y-3 shadow-sm">
                <h3 className="font-display font-bold text-xs uppercase tracking-wider text-amber-500">
                  Mentor Guidelines
                </h3>
                <p className="text-[11px] text-neutral-450 leading-relaxed">
                  Your AI Mentor utilizes clinical CBT patterns and neuroscience data. Feel free to speak candidly about cravings or triggers.
                </p>
              </div>

              {/* Suggested Prompts list */}
              <div className="space-y-2">
                <span className="text-[10px] uppercase font-bold tracking-wider text-neutral-500 px-1">
                  Click to Ask Mentor:
                </span>
                {[
                  "Give me my Daily Encouragement, reflection prompt, and active goal suggestion.",
                  "Analyze my recent trigger logs and advise on environmental design.",
                  "Challenge me with a 48-hour prefrontal challenge.",
                  "Explain the science behind Dopamine receptor upregulation.",
                  "How do I recover from a recent relapse without blaming myself?",
                  "Suggest three immediate physical actions to defuse a severe urge."
                ].map((prompt, idx) => (
                  <button
                    key={idx}
                    onClick={(e) => handleSendMessage(e, prompt)}
                    disabled={chatLoading}
                    className="w-full text-left rounded-xl border border-[#1A1A1B] bg-[#0F0F10] p-3 text-xs text-neutral-400 hover:border-amber-500 hover:text-neutral-200 transition-all hover:bg-[#161618]/30"
                  >
                    <div className="flex items-start space-x-1.5">
                      <ChevronRight className="h-4 w-4 shrink-0 mt-0.5 text-amber-500" />
                      <span>{prompt}</span>
                    </div>
                  </button>
                ))}
              </div>
            </div>

            {/* Right: The Chat Window Terminal */}
            <div className="lg:col-span-3 rounded-2xl border border-[#1A1A1B] bg-[#0F0F10] shadow-sm overflow-hidden flex flex-col h-[580px]">
              
              {/* Terminal Header */}
              <div className="border-b border-[#1A1A1B] bg-[#161618]/40 p-4 flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-purple-500/10 text-purple-400 border border-purple-500/20">
                    <Brain className="h-5 w-5 animate-pulse" />
                  </div>
                  <div>
                    <h3 className="font-display font-bold text-sm text-[#E5E5E5]">AI Sanctuary Mentor</h3>
                    <span className="flex items-center text-[10px] text-emerald-400 font-bold">
                      <span className="mr-1 h-1.5 w-1.5 rounded-full bg-emerald-500 animate-ping"></span>
                      <span>Ready to ground your thoughts</span>
                    </span>
                  </div>
                </div>
                
                {currentUser && (
                  <span className="hidden sm:inline-block rounded bg-[#0A0A0B] border border-[#1A1A1B] px-2.5 py-1 text-[10px] font-mono text-neutral-400">
                    Grounded: {currentUser.username}
                  </span>
                )}
              </div>

              {/* Messages viewport */}
              <div id="chat-messages-viewport" className="flex-1 overflow-y-auto p-4 space-y-4">
                {chatMessages.map((m) => {
                  const isMentor = m.sender === "mentor";
                  return (
                    <div 
                      key={m.id} 
                      className={`flex items-start space-x-3 max-w-[85%] ${
                        isMentor ? "mr-auto" : "ml-auto flex-row-reverse space-x-reverse"
                      }`}
                    >
                      {/* Mini Sigil avatar */}
                      <div className={`h-8.5 w-8.5 rounded-lg border flex items-center justify-center shrink-0 ${
                        isMentor 
                          ? "bg-purple-500/10 text-purple-400 border-purple-500/20" 
                          : "bg-[#0A0A0B] text-amber-500 border-[#1A1A1B]"
                      }`}>
                        {isMentor ? <Brain className="h-4.5 w-4.5" /> : <Eye className="h-4.5 w-4.5" />}
                      </div>

                      {/* Msg text bubble */}
                      <div className={`rounded-2xl p-3.5 text-xs leading-relaxed ${
                        isMentor 
                          ? "bg-[#161618] text-neutral-200 border border-[#262626]" 
                          : "bg-amber-500 text-[#0A0A0B] font-medium"
                      }`}>
                        <p className="whitespace-pre-wrap">{m.text}</p>
                      </div>
                    </div>
                  );
                })}
                
                {/* Typing status loader */}
                {chatLoading && (
                  <div className="flex items-start space-x-3 mr-auto max-w-[85%] animate-pulse">
                    <div className="h-8.5 w-8.5 rounded-lg border bg-purple-500/10 text-purple-400 border-purple-500/20 flex items-center justify-center">
                      <Brain className="h-4.5 w-4.5" />
                    </div>
                    <div className="rounded-2xl p-3.5 text-xs bg-[#161618] text-neutral-400 border border-[#262626] italic">
                      Formulating neural grounding patterns...
                    </div>
                  </div>
                )}
                
                <div ref={chatScrollRef} />
              </div>

              {/* Chat Input form */}
              <form onSubmit={(e) => handleSendMessage(e)} className="border-t border-[#1A1A1B] bg-[#161618]/20 p-4 flex items-center space-x-3">
                <input
                  id="chat-message-input"
                  type="text"
                  disabled={chatLoading}
                  placeholder="Ask about dopamine rewiring, sexual sublimation, or describe an urge..."
                  value={chatInput}
                  onChange={(e) => setChatInput(e.target.value)}
                  className="flex-1 rounded-xl border border-[#1A1A1B] bg-[#0A0A0B] text-neutral-200 px-4 py-3 text-xs outline-none focus:border-amber-500 transition-all disabled:opacity-50"
                />
                <button
                  id="send-chat-btn"
                  type="submit"
                  disabled={chatLoading || !chatInput.trim()}
                  className="rounded-xl bg-amber-500 text-[#0A0A0B] font-bold p-3 hover:bg-amber-400 transition-all disabled:bg-neutral-800 disabled:text-neutral-500"
                >
                  <Send className="h-4.5 w-4.5" />
                </button>
              </form>

            </div>

          </motion.div>
        )}

        {/* ================= TAB: ABOUT PAGE ================= */}
        {activeTab === "about" && (
          <AboutPage onBackToDashboard={() => setActiveTab("dashboard")} />
        )}

        {/* ================= TAB: CONTACT PAGE ================= */}
        {activeTab === "contact" && (
          <ContactPage onBackToDashboard={() => setActiveTab("dashboard")} />
        )}

        {/* ================= TAB: PRIVACY POLICY ================= */}
        {activeTab === "privacy" && (
          <PrivacyPolicy onBackToDashboard={() => setActiveTab("dashboard")} />
        )}

        {/* ================= TAB: TERMS OF SERVICE ================= */}
        {activeTab === "terms" && (
          <TermsOfService onBackToDashboard={() => setActiveTab("dashboard")} />
        )}

        {/* ================= TAB: COOKIE POLICY ================= */}
        {activeTab === "cookies" && (
          <CookiePolicy onBackToDashboard={() => setActiveTab("dashboard")} />
        )}

        {/* ================= TAB: DISCLAIMER ================= */}
        {activeTab === "disclaimer" && (
          <DisclaimerPage onBackToDashboard={() => setActiveTab("dashboard")} />
        )}

        {/* ================= TAB: FAQ ================= */}
        {activeTab === "faq" && (
          <FAQPage onBackToDashboard={() => setActiveTab("dashboard")} />
        )}

        {/* ================= TAB: HELP CENTRE ================= */}
        {activeTab === "help" && (
          <HelpCentrePage onBackToDashboard={() => setActiveTab("dashboard")} />
        )}

        {/* ================= TAB: COMMUNITY GUIDELINES ================= */}
        {activeTab === "guidelines" && (
          <CommunityGuidelinesPage onBackToDashboard={() => setActiveTab("dashboard")} />
        )}

        {/* ================= TAB: CHANGELOG ================= */}
        {activeTab === "changelog" && (
          <ChangelogPage onBackToDashboard={() => setActiveTab("dashboard")} />
        )}

        {/* ================= TAB: ACCESSIBILITY ================= */}
        {activeTab === "accessibility" && (
          <AccessibilityPage onBackToDashboard={() => setActiveTab("dashboard")} />
        )}

        {/* ================= TAB: DOCUMENTATION ================= */}
        {activeTab === "docs" && (
          <Documentation />
        )}

        {/* ================= TAB: SOVEREIGN SETTINGS ================= */}
        {activeTab === "settings" && (
          <SovereignSettings 
            currentUser={currentUser}
            onUpdateUser={handleUpdateUser}
            onLogout={handleLogout}
            onOpenAuth={() => setIsAuthOpen(true)}
            theme={theme}
            onSetTheme={setTheme}
            accentColor={accentColor}
            onSetAccentColor={setAccentColor}
            glassmorphism={glassmorphism}
            onSetGlassmorphism={setGlassmorphism}
            fontSize={fontSize}
            onSetFontSize={setFontSize}
            reducedMotion={reducedMotion}
            onSetReducedMotion={setReducedMotion}
            highContrast={highContrast}
            onSetHighContrast={setHighContrast}
            customCursor={customCursor}
            onSetCustomCursor={setCustomCursor}
          />
        )}

        {/* ================= TAB: 404 NOT FOUND ================= */}
        {!["dashboard", "sos", "wisdom", "leaderboard", "community", "support", "mentor", "about", "contact", "privacy", "terms", "cookies", "docs", "settings", "disclaimer", "faq", "help", "guidelines", "changelog", "accessibility"].includes(activeTab) && (
          <NotFoundPage onBackToDashboard={() => handleSetActiveTab("dashboard")} />
        )}
          </>
        )}

      </main>

      {/* Auth Modal Trigger Stage */}
      <AuthModal 
        isOpen={isAuthOpen}
        onClose={() => setIsAuthOpen(false)}
        onAuthSuccess={handleAuthSuccess}
      />

      {/* Footer Area */}
      <footer id="app-footer" className="border-t border-[#1A1A1B] bg-[#0F0F10] pt-10 pb-8 text-xs text-neutral-400 font-medium">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 pb-8 border-b border-[#1A1A1B]">
            {/* Column 1: Identity */}
            <div className="space-y-3 text-left">
              <span className="flex items-center space-x-2 font-display text-xs font-black tracking-widest text-amber-500 uppercase">
                <Heart className="h-4.5 w-4.5 text-amber-500 fill-amber-500/10 shrink-0" />
                <span>Sovereign Mind Sanctuary</span>
              </span>
              <p className="text-[11px] text-neutral-500 leading-relaxed max-w-xs font-medium">
                Sovereign Mind is a premium digital recovery fortress designed to downregulate DeltaFosB overexpression and reclaim cognitive focus. Fully ad-friendly, safe, and privacy-first.
              </p>
            </div>

            {/* Column 2: Legal & Trust */}
            <div className="space-y-3 text-left">
              <span className="text-[10px] font-black uppercase tracking-widest text-neutral-400 block">Trust & Verification</span>
              <ul className="space-y-2 text-[11px]" role="list">
                <li>
                  <button 
                    onClick={() => { setActiveTab("privacy"); window.scrollTo(0, 0); }}
                    className="text-neutral-500 hover:text-amber-500 transition-all cursor-pointer outline-none"
                    aria-label="View Privacy Policy"
                  >
                    Privacy Policy
                  </button>
                </li>
                <li>
                  <button 
                    onClick={() => { setActiveTab("terms"); window.scrollTo(0, 0); }}
                    className="text-neutral-500 hover:text-amber-500 transition-all cursor-pointer outline-none"
                    aria-label="View Terms of Service"
                  >
                    Terms of Service
                  </button>
                </li>
                <li>
                  <button 
                    onClick={() => { setActiveTab("cookies"); window.scrollTo(0, 0); }}
                    className="text-neutral-500 hover:text-amber-500 transition-all cursor-pointer outline-none"
                    aria-label="View Cookie Policy"
                  >
                    Cookie Policy
                  </button>
                </li>
                <li>
                  <button 
                    onClick={() => { setActiveTab("disclaimer"); window.scrollTo(0, 0); }}
                    className="text-neutral-500 hover:text-amber-500 transition-all cursor-pointer outline-none"
                    aria-label="View Medical Disclaimer"
                  >
                    Medical Disclaimer
                  </button>
                </li>
                <li>
                  <button 
                    onClick={() => { setActiveTab("guidelines"); window.scrollTo(0, 0); }}
                    className="text-neutral-500 hover:text-amber-500 transition-all cursor-pointer outline-none"
                    aria-label="View Community Guidelines"
                  >
                    Community Guidelines
                  </button>
                </li>
              </ul>
            </div>

            {/* Column 3: Platform Resources */}
            <div className="space-y-3 text-left">
              <span className="text-[10px] font-black uppercase tracking-widest text-neutral-400 block">Platform & Support</span>
              <ul className="space-y-2 text-[11px]" role="list">
                <div className="grid grid-cols-2 gap-x-4 gap-y-2">
                  <li>
                    <button 
                      onClick={() => { setActiveTab("docs"); window.scrollTo(0, 0); }}
                      className="text-neutral-500 hover:text-amber-500 transition-all cursor-pointer outline-none text-left"
                      aria-label="Read Documentation"
                    >
                      Documentation
                    </button>
                  </li>
                  <li>
                    <button 
                      onClick={() => { setActiveTab("about"); window.scrollTo(0, 0); }}
                      className="text-neutral-500 hover:text-amber-500 transition-all cursor-pointer outline-none text-left"
                      aria-label="Read About Us"
                    >
                      About Us
                    </button>
                  </li>
                  <li>
                    <button 
                      onClick={() => { setActiveTab("contact"); window.scrollTo(0, 0); }}
                      className="text-neutral-500 hover:text-amber-500 transition-all cursor-pointer outline-none text-left"
                      aria-label="Contact Administration"
                    >
                      Contact Admin
                    </button>
                  </li>
                  <li>
                    <button 
                      onClick={() => { setActiveTab("faq"); window.scrollTo(0, 0); }}
                      className="text-neutral-500 hover:text-amber-500 transition-all cursor-pointer outline-none text-left"
                      aria-label="View FAQ"
                    >
                      FAQ Accordion
                    </button>
                  </li>
                  <li>
                    <button 
                      onClick={() => { setActiveTab("help"); window.scrollTo(0, 0); }}
                      className="text-neutral-500 hover:text-amber-500 transition-all cursor-pointer outline-none text-left"
                      aria-label="View Help Centre"
                    >
                      Help Centre
                    </button>
                  </li>
                  <li>
                    <button 
                      onClick={() => { setActiveTab("changelog"); window.scrollTo(0, 0); }}
                      className="text-neutral-500 hover:text-amber-500 transition-all cursor-pointer outline-none text-left"
                      aria-label="View Changelog"
                    >
                      Changelog
                    </button>
                  </li>
                  <li>
                    <button 
                      onClick={() => { setActiveTab("accessibility"); window.scrollTo(0, 0); }}
                      className="text-neutral-500 hover:text-amber-500 transition-all cursor-pointer outline-none text-left"
                      aria-label="View Accessibility Statement"
                    >
                      Accessibility
                    </button>
                  </li>
                </div>
                <li className="flex items-center space-x-3 text-neutral-600 pt-1 border-t border-neutral-900 mt-1 col-span-2">
                  <a 
                    href="/sitemap.xml" 
                    target="_blank" 
                    className="text-neutral-500 hover:text-amber-500 transition-all outline-none"
                    aria-label="View Sitemap XML"
                  >
                    Sitemap.xml
                  </a>
                  <span>•</span>
                  <a 
                    href="/robots.txt" 
                    target="_blank" 
                    className="text-neutral-500 hover:text-amber-500 transition-all outline-none"
                    aria-label="View Robots TXT"
                  >
                    Robots.txt
                  </a>
                </li>
              </ul>
            </div>
          </div>

          <div className="pt-6 flex flex-col sm:flex-row items-center justify-between gap-4 text-[10px] text-neutral-600 font-mono">
            <span>© 2026 Sovereign Mind LLC. All rights reserved.</span>
            <span>Scientifically backed. Stoically rewired. Zero third-party data harvesting.</span>
          </div>
        </div>
      </footer>

      {/* Privacy Screen Blur Mask */}
      {isPrivacyScreenActive && (
        <div 
          id="privacy-screen-overlay"
          onClick={() => setIsPrivacyScreenActive(false)}
          className="fixed inset-0 z-50 flex flex-col items-center justify-center bg-[#0A0A0B]/95 backdrop-blur-2xl cursor-pointer select-none transition-all duration-300 animate-fade-in"
        >
          <div 
            onClick={(e) => e.stopPropagation()} 
            className="max-w-md p-8 rounded-2xl border border-amber-500/20 bg-[#0F0F10] text-center space-y-6 shadow-2xl relative overflow-hidden"
          >
            <div className="absolute top-0 left-1/2 -translate-x-1/2 h-32 w-32 bg-amber-500/5 rounded-full blur-2xl pointer-events-none"></div>
            
            <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-2xl bg-amber-500/10 text-amber-500 border border-amber-500/20 animate-pulse">
              <ShieldAlert className="h-8 w-8" />
            </div>
            
            <div className="space-y-2">
              <h2 className="font-display text-base font-bold text-neutral-100 uppercase tracking-widest">
                Sanctuary Shield Active
              </h2>
              <p className="text-xs text-neutral-400 leading-relaxed">
                Your private journal logs, CBT history, and progress metrics have been masked for your safety while away from the tab.
              </p>
            </div>
            
            <div className="pt-2">
              <button 
                onClick={() => setIsPrivacyScreenActive(false)}
                className="rounded-xl bg-amber-500 hover:bg-amber-400 text-[#0A0A0B] font-bold text-xs px-5 py-2.5 transition-all shadow-lg shadow-amber-500/10 cursor-pointer"
              >
                Unmask Sanctuary
              </button>
            </div>
            
            <p className="text-[10px] text-neutral-600 font-mono">
              Click anywhere or return focus to resume your sovereign session.
            </p>
          </div>
        </div>
      )}

      {/* Sovereign Command Palette Console */}
      <CommandPalette 
        isOpen={isCommandPaletteOpen}
        onClose={() => setIsCommandPaletteOpen(false)}
        setActiveTab={setActiveTab}
        isFocusMode={isFocusMode}
        onToggleFocusMode={handleToggleFocusMode}
        theme={theme}
        onToggleTheme={() => setTheme(prev => {
          const themes: ("dark" | "deep-night" | "light" | "midnight" | "soft-gray" | "glassmorphism" | "amoled" | "glass" | "ocean")[] = ["dark", "deep-night", "light", "midnight", "soft-gray", "glassmorphism", "amoled", "glass", "ocean"];
          const nextIdx = (themes.indexOf(prev) + 1) % themes.length;
          return themes[nextIdx];
        })}
        onTriggerSOS={() => {
          setActiveTab("sos");
          setIsCommandPaletteOpen(false);
        }}
        onClaimChest={() => {
          setActiveTab("dashboard");
          setIsCommandPaletteOpen(false);
          setTimeout(() => {
            document.getElementById("interactive-companion-section")?.scrollIntoView({ behavior: "smooth" });
          }, 150);
        }}
        onTogglePrivacyScreen={() => setIsPrivacyScreenActive(prev => !prev)}
      />

      {/* EU AdSense Compliant Interactive Cookie Consent Banner */}
      <CookieConsent />

    </div>
  );
}
