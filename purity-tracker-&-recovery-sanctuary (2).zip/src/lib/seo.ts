/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Dynamic SEO Utility for Sovereign Mind Sanctuary (Hopecore)
 * Injects Meta Tags, Open Graph, Twitter Cards, and Schema.org structured JSON-LD data
 * based on the active app tab context to optimize search engine indexing and AdSense compliance.
 */

export interface SEOConfig {
  title: string;
  description: string;
  keywords: string;
  canonicalUrl: string;
  breadcrumbs: string[];
  schemas: any[];
}

const getSEOData = (tab: string, currentUrl: string): SEOConfig => {
  const baseTitle = "Sovereign Mind Sanctuary | Hopecore Purity & Accountability";
  const defaultDesc = "Track your sovereign focus streak, build mental resilience, and reprogram your mind using Stoic philosophy, daily checklists, and CBT logs. Starve the stimulus and reclaim your focus.";
  const defaultKeywords = "hopecore, sovereign mind, mental purity, dopamine detox, stoic mind shield, CBT logbook, sobriety chronometer, self-mastery, focus tracker, peer accountability";
  const organizationUrl = "https://hopecore-purity.org"; // Production target domain placeholder

  const organizationSchema = {
    "@context": "https://schema.org",
    "@type": "Organization",
    "@id": `${organizationUrl}/#organization`,
    "name": "Sovereign Mind Sanctuary",
    "url": organizationUrl,
    "logo": {
      "@type": "ImageObject",
      "url": `${organizationUrl}/purity-sigil.png`,
      "width": 180,
      "height": 180
    },
    "description": "A scientifically backed and stoically guided digital sanctuary for dopamine detox, mental purity, and peer accountability.",
    "sameAs": [
      "https://discord.gg/XFusvy4xKP"
    ]
  };

  const websiteSchema = {
    "@context": "https://schema.org",
    "@type": "WebSite",
    "@id": `${organizationUrl}/#website`,
    "name": "Sovereign Mind Sanctuary",
    "url": organizationUrl,
    "potentialAction": {
      "@type": "SearchAction",
      "target": `${organizationUrl}/?search={search_term_string}`,
      "query-input": "required name=search_term_string"
    }
  };

  const buildBreadcrumbSchema = (crumbs: string[]) => {
    return {
      "@context": "https://schema.org",
      "@type": "BreadcrumbList",
      "itemListElement": crumbs.map((crumb, idx) => ({
        "@type": "ListItem",
        "position": idx + 1,
        "name": crumb,
        "item": idx === 0 ? organizationUrl : `${organizationUrl}/?tab=${crumb.toLowerCase().replace(/[^a-z0-9]/g, "-")}`
      }))
    };
  };

  switch (tab) {
    case "dashboard":
      return {
        title: `My Sovereign Dashboard - ${baseTitle}`,
        description: `Your central self-command command center. Check off daily dopamine-detox habits, document CBT triggers in your private logbook, track DeltaFosB neuro-recovery progress, and monitor live sobriety clocks.`,
        keywords: `${defaultKeywords}, dashboard, habit tracker, cognitive restructuring, deltafosb, sobriety clocks, mental reset`,
        canonicalUrl: `${organizationUrl}/?tab=dashboard`,
        breadcrumbs: ["Home", "Dashboard"],
        schemas: [
          organizationSchema,
          websiteSchema,
          buildBreadcrumbSchema(["Home", "Dashboard"]),
          {
            "@context": "https://schema.org",
            "@type": "FAQPage",
            "mainEntity": [
              {
                "@type": "Question",
                "name": "What is the Sovereign Daily Checklist?",
                "acceptedAnswer": {
                  "@type": "Answer",
                  "text": "The daily checklist consists of high-impact physiological habits like cold-water splashes, box breathing, and skeletal air squats designed to reduce autonomic tension, divert limbic circulation, and starve addictive impulses."
                }
              },
              {
                "@type": "Question",
                "name": "How does the DeltaFosB molecular model work?",
                "acceptedAnswer": {
                  "@type": "Answer",
                  "text": "DeltaFosB is a molecular transcription factor that accumulates in the brain's reward centers during persistent hyper-stimulation. Re-regulation and recovery require a deliberate period of sensory fasting (dopamine detox) to restore prefrontal control."
                }
              }
            ]
          }
        ]
      };

    case "sos":
      return {
        title: `Emergency Mind SOS Grounding Center - ${baseTitle}`,
        description: `In the middle of a heavy neural urge? Access immediate somatic stabilizers, box breathing anchors, and Stoic mental emergency drills designed to bypass limbic overload.`,
        keywords: `${defaultKeywords}, emergency SOS, urge surfing, somatic grounder, box breathing, amygdala hijack, chemical surge, mental first aid`,
        canonicalUrl: `${organizationUrl}/?tab=sos`,
        breadcrumbs: ["Home", "Emergency SOS"],
        schemas: [
          organizationSchema,
          buildBreadcrumbSchema(["Home", "Emergency SOS"]),
          {
            "@context": "https://schema.org",
            "@type": "FAQPage",
            "mainEntity": [
              {
                "@type": "Question",
                "name": "What is Urge Surfing?",
                "acceptedAnswer": {
                  "@type": "Answer",
                  "text": "Urge Surfing is a clinical cognitive behavioral technique where you observe a physical or mental craving as a temporary wave in your nervous system. Rather than fighting or feeding the wave, you breathe, ground yourself, and ride the surge safely as it inevitably de-escalates."
                }
              }
            ]
          }
        ]
      };

    case "wisdom":
      return {
        title: `Neuroscience & Stoic Science Library - ${baseTitle}`,
        description: `Delve into peer-reviewed neurobiological data on hyper-stimulation recovery, prefrontal cortex strengthening, and classical Stoic mental frameworks from Aurelius and Seneca. Knowledge is armor.`,
        keywords: `${defaultKeywords}, neuroscience library, stoicism, Marcus Aurelius, Seneca, prefrontal cortex, dopamine pathways, neural plasticity, mental fortitude`,
        canonicalUrl: `${organizationUrl}/?tab=wisdom`,
        breadcrumbs: ["Home", "Wisdom Library"],
        schemas: [
          organizationSchema,
          buildBreadcrumbSchema(["Home", "Wisdom Library"]),
          {
            "@context": "https://schema.org",
            "@type": "FAQPage",
            "mainEntity": [
              {
                "@type": "Question",
                "name": "What is prefrontal cortex hypofrontality?",
                "acceptedAnswer": {
                  "@type": "Answer",
                  "text": "Hypofrontality is a condition of reduced functional connectivity in the prefrontal cortex caused by chronic over-stimulation. It impairs self-control, foresight, and executive command. Sovereign Mind provides active tools to reverse this through daily attention exercises and cognitive behavioral journaling."
                }
              }
            ]
          }
        ]
      };

    case "leaderboard":
      return {
        title: `Global Sovereignty Leaders & Scroll of Honor - ${baseTitle}`,
        description: `Stand shoulder to shoulder with thousands of focus warriors globally. View active streak counters, milestone badges, and live status broadcasts of sovereign minds in the arena.`,
        keywords: `${defaultKeywords}, global leaderboard, streak counter, recovery milestone, purity community, peer accountability, status broadcast`,
        canonicalUrl: `${organizationUrl}/?tab=leaderboard`,
        breadcrumbs: ["Home", "Leaderboard"],
        schemas: [
          organizationSchema,
          buildBreadcrumbSchema(["Home", "Leaderboard"])
        ]
      };

    case "community":
      return {
        title: `Fellowship Community Sanctuary - ${baseTitle}`,
        description: `Connect, share stories, and establish mutual accountability with a global community of warriors dedicated to clean eyes, sovereign thoughts, and authentic human recovery.`,
        keywords: `${defaultKeywords}, fellowship community, peer support, accountability chat, recovery forum, mental health fellowship`,
        canonicalUrl: `${organizationUrl}/?tab=community`,
        breadcrumbs: ["Home", "Community Fellowship"],
        schemas: [
          organizationSchema,
          buildBreadcrumbSchema(["Home", "Community Fellowship"])
        ]
      };

    case "support":
      return {
        title: `Support Sanctuary & Healing Center - ${baseTitle}`,
        description: `A quiet, compassionate, judgment-free space to seek advice, report critical technical or user issues, and interact with trained sanctuary moderators. Your recovery is protected.`,
        keywords: `${defaultKeywords}, support center, help desk, moderator support, technical bugs, safe space, recovery guides`,
        canonicalUrl: `${organizationUrl}/?tab=support`,
        breadcrumbs: ["Home", "Support Sanctuary"],
        schemas: [
          organizationSchema,
          buildBreadcrumbSchema(["Home", "Support Sanctuary"])
        ]
      };

    case "mentor":
      return {
        title: `AI Sanctuary Mentor Chat - ${baseTitle}`,
        description: `An interactive, clinically minded AI companion. Ask questions about neuroplasticity, receive custom Stoic insights, and undergo cognitive distortion testing to ground your mental states.`,
        keywords: `${defaultKeywords}, AI mentor, interactive therapy, CBT helper, stoic chatbot, neurobiology guide, cognitive restructuring chatbot`,
        canonicalUrl: `${organizationUrl}/?tab=mentor`,
        breadcrumbs: ["Home", "AI Mentor"],
        schemas: [
          organizationSchema,
          buildBreadcrumbSchema(["Home", "AI Mentor"])
        ]
      };

    case "about":
      return {
        title: `About the Purity Sanctuary - ${baseTitle}`,
        description: `Explore the core mission of Sovereign Mind. Learn how we merge clinical cognitive-behavioral science, neurobiology, and ancient Stoic philosophy to foster robust digital attention and mental clarity.`,
        keywords: `${defaultKeywords}, about, philosophy, neuroscience, stoic fortress, digital detox, mental core`,
        canonicalUrl: `${organizationUrl}/?tab=about`,
        breadcrumbs: ["Home", "About"],
        schemas: [
          organizationSchema,
          buildBreadcrumbSchema(["Home", "About"])
        ]
      };

    case "contact":
      return {
        title: `Contact Administrative Liaison - ${baseTitle}`,
        description: `Reach out directly to the Sovereign Mind Sanctuary administrative liaison for partnerships, support issues, Google AdSense inquiries, or moderation appeals.`,
        keywords: `${defaultKeywords}, contact, support email, general inquiries, administrator, helpdesk`,
        canonicalUrl: `${organizationUrl}/?tab=contact`,
        breadcrumbs: ["Home", "Contact Liaison"],
        schemas: [
          organizationSchema,
          buildBreadcrumbSchema(["Home", "Contact Liaison"])
        ]
      };

    case "privacy":
      return {
        title: `Privacy Policy & Data Rights - ${baseTitle}`,
        description: `Read the official Sovereign Mind Sanctuary Privacy Policy. We detail our adherence to Google AdSense compliance, cookie utilization, local storage persistence, and our absolute guarantee of your cognitive data privacy.`,
        keywords: `${defaultKeywords}, privacy policy, compliance, cookie declaration, user rights, data safety`,
        canonicalUrl: `${organizationUrl}/?tab=privacy`,
        breadcrumbs: ["Home", "Privacy Policy"],
        schemas: [
          organizationSchema,
          buildBreadcrumbSchema(["Home", "Privacy Policy"])
        ]
      };

    case "terms":
      return {
        title: `Terms of Service & Code of Conduct - ${baseTitle}`,
        description: `Review the official Terms of Service of the Sovereign Mind platform. Understand our user code of conduct, medical advice disclaimer, leaderboard conditions, and copyright declarations.`,
        keywords: `${defaultKeywords}, terms of service, conditions of use, user behavior, legal disclaimer`,
        canonicalUrl: `${organizationUrl}/?tab=terms`,
        breadcrumbs: ["Home", "Terms of Service"],
        schemas: [
          organizationSchema,
          buildBreadcrumbSchema(["Home", "Terms of Service"])
        ]
      };

    case "cookies":
      return {
        title: `Cookie Declaration & Storage Policies - ${baseTitle}`,
        description: `Detailed log of all tracking cookies, local storage indicators, and third-party advertising cookies managed on our sovereign mind focus network.`,
        keywords: `${defaultKeywords}, cookies, local storage list, privacy, functional cookies, adsense cookie`,
        canonicalUrl: `${organizationUrl}/?tab=cookies`,
        breadcrumbs: ["Home", "Cookie Policy"],
        schemas: [
          organizationSchema,
          buildBreadcrumbSchema(["Home", "Cookie Policy"])
        ]
      };

    default:
      return {
        title: baseTitle,
        description: defaultDesc,
        keywords: defaultKeywords,
        canonicalUrl: organizationUrl,
        breadcrumbs: ["Home"],
        schemas: [organizationSchema, websiteSchema, buildBreadcrumbSchema(["Home"])]
      };
  }
};

/**
 * Dynamically updates document metadata in the head
 */
export const updateSEO = (tab: string): void => {
  if (typeof window === "undefined" || typeof document === "undefined") return;

  const currentUrl = window.location.href;
  const config = getSEOData(tab, currentUrl);

  // 1. Update document title
  document.title = config.title;

  // Helper to set/update standard meta tags
  const setMetaTag = (attributeName: string, attributeValue: string, content: string) => {
    let element = document.querySelector(`meta[${attributeName}="${attributeValue}"]`);
    if (!element) {
      element = document.createElement("meta");
      element.setAttribute(attributeName, attributeValue);
      document.head.appendChild(element);
    }
    element.setAttribute("content", content);
  };

  // Helper to set/update link tags (like canonical)
  const setLinkTag = (relValue: string, hrefValue: string) => {
    let element = document.querySelector(`link[rel="${relValue}"]`);
    if (!element) {
      element = document.createElement("link");
      element.setAttribute("rel", relValue);
      document.head.appendChild(element);
    }
    element.setAttribute("href", hrefValue);
  };

  // 2. Standard Meta Tags
  setMetaTag("name", "description", config.description);
  setMetaTag("name", "keywords", config.keywords);
  setMetaTag("name", "robots", "index, follow, max-image-preview:large, max-snippet:-1, max-video-preview:-1");
  setMetaTag("name", "google-site-verification", "google_verification_placeholder_xyz"); // Search Console

  // 3. Open Graph (Facebook / LinkedIn)
  setMetaTag("property", "og:title", config.title);
  setMetaTag("property", "og:description", config.description);
  setMetaTag("property", "og:type", "website");
  setMetaTag("property", "og:url", config.canonicalUrl);
  setMetaTag("property", "og:image", "https://hopecore-purity.org/social-preview.png"); // Social preview share image
  setMetaTag("property", "og:site_name", "Sovereign Mind Sanctuary");

  // 4. Twitter Cards
  setMetaTag("name", "twitter:card", "summary_large_image");
  setMetaTag("name", "twitter:title", config.title);
  setMetaTag("name", "twitter:description", config.description);
  setMetaTag("name", "twitter:image", "https://hopecore-purity.org/social-preview.png");

  // 5. Canonical Link
  setLinkTag("canonical", config.canonicalUrl);

  // 6. Schema.org Structured Data injection
  // Remove any existing dynamic schemas
  const existingDynamicSchemas = document.querySelectorAll("script[data-dynamic-schema='true']");
  existingDynamicSchemas.forEach((tag) => tag.remove());

  // Inject new dynamic schemas
  config.schemas.forEach((schema, index) => {
    const scriptTag = document.createElement("script");
    scriptTag.type = "application/ld+json";
    scriptTag.setAttribute("data-dynamic-schema", "true");
    scriptTag.setAttribute("id", `schema-dynamic-${index}`);
    scriptTag.textContent = JSON.stringify(schema);
    document.head.appendChild(scriptTag);
  });

  console.log(`[SEO-Engine] Successfully synchronized and injected SEO assets for tab: "${tab}"`);
};
