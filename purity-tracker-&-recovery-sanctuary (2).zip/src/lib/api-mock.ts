/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

// Global mock database stored in localStorage for 100% serverless, static runtime
interface MockDB {
  users: Record<string, any>;
  leaderboard: any[];
  chatMessages: any[];
  supportTickets: any[];
  dailyQuote?: {
    date: string;
    quote: string;
    author: string;
    commentary: string;
    school: string;
  };
}

const DEFAULT_LEADERBOARD = [
  {
    id: "sim-1",
    username: "Marcus_Aurelius_Will",
    avatarUrl: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80",
    currentStreak: 124,
    highestStreak: 124,
    level: 18,
    title: "Ascended Spirit",
    isRealUser: false,
    statusMessage: "The happiness of your life depends upon the quality of your thoughts. Stand firm."
  },
  {
    id: "sim-2",
    username: "Socrates_Mind",
    avatarUrl: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&auto=format&fit=crop&q=80",
    currentStreak: 78,
    highestStreak: 105,
    level: 14,
    title: "Aegis of Integrity",
    isRealUser: false,
    statusMessage: "The secret of change is to focus all of your energy, not on fighting the old, but on building the new."
  },
  {
    id: "sim-3",
    username: "ZenMaster_Kai",
    avatarUrl: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&auto=format&fit=crop&q=80",
    currentStreak: 45,
    highestStreak: 45,
    level: 9,
    title: "Sovereign of Focus",
    isRealUser: false,
    statusMessage: "The urge is like a wave in the ocean. Ride it with mindful breathing. It always subsides."
  },
  {
    id: "sim-4",
    username: "Purity_Warrior",
    avatarUrl: "https://images.unsplash.com/photo-1519345182560-3f2917c472ef?w=150&auto=format&fit=crop&q=80",
    currentStreak: 24,
    highestStreak: 35,
    level: 6,
    title: "Defender of Purity",
    isRealUser: false,
    statusMessage: "Relapsed at 35 days, but we rise back! Day 24 and feeling stronger than ever."
  },
  {
    id: "sim-5",
    username: "Clarity_Seeker",
    avatarUrl: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=150&auto=format&fit=crop&q=80",
    currentStreak: 12,
    highestStreak: 12,
    level: 4,
    title: "Guardian of the Mind",
    isRealUser: false,
    statusMessage: "Using the Urge SOS Box Breathing helped me crush a massive late-night trigger."
  },
  {
    id: "sim-6",
    username: "Sovereign_Willpower",
    avatarUrl: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=150&auto=format&fit=crop&q=80",
    currentStreak: 5,
    highestStreak: 18,
    level: 2,
    title: "Sprout of Discipline",
    isRealUser: false,
    statusMessage: "Social media clean-up complete. Reducing digital temptation is key!"
  }
];

const PRE_SEEDED_CHAT = [
  {
    id: "chat-seed-1",
    userId: "sim-1",
    username: "Marcus_Aurelius_Will",
    avatarUrl: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80",
    text: "Standing firm on Day 124. For anyone struggling today, remember: you have power over your mind, not outside triggers.",
    timestamp: new Date(Date.now() - 3600000 * 4).toISOString(),
    level: 18,
    title: "Ascended Spirit"
  },
  {
    id: "chat-seed-2",
    userId: "sim-5",
    username: "Clarity_Seeker",
    avatarUrl: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=150&auto=format&fit=crop&q=80",
    text: "The box breathing in the SOS tab is a lifesaver. Just survived a major late-night scrolling trigger.",
    timestamp: new Date(Date.now() - 3600000 * 2.5).toISOString(),
    level: 4,
    title: "Guardian of the Mind"
  },
  {
    id: "chat-seed-3",
    userId: "sim-3",
    username: "ZenMaster_Kai",
    avatarUrl: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&auto=format&fit=crop&q=80",
    text: "Remember, the chemical urge only peaks for 90 seconds to 3 minutes. Surf the wave with clean oxygen. It will pass.",
    timestamp: new Date(Date.now() - 3600000).toISOString(),
    level: 9,
    title: "Sovereign of Focus"
  },
  {
    id: "chat-seed-4",
    userId: "sim-4",
    username: "Purity_Warrior",
    avatarUrl: "https://images.unsplash.com/photo-1519345182560-3f2917c472ef?w=150&auto=format&fit=crop&q=80",
    text: "Let's push through today together, crew! Reclaiming our energy and focus.",
    timestamp: new Date(Date.now() - 600000).toISOString(),
    level: 6,
    title: "Defender of Purity"
  }
];

const FALLBACK_PHILOSOPHY_QUOTES = [
  {
    quote: "The happiness of your life depends upon the quality of your thoughts.",
    author: "Marcus Aurelius",
    school: "Stoicism",
    commentary: "Your mind is your ultimate sanctuary. When urges arise, recognize them as mere chemical signals, and choose to focus your thoughts on your higher goals and inner strength."
  },
  {
    quote: "No man is free who is not master of himself.",
    author: "Epictetus",
    school: "Stoicism",
    commentary: "True liberty is not the license to follow every fleeting physical desire, but the sovereignty to veto impulses that undermine your character and spirit."
  },
  {
    quote: "We suffer more often in imagination than in reality.",
    author: "Seneca",
    school: "Stoicism",
    commentary: "An urge can feel like an unbearable storm in your thoughts, but in reality, it is just a passing sensation. Surf the wave; it has no physical power over you."
  },
  {
    quote: "He who conquers others is strong; he who conquers himself is mighty.",
    author: "Lao Tzu",
    school: "Taoism",
    commentary: "The greatest battle is always internal. Restraining yourself from immediate gratification is a sign of ultimate personal power and mastery."
  },
  {
    quote: "He who has a why to live can bear almost any how.",
    author: "Friedrich Nietzsche",
    school: "Existentialism",
    commentary: "Connect deeply with your purpose—whether it is clear cognitive focus, self-respect, or pure energy. A strong 'why' makes any urge easy to overcome."
  },
  {
    quote: "You have power over your mind - not outside events. Realize this, and you will find strength.",
    author: "Marcus Aurelius",
    school: "Stoicism",
    commentary: "Triggers will always exist in the digital world. You cannot control what appears, but you have absolute power over how you respond. Reclaim your focus."
  }
];

// Read from localStorage-based DB
function readMockDB(): MockDB {
  try {
    const raw = localStorage.getItem("sanctuary_mock_db");
    if (!raw) {
      const initial: MockDB = {
        users: {},
        leaderboard: DEFAULT_LEADERBOARD,
        chatMessages: PRE_SEEDED_CHAT,
        supportTickets: []
      };
      localStorage.setItem("sanctuary_mock_db", JSON.stringify(initial));
      return initial;
    }
    const db = JSON.parse(raw);
    if (!db.chatMessages) db.chatMessages = PRE_SEEDED_CHAT;
    if (!db.supportTickets) db.supportTickets = [];
    return db;
  } catch (err) {
    console.error("Failed to read mock db", err);
    return {
      users: {},
      leaderboard: DEFAULT_LEADERBOARD,
      chatMessages: PRE_SEEDED_CHAT,
      supportTickets: []
    };
  }
}

// Write to localStorage-based DB
function writeMockDB(db: MockDB) {
  try {
    localStorage.setItem("sanctuary_mock_db", JSON.stringify(db));
  } catch (err) {
    console.error("Failed to write mock db", err);
  }
}

// Helper to calculate level and title
function calculateLevelAndTitle(xp: number, streakDays: number): { level: number; title: string } {
  const level = Math.floor(xp / 200) + 1;
  let title = "Seed of Will";
  if (streakDays >= 90) title = "Ascended Spirit";
  else if (streakDays >= 60) title = "Aegis of Integrity";
  else if (streakDays >= 30) title = "Sovereign of Focus";
  else if (streakDays >= 15) title = "Defender of Purity";
  else if (streakDays >= 7) title = "Guardian of the Mind";
  else if (streakDays >= 3) title = "Sprout of Discipline";
  return { level, title };
}

// Helper to get streak days from starting date string
function getStreakDays(startDateStr: string | null): number {
  if (!startDateStr) return 0;
  const start = new Date(startDateStr);
  const now = new Date();
  const diffTime = Math.abs(now.getTime() - start.getTime());
  const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24));
  return diffDays;
}

// Sync user streaks and freezes
function syncUserStreakAndFreezes(user: any) {
  if (user.streakFreezes === undefined) {
    user.streakFreezes = 1;
  }
  if (user.lastEarnedFreezeMonth === undefined) {
    user.lastEarnedFreezeMonth = null;
  }

  const currentStreak = getStreakDays(user.streakStartDate);

  // Milestone check for Streak Freezes (once a month upon maintaining a 30+ day streak)
  if (currentStreak >= 30) {
    const currentMonth = new Date().toISOString().slice(0, 7);
    if (user.lastEarnedFreezeMonth !== currentMonth) {
      user.streakFreezes += 1;
      user.lastEarnedFreezeMonth = currentMonth;
      
      user.logs = user.logs || [];
      user.logs.push({
        id: "earned_freeze_" + Math.random().toString(36).substring(2, 11),
        userId: user.id,
        date: new Date().toISOString().split("T")[0],
        note: "🎉 Earned a Streak Freeze for sustaining an elite 30+ day milestone this month!",
        mood: "resilient",
        checkInCompleted: true,
        cleanDay: true,
        isMilestoneFreeze: true
      });
    }
  }

  // Auto-apply freeze or reset if missed checklist on past days
  if (user.streakStartDate) {
    try {
      const todayStr = new Date().toISOString().split("T")[0];
      const streakStartStr = user.streakStartDate.split("T")[0];
      const y = new Date();
      y.setDate(y.getDate() - 1);
      const yesterdayStr = y.toISOString().split("T")[0];

      if (streakStartStr < yesterdayStr) {
        const currentDate = new Date(user.streakStartDate);
        currentDate.setDate(currentDate.getDate() + 1);
        
        let safetyCount = 0;
        while (safetyCount < 100) {
          safetyCount++;
          const checkStr = currentDate.toISOString().split("T")[0];
          if (checkStr >= todayStr) break;

          user.logs = user.logs || [];
          const checkedInOnDay = user.logs.some(
            (l: any) => l.date === checkStr && (l.cleanDay || l.isFreeze)
          );

          if (!checkedInOnDay) {
            if (user.streakFreezes > 0) {
              user.streakFreezes -= 1;
              user.logs.push({
                id: "freeze_" + Math.random().toString(36).substring(2, 11),
                userId: user.id,
                date: checkStr,
                note: `❄️ Streak Freeze auto-applied to protect your streak on ${checkStr}!`,
                mood: "resilient",
                checkInCompleted: true,
                cleanDay: true,
                isFreeze: true
              });
            } else {
              user.streakStartDate = new Date(currentDate).toISOString();
              user.logs.push({
                id: "break_" + Math.random().toString(36).substring(2, 11),
                userId: user.id,
                date: checkStr,
                note: `⚠️ Streak reset because daily checklist was missed on ${checkStr} and no Streak Freezes were available.`,
                mood: "restless",
                checkInCompleted: true,
                cleanDay: false
              });
              break;
            }
          }
          currentDate.setDate(currentDate.getDate() + 1);
        }
      }
    } catch (e) {
      console.error("Error in mock syncUserStreakAndFreezes", e);
    }
  }
}

// Simulated network delay helper
const delay = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

// Process intercepted fetch calls
async function handleMockRequest(urlStr: string, init?: RequestInit): Promise<Response> {
  await delay(250); // Small, realistic latency

  const db = readMockDB();
  const url = new URL(urlStr, window.location.origin);
  const path = url.pathname;
  const method = init?.method?.toUpperCase() || "GET";
  const body = init?.body ? JSON.parse(String(init.body)) : null;

  // JSON Response creator helper
  const jsonResponse = (data: any, status = 200) => {
    return new Response(JSON.stringify(data), {
      status,
      headers: { "Content-Type": "application/json" }
    });
  };

  try {
    // 1. REGISTER
    if (path === "/api/auth/register" && method === "POST") {
      const { username, email, password, avatarUrl } = body || {};
      if (!username || !email || !password) {
        return jsonResponse({ error: "Username, email, and password are required." }, 400);
      }
      
      const lowerEmail = email.toLowerCase();
      const emailExists = Object.values(db.users).some(u => u.email.toLowerCase() === lowerEmail);
      const usernameExists = Object.values(db.users).some(u => u.username.toLowerCase() === username.toLowerCase());

      if (emailExists) return jsonResponse({ error: "Email is already registered." }, 400);
      if (usernameExists) return jsonResponse({ error: "Username is already taken." }, 400);

      const userId = "user_" + Math.random().toString(36).substring(2, 11);
      const now = new Date().toISOString();

      const newUser = {
        id: userId,
        username,
        email,
        password,
        avatarUrl: avatarUrl || `https://api.dicebear.com/7.x/bottts/svg?seed=${username}`,
        streakStartDate: now,
        highestStreak: 0,
        totalXp: 100,
        level: 1,
        title: "Seed of Will",
        joinedDate: now,
        equippedBadgeId: null,
        logs: [],
        triggers: [],
        statusMessage: "Committed to mental clarity and discipline.",
        streakFreezes: 1,
        lastEarnedFreezeMonth: null,
        following: []
      };

      db.users[userId] = newUser;
      writeMockDB(db);

      const { password: _, ...userSafe } = newUser;
      return jsonResponse({ user: userSafe }, 201);
    }

    // 2. LOGIN
    if (path === "/api/auth/login" && method === "POST") {
      const { email, password } = body || {};
      if (!email || !password) {
        return jsonResponse({ error: "Email and password are required." }, 400);
      }

      const lowerEmail = email.toLowerCase();
      const user = Object.values(db.users).find(u => u.email.toLowerCase() === lowerEmail && u.password === password);

      if (!user) {
        return jsonResponse({ error: "Invalid email or password." }, 401);
      }

      syncUserStreakAndFreezes(user);

      const currentStreak = getStreakDays(user.streakStartDate);
      const { level, title } = calculateLevelAndTitle(user.totalXp, currentStreak);
      user.level = level;
      user.title = title;
      
      if (currentStreak > user.highestStreak) {
        user.highestStreak = currentStreak;
      }
      db.users[user.id] = user;
      writeMockDB(db);

      const { password: _, ...userSafe } = user;
      return jsonResponse({ user: userSafe });
    }

    // 3. GOOGLE OAUTH URL
    if (path === "/api/auth/google/url" && method === "GET") {
      return jsonResponse({ url: "auth-google-simulate.html", real: false });
    }

    // 4. FORGOT PASSWORD
    if (path === "/api/auth/forgot-password" && method === "POST") {
      const { email } = body || {};
      if (!email) return jsonResponse({ error: "Email is required." }, 400);

      const lowerEmail = email.toLowerCase();
      const user = Object.values(db.users).find(u => u.email.toLowerCase() === lowerEmail);

      if (!user) {
        return jsonResponse({ error: "This email is not registered in the Sanctuary archives." }, 404);
      }

      const resetCode = Math.floor(100000 + Math.random() * 900000).toString();
      user.resetCode = resetCode;
      user.resetExpiry = new Date(Date.now() + 15 * 60 * 1000).toISOString();

      db.users[user.id] = user;
      writeMockDB(db);

      return jsonResponse({
        success: true,
        code: resetCode,
        message: "A recovery code has been generated. For testing convenience, the code is returned here."
      });
    }

    // 5. RESET PASSWORD
    if (path === "/api/auth/reset-password" && method === "POST") {
      const { email, code, newPassword } = body || {};
      if (!email || !code || !newPassword) {
        return jsonResponse({ error: "Email, verification code, and new password are required." }, 400);
      }

      const lowerEmail = email.toLowerCase();
      const user = Object.values(db.users).find(u => u.email.toLowerCase() === lowerEmail);

      if (!user) return jsonResponse({ error: "This email is not registered." }, 404);

      if (!user.resetCode || user.resetCode !== code) {
        return jsonResponse({ error: "Invalid verification code." }, 400);
      }

      if (user.resetExpiry && new Date() > new Date(user.resetExpiry)) {
        return jsonResponse({ error: "Verification code has expired." }, 400);
      }

      user.password = newPassword;
      delete user.resetCode;
      delete user.resetExpiry;

      db.users[user.id] = user;
      writeMockDB(db);

      return jsonResponse({ success: true, message: "Cognitive protection shield has been re-keyed! Log in with new credentials." });
    }

    // 6. GET USER PROFILE
    const userMatch = path.match(/^\/api\/user\/([^/]+)$/);
    if (userMatch && method === "GET") {
      const userId = userMatch[1];
      const user = db.users[userId];
      if (!user) return jsonResponse({ error: "User not found." }, 404);

      syncUserStreakAndFreezes(user);

      const currentStreak = getStreakDays(user.streakStartDate);
      const { level, title } = calculateLevelAndTitle(user.totalXp, currentStreak);
      user.level = level;
      user.title = title;
      if (currentStreak > user.highestStreak) {
        user.highestStreak = currentStreak;
      }
      db.users[userId] = user;
      writeMockDB(db);

      const { password: _, ...userSafe } = user;
      return jsonResponse(userSafe);
    }

    // 7. RELAPSE OR START STREAK
    const streakMatch = path.match(/^\/api\/user\/([^/]+)\/streak$/);
    if (streakMatch && method === "POST") {
      const userId = streakMatch[1];
      const { action, note, triggerType, relapseMood } = body || {};
      const user = db.users[userId];
      if (!user) return jsonResponse({ error: "User not found." }, 404);

      syncUserStreakAndFreezes(user);
      const now = new Date().toISOString();

      if (action === "relapse") {
        const completedStreak = getStreakDays(user.streakStartDate);
        user.logs = user.logs || [];
        user.logs.push({
          id: "journal_" + Math.random().toString(36).substring(2, 11),
          userId,
          date: new Date().toISOString().split("T")[0],
          note: note || `Streak of ${completedStreak} days ended. Reflecting and rebuilding.`,
          mood: relapseMood || "restless",
          checkInCompleted: true,
          cleanDay: false
        });

        if (triggerType) {
          user.triggers = user.triggers || [];
          user.triggers.push({
            id: "trig_" + Math.random().toString(36).substring(2, 11),
            userId,
            date: now,
            intensity: 8,
            type: triggerType,
            mitigationStrategy: "Reflected in log. Aiming to remove trigger environment next time."
          });
        }

        user.streakStartDate = now;
        user.statusMessage = "Rising stronger. Purity starts again today.";
      } else if (action === "start") {
        user.streakStartDate = now;
        user.statusMessage = "Commencing purity quest. Day 1 is today.";
      }

      const currentStreak = getStreakDays(user.streakStartDate);
      const { level, title } = calculateLevelAndTitle(user.totalXp, currentStreak);
      user.level = level;
      user.title = title;

      db.users[userId] = user;
      writeMockDB(db);

      const { password: _, ...userSafe } = user;
      return jsonResponse(userSafe);
    }

    // 8. LOG DAILY CHECK-IN
    const checkinMatch = path.match(/^\/api\/user\/([^/]+)\/checkin$/);
    if (checkinMatch && method === "POST") {
      const userId = checkinMatch[1];
      const { note, mood, cleanDay } = body || {};
      const user = db.users[userId];
      if (!user) return jsonResponse({ error: "User not found." }, 404);

      syncUserStreakAndFreezes(user);
      const dateStr = new Date().toISOString().split("T")[0];

      user.logs = user.logs || [];
      const alreadyCheckedIn = user.logs.some((l: any) => l.date === dateStr && l.cleanDay === cleanDay);
      let xpGained = 0;

      user.logs.push({
        id: "journal_" + Math.random().toString(36).substring(2, 11),
        userId,
        date: dateStr,
        note: note || "Maintained daily purity checklist.",
        mood: mood || "focused",
        checkInCompleted: true,
        cleanDay: cleanDay !== false
      });

      if (!alreadyCheckedIn) {
        xpGained = cleanDay ? 50 : 15;
        user.totalXp += xpGained;
      }

      const currentStreak = getStreakDays(user.streakStartDate);
      const { level, title } = calculateLevelAndTitle(user.totalXp, currentStreak);
      user.level = level;
      user.title = title;

      if (currentStreak > user.highestStreak) {
        user.highestStreak = currentStreak;
      }

      db.users[userId] = user;
      writeMockDB(db);

      const { password: _, ...userSafe } = user;
      return jsonResponse({ user: userSafe, xpGained });
    }

    // 9. LOG TRIGGER
    const triggerMatch = path.match(/^\/api\/user\/([^/]+)\/trigger$/);
    if (triggerMatch && method === "POST") {
      const userId = triggerMatch[1];
      const { intensity, type, mitigationStrategy } = body || {};
      const user = db.users[userId];
      if (!user) return jsonResponse({ error: "User not found." }, 404);

      user.triggers = user.triggers || [];
      user.triggers.push({
        id: "trig_" + Math.random().toString(36).substring(2, 11),
        userId,
        date: new Date().toISOString(),
        intensity: Number(intensity) || 5,
        type: type || "Boredom",
        mitigationStrategy: mitigationStrategy || "Practiced mindful urge surfing."
      });

      const xpGained = 25;
      user.totalXp += xpGained;

      const currentStreak = getStreakDays(user.streakStartDate);
      const { level, title } = calculateLevelAndTitle(user.totalXp, currentStreak);
      user.level = level;
      user.title = title;

      db.users[userId] = user;
      writeMockDB(db);

      const { password: _, ...userSafe } = user;
      return jsonResponse({ user: userSafe, xpGained });
    }

    // 10. SOS COPE XP REWARD
    const urgesurfedMatch = path.match(/^\/api\/user\/([^/]+)\/urgesurfed$/);
    if (urgesurfedMatch && method === "POST") {
      const userId = urgesurfedMatch[1];
      const user = db.users[userId];
      if (!user) return jsonResponse({ error: "User not found." }, 404);

      const xpGained = 50;
      user.totalXp += xpGained;

      const currentStreak = getStreakDays(user.streakStartDate);
      const { level, title } = calculateLevelAndTitle(user.totalXp, currentStreak);
      user.level = level;
      user.title = title;

      db.users[userId] = user;
      writeMockDB(db);

      const { password: _, ...userSafe } = user;
      return jsonResponse({ user: userSafe, xpGained });
    }

    // 11. STATUS MESSAGE UPDATE
    const statusMatch = path.match(/^\/api\/user\/([^/]+)\/status$/);
    if (statusMatch && method === "POST") {
      const userId = statusMatch[1];
      const { statusMessage } = body || {};
      const user = db.users[userId];
      if (!user) return jsonResponse({ error: "User not found." }, 404);

      user.statusMessage = statusMessage || "";
      db.users[userId] = user;
      writeMockDB(db);

      const { password: _, ...userSafe } = user;
      return jsonResponse(userSafe);
    }

    // 12. CHOOSE BADGE
    const badgeMatch = path.match(/^\/api\/user\/([^/]+)\/badge$/);
    if (badgeMatch && method === "POST") {
      const userId = badgeMatch[1];
      const { badgeId } = body || {};
      const user = db.users[userId];
      if (!user) return jsonResponse({ error: "User not found." }, 404);

      user.equippedBadgeId = badgeId || null;
      db.users[userId] = user;
      writeMockDB(db);

      const { password: _, ...userSafe } = user;
      return jsonResponse(userSafe);
    }

    // 13. COMPREHENSIVE SETTINGS
    const settingsMatch = path.match(/^\/api\/user\/([^/]+)\/settings$/);
    if (settingsMatch && method === "POST") {
      const userId = settingsMatch[1];
      const { username, statusMessage, avatarUrl, bannerColor, customStatus, socialLink } = body || {};
      const user = db.users[userId];
      if (!user) return jsonResponse({ error: "User not found." }, 404);

      if (username && username !== user.username) {
        const cleanUsername = username.replace(/[^a-zA-Z0-9_]/g, "_");
        if (!cleanUsername) return jsonResponse({ error: "Invalid username format." }, 400);

        const usernameTaken = Object.values(db.users).some(u => u.id !== userId && u.username.toLowerCase() === cleanUsername.toLowerCase());
        if (usernameTaken) return jsonResponse({ error: "Username is already claimed." }, 400);

        user.username = cleanUsername;
      }

      if (statusMessage !== undefined) user.statusMessage = statusMessage;
      if (avatarUrl !== undefined) user.avatarUrl = avatarUrl;
      if (bannerColor !== undefined) user.bannerColor = bannerColor;
      if (customStatus !== undefined) user.customStatus = customStatus;
      if (socialLink !== undefined) user.socialLink = socialLink;

      db.users[userId] = user;
      writeMockDB(db);

      const { password: _, ...userSafe } = user;
      return jsonResponse(userSafe);
    }

    // 14. CHANGE PASSWORD
    const changepassMatch = path.match(/^\/api\/user\/([^/]+)\/change-password$/);
    if (changepassMatch && method === "POST") {
      const userId = changepassMatch[1];
      const { currentPassword, newPassword } = body || {};
      const user = db.users[userId];
      if (!user) return jsonResponse({ error: "User not found." }, 404);

      if (user.password && !user.password.startsWith("google_oauth_authorized_") && user.password !== currentPassword) {
        return jsonResponse({ error: "Current password does not match our archives." }, 400);
      }

      user.password = newPassword;
      db.users[userId] = user;
      writeMockDB(db);

      return jsonResponse({ success: true, message: "Password updated successfully!" });
    }

    // 15. EXPORT DATA
    const exportMatch = path.match(/^\/api\/user\/([^/]+)\/export$/);
    if (exportMatch && method === "GET") {
      const userId = exportMatch[1];
      const user = db.users[userId];
      if (!user) return jsonResponse({ error: "User not found." }, 404);

      const { password: _, ...userSafe } = user;
      return jsonResponse({
        exportedAt: new Date().toISOString(),
        user: userSafe,
        schemaVersion: "2.5",
        disclaimer: "This data export contains all journal entries, triggers, and configurations stored in the Sovereign Mind Sanctuary."
      });
    }

    // 16. DELETE ACCOUNT
    const deleteMatch = path.match(/^\/api\/user\/([^/]+)\/delete$/);
    if (deleteMatch && method === "DELETE") {
      const userId = deleteMatch[1];
      if (!db.users[userId]) return jsonResponse({ error: "User not found." }, 404);

      delete db.users[userId];
      writeMockDB(db);

      return jsonResponse({ success: true, message: "All records permanently deleted from this device cache." });
    }

    // 17. RETRIEVE LEADERBOARD
    if (path === "/api/leaderboard" && method === "GET") {
      const realUsersList = Object.values(db.users).map(user => {
        syncUserStreakAndFreezes(user);
        const currentStreak = getStreakDays(user.streakStartDate);
        const { level, title } = calculateLevelAndTitle(user.totalXp, currentStreak);
        return {
          id: user.id,
          username: user.username,
          avatarUrl: user.avatarUrl,
          currentStreak,
          highestStreak: Math.max(user.highestStreak || 0, currentStreak),
          level,
          title,
          isRealUser: true,
          equippedBadgeId: user.equippedBadgeId || null,
          statusMessage: user.statusMessage || "On the path of self-mastery."
        };
      });

      const combined = [...realUsersList, ...db.leaderboard];
      combined.sort((a, b) => {
        if (b.currentStreak !== a.currentStreak) return b.currentStreak - a.currentStreak;
        return b.level - a.level;
      });

      const ranked = combined.map((entry, idx) => ({ ...entry, rank: idx + 1 }));
      return jsonResponse(ranked);
    }

    // 18. CBT PURITY AI MENTOR (Fully self-contained CBT/mindfulness response engine)
    if (path === "/api/mentor" && method === "POST") {
      const { messages, userProfile } = body || {};
      const lastUserMsg = messages && messages.length > 0 ? messages[messages.length - 1]?.text || "" : "";
      
      let replyText = "I am right beside you on this quest towards cognitive freedom. Remember, urges are temporary waves in your brain's chemistry. Take five deep breaths and remind yourself why you started. Every second you choose purity, you are actively rewiring your dopamine pathways for long-term command and power.";
      const lower = lastUserMsg.toLowerCase();

      if (lower.includes("relapse") || lower.includes("failed") || lower.includes("reset") || lower.includes("slipped")) {
        replyText = `Please do not be discouraged, ${userProfile?.username || "Warrior"}. A relapse is not a return to absolute zero; it is a single stumble on a long mountain path. What matters is how you rise. Be compassionate with yourself, identify what triggered this (stress, isolation, boredom, or digital triggers?), and do a physical reset right now—stand up, splash cold water, or step outside. You are a warrior in training.`;
      } else if (lower.includes("urge") || lower.includes("tempted") || lower.includes("horny") || lower.includes("desire") || lower.includes("scrolling")) {
        replyText = "An urge is just an intense neurochemical wave, but it holds zero physical power over your motor muscles. It peaks in 2-3 minutes and then recedes. Enter the box breathing exercise immediately, or drop and do 20 pushups right now. Your prefrontal cortex can and will override this trigger. Let's conquer this together!";
      } else if (lower.includes("why") || lower.includes("benefit") || lower.includes("science") || lower.includes("improve")) {
        replyText = "Fasting from hyper-stimuli triggers incredible neural healing: 1. Your dopamine receptors upregulate, restoring pure satisfaction in daily things. 2. Your prefrontal cortex (the center of will) thickens, granting you supreme focus. 3. Physical vitality and mental clarity return, removing anxiety and guilt. You are reclaiming your sovereignty.";
      } else if (lower.includes("hello") || lower.includes("hi ") || lower.includes("hey")) {
        replyText = `Greetings, ${userProfile?.username || "Warrior"}. I am your Purity Mentor, here to guide you in CBT training and urge-surfing techniques. How is your focus and resolve today on Day ${userProfile?.currentStreak || 0}?`;
      } else if (lower.includes("thank") || lower.includes("help")) {
        replyText = "You are welcome. Standing firm is the ultimate gift you can give your future self. I am always here when you need to surf a craving. Take a slow, deep breath, and hold your head high.";
      }

      return jsonResponse({ text: replyText });
    }

    // 19. DAILY PHILOSOPHICAL QUOTE
    if (path === "/api/philosophy/daily" && method === "GET") {
      const todayStr = new Date().toISOString().split("T")[0];
      
      if (db.dailyQuote && db.dailyQuote.date === todayStr && url.searchParams.get("regen") !== "true") {
        return jsonResponse(db.dailyQuote);
      }

      const hash = todayStr.split("-").reduce((acc, char) => acc + char.charCodeAt(0), 0);
      const randomIdx = hash % FALLBACK_PHILOSOPHY_QUOTES.length;
      const quote = FALLBACK_PHILOSOPHY_QUOTES[randomIdx];

      const selectedQuote = {
        date: todayStr,
        ...quote
      };

      db.dailyQuote = selectedQuote;
      writeMockDB(db);

      return jsonResponse(selectedQuote);
    }

    // 20. GET COMMUNITY CHAT
    if (path === "/api/chat" && method === "GET") {
      return jsonResponse(db.chatMessages);
    }

    // 21. POST CHAT MESSAGE
    if (path === "/api/chat" && method === "POST") {
      const { text, userId, username, avatarUrl, level, title } = body || {};
      if (!text) return jsonResponse({ error: "Text is required." }, 400);

      const newMessage = {
        id: "chat_" + Math.random().toString(36).substring(2, 11),
        userId: userId || "guest",
        username: username || "Guest Warrior",
        avatarUrl: avatarUrl || `https://api.dicebear.com/7.x/bottts/svg?seed=guest`,
        text,
        timestamp: new Date().toISOString(),
        level: level || 1,
        title: title || "Seed of Will"
      };

      db.chatMessages.push(newMessage);
      
      // Limit to last 50 chat messages
      if (db.chatMessages.length > 50) {
        db.chatMessages = db.chatMessages.slice(db.chatMessages.length - 50);
      }

      writeMockDB(db);

      // Trigger delayed simulated community reply to make the forum feel alive
      setTimeout(() => {
        const simDb = readMockDB();
        const replies = [
          "Stand strong, brother! Purity is power.",
          "Absolutely! Survived a major temptation today too. We're in this together.",
          "Good reminder on the 90-second peak. Doing pushups now!",
          "Day by day, the mind clears. Excellent work.",
          "Keep that shield high, warriors!"
        ];
        const randomReply = replies[Math.floor(Math.random() * replies.length)];
        const peer = DEFAULT_LEADERBOARD[Math.floor(Math.random() * DEFAULT_LEADERBOARD.length)];
        
        simDb.chatMessages.push({
          id: "chat_sim_" + Math.random().toString(36).substring(2, 11),
          userId: peer.id,
          username: peer.username,
          avatarUrl: peer.avatarUrl,
          text: `@${username || "Warrior"} ${randomReply}`,
          timestamp: new Date().toISOString(),
          level: peer.level,
          title: peer.title
        });
        
        if (simDb.chatMessages.length > 50) {
          simDb.chatMessages = simDb.chatMessages.slice(simDb.chatMessages.length - 50);
        }
        writeMockDB(simDb);
      }, 5000);

      return jsonResponse(db.chatMessages);
    }

    // 22. SOCIAL FOLLOW/UNFOLLOW/FOLLOWING list
    const followMatch = path.match(/^\/api\/user\/([^/]+)\/follow$/);
    if (followMatch && method === "POST") {
      const { followId } = body || {};
      const userId = followMatch[1];
      const user = db.users[userId];
      if (user) {
        user.following = user.following || [];
        if (!user.following.includes(followId)) {
          user.following.push(followId);
        }
        db.users[userId] = user;
        writeMockDB(db);
      }
      return jsonResponse({ success: true, following: user?.following || [] });
    }

    const unfollowMatch = path.match(/^\/api\/user\/([^/]+)\/unfollow$/);
    if (unfollowMatch && method === "POST") {
      const { followId } = body || {};
      const userId = unfollowMatch[1];
      const user = db.users[userId];
      if (user) {
        user.following = user.following || [];
        user.following = user.following.filter((id: string) => id !== followId);
        db.users[userId] = user;
        writeMockDB(db);
      }
      return jsonResponse({ success: true, following: user?.following || [] });
    }

    const followingMatch = path.match(/^\/api\/user\/([^/]+)\/following$/);
    if (followingMatch && method === "GET") {
      const userId = followingMatch[1];
      const user = db.users[userId];
      return jsonResponse(user?.following || []);
    }

    // 23. SUPPORT TICKETS GET
    if (path === "/api/support/tickets" && method === "GET") {
      const userId = url.searchParams.get("userId");
      if (userId) {
        const userTickets = db.supportTickets.filter(t => t.userId === userId);
        return jsonResponse(userTickets);
      }
      return jsonResponse(db.supportTickets);
    }

    // 24. SUPPORT TICKETS CREATE
    if (path === "/api/support/tickets" && method === "POST") {
      const { userId, username, avatarUrl, title, type } = body || {};
      if (!title) return jsonResponse({ error: "Title is required." }, 400);

      const ticketId = "ticket_" + Math.random().toString(36).substring(2, 11);
      const newTicket = {
        id: ticketId,
        userId: userId || "guest",
        username: username || "Guest Warrior",
        avatarUrl: avatarUrl || `https://api.dicebear.com/7.x/bottts/svg?seed=guest`,
        title,
        status: "open",
        type: type || "real",
        messages: [
          {
            id: "msg_" + Math.random().toString(36).substring(2, 11),
            sender: "user",
            senderName: username || "Guest Warrior",
            text: `Inaugurated support ticket: "${title}"`,
            createdAt: new Date().toISOString()
          }
        ],
        createdAt: new Date().toISOString()
      };

      db.supportTickets.push(newTicket);
      writeMockDB(db);

      // AI support answers immediately if type is AI
      if (type === "ai") {
        setTimeout(() => {
          const simDb = readMockDB();
          const targetTicket = simDb.supportTickets.find(t => t.id === ticketId);
          if (targetTicket) {
            targetTicket.messages.push({
              id: "msg_ai_" + Math.random().toString(36).substring(2, 11),
              sender: "ai",
              senderName: "Sanctuary Archon Bot",
              text: "Hail, Sovereign Warrior. Your support ticket is registered. Since this is an interactive AI Help channel, describe any client issues or questions right here. I will help troubleshoot or offer CBT mental exercises instantly.",
              createdAt: new Date().toISOString()
            });
            writeMockDB(simDb);
          }
        }, 1500);
      }

      return jsonResponse(newTicket);
    }

    // 25. CHAT INSIDE SUPPORT CASE
    const ticketMsgMatch = path.match(/^\/api\/support\/tickets\/([^/]+)\/messages$/);
    if (ticketMsgMatch && method === "POST") {
      const ticketId = ticketMsgMatch[1];
      const { sender, senderName, text } = body || {};
      if (!text) return jsonResponse({ error: "Message text is required." }, 400);

      const targetTicket = db.supportTickets.find(t => t.id === ticketId);
      if (!targetTicket) return jsonResponse({ error: "Ticket not found." }, 404);

      const userMsg = {
        id: "msg_" + Math.random().toString(36).substring(2, 11),
        sender: sender || "user",
        senderName: senderName || "Warrior",
        text,
        createdAt: new Date().toISOString()
      };

      targetTicket.messages.push(userMsg);
      writeMockDB(db);

      // If AI ticket, bot replies in 2 seconds
      if (targetTicket.type === "ai" && sender === "user") {
        setTimeout(() => {
          const simDb = readMockDB();
          const simTicket = simDb.supportTickets.find(t => t.id === ticketId);
          if (simTicket) {
            let botReplyText = "Thank you for the message. I have logged this to your cache. Keep your prefrontal focus aligned. Your sovereign self is proud of your effort.";
            const lText = text.toLowerCase();
            
            if (lText.includes("bug") || lText.includes("error") || lText.includes("blank") || lText.includes("load")) {
              botReplyText = "🔧 Technical Troubleshooting Tip: If you observe any local blank screens or loading lags, click 'Wipe Local Cache' in settings or hard-refresh your browser. Since Sanctuary is 100% static, clearing your local storage will perfectly resolve database lockups!";
            } else if (lText.includes("badge") || lText.includes("level") || lText.includes("xp")) {
              botReplyText = "🎖️ Milestones & Badges: You earn XP (50 XP for daily clean check-ins, 25 XP for logging trigger surfing). Accumulating XP increases your sovereign Level and unlocks elite visual Badges which you can equip in settings!";
            } else if (lText.includes("freeze") || lText.includes("missed")) {
              botReplyText = "❄️ Streak Freezes: Each user receives 1 welcome freeze. You earn another freeze every month you sustain a 30+ day streak. If you miss a daily log, a freeze is auto-applied to protect your count!";
            }

            simTicket.messages.push({
              id: "msg_ai_" + Math.random().toString(36).substring(2, 11),
              sender: "ai",
              senderName: "Sanctuary Archon Bot",
              text: botReplyText,
              createdAt: new Date().toISOString()
            });
            writeMockDB(simDb);
          }
        }, 1500);
      }

      return jsonResponse(targetTicket);
    }

    // 26. RESOLVE CASE
    const resolveMatch = path.match(/^\/api\/support\/tickets\/([^/]+)\/resolve$/);
    if (resolveMatch && method === "POST") {
      const ticketId = resolveMatch[1];
      const targetTicket = db.supportTickets.find(t => t.id === ticketId);
      if (!targetTicket) return jsonResponse({ error: "Ticket not found." }, 404);

      targetTicket.status = "resolved";
      writeMockDB(db);
      return jsonResponse(targetTicket);
    }

    // Fallback 404 for unrecognized API
    return jsonResponse({ error: `Mock endpoint not found: ${method} ${path}` }, 404);

  } catch (err: any) {
    console.error("Mock Request handler crashed:", err);
    return jsonResponse({ error: "Internal Mock Database Error." }, 500);
  }
}

// Global fetch Interception Hook Setup
const originalFetch = window.fetch;
const customFetch = async function (this: any, input: RequestInfo | URL, init?: RequestInit): Promise<Response> {
  const urlStr = typeof input === "string" 
    ? input 
    : input instanceof URL 
      ? input.toString() 
      : (input as Request).url;

  // Catch API calls
  if (urlStr.startsWith("/api/") || urlStr.includes("/api/")) {
    return handleMockRequest(urlStr, init);
  }

  // Fallback to real fetch for non-API static files
  return originalFetch.apply(this, arguments as any);
};

try {
  Object.defineProperty(window, 'fetch', {
    value: customFetch,
    writable: true,
    configurable: true
  });
} catch (e) {
  console.warn("Could not override fetch via defineProperty, falling back to direct assignment", e);
  try {
    (window as any).fetch = customFetch;
  } catch (err) {
    console.error("Failed to intercept fetch completely:", err);
  }
}

console.log("🚀 Sovereign Serverless API Mock layer registered successfully. All endpoints emulated locally.");
