/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface CareerLevelBadge {
  id: string;
  name: string;
  xpRequired: number;
  emoji: string;
  colorClass: string;
  borderColor: string;
  badgeBg: string;
  description: string;
  philosophy: string;
}

export const CAREER_BADGES: CareerLevelBadge[] = [
  {
    id: "bronze_sigil",
    name: "Bronze Aegis",
    xpRequired: 0,
    emoji: "🛡️",
    colorClass: "text-amber-500",
    borderColor: "border-amber-500/30",
    badgeBg: "bg-amber-500/10",
    description: "Initiated into the sovereign path of mental discipline.",
    philosophy: "Every long march begins with a single voluntary boundary."
  },
  {
    id: "iron_will",
    name: "Iron Dynamo",
    xpRequired: 250,
    emoji: "⚙️",
    colorClass: "text-zinc-400",
    borderColor: "border-zinc-500/30",
    badgeBg: "bg-zinc-500/10",
    description: "Cemented the foundation of consistent behavioral checking.",
    philosophy: "Forge your focus daily. Repetition breeds unyielding executive control."
  },
  {
    id: "silver_gaze",
    name: "Silver Mystic",
    xpRequired: 600,
    emoji: "🔮",
    colorClass: "text-blue-400",
    borderColor: "border-blue-500/30",
    badgeBg: "bg-blue-500/10",
    description: "Attuned the prefrontal cortex to capture and log subtle triggers.",
    philosophy: "Mindfulness is a mirror. Seeing your triggers clearly is half the victory."
  },
  {
    id: "golden_sovereign",
    name: "Golden Overlord",
    xpRequired: 1200,
    emoji: "👑",
    colorClass: "text-yellow-400",
    borderColor: "border-yellow-500/30",
    badgeBg: "bg-yellow-500/10",
    description: "Harnessed the standard dopamine homeostasis reset threshold.",
    philosophy: "Rule over your desires, or they will rule over you. Command the domain."
  },
  {
    id: "emerald_phoenix",
    name: "Emerald Transmuter",
    xpRequired: 2200,
    emoji: "🧪",
    colorClass: "text-emerald-400",
    borderColor: "border-emerald-500/30",
    badgeBg: "bg-emerald-500/10",
    description: "Unleashed BDNF synaptic plasticity to rewrite central neural hubs.",
    philosophy: "Transmute base temptation into pure intellectual and creative flow."
  },
  {
    id: "amethyst_warden",
    name: "Amethyst Sovereign",
    xpRequired: 3500,
    emoji: "🧬",
    colorClass: "text-purple-400",
    borderColor: "border-purple-500/30",
    badgeBg: "bg-purple-500/10",
    description: "Consolidated pristine myelin layers for automatic habit triggers.",
    philosophy: "Primal urges fade into automated sovereign mastery. Insulated by grace."
  },
  {
    id: "cosmic_singularity",
    name: "Cosmic Singularity",
    xpRequired: 5000,
    emoji: "🌌",
    colorClass: "text-rose-450",
    borderColor: "border-rose-500/40",
    badgeBg: "bg-rose-500/10",
    description: "Reached absolute spiritual and mental escape velocity.",
    philosophy: "The star collapses into a singularity of infinite, absolute composure."
  }
];

export function getActiveBadge(equippedBadgeId?: string | null, totalXp: number = 0): CareerLevelBadge | null {
  if (equippedBadgeId) {
    const badge = CAREER_BADGES.find(b => b.id === equippedBadgeId && totalXp >= b.xpRequired);
    if (badge) return badge;
  }
  // Fallback to highest unlocked badge
  const unlocked = [...CAREER_BADGES].reverse().find(b => totalXp >= b.xpRequired);
  return unlocked || null;
}
