/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import express from "express";
import path from "path";
import fs from "fs";
import dotenv from "dotenv";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, Type } from "@google/genai";

dotenv.config();

const app = express();
const PORT = 3000;
const DB_FILE = path.join(process.cwd(), "database.json");

app.use(express.json());

// Initialize Database structure
interface DBStructure {
  users: Record<string, any>;
  leaderboard: Array<{
    id: string;
    username: string;
    avatarUrl: string;
    currentStreak: number;
    highestStreak: number;
    level: number;
    title: string;
    isRealUser: boolean;
    statusMessage: string;
  }>;
  chatMessages?: Array<{
    id: string;
    userId: string;
    username: string;
    avatarUrl: string;
    text: string;
    timestamp: string;
    level: number;
    title: string;
  }>;
  supportTickets?: Array<{
    id: string;
    userId: string;
    username: string;
    avatarUrl: string;
    title: string;
    status: "open" | "resolved";
    type: "ai" | "real";
    messages: Array<{
      id: string;
      sender: "user" | "ai" | "mod";
      senderName: string;
      text: string;
      createdAt: string;
    }>;
    createdAt: string;
  }>;
  dailyQuote?: {
    date: string;
    quote: string;
    author: string;
    commentary: string;
    school: string;
  };
}

const DEFAULT_LEADERBOARD = [
  {
    id: "sim-1",
    username: "Marcus_Aurelius_Will",
    avatarUrl: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80",
    currentStreak: 124,
    highestStreak: 124,
    level: 18,
    title: "Ascended Spirit",
    isRealUser: false,
    statusMessage: "The happiness of your life depends upon the quality of your thoughts. Stand firm."
  },
  {
    id: "sim-2",
    username: "Socrates_Mind",
    avatarUrl: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&auto=format&fit=crop&q=80",
    currentStreak: 78,
    highestStreak: 105,
    level: 14,
    title: "Aegis of Integrity",
    isRealUser: false,
    statusMessage: "The secret of change is to focus all of your energy, not on fighting the old, but on building the new."
  },
  {
    id: "sim-3",
    username: "ZenMaster_Kai",
    avatarUrl: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&auto=format&fit=crop&q=80",
    currentStreak: 45,
    highestStreak: 45,
    level: 9,
    title: "Sovereign of Focus",
    isRealUser: false,
    statusMessage: "The urge is like a wave in the ocean. Ride it with mindful breathing. It always subsides."
  },
  {
    id: "sim-4",
    username: "Purity_Warrior",
    avatarUrl: "https://images.unsplash.com/photo-1519345182560-3f2917c472ef?w=150&auto=format&fit=crop&q=80",
    currentStreak: 24,
    highestStreak: 35,
    level: 6,
    title: "Defender of Purity",
    isRealUser: false,
    statusMessage: "Relapsed at 35 days, but we rise back! Day 24 and feeling stronger than ever."
  },
  {
    id: "sim-5",
    username: "Clarity_Seeker",
    avatarUrl: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=150&auto=format&fit=crop&q=80",
    currentStreak: 12,
    highestStreak: 12,
    level: 4,
    title: "Guardian of the Mind",
    isRealUser: false,
    statusMessage: "Using the Urge SOS Box Breathing helped me crush a massive late-night trigger."
  },
  {
    id: "sim-6",
    username: "Sovereign_Willpower",
    avatarUrl: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=150&auto=format&fit=crop&q=80",
    currentStreak: 5,
    highestStreak: 18,
    level: 2,
    title: "Sprout of Discipline",
    isRealUser: false,
    statusMessage: "Social media clean-up complete. Reducing digital temptation is key!"
  }
];

function readDB(): DBStructure {
  try {
    if (!fs.existsSync(DB_FILE)) {
      const initData: DBStructure = { users: {}, leaderboard: DEFAULT_LEADERBOARD, chatMessages: [], supportTickets: [] };
      fs.writeFileSync(DB_FILE, JSON.stringify(initData, null, 2));
      return initData;
    }
    const data = fs.readFileSync(DB_FILE, "utf-8");
    const parsed = JSON.parse(data);
    if (!parsed.chatMessages) parsed.chatMessages = [];
    if (!parsed.supportTickets) parsed.supportTickets = [];
    return parsed;
  } catch (err) {
    console.error("Error reading database", err);
    return { users: {}, leaderboard: DEFAULT_LEADERBOARD, chatMessages: [], supportTickets: [] };
  }
}

function writeDB(data: DBStructure) {
  try {
    fs.writeFileSync(DB_FILE, JSON.stringify(data, null, 2));
  } catch (err) {
    console.error("Error writing database", err);
  }
}

// Utility to calculate level and title based on XP and streak days
function calculateLevelAndTitle(xp: number, streakDays: number): { level: number; title: string } {
  const level = Math.floor(xp / 200) + 1;
  let title = "Seed of Will";
  if (streakDays >= 90) title = "Ascended Spirit";
  else if (streakDays >= 60) title = "Aegis of Integrity";
  else if (streakDays >= 30) title = "Sovereign of Focus";
  else if (streakDays >= 15) title = "Defender of Purity";
  else if (streakDays >= 7) title = "Guardian of the Mind";
  else if (streakDays >= 3) title = "Sprout of Discipline";
  return { level, title };
}

// Helper to estimate current streak days from start date
function getStreakDays(startDateStr: string | null): number {
  if (!startDateStr) return 0;
  const start = new Date(startDateStr);
  const now = new Date();
  const diffTime = Math.abs(now.getTime() - start.getTime());
  const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24));
  return diffDays;
}

// Check and apply streak freezes / earn streak freezes based on 30-day milestone
function syncUserStreakAndFreezes(user: any) {
  // Ensure fields are initialized
  if (user.streakFreezes === undefined) {
    user.streakFreezes = 1; // start with 1 freeze as a welcome gift
  }
  if (user.lastEarnedFreezeMonth === undefined) {
    user.lastEarnedFreezeMonth = null;
  }

  // Calculate current streak
  const currentStreak = getStreakDays(user.streakStartDate);

  // Check if they should earn a Streak Freeze (once a month by hitting a 30+ day streak)
  if (currentStreak >= 30) {
    const currentMonth = new Date().toISOString().slice(0, 7); // e.g., "2026-07"
    if (user.lastEarnedFreezeMonth !== currentMonth) {
      user.streakFreezes += 1;
      user.lastEarnedFreezeMonth = currentMonth;
      
      // Add a milestone log
      user.logs = user.logs || [];
      user.logs.push({
        id: "earned_freeze_" + Math.random().toString(36).substring(2, 11),
        userId: user.id,
        date: new Date().toISOString().split("T")[0],
        note: "🎉 Earned a Streak Freeze for sustaining an elite 30+ day milestone this month!",
        mood: "resilient",
        checkInCompleted: true,
        cleanDay: true,
        isMilestoneFreeze: true
      });
    }
  }

  // Check all days from streakStartDate up to yesterday
  if (user.streakStartDate) {
    try {
      const todayStr = new Date().toISOString().split("T")[0];
      const streakStartStr = user.streakStartDate.split("T")[0];
      
      // Get yesterday's date
      const y = new Date();
      y.setUTCDate(y.getUTCDate() - 1);
      const yesterdayStr = y.toISOString().split("T")[0];

      if (streakStartStr < yesterdayStr) {
        // We will loop from the day after streakStartDate up to yesterday
        let currentDate = new Date(user.streakStartDate);
        currentDate.setUTCDate(currentDate.getUTCDate() + 1); // start from day after
        
        let safetyCount = 0; // avoid infinite loop if dates are weird
        while (safetyCount < 100) {
          safetyCount++;
          const checkStr = currentDate.toISOString().split("T")[0];
          if (checkStr >= todayStr) {
            break; // don't check today or future
          }

          // Did they check in or have a freeze on checkStr?
          user.logs = user.logs || [];
          const checkedInOnDay = user.logs.some(
            (l: any) => l.date === checkStr && (l.cleanDay || l.isFreeze)
          );

          if (!checkedInOnDay) {
            // Missed this day!
            if (user.streakFreezes > 0) {
              user.streakFreezes -= 1;
              user.logs.push({
                id: "freeze_" + Math.random().toString(36).substring(2, 11),
                userId: user.id,
                date: checkStr,
                note: `❄️ Streak Freeze auto-applied to protect your streak on ${checkStr}!`,
                mood: "resilient",
                checkInCompleted: true,
                cleanDay: true,
                isFreeze: true
              });
            } else {
              // No freezes left! Streak breaks
              user.streakStartDate = new Date(currentDate).toISOString(); // reset streak to start on this missed day
              user.logs.push({
                id: "break_" + Math.random().toString(36).substring(2, 11),
                userId: user.id,
                date: checkStr,
                note: `⚠️ Streak reset because daily checklist was missed on ${checkStr} and no Streak Freezes were available.`,
                mood: "restless",
                checkInCompleted: true,
                cleanDay: false
              });
              break; // Since streak is reset to this day, stop checking further past dates
            }
          }

          currentDate.setUTCDate(currentDate.getUTCDate() + 1);
        }
      }
    } catch (e) {
      console.error("Error in syncUserStreakAndFreezes loop", e);
    }
  }
}

// Initialize AI Mentor SDK
let ai: GoogleGenAI | null = null;
const API_KEY = process.env.GEMINI_API_KEY;
if (API_KEY && API_KEY !== "MY_GEMINI_API_KEY") {
  try {
    ai = new GoogleGenAI({ apiKey: API_KEY });
    console.log("Gemini AI Mentor initialized successfully.");
  } catch (err) {
    console.error("Failed to initialize Gemini SDK:", err);
  }
} else {
  console.warn("GEMINI_API_KEY is not configured or uses placeholder value. AI Mentor will run in backup advisory mode.");
}

// ---------------- API ENDPOINTS ----------------

// Register API
app.post("/api/auth/register", (req, res) => {
  const { username, email, password, avatarUrl } = req.body;
  if (!username || !email || !password) {
    return res.status(400).json({ error: "Username, email, and password are required." });
  }

  const db = readDB();
  const lowerEmail = email.toLowerCase();

  // Check if email or username exists
  const emailExists = Object.values(db.users).some(u => u.email.toLowerCase() === lowerEmail);
  const usernameExists = Object.values(db.users).some(u => u.username.toLowerCase() === username.toLowerCase());

  if (emailExists) return res.status(400).json({ error: "Email is already registered." });
  if (usernameExists) return res.status(400).json({ error: "Username is already taken." });

  const userId = "user_" + Math.random().toString(36).substring(2, 11);
  const now = new Date().toISOString();

  const newUser = {
    id: userId,
    username,
    email,
    password, // Stored directly for mock auth simplicity in local workspace
    avatarUrl: avatarUrl || `https://api.dicebear.com/7.x/bottts/svg?seed=${username}`,
    streakStartDate: now,
    highestStreak: 0,
    totalXp: 100, // starting gift XP
    level: 1,
    title: "Seed of Will",
    joinedDate: now,
    equippedBadgeId: null,
    logs: [],
    triggers: [],
    statusMessage: "Committed to mental clarity and discipline.",
    streakFreezes: 1, // 1 welcoming freeze
    lastEarnedFreezeMonth: null
  };

  db.users[userId] = newUser;
  writeDB(db);

  // Return user without password
  const { password: _, ...userSafe } = newUser;
  res.status(201).json({ user: userSafe });
});

// Login API
app.post("/api/auth/login", (req, res) => {
  const { email, password } = req.body;
  if (!email || !password) {
    return res.status(400).json({ error: "Email and password are required." });
  }

  const db = readDB();
  const lowerEmail = email.toLowerCase();
  const user = Object.values(db.users).find(u => u.email.toLowerCase() === lowerEmail && u.password === password);

  if (!user) {
    return res.status(401).json({ error: "Invalid email or password." });
  }

  // Sync streak and freezes
  syncUserStreakAndFreezes(user);

  // Recalculate level & title based on dynamic current streak
  const currentStreak = getStreakDays(user.streakStartDate);
  const { level, title } = calculateLevelAndTitle(user.totalXp, currentStreak);
  user.level = level;
  user.title = title;
  
  if (currentStreak > user.highestStreak) {
    user.highestStreak = currentStreak;
  }
  db.users[user.id] = user;
  writeDB(db);

  const { password: _, ...userSafe } = user;
  res.json({ user: userSafe });
});

// --- GOOGLE OAUTH & SIGN-IN ENDPOINTS ---

// Construct Google OAuth URL
app.get("/api/auth/google/url", (req, res) => {
  const origin = req.headers.referer ? new URL(req.headers.referer).origin : `https://${req.headers.host}`;
  const redirectUri = `${origin}/auth/google/callback`;

  if (process.env.GOOGLE_CLIENT_ID && process.env.GOOGLE_CLIENT_ID !== "MY_GOOGLE_CLIENT_ID") {
    // Real Google OAuth authorize URL
    const params = new URLSearchParams({
      client_id: process.env.GOOGLE_CLIENT_ID,
      redirect_uri: redirectUri,
      response_type: "code",
      scope: "openid email profile",
      access_type: "offline",
      prompt: "consent"
    });
    res.json({ url: `https://accounts.google.com/o/oauth2/v2/auth?${params.toString()}`, real: true });
  } else {
    // Simulated Google OAuth authorization gateway
    res.json({ url: `/api/auth/google/simulate`, real: false });
  }
});

// Simulated Google Identity Selection Page (Self-contained static HTML served for preview popups)
app.get("/api/auth/google/simulate", (req, res) => {
  res.send(`
    <!DOCTYPE html>
    <html lang="en">
    <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>Google Identity Gateway - Simulation Mode</title>
      <style>
        body {
          margin: 0;
          padding: 0;
          background-color: #0A0A0B;
          color: #E5E5E5;
          font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
          display: flex;
          align-items: center;
          justify-content: center;
          min-height: 100vh;
        }
        .container {
          width: 100%;
          max-width: 420px;
          padding: 32px;
          background-color: #0F0F10;
          border: 1px border #1A1A1B;
          border-radius: 16px;
          box-shadow: 0 10px 30px rgba(0,0,0,0.5);
          text-align: center;
        }
        .logo {
          font-size: 24px;
          font-weight: 800;
          letter-spacing: -0.5px;
          margin-bottom: 24px;
          color: #F59E0B;
        }
        .logo span {
          color: #E5E5E5;
        }
        .warning-card {
          background-color: rgba(245, 158, 11, 0.05);
          border: 1px solid rgba(245, 158, 11, 0.15);
          border-radius: 12px;
          padding: 16px;
          margin-bottom: 24px;
          font-size: 13px;
          line-height: 1.5;
          color: #D97706;
          text-align: left;
        }
        .subtitle {
          font-size: 14px;
          color: #888888;
          margin-bottom: 20px;
        }
        .account-btn {
          display: flex;
          align-items: center;
          width: 100%;
          padding: 14px 16px;
          margin-bottom: 12px;
          background-color: #161618;
          border: 1px solid #262626;
          border-radius: 12px;
          color: #E5E5E5;
          cursor: pointer;
          transition: all 0.2s;
          text-align: left;
        }
        .account-btn:hover {
          border-color: #F59E0B;
          background-color: #1A1A1C;
        }
        .avatar {
          width: 36px;
          height: 36px;
          border-radius: 50%;
          background-color: #0A0A0B;
          margin-right: 12px;
          display: flex;
          align-items: center;
          justify-content: center;
          font-weight: bold;
          font-size: 14px;
          border: 1px solid #262626;
          color: #F59E0B;
        }
        .account-info {
          flex: 1;
        }
        .name {
          font-size: 14px;
          font-weight: bold;
        }
        .email {
          font-size: 11px;
          color: #888888;
          margin-top: 2px;
        }
        .custom-form {
          margin-top: 24px;
          padding-top: 20px;
          border-t: 1px solid #1A1A1B;
          text-align: left;
        }
        .form-label {
          display: block;
          font-size: 11px;
          font-weight: bold;
          color: #888888;
          text-transform: uppercase;
          letter-spacing: 0.5px;
          margin-bottom: 8px;
        }
        .input-group {
          display: flex;
          gap: 8px;
        }
        input {
          flex: 1;
          background-color: #0A0A0B;
          border: 1px solid #1A1A1B;
          border-radius: 10px;
          color: #E5E5E5;
          padding: 10px 12px;
          font-size: 13px;
          outline: none;
        }
        input:focus {
          border-color: #F59E0B;
        }
        .submit-btn {
          background-color: #F59E0B;
          color: #0A0A0B;
          border: none;
          border-radius: 10px;
          padding: 10px 16px;
          font-size: 13px;
          font-weight: bold;
          cursor: pointer;
          transition: background-color 0.2s;
        }
        .submit-btn:hover {
          background-color: #D97706;
        }
      </style>
    </head>
    <body>
      <div class="container">
        <div class="logo">Google<span> Sign-In</span></div>
        <div class="subtitle">Choose an account to authorize Sanctuary Access</div>
        
        <div class="warning-card">
          <strong>Simulation Mode Activated:</strong> Production Google OAuth handles credentials via process.env.GOOGLE_CLIENT_ID. Since it is not configured in secrets, we've initiated a secure, simulated OAuth handshake that performs the same <code>postMessage</code> event flow.
        </div>

        <button class="account-btn" onclick="selectAccount('maxilovepigs@gmail.com', 'Maxi')">
          <div class="avatar">M</div>
          <div class="account-info">
            <div class="name">Maxi</div>
            <div class="email">maxilovepigs@gmail.com</div>
          </div>
        </button>

        <button class="account-btn" onclick="selectAccount('seeker.purity@gmail.com', 'Sovereign_Seeker')">
          <div class="avatar">S</div>
          <div class="account-info">
            <div class="name">Sovereign Seeker</div>
            <div class="email">seeker.purity@gmail.com</div>
          </div>
        </button>

        <button class="account-btn" onclick="selectAccount('marcus.aurelius@rome.it', 'Marcus_Aurelius')">
          <div class="avatar">A</div>
          <div class="account-info">
            <div class="name">Marcus Aurelius</div>
            <div class="email">marcus.aurelius@rome.it</div>
          </div>
        </button>

        <div class="custom-form">
          <span class="form-label">Or use custom identity</span>
          <div class="input-group">
            <input type="email" id="custom-email" placeholder="enter.any.email@domain.com" required>
            <button class="submit-btn" onclick="submitCustom()">Authorise</button>
          </div>
        </div>
      </div>

      <script>
        function selectAccount(email, name) {
          window.location.href = '/auth/google/callback?code=sim_code&email=' + encodeURIComponent(email) + '&name=' + encodeURIComponent(name);
        }

        function submitCustom() {
          var email = document.getElementById('custom-email').value;
          if (!email || !email.includes('@')) {
            alert('Please enter a valid email address');
            return;
          }
          var name = email.split('@')[0];
          selectAccount(email, name);
        }
      </script>
    </body>
    </html>
  `);
});

// Google OAuth Redirect Callback Handler
app.get(["/auth/google/callback", "/auth/google/callback/"], async (req, res) => {
  const { code, email: queryEmail, name: queryName } = req.query;

  let email = queryEmail ? String(queryEmail) : null;
  let name = queryName ? String(queryName) : null;

  const origin = req.headers.referer ? new URL(req.headers.referer).origin : `https://${req.headers.host}`;
  const redirectUri = `${origin}/auth/google/callback`;

  // 1. If it's a real Google OAuth login, fetch the profile
  if (process.env.GOOGLE_CLIENT_ID && process.env.GOOGLE_CLIENT_ID !== "MY_GOOGLE_CLIENT_ID" && code && code !== "sim_code") {
    try {
      const tokenResponse = await fetch("https://oauth2.googleapis.com/token", {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: new URLSearchParams({
          code: String(code),
          client_id: process.env.GOOGLE_CLIENT_ID,
          client_secret: process.env.GOOGLE_CLIENT_SECRET || "",
          redirect_uri: redirectUri,
          grant_type: "authorization_code"
        })
      });

      if (!tokenResponse.ok) {
        throw new Error("Failed to exchange authorization code for tokens");
      }

      const tokenData = await tokenResponse.json();
      const profileResponse = await fetch("https://www.googleapis.com/oauth2/v3/userinfo", {
        headers: { Authorization: `Bearer ${tokenData.access_token}` }
      });

      if (profileResponse.ok) {
        const profile = await profileResponse.json();
        email = profile.email;
        name = profile.name || profile.given_name || email!.split("@")[0];
      }
    } catch (err) {
      console.error("Real Google OAuth Error:", err);
      return res.status(500).send("<h3>Google Authorization Failed. Please try again or use local authentication.</h3>");
    }
  }

  // 2. Validate we retrieved an email
  if (!email) {
    return res.status(400).send("<h3>Failed to retrieve Google identity. Please try again.</h3>");
  }

  const db = readDB();
  const lowerEmail = email.toLowerCase();
  
  // Find or create user
  let user = Object.values(db.users).find(u => u.email.toLowerCase() === lowerEmail);

  if (!user) {
    const userId = "user_" + Math.random().toString(36).substring(2, 11);
    const now = new Date().toISOString();
    const cleanUsername = (name || email.split("@")[0]).replace(/[^a-zA-Z0-9_]/g, "_");

    user = {
      id: userId,
      username: cleanUsername,
      email: email,
      password: "google_oauth_authorized_" + Math.random().toString(36).substring(2, 11), // secure random placeholder
      avatarUrl: `https://api.dicebear.com/7.x/bottts/svg?seed=${cleanUsername}`,
      streakStartDate: now,
      highestStreak: 0,
      totalXp: 100, // starting gift XP
      level: 1,
      title: "Seed of Will",
      joinedDate: now,
      equippedBadgeId: null,
      logs: [],
      triggers: [],
      statusMessage: "Aligned mind and spirit via Google.",
      streakFreezes: 1, // 1 welcoming freeze
      lastEarnedFreezeMonth: null
    };

    db.users[userId] = user;
    writeDB(db);
  }

  // Sync user status
  syncUserStreakAndFreezes(user);
  const currentStreak = getStreakDays(user.streakStartDate);
  const { level, title } = calculateLevelAndTitle(user.totalXp, currentStreak);
  user.level = level;
  user.title = title;
  
  if (currentStreak > user.highestStreak) {
    user.highestStreak = currentStreak;
  }
  db.users[user.id] = user;
  writeDB(db);

  const { password: _, ...userSafe } = user;

  // 3. Serve self-closing HTML callback that notifies parent app window via postMessage
  res.send(`
    <!DOCTYPE html>
    <html lang="en">
    <head>
      <meta charset="UTF-8">
      <title>Sanctuary Handshake complete</title>
      <style>
        body {
          background-color: #0A0A0B;
          color: #E5E5E5;
          font-family: sans-serif;
          display: flex;
          flex-direction: column;
          align-items: center;
          justify-content: center;
          height: 100vh;
          margin: 0;
          text-align: center;
        }
        .spinner {
          border: 4px solid rgba(245,158,11,0.1);
          border-left-color: #F59E0B;
          border-radius: 50%;
          width: 36px;
          height: 36px;
          animation: spin 1s linear infinite;
          margin-bottom: 20px;
        }
        @keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }
      </style>
    </head>
    <body>
      <div class="spinner"></div>
      <h3>Handshake Complete</h3>
      <p style="color: #888888; font-size: 13px;">Sanctuary is syncing your profile. This window will close automatically.</p>
      
      <script>
        try {
          if (window.opener) {
            window.opener.postMessage({ 
              type: 'OAUTH_AUTH_SUCCESS', 
              user: ${JSON.stringify(userSafe)} 
            }, '*');
            window.close();
          } else {
            window.location.href = '/';
          }
        } catch (err) {
          console.error("PostMessage failed:", err);
          window.location.href = '/';
        }
      </script>
    </body>
    </html>
  `);
});


// --- PASSWORD RESET ENDPOINTS ---

// Request password reset (Forgot password)
app.post("/api/auth/forgot-password", (req, res) => {
  const { email } = req.body;
  if (!email) {
    return res.status(400).json({ error: "Email is required to dispatch recovery shield." });
  }

  const db = readDB();
  const lowerEmail = email.toLowerCase();
  const user = Object.values(db.users).find(u => u.email.toLowerCase() === lowerEmail);

  if (!user) {
    return res.status(404).json({ error: "This email is not registered in the Sanctuary archives." });
  }

  // Generate 6-digit random code
  const resetCode = Math.floor(100000 + Math.random() * 900000).toString();
  const resetExpiry = new Date(Date.now() + 15 * 60 * 1000).toISOString(); // 15 mins expiry

  user.resetCode = resetCode;
  user.resetExpiry = resetExpiry;

  db.users[user.id] = user;
  writeDB(db);

  console.log(`[SECURITY DISPATCH] Password reset code for ${email} is: ${resetCode}`);

  // Return the code directly in developer simulation mode so they can test easily without SMTP
  res.json({ 
    success: true, 
    code: resetCode,
    message: "A recovery code has been generated and dispatched securely. For testing convenience, the code is returned here." 
  });
});

// Verify reset code and update password
app.post("/api/auth/reset-password", (req, res) => {
  const { email, code, newPassword } = req.body;
  if (!email || !code || !newPassword) {
    return res.status(400).json({ error: "Email, verification code, and new password are required." });
  }

  const db = readDB();
  const lowerEmail = email.toLowerCase();
  const user = Object.values(db.users).find(u => u.email.toLowerCase() === lowerEmail);

  if (!user) {
    return res.status(404).json({ error: "This email is not registered." });
  }

  if (!user.resetCode || user.resetCode !== code) {
    return res.status(400).json({ error: "Invalid verification code. The defense system rejects this attempt." });
  }

  if (user.resetExpiry && new Date() > new Date(user.resetExpiry)) {
    return res.status(400).json({ error: "The verification code has expired. Please dispatch a new one." });
  }

  // Update password and clear reset data
  user.password = newPassword;
  delete user.resetCode;
  delete user.resetExpiry;

  db.users[user.id] = user;
  writeDB(db);

  res.json({ success: true, message: "Your cognitive protection shield has been re-keyed successfully! Please log in with your new credentials." });
});

// Get profile
app.get("/api/user/:userId", (req, res) => {
  const { userId } = req.params;
  const db = readDB();
  const user = db.users[userId];
  if (!user) {
    return res.status(404).json({ error: "User not found." });
  }

  // Sync streak and freezes
  syncUserStreakAndFreezes(user);

  // Sync and recalculate streak
  const currentStreak = getStreakDays(user.streakStartDate);
  const { level, title } = calculateLevelAndTitle(user.totalXp, currentStreak);
  user.level = level;
  user.title = title;
  if (currentStreak > user.highestStreak) {
    user.highestStreak = currentStreak;
  }
  db.users[userId] = user;
  writeDB(db);

  const { password: _, ...userSafe } = user;
  res.json(userSafe);
});

// Update streak status (e.g. Relapse vs. Start New)
app.post("/api/user/:userId/streak", (req, res) => {
  const { userId } = req.params;
  const { action, note, triggerType, relapseMood } = req.body; // action: "relapse" | "start"
  const db = readDB();
  const user = db.users[userId];
  if (!user) return res.status(404).json({ error: "User not found." });

  // Sync streak and freezes
  syncUserStreakAndFreezes(user);

  const now = new Date().toISOString();

  if (action === "relapse") {
    // Record current streak before wiping it
    const completedStreak = getStreakDays(user.streakStartDate);
    
    // Add journal log reflecting on the relapse to foster self-compassion & CBT learning
    const journalId = "journal_" + Math.random().toString(36).substring(2, 11);
    const logEntry = {
      id: journalId,
      userId,
      date: new Date().toISOString().split("T")[0],
      note: note || `Streak of ${completedStreak} days ended. Reflecting and rebuilding.`,
      mood: relapseMood || "restless",
      checkInCompleted: true,
      cleanDay: false
    };

    user.logs.push(logEntry);
    
    // Track triggers if supplied
    if (triggerType) {
      const triggerId = "trig_" + Math.random().toString(36).substring(2, 11);
      user.triggers.push({
        id: triggerId,
        userId,
        date: now,
        intensity: 8,
        type: triggerType,
        mitigationStrategy: "Reflected in log. Aiming to remove trigger environment next time."
      });
    }

    user.streakStartDate = now; // instantly start a new streak. Purity starts NOW.
    user.statusMessage = "Rising stronger. Purity starts again today.";
  } else if (action === "start") {
    user.streakStartDate = now;
    user.statusMessage = "Commencing purity quest. Day 1 is today.";
  }

  const currentStreak = getStreakDays(user.streakStartDate);
  const { level, title } = calculateLevelAndTitle(user.totalXp, currentStreak);
  user.level = level;
  user.title = title;

  db.users[userId] = user;
  writeDB(db);

  const { password: _, ...userSafe } = user;
  res.json(userSafe);
});

// Log Check-in (Daily journal)
app.post("/api/user/:userId/checkin", (req, res) => {
  const { userId } = req.params;
  const { note, mood, cleanDay } = req.body;
  const db = readDB();
  const user = db.users[userId];
  if (!user) return res.status(404).json({ error: "User not found." });

  // Sync streak and freezes
  syncUserStreakAndFreezes(user);

  const dateStr = new Date().toISOString().split("T")[0];

  // Prevent multiple checkins giving duplicate XP on the same day
  const alreadyCheckedIn = user.logs.some((l: any) => l.date === dateStr && l.cleanDay === cleanDay);
  let xpGained = 0;

  const journalId = "journal_" + Math.random().toString(36).substring(2, 11);
  const logEntry = {
    id: journalId,
    userId,
    date: dateStr,
    note: note || "Maintained daily purity checklist.",
    mood: mood || "focused",
    checkInCompleted: true,
    cleanDay: cleanDay !== false
  };

  user.logs.push(logEntry);

  if (!alreadyCheckedIn) {
    xpGained = cleanDay ? 50 : 15; // 50 XP for daily clean check-in, 15 for reflection
    user.totalXp += xpGained;
  }

  const currentStreak = getStreakDays(user.streakStartDate);
  const { level, title } = calculateLevelAndTitle(user.totalXp, currentStreak);
  user.level = level;
  user.title = title;

  if (currentStreak > user.highestStreak) {
    user.highestStreak = currentStreak;
  }

  db.users[userId] = user;
  writeDB(db);

  const { password: _, ...userSafe } = user;
  res.json({ user: userSafe, xpGained });
});

// Log trigger event
app.post("/api/user/:userId/trigger", (req, res) => {
  const { userId } = req.params;
  const { intensity, type, mitigationStrategy } = req.body;
  const db = readDB();
  const user = db.users[userId];
  if (!user) return res.status(404).json({ error: "User not found." });

  const triggerId = "trig_" + Math.random().toString(36).substring(2, 11);
  const triggerLog = {
    id: triggerId,
    userId,
    date: new Date().toISOString(),
    intensity: Number(intensity) || 5,
    type: type || "Boredom",
    mitigationStrategy: mitigationStrategy || "Practiced mindful urge surfing."
  };

  user.triggers.push(triggerLog);
  const xpGained = 25; // 25 XP for logging a conscious trigger mitigation!
  user.totalXp += xpGained;

  const currentStreak = getStreakDays(user.streakStartDate);
  const { level, title } = calculateLevelAndTitle(user.totalXp, currentStreak);
  user.level = level;
  user.title = title;

  db.users[userId] = user;
  writeDB(db);

  const { password: _, ...userSafe } = user;
  res.json({ user: userSafe, xpGained });
});

// Reward XP for Urge Surfing Room Complete
app.post("/api/user/:userId/urgesurfed", (req, res) => {
  const { userId } = req.params;
  const db = readDB();
  const user = db.users[userId];
  if (!user) return res.status(404).json({ error: "User not found." });

  const xpGained = 50; // 50 XP for completing full SOS rescue box breathing or grounding sequence
  user.totalXp += xpGained;

  const currentStreak = getStreakDays(user.streakStartDate);
  const { level, title } = calculateLevelAndTitle(user.totalXp, currentStreak);
  user.level = level;
  user.title = title;

  db.users[userId] = user;
  writeDB(db);

  const { password: _, ...userSafe } = user;
  res.json({ user: userSafe, xpGained });
});

// Update status message
app.post("/api/user/:userId/status", (req, res) => {
  const { userId } = req.params;
  const { statusMessage } = req.body;
  const db = readDB();
  const user = db.users[userId];
  if (!user) return res.status(404).json({ error: "User not found." });

  user.statusMessage = statusMessage || "";
  db.users[userId] = user;
  writeDB(db);

  const { password: _, ...userSafe } = user;
  res.json(userSafe);
});

// Update equipped cosmetic badge
app.post("/api/user/:userId/badge", (req, res) => {
  const { userId } = req.params;
  const { badgeId } = req.body;
  const db = readDB();
  const user = db.users[userId];
  if (!user) return res.status(404).json({ error: "User not found." });

  user.equippedBadgeId = badgeId || null;
  db.users[userId] = user;
  writeDB(db);

  const { password: _, ...userSafe } = user;
  res.json(userSafe);
});

// Update comprehensive user settings
app.post("/api/user/:userId/settings", (req, res) => {
  const { userId } = req.params;
  const { username, statusMessage, avatarUrl, bannerColor, customStatus, socialLink } = req.body;
  const db = readDB();
  const user = db.users[userId];
  if (!user) return res.status(404).json({ error: "User not found." });

  // Check username uniqueness if it's being changed
  if (username && username !== user.username) {
    const cleanUsername = username.replace(/[^a-zA-Z0-9_]/g, "_");
    if (!cleanUsername) {
      return res.status(400).json({ error: "Invalid username format." });
    }
    const usernameTaken = Object.values(db.users).some(u => u.id !== userId && u.username.toLowerCase() === cleanUsername.toLowerCase());
    if (usernameTaken) {
      return res.status(400).json({ error: "Username is already claimed by another warrior." });
    }
    user.username = cleanUsername;
  }

  if (statusMessage !== undefined) user.statusMessage = statusMessage;
  if (avatarUrl !== undefined) user.avatarUrl = avatarUrl;
  if (bannerColor !== undefined) user.bannerColor = bannerColor;
  if (customStatus !== undefined) user.customStatus = customStatus;
  if (socialLink !== undefined) user.socialLink = socialLink;

  db.users[userId] = user;
  writeDB(db);

  const { password: _, ...userSafe } = user;
  res.json(userSafe);
});

// Change Password securely for authenticated sessions
app.post("/api/user/:userId/change-password", (req, res) => {
  const { userId } = req.params;
  const { currentPassword, newPassword } = req.body;
  const db = readDB();
  const user = db.users[userId];
  if (!user) return res.status(404).json({ error: "User not found." });

  // If user signed up with Google and has no current local password, or if they provided correct current password
  if (user.password && !user.password.startsWith("google_oauth_authorized_") && user.password !== currentPassword) {
    return res.status(400).json({ error: "Current password does not match our archives." });
  }

  user.password = newPassword;
  db.users[userId] = user;
  writeDB(db);

  res.json({ success: true, message: "Password updated successfully!" });
});

// Export all user data
app.get("/api/user/:userId/export", (req, res) => {
  const { userId } = req.params;
  const db = readDB();
  const user = db.users[userId];
  if (!user) return res.status(404).json({ error: "User not found." });

  const { password: _, ...userSafe } = user;
  res.json({
    exportedAt: new Date().toISOString(),
    user: userSafe,
    schemaVersion: "2.5",
    disclaimer: "This data export contains all journal entries, triggers, and configurations stored in the Sovereign Mind Sanctuary."
  });
});

// Delete user account
app.delete("/api/user/:userId/delete", (req, res) => {
  const { userId } = req.params;
  const db = readDB();
  if (!db.users[userId]) {
    return res.status(404).json({ error: "User not found." });
  }

  delete db.users[userId];
  writeDB(db);

  res.json({ success: true, message: "Your soul has been freed from the Sanctuary files. All records permanently deleted." });
});

// Retrieve dynamic leaderboard
app.get("/api/leaderboard", (req, res) => {
  const db = readDB();
  
  // Collect actual registered users, calculate current streak and titles
  const realUsersList = Object.values(db.users).map(user => {
    syncUserStreakAndFreezes(user);
    const currentStreak = getStreakDays(user.streakStartDate);
    const { level, title } = calculateLevelAndTitle(user.totalXp, currentStreak);
    return {
      id: user.id,
      username: user.username,
      avatarUrl: user.avatarUrl,
      currentStreak,
      highestStreak: Math.max(user.highestStreak || 0, currentStreak),
      level,
      title,
      isRealUser: true,
      equippedBadgeId: user.equippedBadgeId || null,
      statusMessage: user.statusMessage || "On the path of self-mastery."
    };
  });

  writeDB(db);

  // Combine real users and seed users
  const combined = [...realUsersList, ...DEFAULT_LEADERBOARD];

  // Sort by current streak descending, then level descending
  combined.sort((a, b) => {
    if (b.currentStreak !== a.currentStreak) {
      return b.currentStreak - a.currentStreak;
    }
    return b.level - a.level;
  });

  // Attach ranks
  const ranked = combined.map((entry, idx) => ({
    ...entry,
    rank: idx + 1
  }));

  res.json(ranked);
});

// AI Purity Mentor Chat proxy with Gemini
app.post("/api/mentor", async (req, res) => {
  const { messages, userProfile } = req.body;
  if (!messages || !Array.isArray(messages)) {
    return res.status(400).json({ error: "Messages array is required." });
  }

  // Fallback mode if Gemini is missing API keys
  if (!ai) {
    const lastUserMsg = messages[messages.length - 1]?.text || "";
    let mockReply = "I am here to support you in your journey towards purity and self-discipline. Remember, urges are temporary waves. Take five deep breaths and remind yourself why you started. Every second you choose purity, you are rewiring your brain's dopamine pathways for long-term power and clarity.";
    
    const lower = lastUserMsg.toLowerCase();
    if (lower.includes("relapse") || lower.includes("failed") || lower.includes("reset")) {
      mockReply = "Please do not be discouraged. A relapse is not a return to zero; it is a single stumble on a long path. What matters is how you rise. Be compassionate with yourself, learn what triggered the urge (loneliness, boredom, stress, or late-night scrolling?), and take a cold shower or step outside. You are a warrior in training.";
    } else if (lower.includes("urge") || lower.includes("tempted") || lower.includes("horny") || lower.includes("lust")) {
      mockReply = "An urge is an intense, chemical signal, but it has no power over your muscles. It peaks in 2-3 minutes and then recedes. Enter the Urge SOS Box Breathing room immediately, or do 20 pushups right now. Let's conquer this together! You are stronger than any temporary dopamine itch.";
    } else if (lower.includes("why") || lower.includes("benefit") || lower.includes("science")) {
      mockReply = "Quitting lust unlocks immense neural benefits: 1. Dopamine receptors upregulate, restoring pleasure in simple daily activities. 2. Your prefrontal cortex (the brain's seat of willpower and planning) thickens and takes back command. 3. Brain fog lifts, replacing guilt and anxiety with natural focus, high testosterone-utilization, and pure energy. You are recovering your sovereign self.";
    }

    // Delay response slightly to simulate thinking
    await new Promise(resolve => setTimeout(resolve, 1000));
    return res.json({ text: mockReply });
  }

  try {
    // Format conversation history for Gemini
    // We will provide a rich therapeutic System Instruction focusing on CBT, recovery science, strength, and grace.
    const systemPrompt = `You are the "Purity Mentor," an expert cognitive-behavioral coach, neural recovery specialist, and compassionate guide helping the user break free from compulsive sexual behavior, lust, porn addiction, and unhelpful sexual triggers.

Key Guidelines:
1. **Compassionate & Empowering Tone**: Adopt a warm, objective, encouraging, and deeply respectful stance. Never scold, shame, or guilt-trip. View slip-ups/relapses as valuable educational data to analyze triggers, not moral failures.
2. **Cognitive Restructuring**: Teach the user to identify cognitive distortions (e.g., "I can't take this," "Just one look won't hurt," "I've already ruined my streak so I might as well go all out"). Guide them to dispute these thoughts.
3. **Behavioral Interventions (Urge Surfing)**: Teach "Urge Surfing"—observing the physical urge like a wave without acting on it. Suggest quick, actionable, immediate resets (e.g., box breathing, cold splash, physical change of posture or space, deleting app triggers).
4. **Science of Rewiring**: Use terms of neural recovery (neuroplasticity, dopamine receptor healing, prefrontal cortex thickening) to inspire and justify the physical and mental effort of restraint.
5. **Human and Humble**: Speak as a noble, down-to-earth mentor. No AI-slop corporate warnings, no mechanical lists. Keep responses focused, readable, and under 250 words to avoid cognitive overload.

User Context:
- Username: ${userProfile?.username || "Warrior"}
- Current Streak: ${userProfile?.currentStreak || 0} days
- Level: ${userProfile?.level || 1} (${userProfile?.title || "Seed of Will"})
- Highest Streak: ${userProfile?.highestStreak || 0} days
`;

    // Map conversation array to Gemini content types
    const contents = messages.map((m: any) => ({
      role: m.sender === "user" ? "user" : "model",
      parts: [{ text: m.text }]
    }));

    // Generate content using the new @google/genai SDK format
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents,
      config: {
        systemInstruction: systemPrompt,
        temperature: 0.7,
        maxOutputTokens: 500,
      }
    });

    const replyText = response.text || "I am right beside you on this quest. Focus on the present breath.";
    res.json({ text: replyText });
  } catch (err: any) {
    console.error("Gemini API Error:", err);
    res.status(500).json({ error: "The AI Mentor is temporarily reflecting. Please try again shortly." });
  }
});

// ---------------- PHILOSOPHY QUOTE OF THE DAY ENDPOINT ----------------

const FALLBACK_PHILOSOPHY_QUOTES = [
  {
    quote: "The happiness of your life depends upon the quality of your thoughts.",
    author: "Marcus Aurelius",
    school: "Stoicism",
    commentary: "Your mind is your ultimate sanctuary. When urges arise, recognize them as mere chemical signals, and choose to focus your thoughts on your higher goals and inner strength."
  },
  {
    quote: "No man is free who is not master of himself.",
    author: "Epictetus",
    school: "Stoicism",
    commentary: "True liberty is not the license to follow every fleeting physical desire, but the sovereignty to veto impulses that undermine your character and spirit."
  },
  {
    quote: "We suffer more often in imagination than in reality.",
    author: "Seneca",
    school: "Stoicism",
    commentary: "An urge can feel like an unbearable storm in your thoughts, but in reality, it is just a passing sensation. Surf the wave; it has no physical power over you."
  },
  {
    quote: "He who conquers others is strong; he who conquers himself is mighty.",
    author: "Lao Tzu",
    school: "Taoism",
    commentary: "The greatest battle is always internal. Restraining yourself from immediate gratification is a sign of ultimate personal power and mastery."
  },
  {
    quote: "He who has a why to live can bear almost any how.",
    author: "Friedrich Nietzsche",
    school: "Existentialism",
    commentary: "Connect deeply with your purpose—whether it is clear cognitive focus, self-respect, or pure energy. A strong 'why' makes any urge easy to overcome."
  },
  {
    quote: "You have power over your mind - not outside events. Realize this, and you will find strength.",
    author: "Marcus Aurelius",
    school: "Stoicism",
    commentary: "Triggers will always exist in the digital world. You cannot control what appears, but you have absolute power over how you respond. Reclaim your focus."
  }
];

app.get("/api/philosophy/daily", async (req, res) => {
  const db = readDB();
  const todayStr = new Date().toISOString().split("T")[0];
  const { regen } = req.query;

  // If we already have a valid quote for today, return it
  if (db.dailyQuote && db.dailyQuote.date === todayStr && regen !== "true") {
    return res.json(db.dailyQuote);
  }

  // Otherwise, we need to generate a new one!
  let selectedQuote;

  if (ai) {
    try {
      const prompt = `Generate a profound and motivating philosophical quote about self-mastery, discipline, self-command, or overcoming temptations.
The quote should be from a classic philosopher (Stoic, Taoist, Buddhist, Existentialist, etc.).
Provide a short, practical, modern cognitive-behavioral (CBT) or mindfulness-based commentary (max 50 words) on how this quote helps a person overcome compulsive desires or triggers.

Return the response in JSON format matching this schema:
{
  "quote": "The quote text",
  "author": "Philosopher's name",
  "school": "The philosophical school or philosophy type",
  "commentary": "Actionable, helpful modern CBT commentary for self-control"
}`;

      const response = await ai.models.generateContent({
        model: "gemini-3.5-flash",
        contents: [{ role: "user", parts: [{ text: prompt }] }],
        config: {
          responseMimeType: "application/json",
          temperature: 0.8,
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              quote: { type: Type.STRING },
              author: { type: Type.STRING },
              school: { type: Type.STRING },
              commentary: { type: Type.STRING }
            },
            required: ["quote", "author", "school", "commentary"]
          }
        }
      });

      if (response.text) {
        const parsed = JSON.parse(response.text.trim());
        selectedQuote = {
          date: todayStr,
          quote: parsed.quote || "",
          author: parsed.author || "Unknown Sage",
          school: parsed.school || "Philosophy",
          commentary: parsed.commentary || ""
        };
      }
    } catch (err) {
      console.error("Failed to generate daily philosophy quote via Gemini:", err);
    }
  }

  // Fallback to local list if Gemini failed or is not configured
  if (!selectedQuote) {
    const randomIdx = Math.floor(Math.random() * FALLBACK_PHILOSOPHY_QUOTES.length);
    const fallback = FALLBACK_PHILOSOPHY_QUOTES[randomIdx];
    selectedQuote = {
      date: todayStr,
      ...fallback
    };
  }

  // Save the selected daily quote to database so all requests on this day share the same quote
  db.dailyQuote = selectedQuote;
  writeDB(db);

  res.json(selectedQuote);
});

// ---------------- GLOBAL CHAT ENDPOINTS ----------------

app.get("/api/chat", (req, res) => {
  const db = readDB();
  res.json(db.chatMessages || []);
});

app.post("/api/chat", (req, res) => {
  const { userId, username, avatarUrl, text, level, title } = req.body;
  if (!text || !text.trim()) {
    return res.status(400).json({ error: "Message text is required." });
  }

  const db = readDB();
  const newMessage = {
    id: "chat_" + Math.random().toString(36).substring(2, 11),
    userId: userId || "guest",
    username: username || "Guest Warrior",
    avatarUrl: avatarUrl || `https://api.dicebear.com/7.x/bottts/svg?seed=Guest_${Math.random()}`,
    text: text.trim(),
    timestamp: new Date().toISOString(),
    level: level || 1,
    title: title || "Seed of Will"
  };

  db.chatMessages = db.chatMessages || [];
  db.chatMessages.push(newMessage);
  
  if (db.chatMessages.length > 150) {
    db.chatMessages.shift();
  }

  writeDB(db);
  res.status(201).json(newMessage);
});

// ---------------- TRACKING / BUDDY SYSTEM ENDPOINTS ----------------

app.post("/api/user/:userId/follow", (req, res) => {
  const { userId } = req.params;
  const { targetUsername, targetUserId } = req.body;
  
  const db = readDB();
  const user = db.users[userId];
  if (!user) return res.status(404).json({ error: "User not found." });

  let targetUser = null;
  if (targetUserId) {
    targetUser = db.users[targetUserId];
  } else if (targetUsername) {
    targetUser = Object.values(db.users).find(
      u => u.username.toLowerCase() === targetUsername.trim().toLowerCase()
    );
  }

  if (!targetUser) {
    return res.status(404).json({ error: "Target warrior not found." });
  }

  if (targetUser.id === userId) {
    return res.status(400).json({ error: "You cannot track yourself." });
  }

  user.following = user.following || [];
  if (!user.following.includes(targetUser.id)) {
    user.following.push(targetUser.id);
  }

  db.users[userId] = user;
  writeDB(db);

  const { password: _, ...userSafe } = user;
  res.json(userSafe);
});

app.post("/api/user/:userId/unfollow", (req, res) => {
  const { userId } = req.params;
  const { targetUserId } = req.body;

  const db = readDB();
  const user = db.users[userId];
  if (!user) return res.status(404).json({ error: "User not found." });

  user.following = user.following || [];
  user.following = user.following.filter((id: string) => id !== targetUserId);

  db.users[userId] = user;
  writeDB(db);

  const { password: _, ...userSafe } = user;
  res.json(userSafe);
});

app.get("/api/user/:userId/following", (req, res) => {
  const { userId } = req.params;
  const db = readDB();
  const user = db.users[userId];
  if (!user) return res.status(404).json({ error: "User not found." });

  user.following = user.following || [];
  const profiles = user.following.map((id: string) => {
    const u = db.users[id];
    if (!u) return null;
    const currentStreak = getStreakDays(u.streakStartDate);
    const { level, title } = calculateLevelAndTitle(u.totalXp, currentStreak);
    return {
      id: u.id,
      username: u.username,
      avatarUrl: u.avatarUrl,
      currentStreak,
      highestStreak: Math.max(u.highestStreak || 0, currentStreak),
      level,
      title,
      statusMessage: u.statusMessage || "On the path of self-mastery."
    };
  }).filter(Boolean);

  res.json(profiles);
});

// ---------------- SUPPORT TICKET ENDPOINTS ----------------

app.get("/api/support/tickets", (req, res) => {
  const { userId, username } = req.query;
  const db = readDB();
  const tickets = db.supportTickets || [];

  if (username === "ollymckee101") {
    return res.json(tickets);
  }

  if (!userId) {
    return res.json([]);
  }

  const userTickets = tickets.filter((t: any) => t.userId === userId);
  res.json(userTickets);
});

app.post("/api/support/tickets", async (req, res) => {
  const { userId, username, avatarUrl, title, type, initialMessage } = req.body;
  if (!title || !title.trim() || !initialMessage || !initialMessage.trim()) {
    return res.status(400).json({ error: "Title and initial message are required." });
  }

  const db = readDB();
  const ticketId = "ticket_" + Math.random().toString(36).substring(2, 11);
  const now = new Date().toISOString();

  const initialMsgObj = {
    id: "msg_" + Math.random().toString(36).substring(2, 11),
    sender: "user" as "user" | "ai" | "mod",
    senderName: username || "Guest Warrior",
    text: initialMessage.trim(),
    createdAt: now
  };

  const newTicket = {
    id: ticketId,
    userId: userId || "guest",
    username: username || "Guest Warrior",
    avatarUrl: avatarUrl || `https://api.dicebear.com/7.x/bottts/svg?seed=Guest_${Math.random()}`,
    title: title.trim(),
    status: "open" as "open" | "resolved",
    type: (type === "ai" ? "ai" : "real") as "ai" | "real",
    messages: [initialMsgObj],
    createdAt: now
  };

  db.supportTickets = db.supportTickets || [];
  db.supportTickets.push(newTicket);

  if (type === "ai") {
    let aiResponseText = "Greetings. I am your Sanctuary Support AI. How can I help you? I can answer technical questions about your sobriety clock, levels, box breathing, and logbook features.";
    
    if (ai) {
      try {
        const prompt = `You are the "Sanctuary App Support Bot". Help the user with their technical, app-related, or structural support issue. 
User's issue title: "${title}"
User's initial support message: "${initialMessage}"

Keep your response helpful, clinical, technical, under 150 words, and focused on using the Sanctuary application (e.g., sobriety clocks, levels, tracking daily checklist, logging triggers, or using SOS box breathing). Avoid discussing personal feelings here (direct them to AI Purity Mentor for therapeutic chats).`;
        
        const response = await ai.models.generateContent({
          model: "gemini-2.5-flash",
          contents: [{ role: "user", parts: [{ text: prompt }] }],
          config: {
            temperature: 0.5,
            maxOutputTokens: 300,
          }
        });
        aiResponseText = response.text || aiResponseText;
      } catch (err) {
        console.error("AI Support Error:", err);
      }
    } else {
      const msgLower = initialMessage.toLowerCase();
      if (msgLower.includes("clock") || msgLower.includes("timer") || msgLower.includes("streak")) {
        aiResponseText = "Your sobriety chronometer runs in real-time. It computes streak duration from your selected streak start date. When you record a relapse, it records the history in your CBT Logbook and starts a fresh clock instantly. Check-ins gain you levels and titles!";
      } else if (msgLower.includes("checklist") || msgLower.includes("xp") || msgLower.includes("level")) {
        aiResponseText = "Each completed daily checklist item rewards +10 XP. Daily check-ins reward +50 XP, and logging conscious trigger mitigations rewards +25 XP. Every 200 XP increases your level! Your title scales automatically based on your streak days.";
      } else if (msgLower.includes("sos") || msgLower.includes("breathing") || msgLower.includes("breath")) {
        aiResponseText = "The Urge SOS Room is your defense system. It includes: 1. Mindful Grounding. 2. A 5-minute Box Breathing interface. 3. Physical Sublimation exercises. Completing a full sequence rewards +50 XP and helps discharge temporary neural craving loops.";
      }
    }

    newTicket.messages.push({
      id: "msg_" + Math.random().toString(36).substring(2, 11),
      sender: "ai" as const,
      senderName: "Sanctuary Support AI",
      text: aiResponseText,
      createdAt: new Date().toISOString()
    });
  }

  writeDB(db);
  res.status(201).json(newTicket);
});

app.post("/api/support/tickets/:ticketId/messages", async (req, res) => {
  const { ticketId } = req.params;
  const { userId, username, text } = req.body;
  if (!text || !text.trim()) {
    return res.status(400).json({ error: "Message text is required." });
  }

  const db = readDB();
  const ticket = (db.supportTickets || []).find((t: any) => t.id === ticketId);
  if (!ticket) {
    return res.status(404).json({ error: "Support ticket not found." });
  }

  const now = new Date().toISOString();
  const isMod = username === "ollymckee101";

  const newMsg = {
    id: "msg_" + Math.random().toString(36).substring(2, 11),
    sender: (isMod ? "mod" : "user") as "user" | "ai" | "mod",
    senderName: isMod ? "ollymckee101 (Moderator)" : (username || "Guest Warrior"),
    text: text.trim(),
    createdAt: now
  };

  ticket.messages.push(newMsg);
  ticket.status = isMod ? "resolved" : "open";

  if (ticket.type === "ai" && !isMod) {
    let aiResponseText = "I am processing your reply. Let me know if you need any other assistance with the Sanctuary features.";
    
    if (ai) {
      try {
        const conversationContext = ticket.messages.map((m: any) => `${m.senderName}: ${m.text}`).join("\n");
        const prompt = `You are the "Sanctuary App Support Bot". Help the user with their support issue.
Here is the conversation so far:
${conversationContext}

Please write a helpful, concise response to the user's latest reply. Keep it technical, clear, and under 120 words. Avoid therapeutic chats; keep it focused on the application functions.`;

        const response = await ai.models.generateContent({
          model: "gemini-2.5-flash",
          contents: [{ role: "user", parts: [{ text: prompt }] }],
          config: {
            temperature: 0.5,
            maxOutputTokens: 250,
          }
        });
        aiResponseText = response.text || aiResponseText;
      } catch (err) {
        console.error("AI Support follow-up error:", err);
      }
    } else {
      if (text.toLowerCase().includes("thank")) {
        aiResponseText = "You're very welcome! Stay strong on your journey. Let me know if you need anything else.";
      }
    }

    ticket.messages.push({
      id: "msg_" + Math.random().toString(36).substring(2, 11),
      sender: "ai" as const,
      senderName: "Sanctuary Support AI",
      text: aiResponseText,
      createdAt: new Date().toISOString()
    });
    ticket.status = "resolved";
  }

  writeDB(db);
  res.status(201).json(ticket);
});

app.post("/api/support/tickets/:ticketId/resolve", (req, res) => {
  const { ticketId } = req.params;
  const db = readDB();
  const ticket = (db.supportTickets || []).find((t: any) => t.id === ticketId);
  if (!ticket) return res.status(404).json({ error: "Support ticket not found." });

  ticket.status = "resolved";
  writeDB(db);
  res.json(ticket);
});

// ---------------- VITE MIDDLEWARE SETUP ----------------

async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
